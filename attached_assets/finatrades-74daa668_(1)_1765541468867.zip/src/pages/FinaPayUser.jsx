import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { 
  Wallet, Send, QrCode, DollarSign, Building2, CreditCard, Bitcoin,
  Loader2, RefreshCw, Copy, CheckCircle, Bell, ArrowDown, ArrowUp,
  Clock, TrendingUp, Lock, Upload, FileText, X
} from 'lucide-react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AreaChart, Area, ResponsiveContainer } from 'recharts';

import DashboardSidebar from '@/components/dashboard/DashboardSidebar';

export default function FinaPayUser() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [activeModal, setActiveModal] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  
  const [goldPrice, setGoldPrice] = useState({ perGram: 85.22, perOz: 2650.00, loading: false });
  
  const [balance, setBalance] = useState({
    available: 150.00,
    locked: 50.00,
  });
  
  const [buyData, setBuyData] = useState({ method: '', amount: '', unit: 'usd' });
  const [sendData, setSendData] = useState({ recipient: '', amount: '', note: '' });
  const [requestData, setRequestData] = useState({ amount: '', description: '', type: 'simple', file: null, fileName: '' });
  const [cashoutData, setCashoutData] = useState({ amount: '', method: '' });

  useEffect(() => {
    const storedUser = localStorage.getItem('finatrades_user');
    if (!storedUser) {
      navigate(createPageUrl("SignIn"));
      return;
    }
    const userData = JSON.parse(storedUser);
    setUser(userData);
    loadProfile(userData.email);
    fetchGoldPrice();
  }, [navigate]);

  const loadProfile = async (email) => {
    try {
      const profiles = await base44.entities.UserProfile.filter({ email });
      if (profiles.length > 0) setProfile(profiles[0]);
    } catch (error) {
      console.error('Failed to load profile:', error);
    }
  };

  const fetchGoldPrice = async () => {
    setGoldPrice(prev => ({ ...prev, loading: true }));
    try {
      const response = await base44.functions.invoke('getGoldPrice');
      const data = response.data;
      if (data.success) {
        setGoldPrice({
          perGram: data.price_per_gram,
          perOz: data.price_per_oz,
          loading: false
        });
      }
    } catch (error) {
      setGoldPrice(prev => ({ ...prev, loading: false }));
    }
  };

  const handleTransaction = async (type) => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsLoading(false);
    setActiveModal(null);
    setBuyData({ method: '', amount: '', unit: 'usd' });
    setSendData({ recipient: '', amount: '', note: '' });
    setRequestData({ amount: '', description: '', type: 'simple', file: null, fileName: '' });
    setCashoutData({ amount: '', method: '' });
  };

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      setRequestData({ ...requestData, file, fileName: file.name });
    }
  };

  const removeFile = () => {
    setRequestData({ ...requestData, file: null, fileName: '' });
  };

  const convertToGrams = (amount, fromUnit) => {
    const val = parseFloat(amount) || 0;
    if (fromUnit === 'usd') return (val / goldPrice.perGram).toFixed(4);
    return val.toFixed(4);
  };

  const convertToUSD = (grams) => {
    return ((parseFloat(grams) || 0) * goldPrice.perGram).toFixed(2);
  };

  const convertToAED = (usd) => {
    return ((parseFloat(usd) || 0) * 3.67).toFixed(2);
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const goldPriceData = [
    { price: 2640 }, { price: 2645 }, { price: 2642 }, { price: 2650 }, 
    { price: 2648 }, { price: 2652 }, { price: 2650 },
  ];

  const transactions = [
    { id: 1, type: 'send', description: 'Sent to john@example.com', amount: -10, date: '2024-12-05 14:30' },
    { id: 2, type: 'receive', description: 'Received from Sarah M.', amount: 25, date: '2024-12-04 09:15' },
    { id: 3, type: 'cashout', description: 'Cash out to Bank Account', amount: -15, date: '2024-12-03 16:45' },
    { id: 4, type: 'receive', description: 'Payment from Mike D.', amount: 30, date: '2024-12-02 11:20' },
  ];

  if (!user) return null;

  const usdValue = convertToUSD(balance.available);
  const aedValue = convertToAED(usdValue);

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FAFBFF] via-[#F4F6FC] to-[#FFFFFF]">
      <div className="flex">
        <DashboardSidebar currentPage="FinaPayUser" user={user} />

        <main className="flex-1 min-h-screen">
          {/* Header */}
          <header className="sticky top-0 z-30 bg-white border-b border-[#8A2BE2]/20 px-6 py-4 shadow-sm">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4 ml-12 lg:ml-0">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] flex items-center justify-center shadow-lg">
                  <Wallet className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-[#0D0D0D]">FinaPay Wallet</h1>
                  <p className="text-[#4A4A4A] text-sm">Digital Gold Payments</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <button 
                  onClick={fetchGoldPrice}
                  className="w-11 h-11 rounded-xl bg-[#F4F6FC] border border-[#8A2BE2]/20 flex items-center justify-center hover:bg-[#8A2BE2]/10 transition-all"
                >
                  <RefreshCw className={`w-5 h-5 text-[#8A2BE2] ${goldPrice.loading ? 'animate-spin' : ''}`} />
                </button>
                <button className="w-11 h-11 rounded-xl bg-[#F4F6FC] border border-[#8A2BE2]/20 flex items-center justify-center hover:bg-[#8A2BE2]/10 transition-all">
                  <Bell className="w-5 h-5 text-[#4A4A4A]" />
                </button>
              </div>
            </div>
          </header>

          <div className="p-6 max-w-6xl mx-auto space-y-6">
            {/* Balance Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white border-2 border-[#8A2BE2]/30 rounded-3xl p-8 shadow-lg"
            >
              <div className="flex items-center justify-between mb-6">
                <div>
                  <p className="text-[#4A4A4A] text-sm uppercase tracking-wider mb-2">Total Balance</p>
                  <div className="flex items-baseline gap-4">
                    <h2 className="text-6xl font-black text-[#0D0D0D]">{balance.available.toFixed(3)}</h2>
                    <span className="text-3xl font-bold bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent">grams</span>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-[#4A4A4A] text-sm mb-2">Current Value</p>
                  <p className="text-3xl font-bold text-[#0D0D0D]">${parseFloat(usdValue).toLocaleString()}</p>
                  <p className="text-[#4A4A4A] text-sm mt-1">د.إ{parseFloat(aedValue).toLocaleString()}</p>
                </div>
              </div>
              
              <div className="grid grid-cols-3 gap-4 pt-6 border-t border-[#8A2BE2]/20">
                <div className="bg-gradient-to-br from-[#F4F6FC] to-white rounded-xl p-4 border border-[#8A2BE2]/10">
                  <p className="text-[#4A4A4A] text-xs mb-2">Gold Price</p>
                  <p className="text-xl font-bold text-[#0D0D0D]">${goldPrice.perGram.toFixed(2)}/g</p>
                </div>
                <div className="bg-gradient-to-br from-amber-50 to-yellow-50 rounded-xl p-4 border border-amber-200">
                  <p className="text-amber-700 text-xs mb-2">BNSL Locked</p>
                  <p className="text-xl font-bold text-amber-900">{balance.locked.toFixed(2)}g</p>
                </div>
                <div className="bg-gradient-to-br from-[#F4F6FC] to-white rounded-xl p-4 border border-[#8A2BE2]/10">
                  <p className="text-[#4A4A4A] text-xs mb-2">Total Worth</p>
                  <p className="text-xl font-bold text-[#0D0D0D]">${convertToUSD(balance.available + balance.locked)}</p>
                </div>
              </div>
            </motion.div>

            {/* Main Actions */}
            <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-6">
              {/* Buy Gold */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="bg-white border-2 border-[#8A2BE2]/30 rounded-2xl p-8 shadow-lg hover:border-[#8A2BE2]/50 transition-all group cursor-pointer"
                onClick={() => setActiveModal('buy')}
              >
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-500 to-yellow-600 flex items-center justify-center mb-6 shadow-xl group-hover:scale-110 transition-transform">
                  <Wallet className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-[#0D0D0D] mb-2">Buy Gold</h3>
                <p className="text-[#4A4A4A] mb-6">Purchase gold to your wallet</p>
                <Button className="w-full bg-gradient-to-r from-amber-500 to-yellow-600 text-white font-bold h-12 rounded-xl">
                  Buy Gold
                </Button>
              </motion.div>

              {/* Send Payment */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="bg-white border-2 border-[#8A2BE2]/30 rounded-2xl p-8 shadow-lg hover:border-[#8A2BE2]/50 transition-all group cursor-pointer"
                onClick={() => setActiveModal('send')}
              >
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center mb-6 shadow-xl group-hover:scale-110 transition-transform">
                  <Send className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-[#0D0D0D] mb-2">Send Payment</h3>
                <p className="text-[#4A4A4A] mb-6">Transfer gold to another user</p>
                <Button className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 text-white font-bold h-12 rounded-xl">
                  Send Gold
                </Button>
              </motion.div>

              {/* Request Payment */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="bg-white border-2 border-[#8A2BE2]/30 rounded-2xl p-8 shadow-lg hover:border-[#8A2BE2]/50 transition-all group cursor-pointer"
                onClick={() => setActiveModal('request')}
              >
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center mb-6 shadow-xl group-hover:scale-110 transition-transform">
                  <QrCode className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-[#0D0D0D] mb-2">Request Payment</h3>
                <p className="text-[#4A4A4A] mb-6">Generate payment request</p>
                <Button className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white font-bold h-12 rounded-xl">
                  Request Gold
                </Button>
              </motion.div>

              {/* Cash Out */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="bg-white border-2 border-[#8A2BE2]/30 rounded-2xl p-8 shadow-lg hover:border-[#8A2BE2]/50 transition-all group cursor-pointer"
                onClick={() => setActiveModal('cashout')}
              >
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center mb-6 shadow-xl group-hover:scale-110 transition-transform">
                  <DollarSign className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-[#0D0D0D] mb-2">Cash Out</h3>
                <p className="text-[#4A4A4A] mb-6">Sell gold and withdraw</p>
                <Button className="w-full bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold h-12 rounded-xl">
                  Sell Gold
                </Button>
              </motion.div>
            </div>

            {/* Bottom Grid */}
            <div className="grid lg:grid-cols-3 gap-6">
              {/* Transactions */}
              <div className="lg:col-span-2 bg-white border-2 border-[#8A2BE2]/20 rounded-2xl p-6 shadow-lg">
                <h3 className="text-xl font-bold text-[#0D0D0D] mb-6">Recent Transactions</h3>
                <div className="space-y-3">
                  {transactions.map((tx) => (
                    <div key={tx.id} className="flex items-center justify-between p-4 bg-[#F4F6FC] rounded-xl hover:bg-gradient-to-r hover:from-[#F4F6FC] hover:to-[#8A2BE2]/5 transition-all">
                      <div className="flex items-center gap-4">
                        <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                          tx.type === 'send' ? 'bg-blue-500/20' :
                          tx.type === 'receive' ? 'bg-purple-500/20' :
                          'bg-green-500/20'
                        }`}>
                          {tx.type === 'send' && <ArrowUp className="w-6 h-6 text-blue-600" />}
                          {tx.type === 'receive' && <ArrowDown className="w-6 h-6 text-purple-600" />}
                          {tx.type === 'cashout' && <DollarSign className="w-6 h-6 text-green-600" />}
                        </div>
                        <div>
                          <p className="text-[#0D0D0D] font-semibold">{tx.description}</p>
                          <p className="text-[#4A4A4A] text-xs">{tx.date}</p>
                        </div>
                      </div>
                      <p className={`text-lg font-bold ${tx.amount > 0 ? 'text-purple-600' : 'text-blue-600'}`}>
                        {tx.amount > 0 ? '+' : ''}{tx.amount}g
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Gold Price */}
              <div className="space-y-6">
                <div className="bg-white border-2 border-[#8A2BE2]/20 rounded-2xl p-6 shadow-lg">
                  <h3 className="text-[#0D0D0D] font-bold mb-3">Gold Spot Price</h3>
                  <p className="text-4xl font-black bg-gradient-to-r from-amber-500 to-yellow-600 bg-clip-text text-transparent mb-1">
                    ${goldPrice.perOz.toFixed(2)}
                  </p>
                  <p className="text-[#4A4A4A] text-xs mb-4">per troy oz</p>
                  <div className="h-24 mb-3">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={goldPriceData}>
                        <defs>
                          <linearGradient id="priceGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#8A2BE2" stopOpacity={0.3}/>
                            <stop offset="95%" stopColor="#FF2FBF" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <Area type="monotone" dataKey="price" stroke="#8A2BE2" strokeWidth={2} fill="url(#priceGrad)" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                  <p className="text-[#4A4A4A] text-xs">Live LBMA spot price</p>
                </div>

                <div className="bg-white border-2 border-[#8A2BE2]/20 rounded-2xl p-6 shadow-lg">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-500 to-yellow-600 flex items-center justify-center shadow-md">
                      <Lock className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-[#0D0D0D] font-bold">BNSL Plans</h3>
                      <p className="text-[#4A4A4A] text-xs">Earn 8-12% p.a.</p>
                    </div>
                  </div>
                  <Button onClick={() => navigate(createPageUrl("FinaEarnUser"))} variant="outline" className="w-full border-[#8A2BE2]/30 text-[#8A2BE2] hover:bg-[#8A2BE2]/10 rounded-xl h-11">
                    View Plans
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>

      {/* Buy Gold Modal */}
      <Dialog open={activeModal === 'buy'} onOpenChange={() => setActiveModal(null)}>
        <DialogContent className="max-w-lg bg-white border-2 border-[#8A2BE2]/30 shadow-2xl">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-[#0D0D0D] flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 flex items-center justify-center shadow-lg">
                <Wallet className="w-6 h-6 text-white" />
              </div>
              Buy Gold
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-6 py-4">
            <div className="p-5 bg-amber-50 rounded-xl border border-amber-200">
              <span className="text-amber-700 text-xs uppercase tracking-wider">Current Gold Price</span>
              <p className="text-3xl font-black text-amber-900">${goldPrice.perGram.toFixed(2)}/g</p>
              <p className="text-amber-600 text-sm mt-1">Live LBMA Spot Price</p>
            </div>

            <div>
              <label className="text-[#0D0D0D] text-sm mb-3 block font-semibold">Payment Method</label>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { value: 'bank', label: 'Bank', icon: Building2 },
                  { value: 'card', label: 'Card', icon: CreditCard },
                  { value: 'crypto', label: 'Crypto', icon: Bitcoin },
                ].map(method => (
                  <button
                    key={method.value}
                    onClick={() => setBuyData({ ...buyData, method: method.value })}
                    className={`p-4 rounded-xl border-2 flex flex-col items-center gap-2 transition-all ${
                      buyData.method === method.value
                        ? 'border-amber-500 bg-amber-50'
                        : 'border-[#8A2BE2]/20 hover:border-amber-500/50'
                    }`}
                  >
                    <method.icon className={`w-6 h-6 ${buyData.method === method.value ? 'text-amber-600' : 'text-[#4A4A4A]'}`} />
                    <span className={`text-xs font-medium ${buyData.method === method.value ? 'text-amber-700' : 'text-[#4A4A4A]'}`}>{method.label}</span>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-[#0D0D0D] text-sm mb-2 block font-semibold">Amount</label>
              <div className="flex gap-2">
                <Input
                  type="number"
                  placeholder="0.00"
                  className="h-14 bg-[#F4F6FC] border-[#8A2BE2]/20 text-[#0D0D0D] text-2xl font-bold text-center"
                  value={buyData.amount}
                  onChange={(e) => setBuyData({ ...buyData, amount: e.target.value })}
                />
                <Select value={buyData.unit} onValueChange={(v) => setBuyData({ ...buyData, unit: v })}>
                  <SelectTrigger className="w-28 h-14 bg-[#F4F6FC] border-[#8A2BE2]/20 text-[#0D0D0D] font-bold">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="usd">USD</SelectItem>
                    <SelectItem value="grams">Grams</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {buyData.amount && (
                <p className="text-amber-600 text-sm mt-2 text-center font-semibold">
                  ≈ {buyData.unit === 'grams' ? `$${convertToUSD(buyData.amount)} USD` : `${convertToGrams(buyData.amount, buyData.unit)} grams`}
                </p>
              )}
            </div>

            {buyData.amount && (
              <div className="p-6 bg-amber-50 rounded-2xl border-2 border-amber-200">
                <p className="text-amber-700 text-sm mb-2 font-semibold">You will receive</p>
                <p className="text-4xl font-black text-amber-900 mb-1">{convertToGrams(buyData.amount, buyData.unit)} g</p>
                <p className="text-amber-600 text-sm">≈ ${buyData.unit === 'grams' ? convertToUSD(buyData.amount) : buyData.amount} USD</p>
              </div>
            )}

            <Button
              onClick={() => handleTransaction('Buy')}
              disabled={isLoading || !buyData.method || !buyData.amount}
              className="w-full h-14 bg-gradient-to-r from-amber-500 to-yellow-600 text-white font-bold hover:opacity-90 rounded-xl text-base shadow-lg"
            >
              {isLoading ? <Loader2 className="w-5 h-5 mr-2 animate-spin" /> : <Wallet className="w-5 h-5 mr-2" />}
              Confirm Purchase
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Send Modal */}
      <Dialog open={activeModal === 'send'} onOpenChange={() => setActiveModal(null)}>
        <DialogContent className="max-w-lg bg-white border-2 border-[#8A2BE2]/30 shadow-2xl">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-[#0D0D0D] flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-500 flex items-center justify-center shadow-lg">
                <Send className="w-6 h-6 text-white" />
              </div>
              Send Gold Payment
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-6 py-4">
            <div className="p-5 bg-blue-50 rounded-xl border border-blue-200">
              <span className="text-blue-700 text-xs uppercase tracking-wider">Available Balance</span>
              <p className="text-3xl font-black text-blue-900">{balance.available.toFixed(3)} g</p>
              <p className="text-blue-600 text-sm mt-1">≈ ${usdValue} USD</p>
            </div>

            <div>
              <label className="text-[#0D0D0D] text-sm mb-2 block font-semibold">Recipient Email</label>
              <Input
                placeholder="recipient@example.com"
                className="h-12 bg-[#F4F6FC] border-[#8A2BE2]/20 text-[#0D0D0D]"
                value={sendData.recipient}
                onChange={(e) => setSendData({ ...sendData, recipient: e.target.value })}
              />
            </div>

            <div>
              <label className="text-[#0D0D0D] text-sm mb-2 block font-semibold">Amount (grams)</label>
              <Input
                type="number"
                placeholder="0.00"
                max={balance.available}
                className="h-14 bg-[#F4F6FC] border-[#8A2BE2]/20 text-[#0D0D0D] text-2xl font-bold text-center"
                value={sendData.amount}
                onChange={(e) => setSendData({ ...sendData, amount: e.target.value })}
              />
              {sendData.amount && (
                <p className="text-blue-600 text-sm mt-2 text-center font-semibold">
                  ≈ ${convertToUSD(sendData.amount)} USD
                </p>
              )}
            </div>

            <div>
              <label className="text-[#0D0D0D] text-sm mb-2 block font-semibold">Note (Optional)</label>
              <textarea
                placeholder="Payment for..."
                className="w-full h-20 px-4 py-3 bg-[#F4F6FC] border border-[#8A2BE2]/20 text-[#0D0D0D] rounded-xl focus:border-blue-500 focus:outline-none resize-none"
                value={sendData.note}
                onChange={(e) => setSendData({ ...sendData, note: e.target.value })}
              />
            </div>

            <Button
              onClick={() => handleTransaction('Send')}
              disabled={isLoading || !sendData.recipient || !sendData.amount || parseFloat(sendData.amount) > balance.available}
              className="w-full h-14 bg-gradient-to-r from-blue-500 to-cyan-500 text-white font-bold hover:opacity-90 rounded-xl text-base shadow-lg"
            >
              {isLoading ? <Loader2 className="w-5 h-5 mr-2 animate-spin" /> : <Send className="w-5 h-5 mr-2" />}
              Send Gold Payment
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Request Modal */}
      <Dialog open={activeModal === 'request'} onOpenChange={() => setActiveModal(null)}>
        <DialogContent className="max-w-lg bg-white border-2 border-[#8A2BE2]/30 shadow-2xl">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-[#0D0D0D] flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center shadow-lg">
                <QrCode className="w-6 h-6 text-white" />
              </div>
              Request Gold Payment
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-6 py-4">
            {/* Tabs */}
            <div className="flex gap-2 p-1 bg-[#F4F6FC] rounded-xl">
              <button
                onClick={() => setRequestData({ ...requestData, type: 'simple' })}
                className={`flex-1 py-3 px-4 rounded-lg font-semibold text-sm transition-all ${
                  requestData.type === 'simple'
                    ? 'bg-white text-[#8A2BE2] shadow-sm'
                    : 'text-[#4A4A4A] hover:text-[#0D0D0D]'
                }`}
              >
                Simple Request
              </button>
              <button
                onClick={() => setRequestData({ ...requestData, type: 'invoice' })}
                className={`flex-1 py-3 px-4 rounded-lg font-semibold text-sm transition-all ${
                  requestData.type === 'invoice'
                    ? 'bg-white text-[#8A2BE2] shadow-sm'
                    : 'text-[#4A4A4A] hover:text-[#0D0D0D]'
                }`}
              >
                <FileText className="w-4 h-4 inline mr-1" />
                With Invoice
              </button>
            </div>

            <div>
              <label className="text-[#0D0D0D] text-sm mb-2 block font-semibold">Amount (grams)</label>
              <Input
                type="number"
                placeholder="0.00"
                className="h-14 bg-[#F4F6FC] border-[#8A2BE2]/20 text-[#0D0D0D] text-2xl font-bold text-center"
                value={requestData.amount}
                onChange={(e) => setRequestData({ ...requestData, amount: e.target.value })}
              />
              {requestData.amount && (
                <p className="text-purple-600 text-sm mt-2 text-center font-semibold">
                  ≈ ${convertToUSD(requestData.amount)} USD
                </p>
              )}
            </div>

            <div>
              <label className="text-[#0D0D0D] text-sm mb-2 block font-semibold">Description</label>
              <Input
                placeholder="What is this payment for?"
                className="h-12 bg-[#F4F6FC] border-[#8A2BE2]/20 text-[#0D0D0D]"
                value={requestData.description}
                onChange={(e) => setRequestData({ ...requestData, description: e.target.value })}
              />
            </div>

            {/* Invoice Upload (only shown when invoice tab is selected) */}
            {requestData.type === 'invoice' && (
              <div>
                <label className="text-[#0D0D0D] text-sm mb-2 block font-semibold">Upload Invoice/Document</label>
                {!requestData.file ? (
                  <label className="flex flex-col items-center justify-center h-32 bg-[#F4F6FC] border-2 border-dashed border-[#8A2BE2]/30 rounded-xl cursor-pointer hover:border-[#8A2BE2]/50 hover:bg-purple-50/50 transition-all">
                    <Upload className="w-8 h-8 text-[#8A2BE2] mb-2" />
                    <span className="text-[#4A4A4A] text-sm font-medium">Click to upload file</span>
                    <span className="text-[#4A4A4A] text-xs mt-1">PDF, PNG, JPG (max 10MB)</span>
                    <input type="file" className="hidden" accept=".pdf,.png,.jpg,.jpeg" onChange={handleFileUpload} />
                  </label>
                ) : (
                  <div className="flex items-center gap-3 p-4 bg-purple-50 border-2 border-purple-200 rounded-xl">
                    <div className="w-12 h-12 rounded-lg bg-purple-100 flex items-center justify-center">
                      <FileText className="w-6 h-6 text-purple-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-[#0D0D0D] font-semibold truncate">{requestData.fileName}</p>
                      <p className="text-[#4A4A4A] text-xs">Invoice attached</p>
                    </div>
                    <button
                      onClick={removeFile}
                      className="w-8 h-8 rounded-lg bg-purple-100 text-purple-600 hover:bg-purple-200 flex items-center justify-center transition-colors"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>
            )}

            {requestData.amount && (
              <div className="p-6 bg-purple-50 rounded-2xl border-2 border-purple-200">
                <p className="text-purple-700 text-sm mb-3 font-semibold">Payment Link</p>
                <div className="flex items-center gap-2 p-3 bg-white rounded-xl border border-purple-200">
                  <p className="text-[#4A4A4A] text-sm truncate flex-1 font-mono">
                    finatrades.com/pay/{user?.id?.slice(0, 8)}
                  </p>
                  <button 
                    onClick={() => copyToClipboard(`finatrades.com/pay/${user?.id?.slice(0, 8)}?amt=${requestData.amount}`)}
                    className="p-2 rounded-lg bg-purple-100 text-purple-600 hover:bg-purple-200 transition-colors"
                  >
                    {copied ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
                {requestData.type === 'invoice' && requestData.file && (
                  <p className="text-purple-600 text-xs mt-2">📎 Invoice will be attached to request</p>
                )}
              </div>
            )}

            <Button
              onClick={() => handleTransaction('Request')}
              disabled={isLoading || !requestData.amount || (requestData.type === 'invoice' && !requestData.file)}
              className="w-full h-14 bg-gradient-to-r from-purple-500 to-pink-500 text-white font-bold hover:opacity-90 rounded-xl text-base shadow-lg"
            >
              {isLoading ? <Loader2 className="w-5 h-5 mr-2 animate-spin" /> : <QrCode className="w-5 h-5 mr-2" />}
              Generate Request Link
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Cash Out Modal */}
      <Dialog open={activeModal === 'cashout'} onOpenChange={() => setActiveModal(null)}>
        <DialogContent className="max-w-lg bg-white border-2 border-[#8A2BE2]/30 shadow-2xl">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-[#0D0D0D] flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-green-500 to-emerald-600 flex items-center justify-center shadow-lg">
                <DollarSign className="w-6 h-6 text-white" />
              </div>
              Cash Out (Sell Gold)
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-6 py-4">
            <div className="p-5 bg-green-50 rounded-xl border border-green-200">
              <span className="text-green-700 text-xs uppercase tracking-wider">Available Balance</span>
              <p className="text-3xl font-black text-green-900">{balance.available.toFixed(3)} g</p>
              <p className="text-green-600 text-sm mt-1">≈ ${convertToUSD(balance.available)} USD</p>
            </div>

            <div>
              <label className="text-[#0D0D0D] text-sm mb-2 block font-semibold">Amount to Sell (grams)</label>
              <Input
                type="number"
                placeholder="0.00"
                max={balance.available}
                className="h-14 bg-[#F4F6FC] border-[#8A2BE2]/20 text-[#0D0D0D] text-2xl font-bold text-center"
                value={cashoutData.amount}
                onChange={(e) => setCashoutData({ ...cashoutData, amount: e.target.value })}
              />
              {cashoutData.amount && (
                <p className="text-green-600 text-sm mt-2 text-center font-semibold">
                  ≈ ${convertToUSD(cashoutData.amount)} USD
                </p>
              )}
            </div>

            <div>
              <label className="text-[#0D0D0D] text-sm mb-3 block font-semibold">Withdrawal Method</label>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { value: 'bank', label: 'Bank', icon: Building2 },
                  { value: 'card', label: 'Card', icon: CreditCard },
                  { value: 'crypto', label: 'Crypto', icon: Bitcoin },
                ].map(method => (
                  <button
                    key={method.value}
                    onClick={() => setCashoutData({ ...cashoutData, method: method.value })}
                    className={`p-4 rounded-xl border-2 flex flex-col items-center gap-2 transition-all ${
                      cashoutData.method === method.value
                        ? 'border-green-500 bg-green-50'
                        : 'border-[#8A2BE2]/20 hover:border-green-500/50'
                    }`}
                  >
                    <method.icon className={`w-6 h-6 ${cashoutData.method === method.value ? 'text-green-600' : 'text-[#4A4A4A]'}`} />
                    <span className={`text-xs font-medium ${cashoutData.method === method.value ? 'text-green-700' : 'text-[#4A4A4A]'}`}>{method.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {cashoutData.amount && (
              <div className="p-6 bg-green-50 rounded-2xl border-2 border-green-200">
                <p className="text-green-700 text-sm mb-2 font-semibold">You will receive</p>
                <p className="text-4xl font-black text-green-900 mb-1">${convertToUSD(cashoutData.amount)}</p>
                <p className="text-green-600 text-sm">≈ د.إ{convertToAED(convertToUSD(cashoutData.amount))} AED</p>
              </div>
            )}

            <Button
              onClick={() => handleTransaction('Cashout')}
              disabled={isLoading || !cashoutData.method || !cashoutData.amount || parseFloat(cashoutData.amount) > balance.available}
              className="w-full h-14 bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold hover:opacity-90 rounded-xl text-base shadow-lg"
            >
              {isLoading ? <Loader2 className="w-5 h-5 mr-2 animate-spin" /> : <DollarSign className="w-5 h-5 mr-2" />}
              Confirm Cash Out
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}