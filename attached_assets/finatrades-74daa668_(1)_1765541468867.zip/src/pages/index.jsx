import Layout from "./Layout.jsx";

import Home from "./Home";

import FinaBridge from "./FinaBridge";

import FinaVault from "./FinaVault";

import BNSL from "./BNSL";

import FinaPay from "./FinaPay";

import TermsAndConditions from "./TermsAndConditions";

import Disclaimer from "./Disclaimer";

import PrivacyPolicy from "./PrivacyPolicy";

import RegulatoryInformation from "./RegulatoryInformation";

import Register from "./Register";

import EmailVerified from "./EmailVerified";

import KYC from "./KYC";

import KYCPending from "./KYCPending";

import UserDashboard from "./UserDashboard";

import FinaVaultUser from "./FinaVaultUser";

import FinaPayUser from "./FinaPayUser";

import FinaEarnUser from "./FinaEarnUser";

import FinaFinanceUser from "./FinaFinanceUser";

import SettingsUser from "./SettingsUser";

import SelfieKYC from "./SelfieKYC";

import CorporateKYC from "./CorporateKYC";

import YieldsUser from "./YieldsUser";

import DebitCardUser from "./DebitCardUser";

import AdminDashboard from "./AdminDashboard";

import AdminKYC from "./AdminKYC";

import AdminVault from "./AdminVault";

import AdminBNSL from "./AdminBNSL";

import AdminCards from "./AdminCards";

import AdminAuditLogs from "./AdminAuditLogs";

import AdminFinaPay from "./AdminFinaPay";

import AdminFinaBridge from "./AdminFinaBridge";

import AdminYields from "./AdminYields";

import AdminSettings from "./AdminSettings";

import SignIn from "./SignIn";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Home: Home,
    
    FinaBridge: FinaBridge,
    
    FinaVault: FinaVault,
    
    BNSL: BNSL,
    
    FinaPay: FinaPay,
    
    TermsAndConditions: TermsAndConditions,
    
    Disclaimer: Disclaimer,
    
    PrivacyPolicy: PrivacyPolicy,
    
    RegulatoryInformation: RegulatoryInformation,
    
    Register: Register,
    
    EmailVerified: EmailVerified,
    
    KYC: KYC,
    
    KYCPending: KYCPending,
    
    UserDashboard: UserDashboard,
    
    FinaVaultUser: FinaVaultUser,
    
    FinaPayUser: FinaPayUser,
    
    FinaEarnUser: FinaEarnUser,
    
    FinaFinanceUser: FinaFinanceUser,
    
    SettingsUser: SettingsUser,
    
    SelfieKYC: SelfieKYC,
    
    CorporateKYC: CorporateKYC,
    
    YieldsUser: YieldsUser,
    
    DebitCardUser: DebitCardUser,
    
    AdminDashboard: AdminDashboard,
    
    AdminKYC: AdminKYC,
    
    AdminVault: AdminVault,
    
    AdminBNSL: AdminBNSL,
    
    AdminCards: AdminCards,
    
    AdminAuditLogs: AdminAuditLogs,
    
    AdminFinaPay: AdminFinaPay,
    
    AdminFinaBridge: AdminFinaBridge,
    
    AdminYields: AdminYields,
    
    AdminSettings: AdminSettings,
    
    SignIn: SignIn,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Home />} />
                
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/FinaBridge" element={<FinaBridge />} />
                
                <Route path="/FinaVault" element={<FinaVault />} />
                
                <Route path="/BNSL" element={<BNSL />} />
                
                <Route path="/FinaPay" element={<FinaPay />} />
                
                <Route path="/TermsAndConditions" element={<TermsAndConditions />} />
                
                <Route path="/Disclaimer" element={<Disclaimer />} />
                
                <Route path="/PrivacyPolicy" element={<PrivacyPolicy />} />
                
                <Route path="/RegulatoryInformation" element={<RegulatoryInformation />} />
                
                <Route path="/Register" element={<Register />} />
                
                <Route path="/EmailVerified" element={<EmailVerified />} />
                
                <Route path="/KYC" element={<KYC />} />
                
                <Route path="/KYCPending" element={<KYCPending />} />
                
                <Route path="/UserDashboard" element={<UserDashboard />} />
                
                <Route path="/FinaVaultUser" element={<FinaVaultUser />} />
                
                <Route path="/FinaPayUser" element={<FinaPayUser />} />
                
                <Route path="/FinaEarnUser" element={<FinaEarnUser />} />
                
                <Route path="/FinaFinanceUser" element={<FinaFinanceUser />} />
                
                <Route path="/SettingsUser" element={<SettingsUser />} />
                
                <Route path="/SelfieKYC" element={<SelfieKYC />} />
                
                <Route path="/CorporateKYC" element={<CorporateKYC />} />
                
                <Route path="/YieldsUser" element={<YieldsUser />} />
                
                <Route path="/DebitCardUser" element={<DebitCardUser />} />
                
                <Route path="/AdminDashboard" element={<AdminDashboard />} />
                
                <Route path="/AdminKYC" element={<AdminKYC />} />
                
                <Route path="/AdminVault" element={<AdminVault />} />
                
                <Route path="/AdminBNSL" element={<AdminBNSL />} />
                
                <Route path="/AdminCards" element={<AdminCards />} />
                
                <Route path="/AdminAuditLogs" element={<AdminAuditLogs />} />
                
                <Route path="/AdminFinaPay" element={<AdminFinaPay />} />
                
                <Route path="/AdminFinaBridge" element={<AdminFinaBridge />} />
                
                <Route path="/AdminYields" element={<AdminYields />} />
                
                <Route path="/AdminSettings" element={<AdminSettings />} />
                
                <Route path="/SignIn" element={<SignIn />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}