import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Building2, Users, FileText, Landmark, Check, Lock, ChevronRight,
  ArrowLeft, Loader2
} from 'lucide-react';
import { Button } from "@/components/ui/button";

import CorporateDetailsStep from '@/components/corporate-kyc/CorporateDetailsStep';
import BeneficialOwnershipStep from '@/components/corporate-kyc/BeneficialOwnershipStep';
import DocumentationStep from '@/components/corporate-kyc/DocumentationStep';
import BankingDetailsStep from '@/components/corporate-kyc/BankingDetailsStep';
import KYCPendingScreen from '@/components/corporate-kyc/KYCPendingScreen';

const STEPS = [
  { id: 1, title: 'Corporate Details', icon: Building2, description: 'Company information' },
  { id: 2, title: 'Beneficial Ownership', icon: Users, description: 'UBO & Shareholders' },
  { id: 3, title: 'Documentation', icon: FileText, description: 'Required documents' },
  { id: 4, title: 'Banking Details', icon: Landmark, description: 'Settlement accounts' },
];

export default function CorporateKYC() {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [completedSteps, setCompletedSteps] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [user, setUser] = useState(null);

  const [formData, setFormData] = useState({
    // Step 1: Corporate Details
    companyName: '',
    registrationNumber: '',
    incorporationDate: '',
    countryOfIncorporation: '',
    formOfCompany: '',
    natureOfBusiness: '',
    numberOfEmployees: '',
    headOfficeAddress: '',
    headOfficeCity: '',
    headOfficeCountry: '',
    telephone: '',
    website: '',
    email: '',
    tradingContactName: '',
    tradingContactMobile: '',
    tradingContactEmail: '',
    financeContactName: '',
    financeContactMobile: '',
    financeContactEmail: '',
    
    // Step 2: Beneficial Ownership
    shareholders: [{ name: '', passportNumber: '', email: '' }],
    hasCorpShareholder: false,
    corpShareholderDetails: { legalName: '', regNumber: '', country: '', uboDoc: null },
    hasPEP: false,
    pepDetails: '',
    
    // Step 3: Documents
    documents: {
      incorporationCert: null,
      tradeLicense: null,
      memorandum: null,
      shareholderList: null,
      uboPassports: [],
      bankReference: null,
      authorizedSignatories: null,
      proofOfAuthorization: null,
    },
    
    // Step 4: Banking
    bankName: '',
    bankBranch: '',
    bankCity: '',
    bankCountry: '',
    iban: '',
    swiftCode: '',
    beneficiaryName: '',
    currency: 'USD',
    confirmAccuracy: false,
    confirmAuthorized: false,
    confirmCompliance: false,
  });

  useEffect(() => {
    const storedUser = localStorage.getItem('finatrades_user');
    if (!storedUser) {
      navigate(createPageUrl("SignIn"));
      return;
    }
    setUser(JSON.parse(storedUser));
  }, [navigate]);

  const updateFormData = (updates) => {
    setFormData(prev => ({ ...prev, ...updates }));
  };

  const handleStepComplete = (step) => {
    if (!completedSteps.includes(step)) {
      setCompletedSteps([...completedSteps, step]);
    }
    if (step < 4) {
      setCurrentStep(step + 1);
    }
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      setIsSubmitted(true);
    } catch (error) {
      console.error('Submission failed:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const canAccessStep = (step) => {
    if (step === 1) return true;
    return completedSteps.includes(step - 1);
  };

  if (isSubmitted) {
    return <KYCPendingScreen />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#000000] via-[#0d0515] to-[#1a0a2e]">
      {/* Header */}
      <header className="border-b border-[#D1A954]/20 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link to={createPageUrl("UserDashboard")} className="text-white/60 hover:text-white">
              <ArrowLeft className="w-5 h-5" />
            </Link>
            <div>
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69293bd8e52dce0074daa668/ce96e4d2b_FINANEWLOGO-GOLDANDWHITENB.png" 
                alt="Finatrades" 
                className="h-8"
                style={{ filter: 'brightness(0) invert(1)' }}
              />
              <p className="text-[#D1A954]/60 text-[10px] tracking-[0.2em] mt-0.5">BEYOND BANKING</p>
            </div>
          </div>
          <div className="flex items-center gap-2 text-white/40 text-xs">
            <span>Partner Network:</span>
            <span className="text-white/60">WinGold DMCC</span>
            <span className="text-white/30">•</span>
            <span className="text-white/60">WinCommodities DMCC</span>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid lg:grid-cols-[320px_1fr] gap-8">
          {/* Left Sidebar - Progress */}
          <div className="lg:sticky lg:top-8 lg:self-start">
            <div className="bg-white/[0.02] backdrop-blur-xl border border-[#D1A954]/20 rounded-2xl p-6">
              <h2 className="text-white font-semibold mb-2">Corporate KYC</h2>
              <p className="text-white/40 text-sm mb-8">Complete all steps to verify your organization</p>
              
              <div className="relative">
                {/* Progress Line */}
                <div className="absolute left-5 top-5 bottom-5 w-px bg-[#D1A954]/20" />
                
                {/* Steps */}
                <div className="space-y-6 relative">
                  {STEPS.map((step, index) => {
                    const isCompleted = completedSteps.includes(step.id);
                    const isCurrent = currentStep === step.id;
                    const isLocked = !canAccessStep(step.id);
                    
                    return (
                      <button
                        key={step.id}
                        onClick={() => canAccessStep(step.id) && setCurrentStep(step.id)}
                        disabled={isLocked}
                        className={`flex items-start gap-4 w-full text-left transition-all ${
                          isLocked ? 'opacity-40 cursor-not-allowed' : 'cursor-pointer'
                        }`}
                      >
                        <div className={`relative z-10 w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                          isCompleted 
                            ? 'bg-gradient-to-r from-[#D1A954] to-[#B8963E] shadow-[0_0_20px_rgba(209,169,84,0.3)]' 
                            : isCurrent
                              ? 'bg-[#D1A954]/20 border-2 border-[#D1A954]'
                              : 'bg-white/5 border border-white/20'
                        }`}>
                          {isCompleted ? (
                            <Check className="w-5 h-5 text-black" />
                          ) : isLocked ? (
                            <Lock className="w-4 h-4 text-white/40" />
                          ) : (
                            <step.icon className={`w-5 h-5 ${isCurrent ? 'text-[#D1A954]' : 'text-white/40'}`} />
                          )}
                        </div>
                        <div className="flex-1 pt-1">
                          <p className={`font-medium ${
                            isCompleted || isCurrent ? 'text-white' : 'text-white/40'
                          }`}>
                            {step.title}
                          </p>
                          <p className="text-white/30 text-sm">{step.description}</p>
                        </div>
                        {isCurrent && !isLocked && (
                          <ChevronRight className="w-5 h-5 text-[#D1A954] mt-2" />
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Compliance Notice */}
              <div className="mt-8 pt-6 border-t border-white/10">
                <p className="text-white/30 text-xs leading-relaxed">
                  All information is handled confidentially in accordance with Swiss data protection regulations and international AML/KYC compliance standards.
                </p>
              </div>
            </div>
          </div>

          {/* Right Content - Form Steps */}
          <div className="min-h-[600px]">
            <AnimatePresence mode="wait">
              {currentStep === 1 && (
                <motion.div
                  key="step1"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                >
                  <CorporateDetailsStep 
                    formData={formData}
                    updateFormData={updateFormData}
                    onComplete={() => handleStepComplete(1)}
                  />
                </motion.div>
              )}
              
              {currentStep === 2 && (
                <motion.div
                  key="step2"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                >
                  <BeneficialOwnershipStep 
                    formData={formData}
                    updateFormData={updateFormData}
                    onComplete={() => handleStepComplete(2)}
                    onBack={() => setCurrentStep(1)}
                  />
                </motion.div>
              )}
              
              {currentStep === 3 && (
                <motion.div
                  key="step3"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                >
                  <DocumentationStep 
                    formData={formData}
                    updateFormData={updateFormData}
                    onComplete={() => handleStepComplete(3)}
                    onBack={() => setCurrentStep(2)}
                  />
                </motion.div>
              )}
              
              {currentStep === 4 && (
                <motion.div
                  key="step4"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                >
                  <BankingDetailsStep 
                    formData={formData}
                    updateFormData={updateFormData}
                    onSubmit={handleSubmit}
                    onBack={() => setCurrentStep(3)}
                    isSubmitting={isSubmitting}
                  />
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
}