import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { CreditCard, Shield, Save, Lock, Unlock } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

import AdminSidebar from '@/components/admin/AdminSidebar';
import AdminTopBar from '@/components/admin/AdminTopBar';
import AdminTable from '@/components/admin/AdminTable';
import AdminStatusBadge from '@/components/admin/AdminStatusBadge';
import AdminDrawer from '@/components/admin/AdminDrawer';

const sampleCards = [
  { id: 'CRD-1123', pan: '**** **** **** 4521', user: 'Ahmed Al-Rashid', status: 'active', type: 'Physical', currency: 'USD', balance: 2450.00, lastTx: '2024-12-04 14:32' },
  { id: 'CRD-1124', pan: '**** **** **** 8892', user: 'Sarah Thompson', status: 'active', type: 'Virtual', currency: 'EUR', balance: 1200.00, lastTx: '2024-12-04 11:15' },
  { id: 'CRD-1125', pan: '**** **** **** 2241', user: 'Mohammed Hassan', status: 'frozen', type: 'Physical', currency: 'AED', balance: 8500.00, lastTx: '2024-12-03 09:45' },
];

export default function AdminCards() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [role, setRole] = useState('Operations');
  const [selectedCard, setSelectedCard] = useState(null);
  const [drawerOpen, setDrawerOpen] = useState(false);

  useEffect(() => {
    const storedUser = localStorage.getItem('finatrades_user');
    if (!storedUser) {
      navigate(createPageUrl("SignIn"));
      return;
    }
    const userData = JSON.parse(storedUser);
    if (!userData.is_admin) {
      navigate(createPageUrl("UserDashboard"));
      return;
    }
    setUser(userData);
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('finatrades_user');
    navigate(createPageUrl("Home"));
  };

  const handleManage = (card) => {
    setSelectedCard(card);
    setDrawerOpen(true);
  };

  const cardColumns = [
    { header: 'Card ID', accessor: 'id' },
    { header: 'PAN', accessor: 'pan', render: (val) => <span className="font-mono text-[#4A4A4A]">{val}</span> },
    { header: 'User', accessor: 'user' },
    { header: 'Status', accessor: 'status', render: (val) => <AdminStatusBadge status={val} /> },
    { header: 'Type', accessor: 'type', render: (val) => <span className={`px-2 py-1 rounded text-xs ${val === 'Physical' ? 'bg-blue-500/20 text-blue-400' : 'bg-purple-500/20 text-purple-400'}`}>{val}</span> },
    { header: 'Currency', accessor: 'currency' },
    { header: 'Balance', accessor: 'balance', render: (val) => `$${val.toFixed(2)}` },
    { header: 'Last TX', accessor: 'lastTx' },
  ];

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FAFBFF] via-[#F4F6FC] to-[#FFFFFF]">
      <AdminSidebar currentSection="cards" onLogout={handleLogout} />
      
      <div className="ml-64">
        <AdminTopBar user={user} role={role} onRoleChange={setRole} />
        
        <main className="p-6 space-y-6">
          <div>
            <h1 className="text-2xl font-bold text-[#0D0D0D] flex items-center gap-3">
              <CreditCard className="w-7 h-7 text-[#8A2BE2]" />
              Debit Cards Management
            </h1>
          </div>

          <AdminTable columns={cardColumns} data={sampleCards} onRowAction={handleManage} actionLabel="Manage" />
        </main>
      </div>

      <AdminDrawer
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        title={selectedCard?.id || 'Card Management'}
        subtitle={selectedCard?.user}
        footer={
          <div className="flex items-center justify-end gap-3">
            <Button className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white font-bold">
              <Save className="w-4 h-4 mr-2" />
              Save Changes
            </Button>
          </div>
        }
      >
        {selectedCard && (
          <div className="space-y-6">
            <div className="bg-gradient-to-r from-[#8A2BE2]/20 to-[#FF2FBF]/10 border border-[#8A2BE2]/30 rounded-2xl p-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <p className="text-[#0D0D0D] font-mono text-lg">{selectedCard.pan}</p>
                  <p className="text-[#4A4A4A] text-sm">{selectedCard.user}</p>
                </div>
                <AdminStatusBadge status={selectedCard.status} />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-[#4A4A4A] text-xs">Card Wallet Balance</p>
                  <p className="text-[#0D0D0D] text-2xl font-bold">${selectedCard.balance.toFixed(2)}</p>
                </div>
                <div className="text-right">
                  <p className="text-[#4A4A4A] text-xs">Type</p>
                  <p className="text-[#0D0D0D]">{selectedCard.type}</p>
                </div>
              </div>
            </div>

            <div className="bg-[#F4F6FC] rounded-xl border border-[#8A2BE2]/10 p-4 space-y-4">
              <h4 className="text-[#0D0D0D] font-medium">Card Status</h4>
              <div className="grid grid-cols-3 gap-3">
                <Button variant={selectedCard.status === 'active' ? 'default' : 'outline'} className={selectedCard.status === 'active' ? 'bg-green-500/20 text-green-600 border-green-500/30' : 'border-[#8A2BE2]/10 text-[#4A4A4A]'}>
                  <Unlock className="w-4 h-4 mr-2" />
                  Active
                </Button>
                <Button variant={selectedCard.status === 'frozen' ? 'default' : 'outline'} className={selectedCard.status === 'frozen' ? 'bg-blue-500/20 text-blue-600 border-blue-500/30' : 'border-[#8A2BE2]/10 text-[#4A4A4A]'}>
                  <Lock className="w-4 h-4 mr-2" />
                  Frozen
                </Button>
                <Button variant={selectedCard.status === 'blocked' ? 'default' : 'outline'} className={selectedCard.status === 'blocked' ? 'bg-red-500/20 text-red-600 border-red-500/30' : 'border-[#8A2BE2]/10 text-[#4A4A4A]'}>
                  <Shield className="w-4 h-4 mr-2" />
                  Blocked
                </Button>
              </div>
            </div>
          </div>
        )}
      </AdminDrawer>
    </div>
  );
}