import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { 
  ArrowLeft, FileText, Shield, Users, AlertTriangle, 
  Globe, Scale, XCircle, Building, Briefcase, Lock,
  CheckCircle, Info, Mail
} from 'lucide-react';

export default function TermsAndConditions() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#FAFBFF] to-white">
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-r from-[#0D001E] via-[#2A0055] to-[#4B0082] overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(138,43,226,0.2)_0%,_transparent_70%)]" />
        
        <div className="relative z-10 max-w-4xl mx-auto px-6">
          <Link 
            to={createPageUrl("Home")}
            className="inline-flex items-center gap-2 text-white/70 hover:text-white mb-8 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </Link>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center">
                <FileText className="w-6 h-6 text-white" />
              </div>
              <span className="text-white/60 text-sm">Legal Document</span>
            </div>
            
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Terms and Conditions
            </h1>
            <p className="text-xl text-white/80 mb-2">FINATRADES.COM</p>
            <p className="text-white/60">Last Updated: December 4, 2025</p>
          </motion.div>
        </div>
      </section>

      {/* Content */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-6">
          {/* Introduction */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="prose prose-lg max-w-none mb-12"
          >
            <p className="text-[#4A4A4A] leading-relaxed">
              These Terms and Conditions ("Terms") constitute a legally binding agreement between you ("User," "Customer," "you") and <strong>Finatrades Finance SA</strong>, a company incorporated under the laws of Switzerland, with its registered office at Rue Robert Céard 6, 1204 Geneva, Switzerland, and registered in the Swiss Commercial Register under <strong>CHE-422.960.092</strong> ("Finatrades," "we," "us," "our").
            </p>
            <p className="text-[#4A4A4A] leading-relaxed">
              These Terms govern your access and use of the services accessible via <a href="https://finatrades.com" className="text-[#8A2BE2] hover:underline">https://finatrades.com</a> (the "Site") and the associated Platform. The Platform provides a registry and payment system backed by physical gold, allowing for the certification, transfer, and use of gold holdings as a payment method for trade transactions through third-party infrastructure.
            </p>
          </motion.div>

          {/* Important Notice */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-gradient-to-r from-[#8A2BE2]/10 to-[#FF2FBF]/10 border border-[#8A2BE2]/30 rounded-2xl p-6 mb-12"
          >
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#8A2BE2] to-[#FF2FBF] flex items-center justify-center flex-shrink-0">
                <AlertTriangle className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-[#0D0D0D] mb-2">IMPORTANT NOTICE</h3>
                <p className="text-[#4A4A4A] text-sm leading-relaxed">
                  BY ACCESSING, BROWSING, OR USING THE PLATFORM, YOU EXPLICITLY ACKNOWLEDGE THAT YOU HAVE READ, UNDERSTOOD, AND IRREVOCABLY AGREE TO BE LEGALLY BOUND BY THESE TERMS IN THEIR ENTIRETY. YOU ALSO AGREE TO OUR PRIVACY POLICY, DISCLAIMER, WARRANTY & SECURITY STATEMENT, AND RISK DISCLOSURE STATEMENT (COLLECTIVELY, THE "POLICIES"). IF YOU ARE ENTERING INTO THESE TERMS ON BEHALF OF A LEGAL ENTITY, YOU REPRESENT THAT YOU HAVE THE AUTHORITY TO BIND SUCH ENTITY. IF YOU DO NOT AGREE TO ALL OF THESE TERMS, YOU MUST IMMEDIATELY CEASE ALL USE OF THE PLATFORM AND EXIT THE SITE.
                </p>
              </div>
            </div>
          </motion.div>

          {/* Section 1: Definitions */}
          <Section
            number="1"
            title="DEFINITIONS & INTERPRETATION"
            icon={FileText}
            delay={0.4}
          >
            <DefinitionList definitions={[
              { term: '"Customer" or "User"', definition: 'means any natural or legal person who accesses or uses the Platform.' },
              { term: '"Gold Certificate"', definition: 'means a digital instrument issued and administered on the Platform that certifies the Customer\'s beneficial ownership of a specific quantity and purity of physical gold that has been deposited, assayed, and stored with a licensed third-party vault operator under a vaulting agreement between the vault operator and the relevant Commercial Partner.' },
              { term: '"Underlying Gold"', definition: 'means the specific physical gold bullion (bars, coins) that corresponds to a Gold Certificate. Legal title to the Underlying Gold is held by the Customer, subject to the terms of the vaulting agreement between the Commercial Partner and the third-party vault operator.' },
              { term: '"Platform"', definition: 'means the Finatrades digital infrastructure, including websites, apps, and APIs, that acts as a registry and transaction system for Gold Certificates.' },
              { term: '"Commercial Partner"', definition: 'refers to Wingold & Metals DMCC, a UAE-licensed precious metals trading company, which utilizes the Platform for specific commercial activities, as detailed in Section 2.3. A Commercial Partner acts as an independent principal in its transactions with Users and is responsible for all arrangements regarding the physical gold, including vaulting agreements.' },
              { term: '"Vaulting Agreement"', definition: 'means the separate contractual agreement between the Commercial Partner (Wingold & Metals DMCC) and a licensed third-party vault operator governing the storage, insurance, and safekeeping of physical gold. This agreement is independent of Finatrades and these Terms.' },
              { term: '"Affiliate"', definition: 'means, with respect to Finatrades, any entity that directly or indirectly controls, is controlled by, or is under common control with Finatrades. Affiliates may be engaged to perform specific technical, operational, or administrative functions related to the Platform.' },
              { term: '"Swiss Law"', definition: 'means all applicable statutory, regulatory, and supervisory frameworks of Switzerland.' }
            ]} />
          </Section>

          {/* Section 2: Nature of Services */}
          <Section
            number="2"
            title="NATURE OF SERVICES, ROLES & RESPONSIBILITIES"
            icon={Building}
            delay={0.5}
          >
            <h4 className="text-lg font-semibold text-[#0D0D0D] mb-4">2.1. Finatrades' Role as Platform Provider</h4>
            <p className="text-[#4A4A4A] mb-4">Finatrades operates a technological and administrative platform that provides the following services:</p>
            
            <div className="space-y-4 mb-8">
              <ServiceCard 
                letter="A" 
                title="Gold Certification & Registry" 
                description="We provide the digital infrastructure to issue and maintain a registry of Gold Certificates. These Certificates represent beneficial ownership of physical gold that is stored under vaulting agreements managed solely by Commercial Partners."
              />
              <ServiceCard 
                letter="B" 
                title="Gold-Based Payment and Settlement System" 
                description="The Platform enables a payment and settlement system where Gold Certificates function as the medium of exchange. This involves the transfer of ownership of a Gold Certificate (and the beneficial interest in the Underlying Gold) to another User on the Platform. All transactions are settled through the transfer of Gold Certificates, representing gold. Finatrades does not accept, hold, or transmit customer funds. Customer funds for the purchase of gold are converted into gold via a transaction with a Commercial Partner, and all subsequent Platform activity involves the transfer of gold ownership via Gold Certificates."
              />
              <ServiceCard 
                letter="C" 
                title="Platform Infrastructure for Commercial Partners" 
                description="Finatrades provides the neutral digital infrastructure that enables Commercial Partners to offer their services to Users."
              />
              <ServiceCard 
                letter="D" 
                title="Operational Support" 
                description="Finatrades may engage its Affiliates to provide specific technical, operational, or administrative support for the Platform. Such Affiliates act under Finatrades' instruction and for its benefit, and Finatrades remains responsible for their performance under these Terms."
              />
            </div>

            <h4 className="text-lg font-semibold text-[#0D0D0D] mb-4">2.2. Critical Clarifications of Status (Disclaimers)</h4>
            <p className="text-[#4A4A4A] mb-4">For the avoidance of doubt, and as a fundamental basis of this agreement:</p>
            
            <div className="space-y-3 mb-8">
              {[
                { text: 'Finatrades is "not a bank". Under Swiss law, the activities of trade finance facilitation, payment settlement in commodities, and commodities-linked financing as conducted by Finatrades through this Platform do not constitute deposit-taking from the public and therefore do not require a banking licence. Finatrades does not hold customer money.' },
                { text: 'Finatrades is "not a custodian". The physical Underlying Gold is held exclusively by independent, licensed third-party vault operators under Vaulting Agreements entered into by the Commercial Partner (Wingold). Finatrades acts solely as an administrator of the digital registry for the Gold Certificates.' },
                { text: 'Finatrades is "not a financial advisor" and provides no investment, legal, or tax advice.' },
                { text: 'Finatrades is "not a principal or counterparty" in commercial gold trading transactions facilitated on the Platform, except where explicitly stated otherwise. Finatrades is a service provider to Commercial Partners, not their agent, partner in a joint venture, or guarantor.' }
              ].map((item, i) => (
                <div key={i} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                  <Info className="w-5 h-5 text-[#8A2BE2] flex-shrink-0 mt-0.5" />
                  <p className="text-[#4A4A4A] text-sm">{item.text}</p>
                </div>
              ))}
            </div>

            <h4 className="text-lg font-semibold text-[#0D0D0D] mb-4">2.3. Commercial Partner Activities – Independent Relationship with Users</h4>
            <p className="text-[#4A4A4A] mb-4">
              The Platform hosts commercial activities conducted by independent third-party Commercial Partners, such as Wingold & Metals DMCC ("Wingold"). Wingold utilizes the Finatrades Platform to offer services, including but not limited to, the execution and management of the "Buy-Now-Sell-Later" (BNSL) plan featured on the Platform.
            </p>
            
            <div className="space-y-4">
              {[
                { title: 'Independent Contractor Status', text: 'Wingold is an independent contractor and principal in all its dealings with Users and with third-party vault operators. Its use of the Platform does not create a partnership, joint venture, agency, or employment relationship between Finatrades and Wingold. Finatrades does not control, manage, or supervise Wingold\'s business operations, compliance, or its agreements with vault operators.' },
                { title: 'Direct User-Partner Contract', text: 'When you engage in a transaction with a Commercial Partner like Wingold, you are entering into a direct contractual relationship with that Commercial Partner. The terms of that specific transaction, including all commercial terms, warranties, delivery, financial settlement obligations, and crucially, the terms governing the storage and insurance of the physical gold (the Vaulting Agreement), are governed by separate agreements between you and the Commercial Partner and between the Commercial Partner and the vault operator. Finatrades is not a party to any of these agreements.' },
                { title: 'Vaulting Arrangements', text: 'You acknowledge and agree that any vaulting, storage, insurance, or safekeeping services for the Underlying Gold are provided under a Vaulting Agreement between the Commercial Partner (Wingold) and the third-party vault operator. Finatrades is not a party to this agreement, does not guarantee its performance, and has no liability arising from it.' },
                { title: 'Limitation of Finatrades\' Role', text: 'Finatrades\' role is strictly limited to providing the neutral digital registry, recording, and transaction infrastructure. Finatrades does not: (i) engage in the commercial sale, purchase, or physical handling of gold; (ii) guarantee the performance, solvency, or compliance of Wingold or any vault operator; (iii) hold or transfer funds; or (iv) provide any form of insurance or protection for transactions or storage arrangements.' },
                { title: 'Partner\'s Sole Responsibility', text: 'Wingold & Metals DMCC remains fully and solely responsible for its own regulatory compliance, licensing, operational conduct, financial obligations, representations made to Users, its agreements with vault operators, and any and all claims arising from its commercial activities or the storage of gold.' }
              ].map((item, i) => (
                <div key={i} className="border-l-2 border-[#8A2BE2]/30 pl-4">
                  <h5 className="font-medium text-[#0D0D0D] mb-1">{item.title}</h5>
                  <p className="text-[#4A4A4A] text-sm">{item.text}</p>
                </div>
              ))}
            </div>
          </Section>

          {/* Section 3: User Responsibilities */}
          <Section
            number="3"
            title="USER RESPONSIBILITIES & REPRESENTATIONS"
            icon={Users}
            delay={0.6}
          >
            <p className="text-[#4A4A4A] mb-4">You represent, warrant, and covenant that you will:</p>
            <ul className="space-y-3">
              {[
                'Provide complete, accurate, and truthful information during onboarding and promptly update it.',
                'Comply fully with all applicable laws, including Swiss AMLA and international sanctions regimes.',
                'Maintain the security of your account credentials and authentication devices. You are solely responsible for all activities under your account.',
                'Not use the Platform for any illegal purpose, including money laundering, terrorist financing, or tax evasion.',
                'Understand and accept that the Gold Certificate is a digital record of beneficial ownership. Any rights or claims regarding the physical storage, safety, or delivery of the Underlying Gold are governed solely by the separate agreements between you, the Commercial Partner, and the vault operator.',
                'Conduct your own due diligence on any Commercial Partner (including Wingold) and any associated vault operator before transacting. You acknowledge that Finatrades does not endorse, vet, or guarantee any Commercial Partner or third-party service provider.'
              ].map((item, i) => (
                <li key={i} className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span className="text-[#4A4A4A]">{item}</span>
                </li>
              ))}
            </ul>
          </Section>

          {/* Section 4: Gold Certificates & Risk */}
          <Section
            number="4"
            title="GOLD CERTIFICATES & RISK DISCLOSURE"
            icon={AlertTriangle}
            delay={0.7}
            highlighted
          >
            <p className="text-[#0D0D0D] font-semibold mb-4">YOU EXPRESSLY ACKNOWLEDGE AND ACCEPT THE FOLLOWING INHERENT AND SIGNIFICANT RISKS:</p>
            
            <div className="space-y-4 mb-6">
              {[
                { title: 'No Physical Redemption from Finatrades', text: 'A Gold Certificate does not entitle you to take physical possession of the Underlying Gold from Finatrades. It represents a beneficial ownership right exercisable only through the Platform.' },
                { title: 'Third-Party Vault', text: 'The Underlying Gold is held by independent third-party vault operators under agreements with the Commercial Partner. Finatrades is not a party to these agreements and disclaims all liability for the acts, omissions, insolvency, negligence, or fraud of these operators or for any loss, theft, or damage to the Underlying Gold.' },
                { title: 'Transaction with Commercial Partner', text: 'Transactions with Commercial Partner (Wingold) are undertaken at your own risk. You are solely responsible for assessing the creditworthiness, reliability, and compliance of any Commercial Partner. Finatrades is not a party to these contracts and bears no liability for the performance, solvency, non-delivery, misrepresentation, breach, or any other conduct of Commercial Partners. The risk of default by a Commercial Partner rests entirely with you.' },
                { title: 'Price Volatility', text: 'The value of gold can be highly volatile, which will affect the value of your Gold Certificates.' },
                { title: 'Platform Risk', text: 'The Platform is a critical system. Its unavailability, technical failures, or a security breach could prevent access to or transfer of Gold Certificates.' },
                { title: 'Regulatory Risk', text: 'Changes in law or regulation may adversely affect the Platform, Gold Certificates, or the ability of Commercial Partners to operate.' }
              ].map((item, i) => (
                <div key={i} className="bg-red-50 border border-red-200 rounded-lg p-4">
                  <h5 className="font-medium text-red-800 mb-1">{item.title}</h5>
                  <p className="text-red-700 text-sm">{item.text}</p>
                </div>
              ))}
            </div>

            <div className="bg-gray-100 rounded-lg p-4">
              <p className="text-[#4A4A4A] text-sm">
                <strong>Finatrades explicitly disclaims liability for losses arising from:</strong> the insolvency, fraud, or default of a vault operator or Commercial Partner; gold price fluctuations; system failures or cyber-attacks; any act or omission of a Commercial Partner or vault operator; or any force majeure event.
              </p>
            </div>
          </Section>

          {/* Section 5: Prohibited Users */}
          <Section
            number="5"
            title="PROHIBITED USERS & JURISDICTIONS"
            icon={XCircle}
            delay={0.8}
          >
            <p className="text-[#4A4A4A]">
              Access to and use of the Platform is strictly prohibited for individuals or entities located in, resident of, or incorporated in jurisdictions comprehensively sanctioned by Switzerland, the UN, the EU, or the U.S., or for persons on any sanctions list. Commercial Partners, including Wingold, may impose additional jurisdictional restrictions on their own services.
            </p>
          </Section>

          {/* Section 6: Liability Limitation */}
          <Section
            number="6"
            title="LIABILITY LIMITATION (UNDER SWISS LAW)"
            icon={Shield}
            delay={0.9}
          >
            <p className="text-[#4A4A4A] mb-4 font-medium">TO THE FULLEST EXTENT PERMITTED BY THE SWISS CODE OF OBLIGATIONS (OR):</p>
            
            <ul className="space-y-3 mb-6">
              {[
                'Finatrades shall only be liable for direct damages caused by its own intent (dolus) or gross negligence (culpa lata). Liability for slight negligence (culpa levis) is expressly excluded.',
                'In no event shall Finatrades be liable for any indirect, incidental, special, consequential, or punitive damages, including loss of profits, data, or opportunity.',
                'Finatrades\'s total aggregate liability towards you for any and all claims shall be limited to the amount of platform access or administration fees you have paid directly to Finatrades in the three (3) months preceding the event giving rise to the claim.'
              ].map((item, i) => (
                <li key={i} className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-[#8A2BE2]/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-[#8A2BE2] text-xs font-bold">{i + 1}</span>
                  </div>
                  <span className="text-[#4A4A4A]">{item}</span>
                </li>
              ))}
            </ul>

            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
              <h5 className="font-medium text-amber-800 mb-2">No Liability for Third Parties</h5>
              <p className="text-amber-700 text-sm">
                Finatrades assumes no liability whatsoever for any acts, omissions, breaches, representations, or damages caused by Service Providers, Commercial Partners (including Wingold & Metals DMCC), vault operators, or other Users. Your recourse for any issues with a third party's services or conduct is solely against that third party.
              </p>
            </div>
          </Section>

          {/* Section 7: Governing Law */}
          <Section
            number="7"
            title="GOVERNING LAW, JURISDICTION & DISPUTE RESOLUTION"
            icon={Scale}
            delay={1.0}
          >
            <div className="space-y-4">
              <div className="border-l-2 border-[#8A2BE2]/30 pl-4">
                <h5 className="font-medium text-[#0D0D0D] mb-1">Governing Law for Platform Use</h5>
                <p className="text-[#4A4A4A] text-sm">These Terms, and any dispute arising from your use of the Platform in its capacity as a platform provider, shall be governed by the substantive laws of Switzerland, excluding its conflict of law provisions.</p>
              </div>
              
              <div className="border-l-2 border-[#8A2BE2]/30 pl-4">
                <h5 className="font-medium text-[#0D0D0D] mb-1">Jurisdiction for Platform Disputes</h5>
                <p className="text-[#4A4A4A] text-sm">Any such dispute shall be subject to the exclusive jurisdiction of the ordinary courts of Geneva, Switzerland. Alternatively, at Finatrades's sole discretion, we may elect to submit any such dispute to final and binding arbitration under the Rules of the International Chamber of Commerce (ICC) seated in Geneva, conducted in English.</p>
              </div>
              
              <div className="border-l-2 border-[#8A2BE2]/30 pl-4">
                <h5 className="font-medium text-[#0D0D0D] mb-1">Disputes with Commercial Partners or Vault Operators Are Separate</h5>
                <p className="text-[#4A4A4A] text-sm">Any disputes arising from your commercial relationship with a Commercial Partner (e.g., Wingold) or related to vaulting services shall be governed solely by the terms of your separate agreement(s) with those entities and resolved in the forum and manner specified therein. Finatrades is not a necessary or proper party to such disputes. You agree not to name, join, or attempt to involve Finatrades in any legal proceeding against a Commercial Partner or vault operator.</p>
              </div>
              
              <div className="border-l-2 border-[#8A2BE2]/30 pl-4">
                <h5 className="font-medium text-[#0D0D0D] mb-1">Indemnification for Involvement in Third-Party Disputes</h5>
                <p className="text-[#4A4A4A] text-sm">You agree to indemnify, defend, and hold harmless Finatrades and its Affiliates from and against any and all claims, damages, liabilities, costs, and expenses (including legal fees) arising from or related to any dispute between you and a Commercial Partner, vault operator, or other third party, including any attempt to involve Finatrades in such a dispute.</p>
              </div>
            </div>
          </Section>

          {/* Section 8: Termination */}
          <Section
            number="8"
            title="TERMINATION"
            icon={Lock}
            delay={1.1}
          >
            <p className="text-[#4A4A4A]">
              Finatrades reserves the right to immediately suspend or terminate your access to the Platform for reasons including compliance with legal obligations, suspected violation of these Terms, or any fraudulent conduct. Termination of your access to the Platform does not terminate any separate agreements you may have with Commercial Partners or vault operators, which remain in effect according to their own terms.
            </p>
          </Section>

          {/* Witness Statement */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.2 }}
            className="mt-12 pt-8 border-t border-gray-200"
          >
            <p className="text-[#4A4A4A] italic mb-8">
              IN WITNESS WHEREOF, these Terms have been made accessible and effective as of the date first posted above.
            </p>

            <div className="bg-gradient-to-r from-[#8A2BE2]/5 to-[#FF2FBF]/5 rounded-2xl p-6 border border-[#8A2BE2]/20">
              <p className="text-[#4A4A4A] mb-4">For questions regarding these Terms, please contact:</p>
              <div className="flex items-center gap-2 text-[#8A2BE2] mb-4">
                <Mail className="w-5 h-5" />
                <a href="mailto:admin@finatrades.com" className="hover:underline">admin@finatrades.com</a>
              </div>
              <div className="text-[#0D0D0D]">
                <p className="font-semibold">Finatrades Finance SA</p>
                <p className="text-[#4A4A4A]">Rue Robert Céard 6</p>
                <p className="text-[#4A4A4A]">1204 Geneva</p>
                <p className="text-[#4A4A4A]">Switzerland</p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}

function Section({ number, title, icon: Icon, children, delay = 0, highlighted = false }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      className={`mb-12 ${highlighted ? 'bg-red-50/50 -mx-4 px-4 py-6 rounded-2xl border border-red-100' : ''}`}
    >
      <div className="flex items-center gap-4 mb-6">
        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#8A2BE2] to-[#FF2FBF] flex items-center justify-center text-white font-bold">
          {number}
        </div>
        <div className="flex items-center gap-3">
          <Icon className="w-5 h-5 text-[#8A2BE2]" />
          <h2 className="text-xl font-bold text-[#0D0D0D]">{title}</h2>
        </div>
      </div>
      {children}
    </motion.div>
  );
}

function DefinitionList({ definitions }) {
  return (
    <div className="space-y-3">
      {definitions.map((def, i) => (
        <div key={i} className="flex flex-col sm:flex-row sm:gap-2">
          <span className="font-medium text-[#8A2BE2] whitespace-nowrap">{def.term}</span>
          <span className="text-[#4A4A4A]">{def.definition}</span>
        </div>
      ))}
    </div>
  );
}

function ServiceCard({ letter, title, description }) {
  return (
    <div className="flex items-start gap-4 p-4 bg-white rounded-xl border border-[#8A2BE2]/20 shadow-sm">
      <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#8A2BE2] to-[#FF2FBF] flex items-center justify-center text-white font-bold flex-shrink-0">
        {letter}
      </div>
      <div>
        <h5 className="font-medium text-[#0D0D0D] mb-1">{title}</h5>
        <p className="text-[#4A4A4A] text-sm">{description}</p>
      </div>
    </div>
  );
}