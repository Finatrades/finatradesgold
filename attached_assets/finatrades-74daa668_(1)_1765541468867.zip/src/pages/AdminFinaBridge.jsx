import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { GitBranch, FileText, CheckCircle, XCircle, Download } from 'lucide-react';
import { Button } from "@/components/ui/button";

import AdminSidebar from '@/components/admin/AdminSidebar';
import AdminTopBar from '@/components/admin/AdminTopBar';
import AdminTable from '@/components/admin/AdminTable';
import AdminFilterBar from '@/components/admin/AdminFilterBar';
import AdminStatusBadge from '@/components/admin/AdminStatusBadge';
import AdminDrawer from '@/components/admin/AdminDrawer';

const sampleTradeCases = [
  { id: 'TRD-2241', role: 'Importer', buyer: 'Global Imports LLC', seller: 'Swiss Metals AG', valueUSD: 125000, lockedGold: 1470, status: 'under_review', lastUpdated: '2024-12-04' },
  { id: 'TRD-2242', role: 'Exporter', buyer: 'Dubai Gold Corp', seller: 'Ahmed Trading', valueUSD: 85000, lockedGold: 1000, status: 'docs_pending', lastUpdated: '2024-12-03' },
  { id: 'TRD-2243', role: 'Importer', buyer: 'European Metals', seller: 'Finatrades', valueUSD: 250000, lockedGold: 2941, status: 'approved', lastUpdated: '2024-12-02' },
];

export default function AdminFinaBridge() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [role, setRole] = useState('Operations');
  const [searchValue, setSearchValue] = useState('');
  const [selectedCase, setSelectedCase] = useState(null);
  const [drawerOpen, setDrawerOpen] = useState(false);

  useEffect(() => {
    const storedUser = localStorage.getItem('finatrades_user');
    if (!storedUser) {
      navigate(createPageUrl("SignIn"));
      return;
    }
    const userData = JSON.parse(storedUser);
    if (!userData.is_admin) {
      navigate(createPageUrl("UserDashboard"));
      return;
    }
    setUser(userData);
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('finatrades_user');
    navigate(createPageUrl("Home"));
  };

  const handleReview = (tradeCase) => {
    setSelectedCase(tradeCase);
    setDrawerOpen(true);
  };

  const caseColumns = [
    { header: 'Case ID', accessor: 'id' },
    { header: 'Role', accessor: 'role', render: (val) => <span className={`px-2 py-1 rounded text-xs ${val === 'Importer' ? 'bg-blue-500/20 text-blue-400' : 'bg-green-500/20 text-green-400'}`}>{val}</span> },
    { header: 'Buyer', accessor: 'buyer' },
    { header: 'Seller', accessor: 'seller' },
    { header: 'Value (USD)', accessor: 'valueUSD', render: (val) => `$${val.toLocaleString()}` },
    { header: 'Locked Gold', accessor: 'lockedGold', render: (val) => `${val}g` },
    { header: 'Status', accessor: 'status', render: (val) => <AdminStatusBadge status={val} /> },
    { header: 'Updated', accessor: 'lastUpdated' },
  ];

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FAFBFF] via-[#F4F6FC] to-[#FFFFFF]">
      <AdminSidebar currentSection="finabridge" onLogout={handleLogout} />
      
      <div className="ml-64">
        <AdminTopBar user={user} role={role} onRoleChange={setRole} />
        
        <main className="p-6 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-[#0D0D0D] flex items-center gap-3">
                <GitBranch className="w-7 h-7 text-[#8A2BE2]" />
                FinaBridge Trade Finance
              </h1>
            </div>
            <Button variant="outline" className="border-[#8A2BE2]/30 text-[#FF2FBF]">
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
          </div>

          <AdminFilterBar
            searchPlaceholder="Search by case ID, buyer, or seller..."
            searchValue={searchValue}
            onSearchChange={setSearchValue}
            filters={[]}
          />

          <AdminTable columns={caseColumns} data={sampleTradeCases} onRowAction={handleReview} actionLabel="Review" />
        </main>
      </div>

      <AdminDrawer
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        title={selectedCase?.id || 'Trade Case'}
        subtitle={`${selectedCase?.buyer} ↔ ${selectedCase?.seller}`}
        footer={
          selectedCase?.status === 'approved' ? (
            <div className="flex items-center justify-end gap-3">
              <Button className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white font-bold">Release Gold to Exporter</Button>
            </div>
          ) : (
            <div className="flex items-center justify-end gap-3">
              <Button variant="outline" className="border-red-500/30 text-red-400">Reject</Button>
              <Button className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white font-bold">Approve</Button>
            </div>
          )
        }
      >
        {selectedCase && (
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-[#F4F6FC] rounded-lg p-4 border border-[#8A2BE2]/10">
                <p className="text-[#4A4A4A] text-xs uppercase mb-1">Trade Value</p>
                <p className="text-[#0D0D0D] text-xl font-bold">${selectedCase.valueUSD.toLocaleString()}</p>
              </div>
              <div className="bg-[#F4F6FC] rounded-lg p-4 border border-[#8A2BE2]/10">
                <p className="text-[#4A4A4A] text-xs uppercase mb-1">Gold Locked</p>
                <p className="text-[#FF2FBF] text-xl font-bold">{selectedCase.lockedGold}g</p>
              </div>
              <div className="bg-[#F4F6FC] rounded-lg p-4 border border-[#8A2BE2]/10">
                <p className="text-[#4A4A4A] text-xs uppercase mb-1">Status</p>
                <div className="mt-1"><AdminStatusBadge status={selectedCase.status} /></div>
              </div>
            </div>
          </div>
        )}
      </AdminDrawer>
    </div>
  );
}