import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { 
  TrendingUp, Plus, ArrowRight, Bell, Info, Shield
} from 'lucide-react';
import { Button } from "@/components/ui/button";

import DashboardSidebar from '@/components/dashboard/DashboardSidebar';
import BNSLWalletSummary from '@/components/bnsl/BNSLWalletSummary';
import BNSLTransferModal from '@/components/bnsl/BNSLTransferModal';
import BNSLPlanSelection from '@/components/bnsl/BNSLPlanSelection';
import BNSLPlanReview from '@/components/bnsl/BNSLPlanReview';
import BNSLPlanDetails from '@/components/bnsl/BNSLPlanDetails';
import BNSLPlansTable from '@/components/bnsl/BNSLPlansTable';
import { toast } from 'sonner';

// Sample BNSL plans data
const samplePlans = [
  {
    id: 'BNSL-2024-001',
    tenure: 12,
    rate: 10,
    principalGold: 100.000,
    lockedInPrice: 85.00,
    lockedPrincipalValue: 8500.00,
    startDate: '2024-09-15',
    maturityDate: '2025-09-15',
    status: 'active',
    totalDistributionsPaid: 2.485,
    monetaryValueDistributed: 212.50,
    nextDistributionDate: 'Dec 15, 2024',
    quarterlyMonetaryValue: 212.50,
    distributionHistory: [
      { number: 1, date: 'Sep 15, 2024', monetaryValue: 212.50, marketPriceUsed: 82.00, goldCredited: 2.591, status: 'paid' },
      { number: 2, date: 'Dec 15, 2024', monetaryValue: 212.50, marketPriceUsed: 85.50, goldCredited: 2.485, status: 'paid' },
      { number: 3, date: 'Mar 15, 2025', monetaryValue: 212.50, marketPriceUsed: 0, goldCredited: 0, status: 'upcoming' },
      { number: 4, date: 'Jun 15, 2025', monetaryValue: 212.50, marketPriceUsed: 0, goldCredited: 0, status: 'upcoming' }
    ]
  },
  {
    id: 'BNSL-2024-002',
    tenure: 24,
    rate: 11,
    principalGold: 250.000,
    lockedInPrice: 84.50,
    lockedPrincipalValue: 21125.00,
    startDate: '2024-06-01',
    maturityDate: '2026-06-01',
    status: 'active',
    totalDistributionsPaid: 8.156,
    monetaryValueDistributed: 1162.19,
    nextDistributionDate: 'Dec 01, 2024',
    quarterlyMonetaryValue: 580.94,
    distributionHistory: [
      { number: 1, date: 'Jun 01, 2024', monetaryValue: 580.94, marketPriceUsed: 80.00, goldCredited: 7.262, status: 'paid' },
      { number: 2, date: 'Sep 01, 2024', monetaryValue: 580.94, marketPriceUsed: 83.50, goldCredited: 6.958, status: 'paid' },
      { number: 3, date: 'Dec 01, 2024', monetaryValue: 580.94, marketPriceUsed: 0, goldCredited: 0, status: 'upcoming' },
      { number: 4, date: 'Mar 01, 2025', monetaryValue: 580.94, marketPriceUsed: 0, goldCredited: 0, status: 'upcoming' },
      { number: 5, date: 'Jun 01, 2025', monetaryValue: 580.94, marketPriceUsed: 0, goldCredited: 0, status: 'upcoming' },
      { number: 6, date: 'Sep 01, 2025', monetaryValue: 580.94, marketPriceUsed: 0, goldCredited: 0, status: 'upcoming' },
      { number: 7, date: 'Dec 01, 2025', monetaryValue: 580.94, marketPriceUsed: 0, goldCredited: 0, status: 'upcoming' },
      { number: 8, date: 'Mar 01, 2026', monetaryValue: 580.94, marketPriceUsed: 0, goldCredited: 0, status: 'upcoming' }
    ]
  },
  {
    id: 'BNSL-2023-005',
    tenure: 12,
    rate: 10,
    principalGold: 50.000,
    lockedInPrice: 78.00,
    lockedPrincipalValue: 3900.00,
    startDate: '2023-06-01',
    maturityDate: '2024-06-01',
    status: 'completed',
    totalDistributionsPaid: 4.872,
    monetaryValueDistributed: 390.00,
    nextDistributionDate: null,
    quarterlyMonetaryValue: 97.50,
    distributionHistory: [
      { number: 1, date: 'Jun 01, 2023', monetaryValue: 97.50, marketPriceUsed: 76.00, goldCredited: 1.283, status: 'paid' },
      { number: 2, date: 'Sep 01, 2023', monetaryValue: 97.50, marketPriceUsed: 79.00, goldCredited: 1.234, status: 'paid' },
      { number: 3, date: 'Dec 01, 2023', monetaryValue: 97.50, marketPriceUsed: 81.00, goldCredited: 1.204, status: 'paid' },
      { number: 4, date: 'Mar 01, 2024', monetaryValue: 97.50, marketPriceUsed: 84.00, goldCredited: 1.161, status: 'paid' }
    ]
  }
];

export default function FinaEarnUser() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [view, setView] = useState('home'); // 'home', 'selectPlan', 'review', 'details'
  const [showTransferModal, setShowTransferModal] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState(null);
  const [selectedPlanConfig, setSelectedPlanConfig] = useState(null);
  const [transferAmount, setTransferAmount] = useState(0);
  const [goldToLock, setGoldToLock] = useState(0);
  
  // Balances
  const [finaPayBalance, setFinaPayBalance] = useState(150.000);
  const [bnslWalletBalance, setBnslWalletBalance] = useState(0);
  const [plans, setPlans] = useState(samplePlans);
  
  // Gold price (LBMA)
  const goldPrice = 85.00;

  useEffect(() => {
    const storedUser = localStorage.getItem('finatrades_user');
    if (!storedUser) {
      navigate(createPageUrl("Home"));
      return;
    }
    setUser(JSON.parse(storedUser));
  }, [navigate]);

  // Calculate summary stats
  const activePlans = plans.filter(p => p.status === 'active');
  const principalLocked = activePlans.reduce((sum, p) => sum + p.principalGold, 0);
  const lockedPrincipalValue = activePlans.reduce((sum, p) => sum + p.lockedPrincipalValue, 0);
  const marketValueEquivalent = principalLocked * goldPrice;
  const accumulatedDistributions = plans.reduce((sum, p) => sum + p.totalDistributionsPaid, 0);
  const nextDistribution = activePlans.find(p => p.nextDistributionDate)?.nextDistributionDate || 'N/A';
  const upcomingDistributionValue = activePlans.reduce((sum, p) => sum + p.quarterlyMonetaryValue, 0);
  const averageTenure = activePlans.length > 0 
    ? Math.round(activePlans.reduce((sum, p) => sum + p.tenure, 0) / activePlans.length) 
    : 0;

  const handleTransferContinue = (amount) => {
    setTransferAmount(amount);
    setFinaPayBalance(prev => prev - amount);
    setBnslWalletBalance(prev => prev + amount);
    setShowTransferModal(false);
    setView('selectPlan');
    toast.success(`${amount.toFixed(3)}g transferred to BNSL Wallet`);
  };

  const handleSelectPlan = (planConfig, goldAmount) => {
    setSelectedPlanConfig(planConfig);
    setGoldToLock(goldAmount);
    setView('review');
  };

  const handleConfirmPlan = () => {
    const newPlan = {
      id: `BNSL-2024-${String(plans.length + 1).padStart(3, '0')}`,
      tenure: selectedPlanConfig.tenure,
      rate: selectedPlanConfig.rate,
      principalGold: goldToLock,
      lockedInPrice: goldPrice,
      lockedPrincipalValue: goldToLock * goldPrice,
      startDate: new Date().toISOString().split('T')[0],
      maturityDate: new Date(Date.now() + selectedPlanConfig.tenure * 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      status: 'active',
      totalDistributionsPaid: 0,
      monetaryValueDistributed: 0,
      nextDistributionDate: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      quarterlyMonetaryValue: (goldToLock * goldPrice * (selectedPlanConfig.rate / 100)) / 4,
      distributionHistory: Array.from({ length: selectedPlanConfig.distributions }, (_, i) => ({
        number: i + 1,
        date: new Date(Date.now() + (i + 1) * 90 * 24 * 60 * 60 * 1000).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
        monetaryValue: (goldToLock * goldPrice * (selectedPlanConfig.rate / 100)) / 4,
        marketPriceUsed: 0,
        goldCredited: 0,
        status: 'upcoming'
      }))
    };
    
    setPlans([newPlan, ...plans]);
    setBnslWalletBalance(prev => prev - goldToLock);
    setSelectedPlan(newPlan);
    setView('details');
    toast.success(`BNSL Plan ${newPlan.id} created successfully!`);
  };

  const handleViewPlan = (plan) => {
    setSelectedPlan(plan);
    setView('details');
  };

  const handleTerminatePlan = (planId) => {
    toast.error('Early termination request submitted. Our team will contact you.');
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FAFBFF] via-[#F4F6FC] to-[#FFFFFF]">
      
      <div className="flex">
        {/* Sidebar */}
        <DashboardSidebar currentPage="FinaEarnUser" user={user} />

        {/* Main Content */}
        <main className="flex-1 min-h-screen">
          {/* Top Header */}
          <header className="sticky top-0 z-30 bg-white border-b border-[#8A2BE2]/20 px-4 sm:px-6 py-3 sm:py-4 shadow-sm">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 sm:gap-4 ml-12 lg:ml-0">
                <div className="flex items-center gap-2 sm:gap-3">
                  <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg sm:rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 flex items-center justify-center">
                    <TrendingUp className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
                  </div>
                  <div>
                    <h1 className="text-base sm:text-xl font-bold text-[#0D0D0D]">
                      <span className="hidden sm:inline">BNSL – Buy Now Sell Later (FinaEarn)</span>
                      <span className="sm:hidden">FinaEarn</span>
                    </h1>
                    <p className="text-[#4A4A4A] text-[10px] sm:text-xs hidden sm:block">Structured gold holding plans with quarterly gold rewards.</p>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <button className="w-10 h-10 rounded-full bg-[#F4F6FC] border border-[#8A2BE2]/20 flex items-center justify-center text-[#4A4A4A] hover:bg-[#8A2BE2]/10 hover:border-[#8A2BE2]/40">
                  <Bell className="w-5 h-5" />
                </button>
              </div>
            </div>
          </header>

          <div className="p-4 sm:p-6">
            {view === 'home' && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="space-y-6"
              >
                {/* Wallet Summary */}
                <BNSLWalletSummary
                  principalLocked={principalLocked}
                  lockedPrincipalValue={lockedPrincipalValue}
                  marketValueEquivalent={marketValueEquivalent}
                  accumulatedDistributions={accumulatedDistributions}
                  activePlans={activePlans.length}
                  nextDistributionDate={nextDistribution}
                  upcomingDistributionValue={upcomingDistributionValue}
                  averageTenure={averageTenure}
                  goldPrice={goldPrice}
                />

                {/* Action Buttons */}
                <div className="flex flex-wrap items-center gap-4">
                  <Button 
                    onClick={() => setView('selectPlan')}
                    className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white font-bold hover:opacity-90"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Create New BNSL Plan
                  </Button>
                  <Button 
                    onClick={() => setShowTransferModal(true)}
                    variant="outline"
                    className="border-[#8A2BE2]/30 text-[#FF2FBF] hover:bg-[#8A2BE2]/10"
                  >
                    <ArrowRight className="w-4 h-4 mr-2" />
                    Transfer Gold from FinaPay
                  </Button>
                </div>

                {/* Compliance Notice */}
                <div className="flex items-center gap-3 p-4 bg-amber-500/5 border border-amber-500/20 rounded-xl">
                  <Shield className="w-5 h-5 text-amber-600 flex-shrink-0" />
                  <p className="text-[#4A4A4A] text-sm">
                    BNSL is a physical gold purchase & buyback plan with fixed-term commitments, not a deposit or investment account.
                  </p>
                </div>

                {/* Plans Table */}
                <BNSLPlansTable plans={plans} onViewPlan={handleViewPlan} />
              </motion.div>
            )}

            {view === 'selectPlan' && (
              <BNSLPlanSelection
                initialAmount={transferAmount}
                bnslWalletBalance={bnslWalletBalance}
                goldPrice={goldPrice}
                onBack={() => {
                  setView('home');
                  setTransferAmount(0);
                }}
                onSelectPlan={handleSelectPlan}
              />
            )}

            {view === 'review' && selectedPlanConfig && (
              <BNSLPlanReview
                plan={selectedPlanConfig}
                goldAmount={goldToLock}
                goldPrice={goldPrice}
                onBack={() => setView('selectPlan')}
                onConfirm={handleConfirmPlan}
              />
            )}

            {view === 'details' && selectedPlan && (
              <BNSLPlanDetails
                plan={selectedPlan}
                goldPrice={goldPrice}
                onBack={() => {
                  setView('home');
                  setSelectedPlan(null);
                }}
                onTerminate={handleTerminatePlan}
              />
            )}
          </div>
        </main>
      </div>

      {/* Transfer Modal */}
      <BNSLTransferModal
        open={showTransferModal}
        onClose={() => setShowTransferModal(false)}
        finaPayBalance={finaPayBalance}
        goldPrice={goldPrice}
        onContinue={handleTransferContinue}
      />
    </div>
  );
}