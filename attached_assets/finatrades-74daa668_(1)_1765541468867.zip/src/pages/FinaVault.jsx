import React, { useRef } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { 
  Lock, Shield, FileCheck, Wallet, Globe, CheckCircle,
  ArrowRight, Fingerprint, ScanLine, Database, BarChart3,
  Building, Sparkles, KeyRound, Eye, Layers, BadgeCheck,
  TrendingUp, CircleDot, ArrowDownToLine, ArrowUpFromLine
} from 'lucide-react';
import { motion, useScroll, useTransform, useInView } from 'framer-motion';
import GoldButton from '../components/ui/GoldButton';
import GoldCard from '../components/ui/GoldCard';
import { useLanguage } from '@/components/LanguageContext';

// Particle System
function ParticleField({ count = 40 }) {
  const particles = Array.from({ length: count }, (_, i) => ({
    id: i,
    x: Math.random() * 100,
    y: Math.random() * 100,
    size: Math.random() * 3 + 1,
    duration: Math.random() * 15 + 10,
    delay: Math.random() * 5
  }));

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {particles.map((p) => (
        <motion.div
          key={p.id}
          className="absolute rounded-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF]"
          style={{ width: p.size, height: p.size, left: `${p.x}%`, top: `${p.y}%` }}
          animate={{
            y: [0, -100, 0],
            opacity: [0, 0.6, 0],
            scale: [0, 1, 0]
          }}
          transition={{ duration: p.duration, delay: p.delay, repeat: Infinity, ease: "easeInOut" }}
        />
      ))}
    </div>
  );
}

// Glowing Orb
function GlowingOrb({ className, delay = 0 }) {
  return (
    <motion.div
      className={`absolute rounded-full blur-[100px] ${className}`}
      animate={{ scale: [1, 1.2, 1], opacity: [0.3, 0.5, 0.3] }}
      transition={{ duration: 4, delay, repeat: Infinity, ease: "easeInOut" }}
    />
  );
}

// Vault Card Component (similar to FinaPay wallet card)
function VaultCard() {
  const [unit, setUnit] = React.useState('Grams');
  const units = ['Grams', 'Oz', 'KG'];
  
  // Base value in grams
  const gramsValue = 1000;
  const conversions = {
    Grams: { value: gramsValue.toFixed(2), label: 'grams' },
    Oz: { value: (gramsValue / 31.1035).toFixed(2), label: 'oz' },
    KG: { value: (gramsValue / 1000).toFixed(3), label: 'kg' }
  };

  return (
    <motion.div
      className="relative w-full max-w-sm mx-auto"
      initial={{ opacity: 0, y: 50, rotateX: 20 }}
      animate={{ opacity: 1, y: 0, rotateX: 0 }}
      transition={{ duration: 1, delay: 0.5 }}
    >
      {/* Card Glow */}
      <div className="absolute -inset-4 bg-gradient-to-r from-[#8A2BE2]/30 via-[#FF2FBF]/20 to-[#8A2BE2]/30 rounded-3xl blur-2xl animate-pulse" />
      
      {/* Purple Neon Edge */}
      <div className="absolute -inset-1 bg-gradient-to-r from-[#8A2BE2] via-[#FF2FBF] to-[#8A2BE2] rounded-2xl opacity-60" />
      
      {/* Main Card */}
      <motion.div
        className="relative w-full h-auto min-h-[220px] rounded-2xl bg-white border border-[#8A2BE2]/30 p-5 sm:p-6 overflow-hidden shadow-[0_8px_32px_rgba(138,43,226,0.15)]"
        animate={{ y: [0, -10, 0] }}
        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
      >
        {/* Light Sweep */}
        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-transparent via-[#8A2BE2]/10 to-transparent"
          animate={{ x: [-400, 400] }}
          transition={{ duration: 3, repeat: Infinity, repeatDelay: 2, ease: "easeInOut" }}
        />
        
        {/* Card Content */}
        <div className="relative z-10">
          <div className="flex items-center justify-between mb-4 sm:mb-6">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-br from-[#8A2BE2] to-[#FF2FBF] flex items-center justify-center shadow-[0_0_15px_rgba(138,43,226,0.4)]">
                <Lock className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
              </div>
              <span className="text-[#0D0D0D] font-bold tracking-wide text-sm sm:text-base">FinaVault</span>
            </div>
            <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-[#8A2BE2]" />
          </div>
          
          <div className="mb-4 sm:mb-5">
            <p className="text-[#4A4A4A] text-xs sm:text-sm mb-1 font-medium">Gold Storage</p>
            <div className="flex items-baseline gap-2 flex-wrap">
              <span className="text-2xl sm:text-3xl font-bold bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent">
                {conversions[unit].value}
              </span>
              <span className="text-[#8A2BE2] text-xs sm:text-sm font-medium">{conversions[unit].label}</span>
            </div>
            <p className="text-[#4A4A4A]/80 text-xs sm:text-sm mt-1">≈ $78,450.00 USD</p>
          </div>
          
          {/* Unit Converter */}
          <div className="flex justify-center gap-2 mb-4">
            {units.map((u) => (
              <motion.button
                key={u}
                onClick={() => setUnit(u)}
                className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all ${
                  unit === u 
                    ? 'bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white shadow-[0_0_15px_rgba(138,43,226,0.3)]' 
                    : 'bg-[#8A2BE2]/10 text-[#8A2BE2] border border-[#8A2BE2]/20'
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {u}
              </motion.button>
            ))}
          </div>
          
          {/* Action Buttons */}
          <div className="flex items-center justify-center gap-3">
            {['Deposit', 'Buy Gold'].map((action, i) => (
              <motion.div
                key={action}
                className="px-4 sm:px-5 py-2 rounded-lg bg-[#8A2BE2]/10 border border-[#8A2BE2]/30 text-[#8A2BE2] text-xs font-medium cursor-pointer"
                whileHover={{ scale: 1.05, backgroundColor: 'rgba(138,43,226,0.2)', boxShadow: '0 0 15px rgba(138,43,226,0.3)' }}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.5 + i * 0.1 }}
              >
                {action}
              </motion.div>
            ))}
          </div>
        </div>
        
        {/* Corner Accent */}
        <div className="absolute bottom-0 right-0 w-24 sm:w-32 h-24 sm:h-32 bg-gradient-to-tl from-[#FF2FBF]/20 via-[#8A2BE2]/10 to-transparent rounded-tl-full" />
      </motion.div>
      
      {/* Floating info bubbles - Hidden on mobile */}
      <div className="hidden md:block">
        {[
          { text: '99.99% Pure', icon: BadgeCheck, x: -60, y: -20, delay: 2 },
          { text: 'Secured', icon: Shield, x: 280, y: 80, delay: 2.5 }
        ].map((bubble, i) => (
          <motion.div
            key={i}
            className="absolute px-3 py-2 rounded-xl bg-white border border-[#8A2BE2]/30 backdrop-blur-sm flex items-center gap-2 shadow-[0_4px_20px_rgba(138,43,226,0.15)]"
            style={{ left: bubble.x, top: bubble.y }}
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: [0, 1, 1, 0], scale: [0.5, 1, 1, 0.5] }}
            transition={{ delay: bubble.delay, duration: 4, repeat: Infinity, repeatDelay: 4 }}
          >
            <bubble.icon className="w-4 h-4 text-[#8A2BE2]" />
            <span className="text-[#0D0D0D] text-sm font-medium">{bubble.text}</span>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}

// Hero Section
function HeroSection() {
  const ref = useRef(null);
  const { t } = useLanguage();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], [0, 200]);
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);

  return (
    <section ref={ref} className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-[#FAFBFF] to-white">
        <GlowingOrb className="w-[600px] h-[600px] bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF]/15 -top-40 -right-40" />
        <GlowingOrb className="w-[400px] h-[400px] bg-[#B8860B]/10 bottom-0 left-0" delay={2} />
        <ParticleField count={50} />
        
        {/* Grid overlay */}
        <div className="absolute inset-0 opacity-10" style={{
          backgroundImage: 'linear-gradient(rgba(138,43,226,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(138,43,226,0.1) 1px, transparent 1px)',
          backgroundSize: '50px 50px'
        }} />
      </div>

      <motion.div style={{ y, opacity }} className="relative z-10 max-w-7xl mx-auto px-6 py-32">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Content */}
          <div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-[#8A2BE2]/30 bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF]/5 mb-8"
            >
              <motion.div animate={{ rotate: [0, 360] }} transition={{ duration: 8, repeat: Infinity, ease: "linear" }}>
                <Shield className="w-4 h-4 text-[#8A2BE2]" />
              </motion.div>
              <span className="text-sm text-[#8A2BE2] tracking-wide">{t('finavault.hero.badge')}</span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="text-6xl md:text-7xl lg:text-8xl font-extralight text-[#0D0D0D] mb-6 tracking-tight"
            >
              {t('finavault.hero.title')}
              <motion.span
                className="bg-gradient-to-r from-[#8A2BE2] via-[#FF66D8] to-[#FF2FBF] bg-clip-text text-transparent"
                animate={{ backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"] }}
                transition={{ duration: 5, repeat: Infinity }}
                style={{ backgroundSize: "200% 200%" }}
              >
                {t('finavault.hero.titleHighlight')}
              </motion.span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="text-2xl md:text-3xl text-[#8A2BE2] font-light mb-6"
            >
              {t('finavault.hero.subtitle')}
            </motion.p>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.5 }}
              className="text-xl text-[#4A4A4A] max-w-xl mb-10 leading-relaxed"
            >
              {t('finavault.hero.description')}
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
              className="flex flex-col sm:flex-row gap-4"
            >
              <Link to={createPageUrl("Home")} onClick={() => window.scrollTo(0, 0)}>
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} className="relative group">
                  <div className="absolute -inset-1 bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] rounded-full blur opacity-30 group-hover:opacity-60 transition-opacity" />
                  <GoldButton variant="primary">
                    <span className="flex items-center gap-2">{t('finavault.hero.cta1')} <ArrowRight className="w-4 h-4" /></span>
                  </GoldButton>
                </motion.div>
              </Link>

            </motion.div>
          </div>

          {/* Right Visual - Vault Card */}
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.3 }}
            className="flex justify-center items-center relative px-4 sm:px-0"
          >
            <VaultCard />
          </motion.div>
        </div>
      </motion.div>

      {/* Scroll Indicator */}
      <motion.div
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <div className="w-6 h-10 rounded-full border-2 border-[#8A2BE2]/30 flex justify-center pt-2">
          <motion.div
            className="w-1.5 h-3 rounded-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF]"
            animate={{ y: [0, 12, 0], opacity: [1, 0, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
          />
        </div>
      </motion.div>
    </section>
  );
}

// Value Pillars Section
function ValuePillars() {
  const ref = useRef(null);
  const { t } = useLanguage();
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const pillars = [
    {
      icon: Layers,
      title: t('finavault.pillars.1.title'),
      description: t('finavault.pillars.1.desc')
    },
    {
      icon: Database,
      title: t('finavault.pillars.2.title'),
      description: t('finavault.pillars.2.desc')
    },
    {
      icon: ScanLine,
      title: t('finavault.pillars.3.title'),
      description: t('finavault.pillars.3.desc')
    },
    {
      icon: Wallet,
      title: t('finavault.pillars.4.title'),
      description: t('finavault.pillars.4.desc')
    }
  ];

  return (
    <section ref={ref} className="relative py-32 bg-gradient-to-br from-[#FAFBFF] to-white overflow-hidden">
      <ParticleField count={25} />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(138,43,226,0.05)_0%,_transparent_70%)]" />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-[#0D0D0D] mb-4">
            {t('finavault.pillars.title')} <span className="text-[#8A2BE2]">{t('finavault.pillars.titleHighlight')}</span>
          </h2>
          <motion.div
            className="w-24 h-0.5 bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] mx-auto"
            initial={{ width: 0 }}
            animate={isInView ? { width: 96 } : {}}
            transition={{ duration: 0.8, delay: 0.3 }}
          />
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {pillars.map((pillar, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 50 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: i * 0.15 }}
              whileHover={{ y: -10 }}
              className="group relative p-8 rounded-2xl bg-white border border-[#8A2BE2]/20 hover:border-[#8A2BE2]/40 transition-all duration-500 shadow-[0_8px_32px_rgba(138,43,226,0.08)]"
            >
              <motion.div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-[#8A2BE2]/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

              <div className="relative z-10">
                <motion.div
                  className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#8A2BE2] to-[#FF2FBF] p-0.5 mb-6"
                  whileHover={{ rotate: 360 }}
                  transition={{ duration: 0.8 }}
                >
                  <div className="w-full h-full rounded-2xl bg-[#FAFBFF] flex items-center justify-center">
                    <motion.div
                      animate={{ boxShadow: ["0 0 0px rgba(138,43,226,0)", "0 0 20px rgba(138,43,226,0.5)", "0 0 0px rgba(138,43,226,0)"] }}
                      transition={{ duration: 2, repeat: Infinity, delay: i * 0.5 }}
                    >
                      <pillar.icon className="w-7 h-7 text-[#8A2BE2]" />
                    </motion.div>
                  </div>
                </motion.div>
                <h3 className="text-xl font-semibold text-[#0D0D0D] mb-3">{pillar.title}</h3>
                <p className="text-[#4A4A4A] text-sm leading-relaxed">{pillar.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

// Certificate Section
function CertificateSection() {
  const ref = useRef(null);
  const { t } = useLanguage();
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="relative py-32 bg-gradient-to-b from-[#FAFBFF] via-[#F4F6FC] to-[#FAFBFF] overflow-hidden">
      <GlowingOrb className="w-[500px] h-[500px] bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF]/10 -left-40 top-1/2 -translate-y-1/2" />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Floating Certificates */}
          <motion.div
            className="relative h-[400px]"
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8 }}
          >
            {/* Assay Certificate */}
            <motion.div
              className="absolute top-0 left-0 w-64 p-6 rounded-xl bg-white border border-[#8A2BE2]/30 shadow-[0_8px_32px_rgba(138,43,226,0.15)]"
              animate={isInView ? { y: [0, -10, 0], rotateY: [0, 5, 0] } : {}}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              style={{ transformStyle: 'preserve-3d' }}
            >
              <div className="flex items-center gap-3 mb-4">
                <FileCheck className="w-6 h-6 text-[#8A2BE2]" />
                <span className="text-[#0D0D0D] font-light">Assay Certificate</span>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between"><span className="text-[#4A4A4A]/80">Purity:</span><motion.span className="text-[#8A2BE2]" animate={{ opacity: [1, 0.5, 1] }} transition={{ duration: 1, repeat: Infinity }}>99.99%</motion.span></div>
                <div className="flex justify-between"><span className="text-[#4A4A4A]/80">Weight:</span><span className="text-[#0D0D0D]">1,000.00g</span></div>
                <div className="flex justify-between"><span className="text-[#4A4A4A]/80">Serial:</span><span className="text-[#0D0D0D]">AU-2024-00847</span></div>
              </div>
            </motion.div>

            {/* Vault Certificate */}
            <motion.div
              className="absolute top-20 right-0 w-64 p-6 rounded-xl bg-white border border-[#8A2BE2]/30 shadow-[0_8px_32px_rgba(138,43,226,0.15)]"
              animate={isInView ? { y: [0, 10, 0], rotateY: [0, -5, 0] } : {}}
              transition={{ duration: 4, delay: 1, repeat: Infinity, ease: "easeInOut" }}
              style={{ transformStyle: 'preserve-3d' }}
            >
              <div className="flex items-center gap-3 mb-4">
                <Building className="w-6 h-6 text-[#8A2BE2]" />
                <span className="text-[#0D0D0D] font-light">Vault Certificate</span>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between"><span className="text-[#4A4A4A]/80">Location:</span><span className="text-[#0D0D0D]">Dubai</span></div>
                <div className="flex justify-between"><span className="text-[#4A4A4A]/80">Vault ID:</span><span className="text-[#0D0D0D]">DXB-SEC-001</span></div>
                <div className="flex justify-between"><span className="text-[#4A4A4A]/80">Status:</span><span className="text-green-400">Secured</span></div>
              </div>
            </motion.div>

            {/* QR Code */}
            <motion.div
              className="absolute bottom-10 left-1/4 w-24 h-24 rounded-xl bg-white p-2"
              animate={isInView ? { scale: [1, 1.05, 1], boxShadow: ["0 0 0px rgba(138,43,226,0)", "0 0 30px rgba(138,43,226,0.4)", "0 0 0px rgba(138,43,226,0)"] } : {}}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <div className="w-full h-full bg-[#FAFBFF] rounded-lg flex items-center justify-center">
                <div className="grid grid-cols-4 gap-1">
                  {[...Array(16)].map((_, i) => (
                    <div key={i} className={`w-3 h-3 ${Math.random() > 0.5 ? 'bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF]' : 'bg-transparent'}`} />
                  ))}
                </div>
              </div>
            </motion.div>
          </motion.div>

          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <h2 className="text-4xl md:text-5xl font-bold text-[#0D0D0D] mb-6">
                        {t('finavault.cert.title')}
                        <span className="block text-[#8A2BE2]">{t('finavault.cert.titleHighlight')}</span>
                      </h2>
            <p className="text-xl text-[#4A4A4A] mb-8 leading-relaxed">
              {t('finavault.cert.description')}
            </p>

            <div className="grid grid-cols-2 gap-4">
              {[
                { label: "Purity Grade", value: "99.99%" },
                { label: "Weight Verified", value: "1 Kg" },
                { label: "Bar Serial", value: "AU-2024" },
                { label: "Vault Location", value: "Dubai" }
              ].map((item, i) => (
                <motion.div
                  key={i}
                  className="p-4 rounded-xl bg-white/50 border border-[#8A2BE2]/10"
                  initial={{ opacity: 0, y: 20 }}
                  animate={isInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.4 + i * 0.1 }}
                  whileHover={{ borderColor: "rgba(138,43,226,0.4)" }}
                >
                  <div className="text-xs text-[#4A4A4A]/80 mb-1">{item.label}</div>
                  <motion.div
                    className="text-lg text-[#8A2BE2] font-light"
                    initial={{ opacity: 0 }}
                    animate={isInView ? { opacity: 1 } : {}}
                    transition={{ duration: 0.5, delay: 0.6 + i * 0.1 }}
                  >
                    {item.value}
                  </motion.div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

// Vault Operations Section
function VaultOperationsSection() {
  const ref = useRef(null);
  const { t } = useLanguage();
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const steps = [
    { icon: ArrowDownToLine, title: "Deposit Gold", desc: "Gold bar slides into secure vault tray" },
    { icon: ScanLine, title: "Verification & Assay", desc: "Scanner verifies purity and authenticity" },
    { icon: Database, title: "Ledger Recording", desc: "Digital record created with timestamp" },
    { icon: Wallet, title: "Added to FinaWallet", desc: "Instantly available in your wallet" }
  ];

  return (
    <section ref={ref} className="relative py-32 bg-gradient-to-br from-[#FAFBFF] to-white overflow-hidden">
      <ParticleField count={20} />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-[#0D0D0D] mb-4">
            {t('finavault.operations.title')} <span className="text-[#8A2BE2]">{t('finavault.operations.titleHighlight')}</span>
          </h2>
        </motion.div>

        <div className="relative">
          {/* Connection line */}
          <motion.div
            className="absolute top-1/2 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-[#D4AF37]/30 to-transparent hidden lg:block"
            initial={{ scaleX: 0 }}
            animate={isInView ? { scaleX: 1 } : {}}
            transition={{ duration: 1.5, delay: 0.5 }}
          />

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step, i) => (
              <motion.div
                key={i}
                className="relative text-center"
                initial={{ opacity: 0, y: 50 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: i * 0.2 }}
              >
                {/* Step number */}
                <motion.div
                  className="absolute -top-4 left-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-black text-sm font-medium flex items-center justify-center z-10"
                  initial={{ scale: 0 }}
                  animate={isInView ? { scale: 1 } : {}}
                  transition={{ duration: 0.3, delay: 0.8 + i * 0.2, type: "spring" }}
                >
                  {i + 1}
                </motion.div>

                <motion.div
                  className="relative p-8 pt-12 rounded-2xl bg-white border border-[#8A2BE2]/20 hover:border-[#8A2BE2]/40 transition-all shadow-[0_8px_32px_rgba(138,43,226,0.08)]"
                  whileHover={{ y: -5, boxShadow: "0 20px 40px rgba(138,43,226,0.1)" }}
                >
                  <motion.div
                    className="w-16 h-16 mx-auto rounded-full bg-gradient-to-br from-[#8A2BE2]/20 to-[#FF2FBF]/10 flex items-center justify-center mb-4"
                    animate={isInView ? {
                      boxShadow: ["0 0 0px rgba(138,43,226,0)", "0 0 30px rgba(138,43,226,0.4)", "0 0 0px rgba(138,43,226,0)"]
                    } : {}}
                    transition={{ duration: 2, repeat: Infinity, delay: i * 0.5 }}
                  >
                    <step.icon className="w-7 h-7 text-[#8A2BE2]" />
                  </motion.div>
                  <h3 className="text-lg font-semibold text-[#0D0D0D] mb-2">{step.title}</h3>
                  <p className="text-sm text-[#4A4A4A]">{step.desc}</p>
                </motion.div>

                {/* Animated arrow */}
                {i < steps.length - 1 && (
                  <motion.div
                    className="hidden lg:block absolute top-1/2 -right-4 text-[#8A2BE2]"
                    animate={{ x: [0, 5, 0] }}
                    transition={{ duration: 1, repeat: Infinity }}
                  >
                    <ArrowRight className="w-6 h-6" />
                  </motion.div>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

// Security Section
function SecuritySection() {
  const ref = useRef(null);
  const { t } = useLanguage();
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const features = [
    { icon: Building, label: "Secure Physical Vaults" },
    { icon: Database, label: "Tamper-Proof Digital Ledger" },
    { icon: Lock, label: "Multi-Layer Encryption" },
    { icon: BadgeCheck, label: "Compliance-Ready Architecture" }
  ];

  return (
    <section ref={ref} className="relative py-32 bg-gradient-to-b from-[#FAFBFF] via-[#F4F6FC] to-[#FAFBFF] overflow-hidden">
      <GlowingOrb className="w-[400px] h-[400px] bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF]/10 right-0 top-1/2 -translate-y-1/2" />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Security Visual */}
          <motion.div
            className="relative flex justify-center"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ duration: 0.8 }}
          >
            <div className="relative">
              {/* Shield assembly animation */}
              <motion.div
                className="w-48 h-56 relative"
                animate={isInView ? { rotateY: [0, 5, -5, 0] } : {}}
                transition={{ duration: 6, repeat: Infinity }}
                style={{ transformStyle: 'preserve-3d' }}
              >
                {/* Shield layers */}
                <motion.div
                  className="absolute inset-0 rounded-t-full rounded-b-[40%] bg-gradient-to-b from-[#8A2BE2] to-[#FF2FBF]"
                  initial={{ scale: 0, opacity: 0 }}
                  animate={isInView ? { scale: 1, opacity: 1 } : {}}
                  transition={{ duration: 0.5, delay: 0.3 }}
                />
                <motion.div
                  className="absolute inset-2 rounded-t-full rounded-b-[40%] bg-[#FAFBFF]"
                  initial={{ scale: 0, opacity: 0 }}
                  animate={isInView ? { scale: 1, opacity: 1 } : {}}
                  transition={{ duration: 0.5, delay: 0.5 }}
                />
                <motion.div
                  className="absolute inset-4 rounded-t-full rounded-b-[40%] bg-gradient-to-b from-[#8A2BE2]/20 to-[#FF2FBF]/10 flex items-center justify-center"
                  initial={{ scale: 0, opacity: 0 }}
                  animate={isInView ? { scale: 1, opacity: 1 } : {}}
                  transition={{ duration: 0.5, delay: 0.7 }}
                >
                  <motion.div
                    animate={{ scale: [1, 1.1, 1] }}
                    transition={{ duration: 2, repeat: Infinity }}
                  >
                    <Lock className="w-16 h-16 text-[#8A2BE2]" />
                  </motion.div>
                </motion.div>
              </motion.div>

              {/* Orbiting particles */}
              {[...Array(6)].map((_, i) => (
                <motion.div
                  key={i}
                  className="absolute w-3 h-3 rounded-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF]/60"
                  style={{ top: '50%', left: '50%' }}
                  animate={{
                    x: Math.cos((i * 60 * Math.PI) / 180) * 120,
                    y: Math.sin((i * 60 * Math.PI) / 180) * 120,
                    opacity: [0.3, 1, 0.3]
                  }}
                  transition={{ duration: 3, delay: i * 0.2, repeat: Infinity }}
                />
              ))}

              {/* Fingerprint / biometric effect */}
              <motion.div
                className="absolute -bottom-8 left-1/2 -translate-x-1/2 w-16 h-16 rounded-full bg-white border border-[#8A2BE2]/30 flex items-center justify-center"
                animate={{ boxShadow: ["0 0 0px rgba(138,43,226,0)", "0 0 30px rgba(138,43,226,0.4)", "0 0 0px rgba(138,43,226,0)"] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <Fingerprint className="w-8 h-8 text-[#8A2BE2]" />
              </motion.div>
            </div>
          </motion.div>

          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <h2 className="text-4xl md:text-5xl font-bold text-[#0D0D0D] mb-6">
                        {t('finavault.security.title')}
                        <span className="block text-[#8A2BE2]">{t('finavault.security.titleHighlight')}</span>
                      </h2>
            <p className="text-xl text-[#4A4A4A] mb-8 leading-relaxed">
              {t('finavault.security.description')}
            </p>

            <div className="space-y-4">
              {features.map((feature, i) => (
                <motion.div
                  key={i}
                  className="flex items-center gap-4 p-4 rounded-xl bg-white/50 border border-[#8A2BE2]/10 hover:border-[#8A2BE2]/30 transition-all cursor-pointer group"
                  initial={{ opacity: 0, x: 30 }}
                  animate={isInView ? { opacity: 1, x: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.3 + i * 0.1 }}
                  whileHover={{ x: 10 }}
                >
                  <motion.div
                    className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#8A2BE2]/20 to-[#FF2FBF]/10 flex items-center justify-center"
                    whileHover={{ rotate: 360 }}
                    transition={{ duration: 0.5 }}
                  >
                    <feature.icon className="w-5 h-5 text-[#8A2BE2]" />
                  </motion.div>
                  <span className="text-[#333333] group-hover:text-[#0D0D0D] transition-colors">{feature.label}</span>
                  <CheckCircle className="w-4 h-4 text-green-500 ml-auto" />
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}





// Vault to Wallet Integration
function IntegrationSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="relative py-32 bg-gradient-to-br from-[#FAFBFF] to-white overflow-hidden">
      <ParticleField count={30} />

      <div className="relative z-10 max-w-5xl mx-auto px-6">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-[#0D0D0D] mb-4">
            FinaVault → <span className="text-[#8A2BE2]">FinaPay</span>
          </h2>
          <p className="text-xl text-[#4A4A4A]">
            Deposit physical gold → Instantly usable in your wallet
          </p>
        </motion.div>

        <motion.div
          className="flex flex-col md:flex-row items-center justify-center gap-8"
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          {/* Vault Icon */}
          <motion.div
            className="w-32 h-32 rounded-2xl bg-white border border-[#8A2BE2]/30 flex items-center justify-center shadow-[0_8px_32px_rgba(138,43,226,0.1)]"
            animate={isInView ? { boxShadow: ["0 0 0px rgba(138,43,226,0)", "0 0 40px rgba(138,43,226,0.3)", "0 0 0px rgba(138,43,226,0)"] } : {}}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <Building className="w-12 h-12 text-[#8A2BE2]" />
          </motion.div>

          {/* Animated connection */}
          <div className="relative w-32 md:w-48 h-2">
            <div className="absolute inset-0 bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF]/10 rounded-full" />
            <motion.div
              className="absolute left-0 w-8 h-full bg-gradient-to-r from-[#8A2BE2] to-[#F5E6A3] rounded-full"
              animate={{ x: [0, 120, 0] }}
              transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
            />
            {/* Particles */}
            {[...Array(5)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-2 h-2 rounded-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF]"
                style={{ top: -3 }}
                animate={{ x: [0, 150], opacity: [0, 1, 0] }}
                transition={{ duration: 1.5, delay: i * 0.3, repeat: Infinity }}
              />
            ))}
          </div>

          {/* Wallet Icon */}
          <motion.div
            className="w-32 h-32 rounded-2xl bg-white border border-[#8A2BE2]/30 flex items-center justify-center shadow-[0_8px_32px_rgba(138,43,226,0.1)]"
            animate={isInView ? { boxShadow: ["0 0 0px rgba(138,43,226,0)", "0 0 40px rgba(138,43,226,0.3)", "0 0 0px rgba(138,43,226,0)"] } : {}}
            transition={{ duration: 2, repeat: Infinity, delay: 1 }}
          >
            <Wallet className="w-12 h-12 text-[#8A2BE2]" />
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}

// CTA Section
function CTASection() {
  const ref = useRef(null);
  const { t } = useLanguage();
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="relative py-32 bg-gradient-to-b from-[#FAFBFF] via-[#F4F6FC] to-[#FAFBFF] overflow-hidden">
      <motion.div
        className="absolute inset-0"
        initial={{ opacity: 0 }}
        animate={isInView ? { opacity: 1 } : {}}
      >
        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-transparent via-[#D4AF37]/10 to-transparent"
          animate={{ x: ["-100%", "100%"] }}
          transition={{ duration: 5, repeat: Infinity, ease: "linear" }}
        />
      </motion.div>

      <GlowingOrb className="w-[600px] h-[600px] bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF]/15 left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2" />
      <ParticleField count={50} />

      <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
        <motion.h2
          className="text-5xl md:text-6xl lg:text-7xl font-bold text-[#0D0D0D] mb-6"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          {t('finavault.cta.title')}
          <motion.span
            className="block bg-gradient-to-r from-[#8A2BE2] via-[#FF66D8] to-[#FF2FBF] bg-clip-text text-transparent"
            animate={{ backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"] }}
            transition={{ duration: 5, repeat: Infinity }}
            style={{ backgroundSize: "200% 200%" }}
          >
            {t('finavault.cta.titleHighlight')}
          </motion.span>
        </motion.h2>

        <motion.p
          className="text-xl text-[#4A4A4A] mb-10 max-w-2xl mx-auto"
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          {t('finavault.cta.description')}
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <Link to={createPageUrl("Home")} onClick={() => window.scrollTo(0, 0)}>
            <motion.div
              className="inline-block relative group"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <motion.div
                className="absolute -inset-2 bg-gradient-to-r from-[#8A2BE2] via-[#FF66D8] to-[#FF2FBF] rounded-full blur-lg opacity-40"
                animate={{ opacity: [0.3, 0.6, 0.3] }}
                transition={{ duration: 2, repeat: Infinity }}
              />
              <GoldButton variant="primary" className="text-lg px-12 py-4 relative">
                <span className="flex items-center gap-2">
                  {t('finavault.cta.button')} <ArrowRight className="w-5 h-5" />
                </span>
              </GoldButton>
            </motion.div>
          </Link>
        </motion.div>
      </div>
    </section>
  );
}

// Main Page
export default function FinaVault() {
  return (
    <main className="bg-gradient-to-br from-[#FAFBFF] via-[#F4F6FC] to-[#FFFFFF]">
      <HeroSection />
      <ValuePillars />
      <CertificateSection />
      <VaultOperationsSection />
      <IntegrationSection />
      <CTASection />
    </main>
  );
}