import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import DashboardSidebar from '@/components/dashboard/DashboardSidebar';
import DebitCardHero from '@/components/debitcard/DebitCardHero';
import WalletBalances from '@/components/debitcard/WalletBalances';
import TransferModal from '@/components/debitcard/TransferModal';
import CardControls from '@/components/debitcard/CardControls';
import TransactionsTable from '@/components/debitcard/TransactionsTable';
import SpendingAnalytics from '@/components/debitcard/SpendingAnalytics';
import ComplianceCard from '@/components/debitcard/ComplianceCard';
import HowItWorksPanel from '@/components/debitcard/HowItWorksPanel';
import { Plus, FileText } from 'lucide-react';
import { Button } from "@/components/ui/button";

export default function DebitCardUser() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [showTransferModal, setShowTransferModal] = useState(false);
  
  // Wallet balances
  const [finaPayBalance, setFinaPayBalance] = useState({
    goldGrams: 45.7823,
    goldValueUSD: 3892.50,
    goldValueAED: 14285.28
  });
  
  const [cardWalletBalance, setCardWalletBalance] = useState({
    goldGrams: 12.5000,
    spendingBalanceUSD: 1062.50,
    baseCurrency: 'USD'
  });

  const [goldPrice] = useState(85.00); // USD per gram

  useEffect(() => {
    const storedUser = localStorage.getItem('finatrades_user');
    if (!storedUser) {
      navigate(createPageUrl("Home"));
      return;
    }
    setUser(JSON.parse(storedUser));
  }, [navigate]);

  const handleTransfer = (grams) => {
    setFinaPayBalance(prev => ({
      ...prev,
      goldGrams: prev.goldGrams - grams,
      goldValueUSD: (prev.goldGrams - grams) * goldPrice,
      goldValueAED: (prev.goldGrams - grams) * goldPrice * 3.67
    }));
    setCardWalletBalance(prev => ({
      ...prev,
      goldGrams: prev.goldGrams + grams,
      spendingBalanceUSD: (prev.goldGrams + grams) * goldPrice
    }));
    setShowTransferModal(false);
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FAFBFF] via-[#F4F6FC] to-[#FFFFFF]">
      <div className="flex">
        <DashboardSidebar currentPage="DebitCardUser" user={user} />

        <main className="flex-1 min-h-screen">
          {/* Header */}
          <header className="sticky top-0 z-30 bg-white border-b border-[#8A2BE2]/20 px-4 sm:px-6 py-3 sm:py-4 shadow-sm">
            <div className="flex items-center justify-between ml-12 lg:ml-0">
              <div>
                <h1 className="text-base sm:text-xl font-semibold text-[#0D0D0D] tracking-tight">FinaCard</h1>
                <p className="text-[#4A4A4A] text-[10px] sm:text-xs">Gold-Backed Debit Card</p>
              </div>
            </div>
          </header>

          <div className="p-4 sm:p-6 space-y-4 sm:space-y-8 max-w-7xl mx-auto">
            {/* Hero Section */}
            <DebitCardHero userName={user?.full_name} />

            {/* Wallet Balances */}
            <WalletBalances 
              finaPayBalance={finaPayBalance}
              cardWalletBalance={cardWalletBalance}
              goldPrice={goldPrice}
              onTransferClick={() => setShowTransferModal(true)}
            />

            {/* How It Works */}
            <HowItWorksPanel />

            {/* Card Controls */}
            <CardControls />

            {/* Transactions */}
            <TransactionsTable />

            {/* Analytics */}
            <SpendingAnalytics />

            {/* Compliance */}
            <ComplianceCard />

            {/* Bottom CTA */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex flex-col sm:flex-row gap-4 justify-center pt-4 pb-8"
            >
              <Button 
                onClick={() => setShowTransferModal(true)}
                className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white font-semibold px-8 py-6 rounded-xl hover:shadow-[0_0_30px_rgba(138,43,226,0.3)] transition-all"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Funds from FinaPay
              </Button>
              <Button 
                variant="outline"
                className="border-[#8A2BE2]/30 text-[#FF2FBF] hover:bg-[#8A2BE2]/10 px-8 py-6 rounded-xl"
              >
                <FileText className="w-4 h-4 mr-2" />
                View Full Card Statements
              </Button>
            </motion.div>
          </div>
        </main>
      </div>

      {/* Transfer Modal */}
      <TransferModal 
        isOpen={showTransferModal}
        onClose={() => setShowTransferModal(false)}
        availableGold={finaPayBalance.goldGrams}
        goldPrice={goldPrice}
        onConfirm={handleTransfer}
      />
    </div>
  );
}