import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { 
  Settings, User, Shield, Bell, Clock, Key, Smartphone,
  Mail, Globe, CheckCircle, Eye, EyeOff, LogOut, Fingerprint, Plus, Trash2
} from 'lucide-react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";

import DashboardSidebar from '@/components/dashboard/DashboardSidebar';
import NotificationPreferences from '@/components/notifications/NotificationPreferences';

export default function SettingsUser() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState('profile');
  const [isLoading, setIsLoading] = useState(false);
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);



  useEffect(() => {
    const storedUser = localStorage.getItem('finatrades_user');
    if (!storedUser) {
      navigate(createPageUrl("Home"));
      return;
    }
    setUser(JSON.parse(storedUser));
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('finatrades_user');
    navigate(createPageUrl("Home"));
  };

  const tabs = [
    { id: 'profile', label: 'Account Details', icon: User },
    { id: 'kyc', label: 'KYC Status', icon: Shield },
    { id: 'security', label: 'Security', icon: Key },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'history', label: 'Login History', icon: Clock },
  ];

  const loginHistory = [
    { date: '2024-12-05 14:30', device: 'Chrome on Windows', location: 'Dubai, UAE', ip: '192.168.1.xxx' },
    { date: '2024-12-04 09:15', device: 'Safari on iPhone', location: 'Dubai, UAE', ip: '192.168.1.xxx' },
    { date: '2024-12-03 18:45', device: 'Chrome on MacOS', location: 'Geneva, CH', ip: '10.0.0.xxx' },
  ];

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FAFBFF] via-[#F4F6FC] to-[#FFFFFF]">
      
      <div className="flex">
        {/* Sidebar */}
        <DashboardSidebar currentPage="SettingsUser" user={user} />

        {/* Main Content */}
        <main className="flex-1 min-h-screen">
          {/* Top Header */}
          <header className="sticky top-0 z-30 bg-white border-b border-[#8A2BE2]/20 px-4 sm:px-6 py-3 sm:py-4 shadow-sm">
            <div className="flex items-center gap-2 sm:gap-4 ml-12 lg:ml-0">
              <div className="flex items-center gap-2 sm:gap-3">
                <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg sm:rounded-xl bg-gradient-to-r from-gray-500 to-slate-600 flex items-center justify-center">
                  <Settings className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
                </div>
                <div>
                  <h1 className="text-base sm:text-xl font-bold text-[#0D0D0D]">Settings</h1>
                  <p className="text-[#4A4A4A] text-[10px] sm:text-xs hidden sm:block">Manage your account preferences</p>
                </div>
              </div>
            </div>
          </header>

          <div className="p-4 sm:p-6">
            <div className="max-w-4xl mx-auto">
              {/* Settings Tabs */}
              <div className="flex gap-1.5 sm:gap-2 mb-4 sm:mb-6 overflow-x-auto pb-2 scrollbar-hide">
                {tabs.map(tab => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-2 rounded-lg sm:rounded-xl transition-all whitespace-nowrap text-xs sm:text-sm ${
                      activeTab === tab.id
                        ? 'bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white font-medium'
                        : 'bg-[#F4F6FC] text-[#4A4A4A] hover:bg-[#8A2BE2]/10 hover:text-[#0D0D0D]'
                    }`}
                  >
                    <tab.icon className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                    <span className="hidden sm:inline">{tab.label}</span>
                    <span className="sm:hidden">{tab.id === 'profile' ? 'Account' : tab.id === 'notifications' ? 'Alerts' : tab.id === 'history' ? 'History' : tab.label}</span>
                  </button>
                ))}
              </div>

              {/* Content */}
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-white border border-[#8A2BE2]/20 rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-sm"
            >
              {/* Profile Tab */}
              {activeTab === 'profile' && (
                <div className="space-y-4 sm:space-y-6">
                  <h2 className="text-lg sm:text-xl font-bold text-[#0D0D0D] mb-4 sm:mb-6">Account Details</h2>
                  
                  <div className="flex items-center gap-4 sm:gap-6 mb-6 sm:mb-8">
                    <div className="w-14 h-14 sm:w-20 sm:h-20 rounded-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] flex items-center justify-center text-white text-xl sm:text-2xl font-bold flex-shrink-0">
                      {user.full_name?.charAt(0) || 'U'}
                    </div>
                    <div className="min-w-0">
                      <h3 className="text-base sm:text-xl font-bold text-[#0D0D0D] truncate">{user.full_name}</h3>
                      <p className="text-[#4A4A4A] text-sm truncate">{user.email}</p>
                      <span className="inline-block mt-1 sm:mt-2 px-2 sm:px-3 py-0.5 sm:py-1 rounded-full text-[10px] sm:text-xs bg-amber-500/20 text-amber-600 capitalize">
                        {user.account_type || 'Personal'} Account
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                    <div>
                      <label className="text-black font-medium text-sm mb-2 block">Full Name</label>
                      <Input
                        value={user.full_name || ''}
                        className="bg-[#F4F6FC] border-[#8A2BE2]/20 text-black"
                        readOnly
                      />
                    </div>
                    <div>
                      <label className="text-black font-medium text-sm mb-2 block">Email</label>
                      <Input
                        value={user.email || ''}
                        className="bg-[#F4F6FC] border-[#8A2BE2]/20 text-black"
                        readOnly
                      />
                    </div>
                    <div>
                      <label className="text-black font-medium text-sm mb-2 block">Account Type</label>
                      <Input
                        value={user.account_type || 'Personal'}
                        className="bg-[#F4F6FC] border-[#8A2BE2]/20 text-black capitalize"
                        readOnly
                      />
                    </div>
                    <div>
                      <label className="text-black font-medium text-sm mb-2 block">Member Since</label>
                      <Input
                        value="December 2024"
                        className="bg-[#F4F6FC] border-[#8A2BE2]/20 text-black"
                        readOnly
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* KYC Tab */}
              {activeTab === 'kyc' && (
                <div className="space-y-4 sm:space-y-6">
                  <h2 className="text-lg sm:text-xl font-bold text-[#0D0D0D] mb-4 sm:mb-6">KYC Verification Status</h2>
                  
                  <div className="p-4 sm:p-6 bg-amber-500/10 rounded-lg sm:rounded-xl border border-amber-500/30">
                    <div className="flex items-center gap-3 sm:gap-4">
                      <div className="w-12 h-12 sm:w-16 sm:h-16 rounded-full bg-yellow-500/20 flex items-center justify-center flex-shrink-0">
                        <Clock className="w-6 h-6 sm:w-8 sm:h-8 text-yellow-400" />
                      </div>
                      <div>
                        <h3 className="text-base sm:text-xl font-bold text-[#0D0D0D]">Pending Review</h3>
                        <p className="text-[#4A4A4A] text-xs sm:text-base">Your documents are being verified</p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2 sm:space-y-4">
                    {[
                      { label: 'Personal Details', status: 'completed' },
                      { label: 'ID Document', status: 'completed' },
                      { label: 'Face Verification', status: 'completed' },
                      { label: 'Address Proof', status: 'completed' },
                      { label: 'Admin Review', status: 'pending' },
                    ].map((step, i) => (
                      <div key={i} className="flex items-center gap-3 sm:gap-4 p-3 sm:p-4 bg-[#F4F6FC] rounded-lg sm:rounded-xl">
                        <div className={`w-7 h-7 sm:w-8 sm:h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                          step.status === 'completed' ? 'bg-green-500/20' : 'bg-yellow-500/20'
                        }`}>
                          {step.status === 'completed' ? (
                            <CheckCircle className="w-4 h-4 sm:w-5 sm:h-5 text-green-400" />
                          ) : (
                            <Clock className="w-4 h-4 sm:w-5 sm:h-5 text-yellow-400" />
                          )}
                        </div>
                        <span className="text-[#0D0D0D] text-sm sm:text-base flex-1">{step.label}</span>
                        <span className={`text-xs sm:text-sm capitalize ${
                          step.status === 'completed' ? 'text-green-400' : 'text-yellow-400'
                        }`}>
                          {step.status}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Security Tab */}
              {activeTab === 'security' && (
                <div className="space-y-4 sm:space-y-6">
                  <h2 className="text-lg sm:text-xl font-bold text-[#0D0D0D] mb-4 sm:mb-6">Security Settings</h2>

                  {/* Change Password */}
                  <div className="p-3 sm:p-4 bg-[#F4F6FC] rounded-lg sm:rounded-xl border border-[#8A2BE2]/10">
                    <h3 className="text-black font-medium text-sm sm:text-base mb-3 sm:mb-4">Change Password</h3>
                    <div className="space-y-4">
                      <div className="relative">
                        <Input
                          type={showCurrentPassword ? 'text' : 'password'}
                          placeholder="Current Password"
                          className="bg-white border-[#8A2BE2]/20 text-black pr-10"
                        />
                        <button
                          onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-black/60"
                        >
                          {showCurrentPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                      <div className="relative">
                        <Input
                          type={showNewPassword ? 'text' : 'password'}
                          placeholder="New Password"
                          className="bg-white border-[#8A2BE2]/20 text-black pr-10"
                        />
                        <button
                          onClick={() => setShowNewPassword(!showNewPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-black/60"
                        >
                          {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                      <Input
                        type="password"
                        placeholder="Confirm New Password"
                        className="bg-white border-[#8A2BE2]/20 text-black"
                      />
                      <Button className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white font-bold hover:opacity-90">
                        Update Password
                      </Button>
                    </div>
                  </div>

                  {/* 2FA */}
                  <div className="p-3 sm:p-4 bg-[#F4F6FC] rounded-lg sm:rounded-xl border border-[#8A2BE2]/10">
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2 sm:gap-3 min-w-0">
                        <Smartphone className="w-4 h-4 sm:w-5 sm:h-5 text-[#8A2BE2] flex-shrink-0" />
                        <div className="min-w-0">
                          <h3 className="text-black font-medium text-sm sm:text-base">Two-Factor Authentication</h3>
                          <p className="text-black/70 text-[10px] sm:text-sm">Add an extra layer of security</p>
                        </div>
                      </div>
                      <Switch />
                    </div>
                  </div>

                  {/* Passkeys */}
                  <div className="p-3 sm:p-4 bg-[#F4F6FC] rounded-lg sm:rounded-xl border border-[#8A2BE2]/10">
                    <div className="flex items-center justify-between gap-3 mb-4">
                      <div className="flex items-center gap-2 sm:gap-3 min-w-0">
                        <Fingerprint className="w-4 h-4 sm:w-5 sm:h-5 text-[#8A2BE2] flex-shrink-0" />
                        <div className="min-w-0">
                          <h3 className="text-black font-medium text-sm sm:text-base">Passkeys</h3>
                          <p className="text-black/70 text-[10px] sm:text-sm">Sign in securely without a password using biometrics or device PIN</p>
                        </div>
                      </div>
                    </div>
                    
                    {/* Registered Passkeys */}
                    <div className="space-y-2 mb-4">
                      <p className="text-black/70 text-xs uppercase tracking-wider">Registered Passkeys</p>
                      <div className="space-y-2">
                        {/* Example passkey - would be dynamic in production */}
                        <div className="flex items-center justify-between p-3 bg-white rounded-lg border border-[#8A2BE2]/10">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-[#8A2BE2]/10 flex items-center justify-center">
                            <Fingerprint className="w-4 h-4 text-[#8A2BE2]" />
                          </div>
                          <div>
                            <p className="text-black text-sm font-medium">iPhone 15 Pro</p>
                            <p className="text-black/60 text-xs">Added Dec 1, 2024</p>
                          </div>
                        </div>
                        <button className="p-2 rounded-lg hover:bg-red-500/10 text-black/60 hover:text-red-600 transition-colors">
                          <Trash2 className="w-4 h-4" />
                        </button>
                        </div>
                        <div className="flex items-center justify-between p-3 bg-white rounded-lg border border-[#8A2BE2]/10">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-[#8A2BE2]/10 flex items-center justify-center">
                            <Fingerprint className="w-4 h-4 text-[#8A2BE2]" />
                          </div>
                          <div>
                            <p className="text-black text-sm font-medium">MacBook Pro</p>
                            <p className="text-black/60 text-xs">Added Nov 15, 2024</p>
                          </div>
                        </div>
                        <button className="p-2 rounded-lg hover:bg-red-500/10 text-black/60 hover:text-red-600 transition-colors">
                          <Trash2 className="w-4 h-4" />
                        </button>
                        </div>
                      </div>
                    </div>

                    <Button 
                      variant="outline" 
                      className="w-full border-[#8A2BE2]/30 text-[#FF2FBF] hover:bg-[#8A2BE2]/10"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Add New Passkey
                    </Button>
                  </div>
                </div>
              )}

              {/* Notifications Tab */}
              {activeTab === 'notifications' && (
                <NotificationPreferences userEmail={user?.email} />
              )}

              {/* Login History Tab */}
              {activeTab === 'history' && (
                <div className="space-y-4 sm:space-y-6">
                  <h2 className="text-lg sm:text-xl font-bold text-[#0D0D0D] mb-4 sm:mb-6">Login History</h2>

                  <div className="space-y-2 sm:space-y-3">
                    {loginHistory.map((log, i) => (
                      <div key={i} className="flex items-center justify-between gap-3 p-3 sm:p-4 bg-[#F4F6FC] rounded-lg sm:rounded-xl">
                        <div className="flex items-center gap-3 sm:gap-4 min-w-0">
                          <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-[#8A2BE2]/10 flex items-center justify-center flex-shrink-0">
                            <Globe className="w-4 h-4 sm:w-5 sm:h-5 text-[#8A2BE2]" />
                          </div>
                          <div className="min-w-0">
                            <p className="text-black font-medium text-sm sm:text-base truncate">{log.device}</p>
                            <p className="text-black/60 text-[10px] sm:text-sm truncate">{log.location}</p>
                          </div>
                        </div>
                        <span className="text-black/60 text-[10px] sm:text-sm whitespace-nowrap">{log.date.split(' ')[0]}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </motion.div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}