import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Vault, Download, CheckCircle, XCircle, Package, Truck, MapPin, Scale } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

import AdminSidebar from '@/components/admin/AdminSidebar';
import AdminTopBar from '@/components/admin/AdminTopBar';
import AdminTable from '@/components/admin/AdminTable';
import AdminFilterBar from '@/components/admin/AdminFilterBar';
import AdminStatusBadge from '@/components/admin/AdminStatusBadge';
import AdminDrawer from '@/components/admin/AdminDrawer';

const sampleDeposits = [
  { id: 'DEP-8892', user: 'Ahmed Al-Rashid', vault: 'Dubai', declaredWeight: 500, type: 'Bars', status: 'submitted', submittedDate: '2024-12-04' },
  { id: 'DEP-8893', user: 'Swiss Metals AG', vault: 'Switzerland', declaredWeight: 2500, type: 'Mixed', status: 'under_review', submittedDate: '2024-12-03' },
  { id: 'DEP-8894', user: 'Sarah Thompson', vault: 'Dubai', declaredWeight: 100, type: 'Coins', status: 'received', submittedDate: '2024-12-02' },
];

const sampleWithdrawals = [
  { id: 'WTH-2241', user: 'Mohammed Hassan', type: 'Sell', goldRequested: 250, payoutMethod: 'Bank Transfer', status: 'pending', requestedDate: '2024-12-04' },
  { id: 'WTH-2242', user: 'Swiss Metals AG', type: 'Physical', goldRequested: 1000, payoutMethod: 'Pickup', status: 'in_review', requestedDate: '2024-12-03' },
];

export default function AdminVault() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [role, setRole] = useState('Operations');
  const [activeTab, setActiveTab] = useState('deposits');
  const [searchValue, setSearchValue] = useState('');
  const [selectedItem, setSelectedItem] = useState(null);
  const [drawerOpen, setDrawerOpen] = useState(false);

  useEffect(() => {
    const storedUser = localStorage.getItem('finatrades_user');
    if (!storedUser) {
      navigate(createPageUrl("SignIn"));
      return;
    }
    const userData = JSON.parse(storedUser);
    if (!userData.is_admin) {
      navigate(createPageUrl("UserDashboard"));
      return;
    }
    setUser(userData);
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('finatrades_user');
    navigate(createPageUrl("Home"));
  };

  const handleReview = (item) => {
    setSelectedItem(item);
    setDrawerOpen(true);
  };

  const depositColumns = [
    { header: 'Request ID', accessor: 'id' },
    { header: 'User / Company', accessor: 'user' },
    { header: 'Vault', accessor: 'vault', render: (val) => <span className="flex items-center gap-1"><MapPin className="w-3 h-3 text-[#8A2BE2]" />{val}</span> },
    { header: 'Declared Weight', accessor: 'declaredWeight', render: (val) => `${val}g` },
    { header: 'Type', accessor: 'type' },
    { header: 'Status', accessor: 'status', render: (val) => <AdminStatusBadge status={val} /> },
    { header: 'Submitted', accessor: 'submittedDate' },
  ];

  const withdrawalColumns = [
    { header: 'Request ID', accessor: 'id' },
    { header: 'User', accessor: 'user' },
    { header: 'Type', accessor: 'type', render: (val) => <span className={`px-2 py-1 rounded text-xs ${val === 'Sell' ? 'bg-green-500/20 text-green-400' : 'bg-blue-500/20 text-blue-400'}`}>{val}</span> },
    { header: 'Gold Requested', accessor: 'goldRequested', render: (val) => `${val}g` },
    { header: 'Payout Method', accessor: 'payoutMethod' },
    { header: 'Status', accessor: 'status', render: (val) => <AdminStatusBadge status={val} /> },
    { header: 'Requested', accessor: 'requestedDate' },
  ];

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FAFBFF] via-[#F4F6FC] to-[#FFFFFF]">
      <AdminSidebar currentSection="vault" onLogout={handleLogout} />
      
      <div className="ml-64">
        <AdminTopBar user={user} role={role} onRoleChange={setRole} />
        
        <main className="p-6 space-y-6">
          <div>
            <h1 className="text-2xl font-bold text-[#0D0D0D] flex items-center gap-3">
              <Vault className="w-7 h-7 text-[#8A2BE2]" />
              FinaVault Management
            </h1>
            <p className="text-[#4A4A4A] text-sm">Manage gold deposits and withdrawal requests</p>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="bg-white border border-[#8A2BE2]/10 p-1 shadow-sm">
              <TabsTrigger value="deposits" className="data-[state=active]:bg-[#8A2BE2]/20 data-[state=active]:text-[#FF2FBF]">Deposits</TabsTrigger>
              <TabsTrigger value="withdrawals" className="data-[state=active]:bg-[#8A2BE2]/20 data-[state=active]:text-[#FF2FBF]">Withdrawals</TabsTrigger>
            </TabsList>

            <TabsContent value="deposits" className="mt-4">
              <AdminTable columns={depositColumns} data={sampleDeposits} onRowAction={handleReview} actionLabel="Review" />
            </TabsContent>

            <TabsContent value="withdrawals" className="mt-4">
              <AdminTable columns={withdrawalColumns} data={sampleWithdrawals} onRowAction={handleReview} actionLabel="Review" />
            </TabsContent>
          </Tabs>
        </main>
      </div>

      <AdminDrawer
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        title={selectedItem?.id || 'Review'}
        subtitle={selectedItem?.user}
        footer={
          <div className="flex items-center justify-end gap-3">
            <Button variant="outline" className="border-red-500/30 text-red-400">Reject</Button>
            <Button className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white font-bold">Update Status</Button>
          </div>
        }
      >
        {selectedItem && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-[#F4F6FC] rounded-lg p-4 border border-[#8A2BE2]/10">
                <p className="text-[#4A4A4A] text-xs uppercase mb-1">User</p>
                <p className="text-[#0D0D0D]">{selectedItem.user}</p>
              </div>
              <div className="bg-[#F4F6FC] rounded-lg p-4 border border-[#8A2BE2]/10">
                <p className="text-[#4A4A4A] text-xs uppercase mb-1">Weight</p>
                <p className="text-[#0D0D0D]">{selectedItem.declaredWeight || selectedItem.goldRequested}g</p>
              </div>
            </div>
          </div>
        )}
      </AdminDrawer>
    </div>
  );
}