import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { FileText, Download, Eye, ChevronDown, ChevronUp } from 'lucide-react';
import { Button } from "@/components/ui/button";

import AdminSidebar from '@/components/admin/AdminSidebar';
import AdminTopBar from '@/components/admin/AdminTopBar';
import AdminFilterBar from '@/components/admin/AdminFilterBar';

const sampleLogs = [
  { id: 1, timestamp: '2024-12-04 14:32:15', adminUser: 'admin@finatrades.com', module: 'KYC', actionType: 'Approve', objectId: 'KYC-4521', oldValue: '{"status":"pending"}', newValue: '{"status":"approved"}' },
  { id: 2, timestamp: '2024-12-04 14:28:42', adminUser: 'compliance@finatrades.com', module: 'BNSL', actionType: 'Rate change', objectId: 'RATE-12M', oldValue: '{"rate":9.5}', newValue: '{"rate":10}' },
  { id: 3, timestamp: '2024-12-04 13:45:20', adminUser: 'ops@finatrades.com', module: 'Vault', actionType: 'Update', objectId: 'DEP-8892', oldValue: '{"status":"submitted"}', newValue: '{"status":"received"}' },
];

const moduleColors = {
  KYC: 'bg-blue-500/20 text-blue-400',
  Vault: 'bg-amber-500/20 text-amber-400',
  BNSL: 'bg-green-500/20 text-green-400',
  Card: 'bg-purple-500/20 text-purple-400',
  Trade: 'bg-pink-500/20 text-pink-400',
};

const actionColors = {
  Create: 'text-green-400',
  Update: 'text-blue-400',
  Approve: 'text-green-400',
  Reject: 'text-red-400',
  'Rate change': 'text-amber-400',
};

export default function AdminAuditLogs() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [role, setRole] = useState('Admin');
  const [searchValue, setSearchValue] = useState('');
  const [moduleFilter, setModuleFilter] = useState('all');
  const [expandedLog, setExpandedLog] = useState(null);

  useEffect(() => {
    const storedUser = localStorage.getItem('finatrades_user');
    if (!storedUser) {
      navigate(createPageUrl("SignIn"));
      return;
    }
    const userData = JSON.parse(storedUser);
    if (!userData.is_admin) {
      navigate(createPageUrl("UserDashboard"));
      return;
    }
    setUser(userData);
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('finatrades_user');
    navigate(createPageUrl("Home"));
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FAFBFF] via-[#F4F6FC] to-[#FFFFFF]">
      <AdminSidebar currentSection="audit" onLogout={handleLogout} />
      
      <div className="ml-64">
        <AdminTopBar user={user} role={role} onRoleChange={setRole} />
        
        <main className="p-6 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-[#0D0D0D] flex items-center gap-3">
                <FileText className="w-7 h-7 text-[#8A2BE2]" />
                Audit Logs
              </h1>
            </div>
            <Button variant="outline" className="border-[#8A2BE2]/30 text-[#FF2FBF]">
              <Download className="w-4 h-4 mr-2" />
              Export Logs
            </Button>
          </div>

          <AdminFilterBar
            searchPlaceholder="Search by object ID or admin..."
            searchValue={searchValue}
            onSearchChange={setSearchValue}
            filters={[
              { value: moduleFilter, onChange: setModuleFilter, placeholder: 'Module', allLabel: 'All Modules', options: [{ value: 'KYC', label: 'KYC' }, { value: 'Vault', label: 'Vault' }, { value: 'BNSL', label: 'BNSL' }] }
            ]}
          />

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white border border-[#8A2BE2]/20 rounded-2xl overflow-hidden shadow-sm">
            <table className="w-full">
              <thead>
                <tr className="border-b border-white/10">
                  <th className="px-6 py-4 text-left text-[#4A4A4A] text-xs uppercase">Timestamp</th>
                  <th className="px-6 py-4 text-left text-[#4A4A4A] text-xs uppercase">Admin User</th>
                  <th className="px-6 py-4 text-left text-[#4A4A4A] text-xs uppercase">Module</th>
                  <th className="px-6 py-4 text-left text-[#4A4A4A] text-xs uppercase">Action</th>
                  <th className="px-6 py-4 text-left text-[#4A4A4A] text-xs uppercase">Object ID</th>
                  <th className="px-6 py-4 text-left text-[#4A4A4A] text-xs uppercase">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#8A2BE2]/10">
                {sampleLogs.map((log) => (
                  <React.Fragment key={log.id}>
                    <tr className="hover:bg-[#F4F6FC] transition-colors">
                      <td className="px-6 py-4 text-[#4A4A4A] text-sm font-mono">{log.timestamp}</td>
                      <td className="px-6 py-4 text-[#0D0D0D] text-sm">{log.adminUser}</td>
                      <td className="px-6 py-4">
                        <span className={`px-2 py-1 rounded text-xs font-medium ${moduleColors[log.module] || 'bg-gray-500/20 text-gray-400'}`}>{log.module}</span>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`text-sm font-medium ${actionColors[log.actionType] || 'text-white/70'}`}>{log.actionType}</span>
                      </td>
                      <td className="px-6 py-4 text-[#0D0D0D] font-mono text-sm">{log.objectId}</td>
                      <td className="px-6 py-4">
                        <Button variant="ghost" size="sm" onClick={() => setExpandedLog(expandedLog === log.id ? null : log.id)} className="text-[#FF2FBF]">
                          <Eye className="w-4 h-4 mr-1" />
                          {expandedLog === log.id ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                        </Button>
                      </td>
                    </tr>
                    {expandedLog === log.id && (
                      <tr className="bg-[#F4F6FC]">
                        <td colSpan={6} className="px-6 py-4">
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <p className="text-[#4A4A4A] text-xs uppercase mb-2">Old Value</p>
                              <pre className="bg-white border border-[#8A2BE2]/10 rounded-lg p-3 text-xs text-[#4A4A4A] overflow-x-auto">
                                {log.oldValue ? JSON.stringify(JSON.parse(log.oldValue), null, 2) : 'null'}
                              </pre>
                            </div>
                            <div>
                              <p className="text-[#4A4A4A] text-xs uppercase mb-2">New Value</p>
                              <pre className="bg-white border border-green-500/20 rounded-lg p-3 text-xs text-green-600 overflow-x-auto">
                                {log.newValue ? JSON.stringify(JSON.parse(log.newValue), null, 2) : 'null'}
                              </pre>
                            </div>
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                ))}
              </tbody>
            </table>
          </motion.div>
        </main>
      </div>
    </div>
  );
}