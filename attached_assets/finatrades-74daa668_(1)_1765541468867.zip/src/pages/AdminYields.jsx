import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { BarChart3, Download, Calendar, TrendingUp, Coins, Globe } from 'lucide-react';
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

import AdminSidebar from '@/components/admin/AdminSidebar';
import AdminTopBar from '@/components/admin/AdminTopBar';
import AdminKPICard from '@/components/admin/AdminKPICard';

const distributionData = [
  { month: 'Jul', amount: 124.5 },
  { month: 'Aug', amount: 132.8 },
  { month: 'Sep', amount: 145.2 },
  { month: 'Oct', amount: 158.9 },
  { month: 'Nov', amount: 167.4 },
  { month: 'Dec', amount: 189.2 },
];

const yieldsByPlan = [
  { name: '12M Plans', value: 35, color: '#8A2BE2' },
  { name: '24M Plans', value: 45, color: '#8A2BE2' },
  { name: '36M Plans', value: 20, color: '#FF2FBF' },
];

export default function AdminYields() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [role, setRole] = useState('Finance');
  const [dateRange, setDateRange] = useState('30d');

  useEffect(() => {
    const storedUser = localStorage.getItem('finatrades_user');
    if (!storedUser) {
      navigate(createPageUrl("SignIn"));
      return;
    }
    const userData = JSON.parse(storedUser);
    if (!userData.is_admin) {
      navigate(createPageUrl("UserDashboard"));
      return;
    }
    setUser(userData);
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('finatrades_user');
    navigate(createPageUrl("Home"));
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FAFBFF] via-[#F4F6FC] to-[#FFFFFF]">
      <AdminSidebar currentSection="yields" onLogout={handleLogout} />
      
      <div className="ml-64">
        <AdminTopBar user={user} role={role} onRoleChange={setRole} />
        
        <main className="p-6 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-[#0D0D0D] flex items-center gap-3">
                <BarChart3 className="w-7 h-7 text-[#8A2BE2]" />
                Yields & Reports
              </h1>
            </div>
            <div className="flex items-center gap-3">
              <Select value={dateRange} onValueChange={setDateRange}>
                <SelectTrigger className="w-32 bg-white border-[#8A2BE2]/20 text-[#0D0D0D]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[#1a0a2e] border-[#D1A954]/20">
                  <SelectItem value="7d" className="text-white/70">7 Days</SelectItem>
                  <SelectItem value="30d" className="text-white/70">30 Days</SelectItem>
                  <SelectItem value="90d" className="text-white/70">90 Days</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" className="border-[#8A2BE2]/30 text-[#FF2FBF]">
                <Download className="w-4 h-4 mr-2" />
                Export Report
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-4 gap-4">
            <AdminKPICard icon={Coins} label="Total BNSL Locked" value="847.3 kg" subValue="$72M value" color="from-amber-500 to-yellow-600" />
            <AdminKPICard icon={TrendingUp} label="Total Distributed" value="124.8 kg" subValue="All time" color="from-green-500 to-emerald-600" />
            <AdminKPICard icon={Calendar} label="Upcoming (30 days)" value="195.3 kg" subValue="1,385 plans" color="from-blue-500 to-cyan-600" />
            <AdminKPICard icon={Globe} label="Active Countries" value="47" subValue="12,847 users" color="from-purple-500 to-violet-600" />
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="lg:col-span-2 bg-white border border-[#8A2BE2]/20 rounded-2xl p-6 shadow-sm">
              <h3 className="text-[#0D0D0D] font-semibold mb-4">Monthly Distributions (kg)</h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={distributionData}>
                    <defs>
                      <linearGradient id="goldGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#8A2BE2" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#8A2BE2" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <XAxis dataKey="month" stroke="#ffffff30" tick={{ fill: '#ffffff60', fontSize: 12 }} />
                    <YAxis stroke="#ffffff30" tick={{ fill: '#ffffff60', fontSize: 12 }} />
                    <Tooltip contentStyle={{ background: '#1a0a2e', border: '1px solid rgba(138,43,226,0.3)', borderRadius: '8px' }} />
                    <Area type="monotone" dataKey="amount" stroke="#8A2BE2" strokeWidth={2} fill="url(#goldGradient)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </motion.div>

            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-white border border-[#8A2BE2]/20 rounded-2xl p-6 shadow-sm">
              <h3 className="text-[#0D0D0D] font-semibold mb-4">Yields by Plan Type</h3>
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={yieldsByPlan} cx="50%" cy="50%" innerRadius={50} outerRadius={70} dataKey="value">
                      {yieldsByPlan.map((entry, index) => (
                        <Cell key={index} fill={entry.color} />
                      ))}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="space-y-2 mt-4">
                {yieldsByPlan.map((plan, i) => (
                  <div key={i} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: plan.color }} />
                      <span className="text-[#4A4A4A] text-sm">{plan.name}</span>
                    </div>
                    <span className="text-[#0D0D0D] font-medium">{plan.value}%</span>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </main>
      </div>
    </div>
  );
}