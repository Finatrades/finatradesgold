import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { 
  Vault, Wallet, TrendingUp, GitBranch, LogOut, Bell, Settings, Menu, X,
  Shield, Globe, Coins, DollarSign, PieChart, ArrowUpRight, ArrowDownRight,
  Send, QrCode, Plus, History, Users, Copy, CheckCircle, AlertTriangle,
  ChevronRight, BarChart3, Percent, CreditCard
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';

import NotificationBell from '@/components/notifications/NotificationBell';
import FinatradesCard from '@/components/home/FinatradesCard';
import AIFinancialAdvisor from '@/components/dashboard/AIFinancialAdvisor';

// Mock gold price data
const goldPriceData = [
  { time: '00:00', price: 2640 },
  { time: '04:00', price: 2645 },
  { time: '08:00', price: 2642 },
  { time: '12:00', price: 2650 },
  { time: '16:00', price: 2648 },
  { time: '20:00', price: 2652 },
  { time: '24:00', price: 2650 },
];

const recentTransactions = [
  { id: 1, type: 'deposit', description: 'Gold Deposit', weight: 100, value: 8650, status: 'completed', date: '2024-12-05' },
  { id: 2, type: 'buy', description: 'Buy Gold', weight: 50, value: 4325, status: 'completed', date: '2024-12-04' },
  { id: 3, type: 'stake', description: 'BNSL Lock', weight: 25, value: 2162, status: 'active', date: '2024-12-03' },
  { id: 4, type: 'send', description: 'Send to User', weight: 10, value: 865, status: 'completed', date: '2024-12-02' },
];

export default function UserDashboard() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [referralCopied, setReferralCopied] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const storedUser = localStorage.getItem('finatrades_user');
    if (!storedUser) {
      navigate(createPageUrl("Home"));
      return;
    }
    try {
      const userData = JSON.parse(storedUser);
      setUser(userData);
      loadProfile(userData.email);
    } catch (error) {
      console.error('Error loading user:', error);
      navigate(createPageUrl("Home"));
    }
  }, [navigate]);

  const loadProfile = async (email) => {
    try {
      const profiles = await base44.entities.UserProfile.filter({ email });
      if (profiles.length > 0) {
        setProfile(profiles[0]);
      }
    } catch (error) {
      console.error('Failed to load profile:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('finatrades_user');
    navigate(createPageUrl("Home"));
  };

  const copyReferralLink = () => {
    navigator.clipboard.writeText(`https://finatrades.com/ref/${user?.id || 'USER123'}`);
    setReferralCopied(true);
    setTimeout(() => setReferralCopied(false), 2000);
  };

  const menuItems = [
    { icon: PieChart, label: 'Dashboard', page: 'UserDashboard', active: true },
    { icon: Vault, label: 'FinaVault', page: 'FinaVaultUser' },
    { icon: TrendingUp, label: 'FinaEarn (BNSL)', page: 'FinaEarnUser' },
    { icon: Wallet, label: 'FinaPay Wallet', page: 'FinaPayUser' },
    { icon: GitBranch, label: 'FinaFinance', page: 'FinaFinanceUser' },
    { icon: Percent, label: 'Yields', page: 'YieldsUser' },
    { icon: CreditCard, label: 'FinaCard', page: 'DebitCardUser' },
    { icon: Settings, label: 'Settings', page: 'SettingsUser' },
  ];

  const statsCards = [
    { label: 'Gold Storage', value: '0.00', unit: '', icon: Vault, color: 'from-amber-500 to-yellow-600', tooltip: 'Physical gold stored in FinaVault' },
    { label: 'Gold Portfolio', value: '0.00', unit: '', icon: PieChart, color: 'from-purple-500 to-violet-600', tooltip: 'Gold storage + wallet + staking' },
    { label: 'Card Value', value: '$0.00', unit: '', icon: CreditCard, color: 'from-blue-500 to-cyan-600', tooltip: 'FinaCard wallet balance' },
    { label: 'Total Staking', value: '0.00', unit: '', icon: TrendingUp, color: 'from-orange-500 to-red-600', tooltip: 'Gold locked in BNSL plans' },
    { label: 'Total Yield', value: '0.00', unit: '', icon: Percent, color: 'from-green-500 to-emerald-600', tooltip: 'Accumulated yields from staking' },
    { label: 'Total Profit', value: '$0.00', unit: '', icon: BarChart3, color: 'from-pink-500 to-rose-600', tooltip: 'Total rewards and profits earned' },
  ];

  if (isLoading || !user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#FAFBFF] via-[#F4F6FC] to-[#FFFFFF] flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-[#8A2BE2] border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-[#4A4A4A]">Loading...</p>
        </div>
      </div>
    );
  }

  const kycPending = profile?.kyc_status !== 'approved' && profile?.registration_status !== 'verified';

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FAFBFF] via-[#F4F6FC] to-[#FFFFFF]">
      
      <div className="flex">
        {/* Sidebar */}
        <aside className={`fixed lg:static inset-y-0 left-0 z-50 w-64 bg-white border-r border-[#8A2BE2]/20 shadow-sm transform transition-transform lg:translate-x-0 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
          <div className="flex flex-col h-full">
            {/* Logo */}
            <div className="p-6 border-b border-[#8A2BE2]/20">
              <Link to={createPageUrl("Home")} className="flex items-center">
                <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69293bd8e52dce0074daa668/ce96e4d2b_FINANEWLOGO-GOLDANDWHITENB.png" 
                  alt="Finatrades" 
                  className="h-8"
                  style={{ filter: 'brightness(0) saturate(100%) invert(29%) sepia(89%) saturate(4527%) hue-rotate(262deg) brightness(96%) contrast(93%)' }}
                />
              </Link>
              <button 
                onClick={() => setSidebarOpen(false)} 
                className="lg:hidden absolute top-6 right-6 text-[#4A4A4A] hover:text-[#0D0D0D]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Menu */}
            <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
              {menuItems.map((item) => (
                <Link
                  key={item.label}
                  to={createPageUrl(item.page)}
                  className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                    item.active 
                      ? 'bg-gradient-to-r from-[#8A2BE2]/10 to-[#FF2FBF]/10 text-[#8A2BE2] border border-[#8A2BE2]/30' 
                      : 'text-[#4A4A4A] hover:bg-[#F4F6FC] hover:text-[#0D0D0D]'
                  }`}
                >
                  <item.icon className="w-5 h-5" />
                  <span className="font-medium">{item.label}</span>
                </Link>
              ))}
            </nav>

            {/* User Info */}
            <div className="p-4 border-t border-[#8A2BE2]/20">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] flex items-center justify-center text-white font-semibold">
                  {user.full_name?.charAt(0) || 'U'}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[#0D0D0D] font-medium truncate">{user.full_name}</p>
                  <p className="text-[#4A4A4A] text-sm truncate">{user.email}</p>
                </div>
              </div>
              <button
                onClick={handleLogout}
                className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl border border-[#8A2BE2]/30 text-[#4A4A4A] hover:bg-[#8A2BE2]/10 hover:text-[#0D0D0D] hover:border-[#8A2BE2]/50 transition-all font-medium"
              >
                <LogOut className="w-4 h-4" />
                Sign Out
              </button>
            </div>
          </div>
        </aside>

        {/* Mobile sidebar overlay */}
        {sidebarOpen && (
          <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={() => setSidebarOpen(false)} />
        )}

        {/* Main Content */}
        <main className="flex-1 min-h-screen">
          {/* Top Header */}
          <header className="sticky top-0 z-30 bg-white border-b border-[#8A2BE2]/20 px-4 sm:px-6 py-3 sm:py-4 shadow-sm">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 sm:gap-4">
                <button onClick={() => setSidebarOpen(true)} className="lg:hidden text-[#0D0D0D]">
                  <Menu className="w-5 h-5 sm:w-6 sm:h-6" />
                </button>
                <h1 className="text-base sm:text-xl font-bold text-[#0D0D0D]">Dashboard</h1>
              </div>
              <div className="flex items-center gap-2 sm:gap-3">
                    {user?.email && <NotificationBell userEmail={user.email} />}
                    <button className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-[#F4F6FC] border border-[#8A2BE2]/20 flex items-center justify-center text-[#4A4A4A] hover:bg-[#8A2BE2]/10 hover:border-[#8A2BE2]/40">
                      <Settings className="w-4 h-4 sm:w-5 sm:h-5" />
                    </button>
                  </div>
            </div>
          </header>

          <div className="p-3 sm:p-6 space-y-3 sm:space-y-6">
            {/* KYC Banner */}
            {kycPending && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-gradient-to-r from-amber-500/20 to-orange-500/20 border border-amber-500/30 rounded-xl p-2.5 sm:p-4"
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0" />
                    <div className="min-w-0">
                      <p className="text-white font-medium text-xs sm:text-base">Complete KYC Verification</p>
                      <p className="text-white/60 text-[10px] sm:text-sm hidden sm:block">Verify your identity to unlock all features</p>
                    </div>
                  </div>
                  <Link to={createPageUrl("KYC")}>
                    <Button className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white font-bold text-[10px] sm:text-sm px-2.5 sm:px-4 py-1 sm:py-2 h-auto whitespace-nowrap">
                      Start KYC
                      <ChevronRight className="w-3 h-3 ml-0.5" />
                    </Button>
                  </Link>
                </div>
              </motion.div>
            )}

            {/* Hero Section - Card + Stats */}
            <div className="grid grid-cols-1 lg:grid-cols-[1fr_auto] gap-4 sm:gap-6 items-start">
              {/* Stats Cards - Left Side */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 sm:gap-4">
                {statsCards.map((stat, index) => (
                  <motion.div
                    key={stat.label + stat.unit}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 + index * 0.05 }}
                    className="bg-white border-2 border-[#8A2BE2]/30 rounded-xl sm:rounded-2xl p-3 sm:p-5 group hover:border-[#8A2BE2]/60 hover:shadow-lg transition-all"
                    title={stat.tooltip}
                  >
                    <div className="flex items-start justify-between mb-1 sm:mb-3">
                      <div className={`w-8 h-8 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-r ${stat.color} flex items-center justify-center shadow-lg`}>
                        <stat.icon className="w-4 h-4 sm:w-6 sm:h-6 text-white" />
                      </div>
                      {stat.unit && <span className="text-[#0D0D0D] text-[8px] sm:text-xs font-semibold uppercase tracking-wider">{stat.unit}</span>}
                    </div>
                    <p className="text-[#4A4A4A] text-[9px] sm:text-sm font-medium mb-1 truncate">{stat.label}</p>
                    <p className="text-[#0D0D0D] font-bold text-sm sm:text-2xl">{stat.value}</p>
                  </motion.div>
                ))}
              </div>

              {/* Debit Card - Right Side */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.1 }}
                className="flex items-center justify-center lg:justify-end w-full lg:w-auto"
              >
                <div className="w-full max-w-[420px] lg:max-w-[380px]">
                  <FinatradesCard userName={user?.full_name || 'User'} />
                </div>
              </motion.div>
            </div>

            {/* All Wallets */}
            <div className="grid lg:grid-cols-3 gap-4 sm:gap-6">
              {/* FinaPay Wallet */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="bg-white border-2 border-[#8A2BE2]/30 rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-lg hover:shadow-xl transition-all"
              >
                <div className="flex items-center justify-between mb-3 sm:mb-4">
                  <h2 className="text-sm sm:text-lg font-bold text-[#0D0D0D]">FinaPay Wallet</h2>
                  <Link to={createPageUrl("FinaPayUser")}>
                    <Button size="sm" variant="ghost" className="text-[#FF2FBF] hover:text-[#8A2BE2] text-[10px] sm:text-sm font-semibold h-auto p-1.5">
                      View <ChevronRight className="w-3.5 h-3.5 ml-0.5" />
                    </Button>
                  </Link>
                </div>
                <div className="bg-gradient-to-r from-[#8A2BE2]/20 to-[#D1A954]/15 rounded-xl p-3 sm:p-5 mb-3 sm:mb-4 border-2 border-[#8A2BE2]/30">
                  <p className="text-[#0D0D0D] text-[10px] sm:text-sm font-semibold mb-1">Available Balance</p>
                  <p className="text-xl sm:text-3xl font-bold text-[#0D0D0D]">0.00 <span className="text-sm sm:text-lg text-[#4A4A4A]">g</span></p>
                  <p className="text-[#4A4A4A] text-xs sm:text-base font-medium">≈ $0.00 USD</p>
                </div>
                <div className="grid grid-cols-2 gap-2 sm:gap-3">
                  <div className="bg-green-50 border border-green-200 rounded-lg sm:rounded-xl p-2.5 sm:p-4">
                    <p className="text-green-700 text-[9px] sm:text-xs font-semibold mb-0.5">Today's P/L</p>
                    <p className="text-base sm:text-xl font-bold text-green-600">+0.00g</p>
                  </div>
                  <div className="bg-blue-50 border border-blue-200 rounded-lg sm:rounded-xl p-2.5 sm:p-4">
                    <p className="text-blue-700 text-[9px] sm:text-xs font-semibold mb-0.5">Transactions</p>
                    <p className="text-base sm:text-xl font-bold text-blue-600">0</p>
                  </div>
                </div>
              </motion.div>

              {/* FinaBridge Trade Wallet */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.35 }}
                className="bg-white border-2 border-emerald-500/30 rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-lg hover:shadow-xl transition-all"
              >
                <div className="flex items-center justify-between mb-3 sm:mb-4">
                  <h2 className="text-sm sm:text-lg font-bold text-[#0D0D0D]">FinaBridge Trade Wallet</h2>
                  <Link to={createPageUrl("FinaFinanceUser")}>
                    <Button size="sm" variant="ghost" className="text-[#FF2FBF] hover:text-[#8A2BE2] text-[10px] sm:text-sm font-semibold h-auto p-1.5">
                      View <ChevronRight className="w-3.5 h-3.5 ml-0.5" />
                    </Button>
                  </Link>
                </div>
                <div className="bg-gradient-to-r from-emerald-500/20 to-teal-600/15 rounded-xl p-3 sm:p-5 mb-3 sm:mb-4 border-2 border-emerald-500/30">
                  <p className="text-[#0D0D0D] text-[10px] sm:text-sm font-semibold mb-1">Available Balance</p>
                  <p className="text-xl sm:text-3xl font-bold text-[#0D0D0D]">0.00 <span className="text-sm sm:text-lg text-[#4A4A4A]">g</span></p>
                  <p className="text-[#4A4A4A] text-xs sm:text-base font-medium">≈ $0.00 USD</p>
                </div>
                <div className="grid grid-cols-2 gap-2 sm:gap-3">
                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg sm:rounded-xl p-2.5 sm:p-4">
                    <p className="text-yellow-700 text-[9px] sm:text-xs font-semibold mb-0.5">Locked</p>
                    <p className="text-base sm:text-xl font-bold text-yellow-600">0.00g</p>
                  </div>
                  <div className="bg-purple-50 border border-purple-200 rounded-lg sm:rounded-xl p-2.5 sm:p-4">
                    <p className="text-purple-700 text-[9px] sm:text-xs font-semibold mb-0.5">Active Cases</p>
                    <p className="text-base sm:text-xl font-bold text-purple-600">0</p>
                  </div>
                </div>
              </motion.div>

              {/* BNSL Wallet */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="bg-white border-2 border-orange-500/30 rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-lg hover:shadow-xl transition-all"
              >
                <div className="flex items-center justify-between mb-3 sm:mb-4">
                  <h2 className="text-sm sm:text-lg font-bold text-[#0D0D0D]">BNSL Wallet</h2>
                  <Link to={createPageUrl("FinaEarnUser")}>
                    <Button size="sm" variant="ghost" className="text-[#FF2FBF] hover:text-[#8A2BE2] text-[10px] sm:text-sm font-semibold h-auto p-1.5">
                      View <ChevronRight className="w-3.5 h-3.5 ml-0.5" />
                    </Button>
                  </Link>
                </div>
                <div className="bg-gradient-to-r from-orange-500/20 to-amber-600/15 rounded-xl p-3 sm:p-5 mb-3 sm:mb-4 border-2 border-orange-500/30">
                  <p className="text-[#0D0D0D] text-[10px] sm:text-sm font-semibold mb-1">Available Balance</p>
                  <p className="text-xl sm:text-3xl font-bold text-[#0D0D0D]">0.00 <span className="text-sm sm:text-lg text-[#4A4A4A]">g</span></p>
                  <p className="text-[#4A4A4A] text-xs sm:text-base font-medium">≈ $0.00 USD</p>
                </div>
                <div className="grid grid-cols-2 gap-2 sm:gap-3">
                  <div className="bg-orange-50 border border-orange-200 rounded-lg sm:rounded-xl p-2.5 sm:p-4">
                    <p className="text-orange-700 text-[9px] sm:text-xs font-semibold mb-0.5">Locked</p>
                    <p className="text-base sm:text-xl font-bold text-orange-600">0.00g</p>
                  </div>
                  <div className="bg-amber-50 border border-amber-200 rounded-lg sm:rounded-xl p-2.5 sm:p-4">
                    <p className="text-amber-700 text-[9px] sm:text-xs font-semibold mb-0.5">Active Plans</p>
                    <p className="text-base sm:text-xl font-bold text-amber-600">0</p>
                  </div>
                </div>
              </motion.div>
              </div>

            {/* AI Financial Advisor */}
            <AIFinancialAdvisor user={user} profile={profile} />

            {/* Bottom Grid */}
            <div className="grid lg:grid-cols-3 gap-3 sm:gap-6">
              {/* Recent Transactions */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="lg:col-span-2 bg-white border-2 border-[#8A2BE2]/30 rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-lg"
              >
                <div className="flex items-center justify-between mb-3 sm:mb-5">
                  <h2 className="text-sm sm:text-lg font-bold text-[#0D0D0D]">Recent Transactions</h2>
                  <button className="text-[#FF2FBF] text-[10px] sm:text-sm font-semibold hover:underline">View All</button>
                </div>
                {/* Mobile Cards */}
                <div className="sm:hidden space-y-2">
                  {recentTransactions.map(tx => (
                    <div key={tx.id} className="bg-gradient-to-r from-[#F4F6FC] to-white border-2 border-[#8A2BE2]/20 rounded-xl p-3 flex items-center justify-between shadow-sm">
                      <div className="min-w-0 flex-1">
                        <p className="text-[#0D0D0D] text-xs font-semibold truncate">{tx.description}</p>
                        <p className="text-[#4A4A4A] text-[9px] font-medium">{tx.date.slice(5)} · {tx.weight}g</p>
                      </div>
                      <div className="text-right flex-shrink-0 ml-2">
                        <p className="text-[#D1A954] text-xs font-bold">${tx.value}</p>
                        <span className={`text-[8px] font-semibold ${
                          tx.status === 'completed' ? 'text-green-600' :
                          tx.status === 'active' ? 'text-blue-600' : 'text-yellow-600'
                        }`}>{tx.status}</span>
                      </div>
                    </div>
                  ))}
                </div>
                {/* Desktop Table */}
                <div className="hidden sm:block overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="text-left text-[#4A4A4A] text-[10px] uppercase tracking-wider border-b border-[#8A2BE2]/10">
                        <th className="pb-3 pr-4">Date</th>
                        <th className="pb-3 pr-4">Type</th>
                        <th className="pb-3 pr-4">Description</th>
                        <th className="pb-3 pr-4 text-right">Weight</th>
                        <th className="pb-3 pr-4 text-right">Value</th>
                        <th className="pb-3 text-right">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#8A2BE2]/10">
                      {recentTransactions.map(tx => (
                        <tr key={tx.id} className="text-[#4A4A4A] text-sm hover:bg-[#F4F6FC] transition-colors">
                          <td className="py-3 pr-4 text-[#4A4A4A]">{tx.date.slice(5)}</td>
                          <td className="py-3 pr-4 capitalize">{tx.type}</td>
                          <td className="py-3 pr-4 text-[#0D0D0D]">{tx.description}</td>
                          <td className="py-3 pr-4 text-right font-medium">{tx.weight}g</td>
                          <td className="py-3 pr-4 text-right text-[#D1A954]">${tx.value.toLocaleString()}</td>
                          <td className="py-3 text-right">
                            <span className={`px-2 py-1 rounded-full text-[10px] font-medium ${
                              tx.status === 'completed' ? 'bg-green-500/15 text-green-400' :
                              tx.status === 'active' ? 'bg-blue-500/15 text-blue-400' :
                              'bg-yellow-500/15 text-yellow-400'
                            }`}>
                              {tx.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </motion.div>

              {/* Referral */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className="bg-white border-2 border-[#8A2BE2]/30 rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-lg"
              >
                <div className="flex items-center gap-2 mb-3 sm:mb-4">
                  <div className="w-8 h-8 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] flex items-center justify-center shadow-lg">
                    <Users className="w-4 h-4 sm:w-6 sm:h-6 text-white" />
                  </div>
                  <h2 className="text-sm sm:text-lg font-bold text-[#0D0D0D]">Referral Program</h2>
                </div>
                <p className="text-[#4A4A4A] text-[10px] sm:text-sm font-medium mb-3 sm:mb-5">
                  Invite friends and earn gold rewards when they make their first deposit.
                </p>
                <div className="bg-gradient-to-r from-[#F4F6FC] to-white border-2 border-[#8A2BE2]/20 rounded-xl p-3 sm:p-4 mb-3 sm:mb-5">
                  <p className="text-[#0D0D0D] text-[9px] sm:text-xs uppercase tracking-wider font-semibold mb-1 sm:mb-2">Your Referral Link</p>
                  <div className="flex items-center gap-2 sm:gap-3">
                    <p className="text-[#0D0D0D] text-[10px] sm:text-sm truncate flex-1 font-mono font-medium">finatrades.com/ref/{user?.id?.slice(0, 8) || 'USER123'}</p>
                    <button onClick={copyReferralLink} className="p-1.5 sm:p-2 rounded-lg bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white hover:shadow-lg transition-all">
                      {referralCopied ? <CheckCircle className="w-3 h-3 sm:w-4 sm:h-4" /> : <Copy className="w-3 h-3 sm:w-4 sm:h-4" />}
                    </button>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2 sm:gap-4">
                  <div className="bg-gradient-to-br from-blue-50 to-purple-50 border-2 border-blue-200 rounded-lg sm:rounded-xl p-3 sm:p-4 text-center">
                    <p className="text-xl sm:text-3xl font-bold text-[#0D0D0D]">0</p>
                    <p className="text-[#4A4A4A] text-[9px] sm:text-xs font-semibold mt-1">Referred</p>
                  </div>
                  <div className="bg-gradient-to-br from-amber-50 to-yellow-50 border-2 border-amber-200 rounded-lg sm:rounded-xl p-3 sm:p-4 text-center">
                    <p className="text-xl sm:text-3xl font-bold text-amber-600">0g</p>
                    <p className="text-[#4A4A4A] text-[9px] sm:text-xs font-semibold mt-1">Earned</p>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}