import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { 
  GitBranch, Plus, ArrowRight, Bell, Info, Shield
} from 'lucide-react';
import { Button } from "@/components/ui/button";

import DashboardSidebar from '@/components/dashboard/DashboardSidebar';
import TradeSummaryCards from '@/components/finabridge/TradeSummaryCards';
import TransferModal from '@/components/finabridge/TransferModal';
import TradeCasesTable from '@/components/finabridge/TradeCasesTable';
import CreateTradeCaseForm from '@/components/finabridge/CreateTradeCaseForm';
import TradeCaseDetails from '@/components/finabridge/TradeCaseDetails';
import { toast } from 'sonner';

// Sample trade cases data
const sampleTradeCases = [
  { 
    id: 'TRD-2024-001', 
    role: 'importer',
    buyer: 'ABC Trading LLC', 
    seller: 'XYZ Manufacturing Co.',
    commodity: 'Electronics Components',
    valueUSD: 250000,
    valueGold: 2941.18,
    lockedGold: 2941.18,
    status: 'approved',
    lastUpdated: '2024-12-03',
    contractNumber: 'PO-2024-001',
    paymentTerms: 'LC at Sight',
    deliveryTerms: 'FOB',
    shipmentMethod: 'Sea Freight',
    deliveryTimeline: 'Dec 15-20, 2024',
    documents: { invoice: { status: 'uploaded', version: 'v1' }, bl: { status: 'uploaded', version: 'v1' } }
  },
  { 
    id: 'TRD-2024-002', 
    role: 'exporter',
    buyer: 'Global Imports Inc.', 
    seller: 'My Company Ltd.',
    commodity: 'Raw Materials - Steel',
    valueUSD: 150000,
    valueGold: 1764.71,
    lockedGold: 1764.71,
    status: 'documents_pending',
    lastUpdated: '2024-12-01',
    contractNumber: 'EXP-2024-015',
    paymentTerms: 'Net 30',
    deliveryTerms: 'CIF',
    shipmentMethod: 'Air Freight',
    deliveryTimeline: 'Dec 10-12, 2024',
    documents: {}
  },
  { 
    id: 'TRD-2024-003', 
    role: 'importer',
    buyer: 'Tech Solutions ME', 
    seller: 'Asian Electronics Ltd.',
    commodity: 'Semiconductor Chips',
    valueUSD: 500000,
    valueGold: 5882.35,
    lockedGold: 5882.35,
    status: 'settled',
    lastUpdated: '2024-11-28',
    contractNumber: 'PO-2024-089',
    paymentTerms: 'LC 60 days',
    deliveryTerms: 'DDP',
    shipmentMethod: 'Air Freight',
    deliveryTimeline: 'Nov 20-25, 2024',
    documents: { invoice: { status: 'uploaded', version: 'v2' }, bl: { status: 'uploaded', version: 'v1' }, packing: { status: 'uploaded', version: 'v1' }, coo: { status: 'uploaded', version: 'v1' } }
  }
];

export default function FinaFinanceUser() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [view, setView] = useState('home'); // 'home', 'create', 'details'
  const [selectedCase, setSelectedCase] = useState(null);
  const [showTransferModal, setShowTransferModal] = useState(false);
  const [filter, setFilter] = useState('all');
  
  // Balances
  const [finaPayBalance, setFinaPayBalance] = useState(500.000);
  const [tradeWalletBalance, setTradeWalletBalance] = useState(1250.000);
  const [lockedBalance, setLockedBalance] = useState(10588.24);
  const [tradeCases, setTradeCases] = useState(sampleTradeCases);
  
  // Gold price (LBMA)
  const goldPrice = 85.00; // USD per gram

  useEffect(() => {
    const storedUser = localStorage.getItem('finatrades_user');
    if (!storedUser) {
      navigate(createPageUrl("Home"));
      return;
    }
    setUser(JSON.parse(storedUser));
  }, [navigate]);

  const handleTransfer = (amount, note) => {
    setFinaPayBalance(prev => prev - amount);
    setTradeWalletBalance(prev => prev + amount);
    toast.success(`${amount.toFixed(3)}g successfully transferred to FinaBridge Trade Wallet`);
  };

  const handleCreateCase = (formData, goldToLock) => {
    const newCase = {
      id: `TRD-2024-${String(tradeCases.length + 1).padStart(3, '0')}`,
      role: formData.role,
      buyer: formData.buyerName,
      seller: formData.sellerName,
      commodity: formData.commodity,
      valueUSD: formData.valueType === 'usd' ? parseFloat(formData.valueAmount) : parseFloat(formData.valueAmount) * goldPrice,
      valueGold: formData.valueType === 'grams' ? parseFloat(formData.valueAmount) : parseFloat(formData.valueAmount) / goldPrice,
      lockedGold: goldToLock,
      status: 'draft',
      lastUpdated: new Date().toISOString().split('T')[0],
      contractNumber: formData.contractNumber,
      paymentTerms: formData.paymentTerms,
      deliveryTerms: formData.deliveryTerms,
      shipmentMethod: formData.shipmentMethod,
      deliveryTimeline: `${formData.deliveryStart} - ${formData.deliveryEnd}`,
      documents: {}
    };
    setTradeCases([newCase, ...tradeCases]);
    setTradeWalletBalance(prev => prev - goldToLock);
    setLockedBalance(prev => prev + goldToLock);
    setSelectedCase(newCase);
    setView('details');
    toast.success(`Trade Case ${newCase.id} created successfully!`);
  };

  const handleViewDetails = (tradeCase) => {
    setSelectedCase(tradeCase);
    setView('details');
  };

  const activeCases = tradeCases.filter(tc => !['settled', 'closed'].includes(tc.status)).length;
  const completedCases = tradeCases.filter(tc => ['settled', 'closed'].includes(tc.status)).length;

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FAFBFF] via-[#F4F6FC] to-[#FFFFFF]">
      
      <div className="flex">
        {/* Sidebar */}
        <DashboardSidebar currentPage="FinaFinanceUser" user={user} />

        {/* Main Content */}
        <main className="flex-1 min-h-screen">
          {/* Top Header */}
          <header className="sticky top-0 z-30 bg-white border-b border-[#8A2BE2]/20 px-4 sm:px-6 py-3 sm:py-4 shadow-sm">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 sm:gap-4 ml-12 lg:ml-0">
                <div className="flex items-center gap-2 sm:gap-3">
                  <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg sm:rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 flex items-center justify-center">
                    <GitBranch className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
                  </div>
                  <div>
                    <h1 className="text-base sm:text-xl font-bold text-[#0D0D0D]">
                      <span className="hidden sm:inline">FinaBridge — Trade Wallet</span>
                      <span className="sm:hidden">FinaBridge</span>
                    </h1>
                    <p className="text-[#4A4A4A] text-[10px] sm:text-xs hidden sm:block">Gold-backed settlement & collateral for importers and exporters</p>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <button className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-[#F4F6FC] border border-[#8A2BE2]/20 flex items-center justify-center text-[#4A4A4A] hover:bg-[#8A2BE2]/10 hover:border-[#8A2BE2]/40">
                  <Bell className="w-4 h-4 sm:w-5 sm:h-5" />
                </button>
              </div>
            </div>
          </header>

          <div className="p-4 sm:p-6">
            {view === 'home' && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="space-y-6"
              >
                {/* Summary Cards */}
                <TradeSummaryCards
                  walletBalance={tradeWalletBalance}
                  lockedBalance={lockedBalance}
                  activeCases={activeCases}
                  completedCases={completedCases}
                />

                {/* Action Buttons */}
                <div className="flex flex-wrap items-center gap-2 sm:gap-4">
                  <Button 
                    onClick={() => setShowTransferModal(true)}
                    className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white font-bold hover:opacity-90 text-xs sm:text-sm h-9 sm:h-10 px-3 sm:px-4"
                  >
                    <ArrowRight className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                    <span className="hidden sm:inline">Transfer Gold from FinaPay</span>
                    <span className="sm:hidden">Transfer from FinaPay</span>
                  </Button>
                  <Button 
                    onClick={() => setView('create')}
                    variant="outline"
                    className="border-[#8A2BE2]/30 text-[#FF2FBF] hover:bg-[#8A2BE2]/10 text-xs sm:text-sm h-9 sm:h-10 px-3 sm:px-4"
                  >
                    <Plus className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                    New Trade Case
                  </Button>
                </div>

                {/* Transfer Context Text */}
                <div className="flex items-start gap-2 sm:gap-3 p-3 sm:p-4 bg-amber-500/5 border border-amber-500/20 rounded-lg sm:rounded-xl">
                  <Info className="w-4 h-4 sm:w-5 sm:h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <p className="text-[#4A4A4A] text-xs sm:text-sm">
                    Gold must be transferred from FinaPay into FinaBridge before it can be locked as trade collateral.
                  </p>
                </div>

                {/* Trade Cases Table */}
                <TradeCasesTable 
                  cases={tradeCases}
                  onViewDetails={handleViewDetails}
                  filter={filter}
                  onFilterChange={setFilter}
                />

                {/* Compliance Notice */}
                <div className="flex items-start gap-2 sm:gap-3 p-3 sm:p-4 bg-[#F4F6FC] border border-[#8A2BE2]/10 rounded-lg sm:rounded-xl">
                  <Shield className="w-4 h-4 sm:w-5 sm:h-5 text-[#4A4A4A] flex-shrink-0 mt-0.5" />
                  <p className="text-[#4A4A4A] text-[10px] sm:text-xs">
                    All actions are fully logged for trade-based money laundering (TBML) monitoring. 
                    Finatrades operates under Swiss regulatory compliance standards.
                  </p>
                </div>
              </motion.div>
            )}

            {view === 'create' && (
              <CreateTradeCaseForm
                walletBalance={tradeWalletBalance}
                goldPrice={goldPrice}
                onBack={() => setView('home')}
                onSubmit={handleCreateCase}
                onSaveDraft={() => {
                  toast.success('Draft saved');
                  setView('home');
                }}
              />
            )}

            {view === 'details' && selectedCase && (
              <TradeCaseDetails
                tradeCase={selectedCase}
                goldPrice={goldPrice}
                onBack={() => {
                  setView('home');
                  setSelectedCase(null);
                }}
                userRole={selectedCase.role}
              />
            )}
          </div>
        </main>
      </div>

      {/* Transfer Modal */}
      <TransferModal
        open={showTransferModal}
        onClose={() => setShowTransferModal(false)}
        finaPayBalance={finaPayBalance}
        goldPrice={goldPrice}
        onTransfer={handleTransfer}
      />
    </div>
  );
}