import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Wallet, ArrowUpRight, ArrowDownRight, Send, Download } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

import AdminSidebar from '@/components/admin/AdminSidebar';
import AdminTopBar from '@/components/admin/AdminTopBar';
import AdminTable from '@/components/admin/AdminTable';
import AdminFilterBar from '@/components/admin/AdminFilterBar';
import AdminStatusBadge from '@/components/admin/AdminStatusBadge';

const sampleTransactions = [
  { id: 'TXN-8821', user: 'Ahmed Al-Rashid', type: 'Buy', amount: 50, goldPrice: 85.00, value: 4250, status: 'completed', date: '2024-12-04 14:32' },
  { id: 'TXN-8822', user: 'Sarah Thompson', type: 'Sell', amount: 25, goldPrice: 85.50, value: 2137.50, status: 'pending', date: '2024-12-04 12:15' },
  { id: 'TXN-8823', user: 'Swiss Metals AG', type: 'Transfer', amount: 100, goldPrice: 85.00, value: 8500, status: 'completed', date: '2024-12-04 11:45' },
];

export default function AdminFinaPay() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [role, setRole] = useState('Operations');
  const [activeTab, setActiveTab] = useState('transactions');
  const [searchValue, setSearchValue] = useState('');

  useEffect(() => {
    const storedUser = localStorage.getItem('finatrades_user');
    if (!storedUser) {
      navigate(createPageUrl("SignIn"));
      return;
    }
    const userData = JSON.parse(storedUser);
    if (!userData.is_admin) {
      navigate(createPageUrl("UserDashboard"));
      return;
    }
    setUser(userData);
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('finatrades_user');
    navigate(createPageUrl("Home"));
  };

  const txColumns = [
    { header: 'TX ID', accessor: 'id' },
    { header: 'User', accessor: 'user' },
    { header: 'Type', accessor: 'type', render: (val) => {
      const colors = { Buy: 'bg-green-500/20 text-green-400', Sell: 'bg-red-500/20 text-red-400', Transfer: 'bg-blue-500/20 text-blue-400' };
      return <span className={`px-2 py-1 rounded text-xs ${colors[val]}`}>{val}</span>;
    }},
    { header: 'Amount', accessor: 'amount', render: (val) => `${val}g` },
    { header: 'Price', accessor: 'goldPrice', render: (val) => `$${val.toFixed(2)}` },
    { header: 'Value', accessor: 'value', render: (val) => `$${val.toLocaleString()}` },
    { header: 'Status', accessor: 'status', render: (val) => <AdminStatusBadge status={val} /> },
    { header: 'Date', accessor: 'date' },
  ];

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FAFBFF] via-[#F4F6FC] to-[#FFFFFF]">
      <AdminSidebar currentSection="finapay" onLogout={handleLogout} />
      
      <div className="ml-64">
        <AdminTopBar user={user} role={role} onRoleChange={setRole} />
        
        <main className="p-6 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-[#0D0D0D] flex items-center gap-3">
                <Wallet className="w-7 h-7 text-[#8A2BE2]" />
                FinaPay & Transfers
              </h1>
            </div>
            <Button variant="outline" className="border-[#8A2BE2]/30 text-[#FF2FBF]">
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
          </div>

          <AdminFilterBar
            searchPlaceholder="Search by TX ID or user..."
            searchValue={searchValue}
            onSearchChange={setSearchValue}
            filters={[]}
          />

          <AdminTable columns={txColumns} data={sampleTransactions} />
        </main>
      </div>
    </div>
  );
}