import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Settings, Users, Shield, Save, Plus, Trash2, Edit2 } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

import AdminSidebar from '@/components/admin/AdminSidebar';
import AdminTopBar from '@/components/admin/AdminTopBar';
import AdminStatusBadge from '@/components/admin/AdminStatusBadge';

const sampleAdmins = [
  { id: 1, name: 'John Admin', email: 'admin@finatrades.com', role: 'Super Admin', status: 'active', lastLogin: '2024-12-04 14:32' },
  { id: 2, name: 'Sarah Compliance', email: 'compliance@finatrades.com', role: 'Compliance', status: 'active', lastLogin: '2024-12-04 12:15' },
  { id: 3, name: 'Mike Operations', email: 'ops@finatrades.com', role: 'Operations', status: 'active', lastLogin: '2024-12-04 09:45' },
];

export default function AdminSettings() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [role, setRole] = useState('Admin');

  useEffect(() => {
    const storedUser = localStorage.getItem('finatrades_user');
    if (!storedUser) {
      navigate(createPageUrl("SignIn"));
      return;
    }
    const userData = JSON.parse(storedUser);
    if (!userData.is_admin) {
      navigate(createPageUrl("UserDashboard"));
      return;
    }
    setUser(userData);
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('finatrades_user');
    navigate(createPageUrl("Home"));
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FAFBFF] via-[#F4F6FC] to-[#FFFFFF]">
      <AdminSidebar currentSection="settings" onLogout={handleLogout} />
      
      <div className="ml-64">
        <AdminTopBar user={user} role={role} onRoleChange={setRole} />
        
        <main className="p-6 space-y-6">
          <div>
            <h1 className="text-2xl font-bold text-[#0D0D0D] flex items-center gap-3">
              <Settings className="w-7 h-7 text-[#8A2BE2]" />
              Settings & Roles
            </h1>
          </div>

          <Tabs defaultValue="users">
            <TabsList className="bg-white border border-[#8A2BE2]/10 p-1 shadow-sm">
              <TabsTrigger value="users" className="data-[state=active]:bg-[#8A2BE2]/20 data-[state=active]:text-[#FF2FBF]">
                <Users className="w-4 h-4 mr-2" />
                Admin Users
              </TabsTrigger>
              <TabsTrigger value="system" className="data-[state=active]:bg-[#8A2BE2]/20 data-[state=active]:text-[#FF2FBF]">
                <Settings className="w-4 h-4 mr-2" />
                System Settings
              </TabsTrigger>
            </TabsList>

            <TabsContent value="users" className="mt-6">
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white border border-[#8A2BE2]/20 rounded-2xl overflow-hidden shadow-sm">
                <div className="px-6 py-4 border-b border-[#8A2BE2]/10 flex items-center justify-between">
                  <h3 className="text-[#0D0D0D] font-semibold">Admin Users</h3>
                  <Button className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white font-bold">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Admin
                  </Button>
                </div>
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-[#8A2BE2]/10">
                      <th className="px-6 py-4 text-left text-[#4A4A4A] text-xs uppercase">Name</th>
                      <th className="px-6 py-4 text-left text-[#4A4A4A] text-xs uppercase">Email</th>
                      <th className="px-6 py-4 text-left text-[#4A4A4A] text-xs uppercase">Role</th>
                      <th className="px-6 py-4 text-left text-[#4A4A4A] text-xs uppercase">Status</th>
                      <th className="px-6 py-4 text-left text-[#4A4A4A] text-xs uppercase">Last Login</th>
                      <th className="px-6 py-4 text-left text-[#4A4A4A] text-xs uppercase">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {sampleAdmins.map((admin) => (
                      <tr key={admin.id} className="border-b border-[#8A2BE2]/10 hover:bg-[#F4F6FC]">
                        <td className="px-6 py-4 text-[#0D0D0D]">{admin.name}</td>
                        <td className="px-6 py-4 text-[#4A4A4A]">{admin.email}</td>
                        <td className="px-6 py-4">
                          <span className="px-2 py-1 rounded text-xs bg-[#8A2BE2]/20 text-[#FF2FBF]">{admin.role}</span>
                        </td>
                        <td className="px-6 py-4"><AdminStatusBadge status={admin.status} /></td>
                        <td className="px-6 py-4 text-[#4A4A4A]">{admin.lastLogin}</td>
                        <td className="px-6 py-4">
                          <div className="flex gap-2">
                            <Button variant="ghost" size="sm" className="text-[#4A4A4A] hover:text-[#0D0D0D]"><Edit2 className="w-4 h-4" /></Button>
                            <Button variant="ghost" size="sm" className="text-red-400 hover:text-red-300"><Trash2 className="w-4 h-4" /></Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </motion.div>
            </TabsContent>

            <TabsContent value="system" className="mt-6">
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white border border-[#8A2BE2]/20 rounded-2xl p-6 shadow-sm">
                <h3 className="text-[#0D0D0D] font-semibold mb-6">Environment Settings</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between py-3 border-b border-[#8A2BE2]/10">
                    <div>
                      <p className="text-[#0D0D0D]">Two-Factor Authentication</p>
                      <p className="text-[#4A4A4A] text-sm">Require 2FA for all admin users</p>
                    </div>
                    <Switch defaultChecked className="data-[state=checked]:bg-[#8A2BE2]" />
                  </div>
                  <div className="flex items-center justify-between py-3 border-b border-[#8A2BE2]/10">
                    <div>
                      <p className="text-[#0D0D0D]">Audit Logging</p>
                      <p className="text-[#4A4A4A] text-sm">Log all admin actions</p>
                    </div>
                    <Switch defaultChecked className="data-[state=checked]:bg-[#8A2BE2]" />
                  </div>
                </div>
                <Button className="mt-4 bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white font-bold">
                  <Save className="w-4 h-4 mr-2" />
                  Save Settings
                </Button>
              </motion.div>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  );
}