import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { 
  Users, UserCheck, Vault, Wallet, TrendingUp, CreditCard, 
  BarChart3, AlertTriangle, Clock, ChevronRight
} from 'lucide-react';

import AdminSidebar from '@/components/admin/AdminSidebar';
import AdminTopBar from '@/components/admin/AdminTopBar';
import AdminKPICard from '@/components/admin/AdminKPICard';
import AdminTable from '@/components/admin/AdminTable';
import AdminAlertCard from '@/components/admin/AdminAlertCard';
import AdminStatusBadge from '@/components/admin/AdminStatusBadge';

// Sample data
const kpiData = [
  { icon: Users, label: 'Total Users', value: '12,847', subValue: '892 active today', trend: 'up', trendValue: '+4.2%', color: 'from-blue-500 to-cyan-600' },
  { icon: UserCheck, label: 'KYC Status', value: '156', subValue: 'Pending review', trend: 'down', trendValue: '-12', color: 'from-amber-500 to-orange-600' },
  { icon: Vault, label: 'Vault Gold', value: '2,458.5 kg', subValue: '$198.2M value', trend: 'up', trendValue: '+2.1%', color: 'from-amber-500 to-yellow-600' },
  { icon: TrendingUp, label: 'BNSL Locked', value: '847.3 kg', subValue: '1,247 active plans', trend: 'up', trendValue: '+8.5%', color: 'from-purple-500 to-violet-600' },
  { icon: CreditCard, label: 'Card Wallet Load', value: '$4.2M', subValue: 'AED 15.4M', trend: 'up', trendValue: '+15%', color: 'from-green-500 to-emerald-600' },
  { icon: BarChart3, label: "Today's Transactions", value: '2,847', subValue: '$12.4M volume', trend: 'up', trendValue: '+22%', color: 'from-pink-500 to-rose-600' },
];

const actionsQueue = [
  { id: 'KYC-4521', type: 'KYC', user: 'Ahmed Al-Rashid', action: 'Document Review', time: '5 min ago', status: 'pending' },
  { id: 'VLT-8892', type: 'Vault', user: 'Swiss Metals AG', action: 'Deposit Approval', time: '12 min ago', status: 'under_review' },
  { id: 'TRD-2241', type: 'Trade', user: 'Global Imports LLC', action: 'Settlement Release', time: '18 min ago', status: 'pending' },
  { id: 'BNS-7712', type: 'BNSL', user: 'Sarah Thompson', action: 'Early Termination', time: '25 min ago', status: 'pending' },
  { id: 'CRD-1123', type: 'Card', user: 'Mohammed Hassan', action: 'Limit Increase', time: '32 min ago', status: 'in_review' },
];

const systemAlerts = [
  { type: 'aml', severity: 'critical', title: 'AML Flag - High Value Transfer', description: 'Transaction ID TXN-88912 flagged for review. Amount: $245,000', time: '2 min ago' },
  { type: 'sanctions', severity: 'warning', title: 'Sanctions Screening Match', description: 'Partial name match detected for user ID USR-44521', time: '15 min ago' },
  { type: 'volume', severity: 'info', title: 'Unusual Volume Pattern', description: 'User USR-22341 showing 3x normal transaction volume', time: '1 hour ago' },
];

export default function AdminDashboard() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [role, setRole] = useState('Admin');

  useEffect(() => {
    const storedUser = localStorage.getItem('finatrades_user');
    if (!storedUser) {
      navigate(createPageUrl("SignIn"));
      return;
    }
    const userData = JSON.parse(storedUser);
    if (!userData.is_admin) {
      navigate(createPageUrl("UserDashboard"));
      return;
    }
    setUser(userData);
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('finatrades_user');
    navigate(createPageUrl("Home"));
  };

  const queueColumns = [
    { header: 'ID', accessor: 'id' },
    { header: 'Type', accessor: 'type', render: (val) => (
      <span className={`px-2 py-1 rounded text-xs font-medium ${
        val === 'KYC' ? 'bg-blue-500/20 text-blue-400' :
        val === 'Vault' ? 'bg-amber-500/20 text-amber-400' :
        val === 'Trade' ? 'bg-purple-500/20 text-purple-400' :
        val === 'BNSL' ? 'bg-green-500/20 text-green-400' :
        'bg-pink-500/20 text-pink-400'
      }`}>{val}</span>
    )},
    { header: 'User / Company', accessor: 'user' },
    { header: 'Requested Action', accessor: 'action' },
    { header: 'Time', accessor: 'time' },
    { header: 'Status', accessor: 'status', render: (val) => <AdminStatusBadge status={val} /> },
  ];

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FAFBFF] via-[#F4F6FC] to-[#FFFFFF]">
      <AdminSidebar currentSection="dashboard" onLogout={handleLogout} />
      
      <div className="ml-64">
        <AdminTopBar user={user} role={role} onRoleChange={setRole} />
        
        <main className="p-6 space-y-6">
          {/* Welcome */}
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h1 className="text-2xl font-bold text-[#0D0D0D]">Dashboard Overview</h1>
            <p className="text-[#4A4A4A] text-sm">Monitor platform activity and manage operations</p>
          </motion.div>

          {/* KPI Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
            {kpiData.map((kpi, index) => (
              <AdminKPICard key={index} {...kpi} delay={index * 0.05} />
            ))}
          </div>

          {/* Main Content Grid */}
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Actions Queue */}
            <div className="lg:col-span-2">
              <AdminTable
                title="Latest Actions Queue"
                columns={queueColumns}
                data={actionsQueue}
                onRowAction={(row) => console.log('Open case:', row)}
                actionLabel="Open Case"
              />
            </div>

            {/* System Alerts */}
            <div>
              <AdminAlertCard alerts={systemAlerts} />
            </div>
          </div>

          {/* Quick Stats Row */}
          <div className="grid md:grid-cols-4 gap-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-white/[0.03] border border-[#D1A954]/20 rounded-2xl p-5"
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-[#4A4A4A] text-xs uppercase tracking-wider">KYC Approved Today</span>
                <UserCheck className="w-5 h-5 text-green-500" />
              </div>
              <p className="text-[#0D0D0D] text-2xl font-bold">47</p>
              <div className="flex items-center gap-2 mt-2">
                <div className="flex-1 h-1.5 bg-gray-200 rounded-full overflow-hidden">
                  <div className="h-full w-3/4 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full" />
                </div>
                <span className="text-[#4A4A4A] text-xs">75%</span>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.35 }}
              className="bg-white/[0.03] border border-[#D1A954]/20 rounded-2xl p-5"
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-[#4A4A4A] text-xs uppercase tracking-wider">Vault Deposits Today</span>
                <Vault className="w-5 h-5 text-amber-400" />
              </div>
              <p className="text-[#0D0D0D] text-2xl font-bold">12.4 kg</p>
              <p className="text-amber-400 text-sm mt-1">≈ $1.05M USD</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="bg-white/[0.03] border border-[#D1A954]/20 rounded-2xl p-5"
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-[#4A4A4A] text-xs uppercase tracking-wider">Card Transactions</span>
                <CreditCard className="w-5 h-5 text-purple-500" />
              </div>
              <p className="text-[#0D0D0D] text-2xl font-bold">1,247</p>
              <p className="text-purple-400 text-sm mt-1">$892K volume</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.45 }}
              className="bg-white/[0.03] border border-[#D1A954]/20 rounded-2xl p-5"
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-[#4A4A4A] text-xs uppercase tracking-wider">Pending Reviews</span>
                <Clock className="w-5 h-5 text-amber-500" />
              </div>
              <p className="text-[#0D0D0D] text-2xl font-bold">23</p>
              <p className="text-amber-400 text-sm mt-1">Avg. 4.2h wait time</p>
            </motion.div>
          </div>
        </main>
      </div>
    </div>
  );
}