import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { CheckCircle, ArrowRight, Shield } from 'lucide-react';
import { Button } from "@/components/ui/button";

export default function EmailVerified() {
  const navigate = useNavigate();
  const [countdown, setCountdown] = useState(5);

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          navigate(createPageUrl("SelfieKYC"));
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [navigate]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0D001E] via-[#2A0055] to-[#4B0082] flex items-center justify-center p-4">
      {/* Background effects */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#8A2BE2]/20 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-[#FF2FBF]/20 rounded-full blur-3xl" />
      </div>

      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="relative w-full max-w-md text-center"
      >
        {/* Logo */}
        <Link to={createPageUrl("Home")} className="flex justify-center mb-8">
          <img 
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69293bd8e52dce0074daa668/ce96e4d2b_FINANEWLOGO-GOLDANDWHITENB.png" 
            alt="Finatrades" 
            className="h-10"
            style={{ filter: 'brightness(0) invert(1)' }}
          />
        </Link>

        {/* Success Card */}
        <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl p-8">
          {/* Animated Checkmark */}
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 200, delay: 0.2 }}
            className="w-24 h-24 mx-auto rounded-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] flex items-center justify-center mb-6 shadow-[0_0_40px_rgba(138,43,226,0.5)]"
          >
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
            >
              <CheckCircle className="w-12 h-12 text-white" />
            </motion.div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <h2 className="text-2xl font-bold text-white mb-2">Email Verified!</h2>
            <p className="text-white/70 mb-6">
              Great! Now let's verify your identity with a quick selfie and ID document.
            </p>

            {/* Next Steps */}
            <div className="bg-white/5 rounded-xl p-4 border border-white/10 mb-6">
              <div className="flex items-center gap-3 text-white/80">
                <div className="w-8 h-8 rounded-full bg-[#8A2BE2]/20 flex items-center justify-center">
                  <CheckCircle className="w-4 h-4 text-[#8A2BE2]" />
                </div>
                <span className="text-sm">Email Verified</span>
              </div>
              <div className="flex items-center gap-3 text-white/80 mt-3">
                <div className="w-8 h-8 rounded-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] flex items-center justify-center">
                  <span className="text-white text-xs font-bold">2</span>
                </div>
                <span className="text-sm font-medium text-[#FF2FBF]">Identity Verification (Next)</span>
              </div>
            </div>

            {/* Auto-redirect countdown */}
            <p className="text-white/60 text-sm mb-6">
              Redirecting to KYC in <span className="text-[#FF2FBF] font-bold">{countdown}</span> seconds...
            </p>

            <Link to={createPageUrl("SelfieKYC")}>
              <Button className="w-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white font-bold py-6 rounded-xl hover:shadow-[0_0_30px_rgba(138,43,226,0.5)]">
                Complete KYC
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
          </motion.div>
        </div>

        {/* Additional Info */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="text-white/50 text-xs mt-6"
        >
          Your account is now pending review. You'll receive a notification once verified.
        </motion.p>
      </motion.div>
    </div>
  );
}