import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { TrendingUp, Settings, Save, CheckCircle, XCircle, AlertTriangle, Calendar, Coins } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

import AdminSidebar from '@/components/admin/AdminSidebar';
import AdminTopBar from '@/components/admin/AdminTopBar';
import AdminTable from '@/components/admin/AdminTable';
import AdminStatusBadge from '@/components/admin/AdminStatusBadge';
import AdminDrawer from '@/components/admin/AdminDrawer';

const samplePlans = [
  { id: 'BNSL-2024-001', user: 'Ahmed Al-Rashid', tenure: 12, rate: 10, principalGold: 100, lockedPrice: 85.00, startDate: '2024-09-15', maturityDate: '2025-09-15', status: 'active' },
  { id: 'BNSL-2024-002', user: 'Sarah Thompson', tenure: 24, rate: 11, principalGold: 250, lockedPrice: 84.50, startDate: '2024-06-01', maturityDate: '2026-06-01', status: 'active' },
  { id: 'BNSL-2024-003', user: 'Swiss Metals AG', tenure: 36, rate: 12, principalGold: 500, lockedPrice: 82.00, startDate: '2024-01-01', maturityDate: '2027-01-01', status: 'early_term_requested' },
];

export default function AdminBNSL() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [role, setRole] = useState('Finance');
  const [activeTab, setActiveTab] = useState('plans');
  const [selectedPlan, setSelectedPlan] = useState(null);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [rates, setRates] = useState({ r12: 10, r24: 11, r36: 12 });

  useEffect(() => {
    const storedUser = localStorage.getItem('finatrades_user');
    if (!storedUser) {
      navigate(createPageUrl("SignIn"));
      return;
    }
    const userData = JSON.parse(storedUser);
    if (!userData.is_admin) {
      navigate(createPageUrl("UserDashboard"));
      return;
    }
    setUser(userData);
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('finatrades_user');
    navigate(createPageUrl("Home"));
  };

  const handleReview = (plan) => {
    setSelectedPlan(plan);
    setDrawerOpen(true);
  };

  const planColumns = [
    { header: 'Plan ID', accessor: 'id' },
    { header: 'User', accessor: 'user' },
    { header: 'Tenure', accessor: 'tenure', render: (val) => `${val}M` },
    { header: 'Rate', accessor: 'rate', render: (val) => `${val}%` },
    { header: 'Principal', accessor: 'principalGold', render: (val) => `${val}g` },
    { header: 'Locked Price', accessor: 'lockedPrice', render: (val) => `$${val.toFixed(2)}` },
    { header: 'Start Date', accessor: 'startDate' },
    { header: 'Maturity', accessor: 'maturityDate' },
    { header: 'Status', accessor: 'status', render: (val) => <AdminStatusBadge status={val} /> },
  ];

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FAFBFF] via-[#F4F6FC] to-[#FFFFFF]">
      <AdminSidebar currentSection="bnsl" onLogout={handleLogout} />
      
      <div className="ml-64">
        <AdminTopBar user={user} role={role} onRoleChange={setRole} />
        
        <main className="p-6 space-y-6">
          <div>
            <h1 className="text-2xl font-bold text-[#0D0D0D] flex items-center gap-3">
              <TrendingUp className="w-7 h-7 text-[#8A2BE2]" />
              BNSL Plans Administration
            </h1>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="bg-white border border-[#8A2BE2]/10 p-1 shadow-sm">
              <TabsTrigger value="settings" className="data-[state=active]:bg-[#8A2BE2]/20 data-[state=active]:text-[#FF2FBF]">
                <Settings className="w-4 h-4 mr-2" />
                Rate Settings
              </TabsTrigger>
              <TabsTrigger value="plans" className="data-[state=active]:bg-[#8A2BE2]/20 data-[state=active]:text-[#FF2FBF]">User Plans</TabsTrigger>
            </TabsList>

            <TabsContent value="settings" className="mt-4">
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white border border-[#8A2BE2]/20 rounded-2xl p-6 shadow-sm">
                <h3 className="text-[#0D0D0D] font-semibold mb-6">Master Plan Rate Settings</h3>
                <div className="grid md:grid-cols-3 gap-6">
                  <div className="space-y-2">
                    <label className="text-[#4A4A4A] text-sm">12-Month Plan Rate (% p.a.)</label>
                    <Input type="number" value={rates.r12} onChange={(e) => setRates({...rates, r12: parseFloat(e.target.value)})} className="bg-white border-[#8A2BE2]/20 text-[#0D0D0D] text-lg" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[#4A4A4A] text-sm">24-Month Plan Rate (% p.a.)</label>
                    <Input type="number" value={rates.r24} onChange={(e) => setRates({...rates, r24: parseFloat(e.target.value)})} className="bg-white border-[#8A2BE2]/20 text-[#0D0D0D] text-lg" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[#4A4A4A] text-sm">36-Month Plan Rate (% p.a.)</label>
                    <Input type="number" value={rates.r36} onChange={(e) => setRates({...rates, r36: parseFloat(e.target.value)})} className="bg-white border-[#8A2BE2]/20 text-[#0D0D0D] text-lg" />
                  </div>
                </div>
                <div className="flex items-center gap-3 mt-6">
                  <Button className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white font-bold">
                    <Save className="w-4 h-4 mr-2" />
                    Update Rates
                  </Button>
                </div>
              </motion.div>
            </TabsContent>

            <TabsContent value="plans" className="mt-4">
              <AdminTable columns={planColumns} data={samplePlans} onRowAction={handleReview} actionLabel="Review" />
            </TabsContent>
          </Tabs>
        </main>
      </div>

      <AdminDrawer
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        title={selectedPlan?.id || 'Plan Review'}
        subtitle={selectedPlan?.user}
        footer={
          selectedPlan?.status === 'early_term_requested' ? (
            <div className="flex items-center justify-end gap-3">
              <Button variant="outline" className="border-red-500/30 text-red-400">Reject</Button>
              <Button className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white font-bold">Approve Termination</Button>
            </div>
          ) : null
        }
      >
        {selectedPlan && (
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-[#F4F6FC] rounded-lg p-4 border border-[#8A2BE2]/10">
                <p className="text-[#4A4A4A] text-xs uppercase mb-1">Principal</p>
                <p className="text-[#0D0D0D] text-xl font-bold">{selectedPlan.principalGold}g</p>
              </div>
              <div className="bg-[#F4F6FC] rounded-lg p-4 border border-[#8A2BE2]/10">
                <p className="text-[#4A4A4A] text-xs uppercase mb-1">Locked Price</p>
                <p className="text-[#0D0D0D] text-xl font-bold">${selectedPlan.lockedPrice}</p>
              </div>
              <div className="bg-[#F4F6FC] rounded-lg p-4 border border-[#8A2BE2]/10">
                <p className="text-[#4A4A4A] text-xs uppercase mb-1">Locked Value</p>
                <p className="text-[#FF2FBF] text-xl font-bold">${(selectedPlan.principalGold * selectedPlan.lockedPrice).toFixed(2)}</p>
              </div>
            </div>
          </div>
        )}
      </AdminDrawer>
    </div>
  );
}