import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { 
  Shield, Building2, Globe, FileText, MapPin, Calendar, 
  Hash, Award, CheckCircle, Users, Search, FolderArchive, 
  GraduationCap, BarChart3, Mail, ArrowLeft, ExternalLink
} from 'lucide-react';

export default function RegulatoryInformation() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FAFBFF] via-[#F4F6FC] to-white text-[#0D0D0D]">
      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(138,43,226,0.08)_0%,_transparent_50%)]" />
        <div className="max-w-4xl mx-auto px-6 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <Link 
              to={createPageUrl("Home")} 
              onClick={() => window.scrollTo(0, 0)}
              className="inline-flex items-center gap-2 text-[#8A2BE2] hover:text-[#FF2FBF] transition-colors mb-6"
            >
              <ArrowLeft className="w-4 h-4" />
              <span className="text-sm">Back to Home</span>
            </Link>
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF]/10 border border-[#8A2BE2]/30 mb-6">
              <Shield className="w-4 h-4 text-[#8A2BE2]" />
              <span className="text-sm text-[#8A2BE2]">Trusted & Regulated</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-extralight mb-4">
              Complete Regulatory and <span className="text-[#8A2BE2]">Legal Information</span>
            </h1>
            <p className="text-[#4A4A4A]">About Finatrades Finance SA</p>
          </motion.div>
        </div>
      </section>

      {/* Content */}
      <section className="pb-20">
        <div className="max-w-4xl mx-auto px-6">

          {/* Company Information */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="mb-12"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#8A2BE2]/20 to-[#FF2FBF]/10 flex items-center justify-center">
                <Building2 className="w-6 h-6 text-[#8A2BE2]" />
              </div>
              <h2 className="text-2xl font-light text-[#0D0D0D]">Company Information</h2>
            </div>
            
            <div className="bg-white shadow-[0_8px_32px_rgba(160,50,255,0.12)] rounded-2xl border border-[#8A2BE2]/20 p-8">
              <div className="grid md:grid-cols-2 gap-6">
                <InfoItem icon={FileText} label="Full Legal Name" value="Finatrades Finance SA" />
                <InfoItem icon={Globe} label="Website" value="https://finatrades.com" isLink />
                <InfoItem icon={MapPin} label="Registered Office" value="Rue Robert-CÉARD 6, 1204, GENEVA" />
                <InfoItem icon={MapPin} label="Canton" value="GENEVA" />
                <InfoItem icon={Hash} label="Company Number (UID)" value="CHE-422.960.092" highlight />
                <InfoItem icon={Calendar} label="Date of Formation" value="29.01.2019" />
                <InfoItem icon={Building2} label="Type of Corporation" value="Société Anonyme LLC" className="md:col-span-2" />
              </div>
            </div>
          </motion.div>

          {/* License Confirmation */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="mb-12"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#8A2BE2]/20 to-[#FF2FBF]/10 flex items-center justify-center">
                <Award className="w-6 h-6 text-[#8A2BE2]" />
              </div>
              <h2 className="text-2xl font-light text-[#0D0D0D]">License Confirmation</h2>
            </div>

            <div className="bg-gradient-to-br from-[#8A2BE2]/10 to-[#FF2FBF]/5 rounded-2xl border border-[#8A2BE2]/30 p-8">
              <div className="flex items-center gap-4 mb-6">
                <div className="px-4 py-2 rounded-lg bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white font-medium">
                  FINMA
                </div>
                <div>
                  <p className="text-[#0D0D0D] font-medium">Regulatory Supervision</p>
                  <p className="text-[#8A2BE2]">SO-FIT Member No.: 1186</p>
                </div>
              </div>

              <p className="text-[#333333] leading-relaxed mb-4">
                Finatrades Finance SA ("Finatrades") is an authorized member of d'Organisme de Surveillance pour Intermédiaires Financiers & Trustees (SO-FIT) (Member No.: 1186), and as such is subject to supervision by SO-FIT, a supervisory body officially recognized by the Swiss Financial Market Supervisory Authority (FINMA).
              </p>
              <p className="text-[#333333] leading-relaxed mb-4">
                Finatrades' activities, including provision of its digital barter and payment platform, are carried out in compliance with the Swiss Federal Anti-Money Laundering Act (AMLA) and other applicable Swiss and international financial regulations.
              </p>
              <p className="text-[#4A4A4A] text-sm">
                All regulatory matters regarding Finatrades should be addressed to SO-FIT in its capacity as supervisory body.
              </p>
            </div>
          </motion.div>

          {/* AML Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="mb-12"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#8A2BE2]/20 to-[#FF2FBF]/10 flex items-center justify-center">
                <Shield className="w-6 h-6 text-[#8A2BE2]" />
              </div>
              <h2 className="text-2xl font-light text-[#0D0D0D]">Anti-Money Laundering (AML)</h2>
            </div>

            <div className="bg-white shadow-[0_8px_32px_rgba(160,50,255,0.12)] rounded-2xl border border-[#8A2BE2]/20 p-8">
              <h3 className="text-lg font-medium text-[#8A2BE2] mb-4">Comprehensive AML Compliance Statement</h3>
              
              <p className="text-[#333333] leading-relaxed mb-6">
                Finatrades Finance SA ("Finatrades") is subject to the Swiss Federal Anti-Money Laundering Act (AMLA) and operates in full alignment with the Financial Action Task Force (FATF) Recommendations. Switzerland, as a FATF member country, requires Finatrades to identify its customers and verify the identity of the ultimate beneficial owner (UBO) for every relationship and transaction.
              </p>

              <p className="text-[#4A4A4A] mb-6">
                Finatrades' AML & CFT Compliance Program, approved by the Management Board, includes:
              </p>

              <div className="grid md:grid-cols-2 gap-4 mb-6">
                <AMLCard 
                  icon={Users} 
                  title="Customer Due Diligence (CDD)" 
                  description="Mandatory identity verification of all customers and beneficial owners, including documentation of source of funds and purpose of transactions."
                />
                <AMLCard 
                  icon={Search} 
                  title="Enhanced Due Diligence (EDD)" 
                  description="Additional scrutiny for Politically Exposed Persons (PEPs), high-risk jurisdictions, and complex structures."
                />
                <AMLCard 
                  icon={BarChart3} 
                  title="Ongoing Monitoring" 
                  description="Continuous review of transactions to detect and report unusual or suspicious activity."
                />
                <AMLCard 
                  icon={FolderArchive} 
                  title="Record Retention" 
                  description="Secure storage of customer and transaction records for the statutory retention period."
                />
                <AMLCard 
                  icon={GraduationCap} 
                  title="Employee Training" 
                  description="Regular AML/CFT training for all relevant employees to ensure understanding of regulatory obligations."
                />
                <AMLCard 
                  icon={BarChart3} 
                  title="Risk-Based Approach" 
                  description="Application of the Wolfsberg Principles and other international best practices for risk classification and monitoring."
                />
              </div>

              <p className="text-[#333333] leading-relaxed">
                Finatrades does not maintain relationships with shell banks (banks without physical presence or supervision) and ensures that all counterparties are properly regulated entities. These AML policies apply equally to Finatrades' headquarters and any affiliates or branches.
              </p>
            </div>
          </motion.div>

          {/* Compliance Contact */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-white shadow-[0_8px_32px_rgba(160,50,255,0.12)] rounded-2xl border border-[#8A2BE2]/20 p-8"
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#8A2BE2]/20 to-[#FF2FBF]/10 flex items-center justify-center">
                <Mail className="w-5 h-5 text-[#8A2BE2]" />
              </div>
              <h3 className="text-xl font-light text-[#0D0D0D]">Compliance Contact</h3>
            </div>
            <p className="text-[#4A4A4A] mb-4">
              For compliance-related inquiries, please use the contact form on our website's Contact Us page.
            </p>
            <a 
              href="mailto:support@finatrades.com" 
              className="text-[#8A2BE2] hover:underline flex items-center gap-2"
            >
              <Mail className="w-4 h-4" />
              support@finatrades.com
            </a>
          </motion.div>

          {/* Back to Home Button */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="mt-12 text-center"
          >
            <Link 
              to={createPageUrl("Home")} 
              onClick={() => window.scrollTo(0, 0)}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white font-medium hover:shadow-[0_0_20px_rgba(138,43,226,0.3)] transition-all"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Home
            </Link>
          </motion.div>

        </div>
      </section>
    </div>
  );
}

function InfoItem({ icon: Icon, label, value, isLink = false, highlight = false, className = "" }) {
  return (
    <div className={`flex items-start gap-3 ${className}`}>
      <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#FAFBFF] via-[#F4F6FC] to-white flex items-center justify-center flex-shrink-0 mt-0.5">
        <Icon className="w-4 h-4 text-[#8A2BE2]" />
      </div>
      <div>
        <p className="text-sm text-[#4A4A4A]/80 mb-1">{label}</p>
        {isLink ? (
          <a href={value} target="_blank" rel="noopener noreferrer" className="text-[#8A2BE2] hover:underline flex items-center gap-1">
            {value}
            <ExternalLink className="w-3 h-3" />
          </a>
        ) : (
          <p className={`${highlight ? 'text-[#8A2BE2] font-medium' : 'text-[#0D0D0D]'}`}>{value}</p>
        )}
      </div>
    </div>
  );
}

function AMLCard({ icon: Icon, title, description }) {
  return (
    <div className="bg-gradient-to-br from-[#FAFBFF] via-[#F4F6FC] to-white rounded-xl border border-[#8A2BE2]/10 p-5">
      <div className="flex items-start gap-3">
        <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#8A2BE2]/20 to-[#FF2FBF]/10 flex items-center justify-center flex-shrink-0">
          <Icon className="w-4 h-4 text-[#8A2BE2]" />
        </div>
        <div>
          <h4 className="text-[#0D0D0D] font-medium mb-1">{title}</h4>
          <p className="text-[#4A4A4A] text-sm leading-relaxed">{description}</p>
        </div>
      </div>
    </div>
  );
}