import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion, useScroll, useTransform, AnimatePresence } from 'framer-motion';
import { 
  Wallet, Send, ArrowRightLeft, Globe, Shield, Lock, 
  CreditCard, ArrowRight, CheckCircle, TrendingUp, 
  Fingerprint, Database, Zap, RefreshCw, Clock,
  ArrowUpRight, ArrowDownLeft, Building, Sparkles, Wifi
} from 'lucide-react';
import { useLanguage } from '@/components/LanguageContext';

// Particle Field Component
const ParticleField = ({ count = 50 }) => {
  const particles = Array.from({ length: count }, (_, i) => ({
    id: i,
    x: Math.random() * 100,
    y: Math.random() * 100,
    size: Math.random() * 3 + 1,
    duration: Math.random() * 20 + 10,
    delay: Math.random() * 5,
    color: Math.random() > 0.5 ? '#8A2BE2' : '#FF2FBF'
  }));

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {particles.map((p) => (
        <motion.div
          key={p.id}
          className="absolute rounded-full"
          style={{
            left: `${p.x}%`,
            top: `${p.y}%`,
            width: p.size,
            height: p.size,
            backgroundColor: p.color,
            boxShadow: `0 0 ${p.size * 2}px ${p.color}`
          }}
          animate={{
            y: [0, -100, 0],
            opacity: [0, 0.6, 0],
            scale: [0.5, 1.2, 0.5]
          }}
          transition={{
            duration: p.duration,
            delay: p.delay,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      ))}
    </div>
  );
};

// Glowing Orb Component
const GlowingOrb = ({ className, delay = 0 }) => (
  <motion.div
    className={`absolute rounded-full blur-3xl ${className}`}
    animate={{
      scale: [1, 1.3, 1],
      opacity: [0.3, 0.6, 0.3]
    }}
    transition={{ duration: 4, delay, repeat: Infinity, ease: "easeInOut" }}
  />
);

// Brush Splash Background
const BrushSplash = () => (
  <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-30">
    <svg className="absolute w-full h-full" viewBox="0 0 1000 1000" preserveAspectRatio="none">
      <defs>
        <linearGradient id="splashGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#8A2BE2" stopOpacity="0.2" />
          <stop offset="50%" stopColor="#FF2FBF" stopOpacity="0.1" />
          <stop offset="100%" stopColor="#A855F7" stopOpacity="0.15" />
        </linearGradient>
      </defs>
      <path d="M0,200 Q250,100 500,200 T1000,200 L1000,0 L0,0 Z" fill="url(#splashGrad)" />
      <path d="M0,800 Q250,900 500,800 T1000,800 L1000,1000 L0,1000 Z" fill="url(#splashGrad)" />
    </svg>
  </div>
);

// Animated Wallet Card Component
const WalletCard = () => {
  const [balance, setBalance] = useState(0);
  const targetBalance = 24750.85;

  useEffect(() => {
    const duration = 2000;
    const steps = 60;
    const increment = targetBalance / steps;
    let current = 0;
    const timer = setInterval(() => {
      current += increment;
      if (current >= targetBalance) {
        setBalance(targetBalance);
        clearInterval(timer);
      } else {
        setBalance(current);
      }
    }, duration / steps);
    return () => clearInterval(timer);
  }, []);

  return (
    <motion.div
      className="relative w-full max-w-sm mx-auto"
      initial={{ opacity: 0, y: 50, rotateX: 20 }}
      animate={{ opacity: 1, y: 0, rotateX: 0 }}
      transition={{ duration: 1, delay: 0.5 }}
    >
      {/* Card Glow */}
      <div className="absolute -inset-4 bg-gradient-to-r from-[#8A2BE2]/30 via-[#FF2FBF]/20 to-[#8A2BE2]/30 rounded-3xl blur-2xl animate-pulse" />
      
      {/* Purple Neon Edge */}
      <div className="absolute -inset-1 bg-gradient-to-r from-[#8A2BE2] via-[#FF2FBF] to-[#8A2BE2] rounded-2xl opacity-60" />
      
      {/* Main Card */}
      <motion.div
        className="relative w-full h-auto min-h-[200px] rounded-2xl bg-white border border-[#8A2BE2]/30 p-5 sm:p-6 overflow-hidden shadow-[0_8px_32px_rgba(138,43,226,0.15)]"
        animate={{ y: [0, -10, 0] }}
        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
      >
        {/* Light Sweep */}
        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-transparent via-[#8A2BE2]/10 to-transparent"
          animate={{ x: [-400, 400] }}
          transition={{ duration: 3, repeat: Infinity, repeatDelay: 2, ease: "easeInOut" }}
        />
        
        {/* Card Content */}
        <div className="relative z-10">
          <div className="flex items-center justify-between mb-4 sm:mb-6">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-br from-[#8A2BE2] to-[#FF2FBF] flex items-center justify-center shadow-[0_0_15px_rgba(138,43,226,0.4)]">
                <Wallet className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
              </div>
              <span className="text-[#0D0D0D] font-bold tracking-wide text-sm sm:text-base">FinaPay</span>
            </div>
            <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-[#8A2BE2]" />
          </div>
          
          <div className="mb-4 sm:mb-6">
            <p className="text-[#4A4A4A] text-xs sm:text-sm mb-1 font-medium">Gold Balance</p>
            <div className="flex items-baseline gap-2 flex-wrap">
              <span className="text-2xl sm:text-3xl font-bold bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent">
                ${balance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
              <span className="text-[#8A2BE2] text-xs sm:text-sm font-medium">USD</span>
            </div>
            <p className="text-[#4A4A4A]/80 text-xs sm:text-sm mt-1">≈ 12.45 oz Gold</p>
          </div>
          
          <div className="flex items-center">
            <div className="flex gap-2 flex-wrap">
              {['Send', 'Receive', 'Convert'].map((action, i) => (
                <motion.div
                  key={action}
                  className="px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-lg bg-[#8A2BE2]/10 border border-[#8A2BE2]/30 text-[#8A2BE2] text-xs font-medium"
                  whileHover={{ scale: 1.05, backgroundColor: 'rgba(138,43,226,0.2)', boxShadow: '0 0 15px rgba(138,43,226,0.3)' }}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 1.5 + i * 0.1 }}
                >
                  {action}
                </motion.div>
              ))}
            </div>
          </div>
        </div>
        
        {/* Corner Accent */}
        <div className="absolute bottom-0 right-0 w-24 sm:w-32 h-24 sm:h-32 bg-gradient-to-tl from-[#FF2FBF]/20 via-[#8A2BE2]/10 to-transparent rounded-tl-full" />
      </motion.div>
      
      {/* Floating Transaction Bubbles - Hidden on mobile */}
      <div className="hidden md:block">
        {[
          { text: '+$500.00', icon: ArrowDownLeft, x: -60, y: -20, delay: 2 },
          { text: 'Transfer', icon: Send, x: 280, y: 80, delay: 2.5 },
          { text: 'Synced', icon: CheckCircle, x: -40, y: 180, delay: 3 }
        ].map((bubble, i) => (
          <motion.div
            key={i}
            className="absolute px-3 py-2 rounded-xl bg-white border border-[#8A2BE2]/30 backdrop-blur-sm flex items-center gap-2 shadow-[0_4px_20px_rgba(138,43,226,0.15)]"
            style={{ left: bubble.x, top: bubble.y }}
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: [0, 1, 1, 0], scale: [0.5, 1, 1, 0.5] }}
            transition={{ delay: bubble.delay, duration: 4, repeat: Infinity, repeatDelay: 4 }}
          >
            <bubble.icon className="w-4 h-4 text-[#8A2BE2]" />
            <span className="text-[#0D0D0D] text-sm font-medium">{bubble.text}</span>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

// Hero Section
const HeroSection = () => {
  const { t } = useLanguage() || { t: (key) => key };
  const { scrollYProgress } = useScroll();
  const y = useTransform(scrollYProgress, [0, 0.3], [0, 100]);
  const opacity = useTransform(scrollYProgress, [0, 0.3], [1, 0]);

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden py-20">
      {/* Background Gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#FAFBFF] via-[#F4F6FC] to-[#FFFFFF]" />
      
      {/* Background Effects */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(138,43,226,0.08)_0%,_transparent_50%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_rgba(255,47,191,0.06)_0%,_transparent_40%)]" />
      <BrushSplash />
      <ParticleField count={60} />
      <GlowingOrb className="w-96 h-96 bg-[#8A2BE2]/20 top-1/4 left-1/4" />
      <GlowingOrb className="w-64 h-64 bg-[#FF2FBF]/15 bottom-1/4 right-1/4" delay={1} />
      
      <motion.div style={{ y, opacity }} className="relative z-10 max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Text Content */}
          <div className="text-center lg:text-left">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#8A2BE2]/10 border border-[#8A2BE2]/30 text-[#8A2BE2] text-sm mb-6"
            >
              <Wallet className="w-4 h-4 text-[#8A2BE2]" />
              <span className="font-semibold">{t('finapay.hero.badge')}</span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="text-5xl md:text-7xl font-bold text-[#0D0D0D] mb-4"
            >
              {t('finapay.hero.title')}<span className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent">{t('finapay.hero.titleHighlight')}</span>
            </motion.h1>

            <motion.h2
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="text-2xl md:text-3xl font-medium text-[#4A4A4A] mb-6"
            >
              {t('finapay.hero.subtitle')}<br />
              <span className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent font-bold">{t('finapay.hero.subtitleHighlight')}</span>
            </motion.h2>

            <motion.p
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="text-[#4A4A4A] text-lg mb-8 max-w-lg mx-auto lg:mx-0"
            >
              {t('finapay.hero.description')}
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.5 }}
              className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start"
            >
              <Link to={createPageUrl("Home")} onClick={() => window.scrollTo(0, 0)}>
                <motion.button
                  className="group px-8 py-4 rounded-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white font-bold flex items-center justify-center gap-2 shadow-[0_0_30px_rgba(138,43,226,0.3)]"
                  whileHover={{ scale: 1.05, boxShadow: '0 0 50px rgba(138,43,226,0.5)' }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Wallet className="w-5 h-5" />
                  {t('finapay.hero.cta1')}
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </motion.button>
              </Link>
              <motion.button
                className="px-8 py-4 rounded-full border border-[#8A2BE2]/30 text-[#8A2BE2] font-bold flex items-center justify-center gap-2 bg-white hover:bg-[#8A2BE2]/5 transition-colors"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Clock className="w-5 h-5" />
                {t('finapay.hero.cta2')}
              </motion.button>
            </motion.div>
          </div>

          {/* Wallet Card */}
          <div className="flex justify-center lg:justify-end px-4 sm:px-0">
            <WalletCard />
          </div>
        </div>
      </motion.div>

      {/* Scroll Indicator */}
      <motion.div 
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <div className="w-6 h-10 rounded-full border-2 border-[#8A2BE2]/30 flex items-start justify-center p-2">
          <motion.div 
            className="w-1.5 h-1.5 rounded-full bg-[#8A2BE2]"
            animate={{ y: [0, 12, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
          />
        </div>
      </motion.div>
    </section>
  );
};

// Value Pillars Section
const ValuePillars = () => {
  const { t } = useLanguage() || { t: (key) => key };
  const pillars = [
    { icon: Wallet, title: 'Gold-Backed Wallet', desc: 'Every balance unit represents real gold in secure vaults', anim: 'counter' },
    { icon: Zap, title: 'Instant Transfers', desc: 'Send and receive gold value in seconds globally', anim: 'pulse' },
    { icon: RefreshCw, title: 'Multi-Currency Value', desc: 'View balance in USD, grams, or troy ounces', anim: 'rotate' },
    { icon: Building, title: 'Vault-Linked', desc: 'Directly connected to your FinaVault holdings', anim: 'flow' },
    { icon: TrendingUp, title: 'Real-Time Pricing', desc: 'Live gold rates updated every second', anim: 'ticker' },
    { icon: Lock, title: 'Secure & Encrypted', desc: 'Bank-level security with end-to-end encryption', anim: 'lock' }
  ];

  return (
    <section className="relative py-32 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#FAFBFF] via-[#F4F6FC] to-[#FAFBFF]" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(138,43,226,0.05)_0%,_transparent_50%)]" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-[#0D0D0D] mb-4">
            {t('finapay.features.title')} <span className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent">{t('finapay.features.titleHighlight')}</span>
          </h2>
          <p className="text-[#4A4A4A] text-lg max-w-2xl mx-auto font-medium">
            {t('finapay.features.subtitle')}
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {pillars.map((pillar, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              whileHover={{ y: -5, boxShadow: '0 0 40px rgba(212,175,55,0.3), 0 0 60px rgba(75,0,130,0.4)' }}
              className="relative group p-8 rounded-2xl bg-white border border-[#8A2BE2]/20 overflow-hidden shadow-[0_8px_32px_rgba(138,43,226,0.08)] hover:border-[#8A2BE2]/40 transition-all"
            >
              {/* Purple Neon Edge */}
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-[#8427C9]/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              
              {/* Gold Glow Effect */}
              <div className="absolute -inset-1 bg-gradient-to-r from-[#D4AF37]/0 via-[#D4AF37]/20 to-[#D4AF37]/0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-xl" />
              
              <motion.div
                className="w-14 h-14 rounded-xl bg-gradient-to-br from-[#8A2BE2]/20 to-[#FF2FBF]/10 border border-[#8A2BE2]/30 flex items-center justify-center mb-4"
                whileHover={{ rotate: 5, scale: 1.1 }}
              >
                <pillar.icon className="w-7 h-7 text-[#8A2BE2]" />
              </motion.div>
              
              <h3 className="text-xl font-bold text-[#0D0D0D] mb-2">{pillar.title}</h3>
              <p className="text-[#4A4A4A]">{pillar.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

// Wallet UI Demo Section
const WalletUIDemo = () => {
  const { t } = useLanguage() || { t: (key) => key };
  const [activeTab, setActiveTab] = useState('balance');
  const [currency, setCurrency] = useState('USD');
  const currencies = ['USD', 'Grams', 'Oz'];
  const balances = { USD: '$24,750.85', Grams: '385.2 g', Oz: '12.45 oz' };

  const transactions = [
    { type: 'received', from: 'John Smith', amount: '+$2,500.00', time: '2 min ago', icon: ArrowDownLeft },
    { type: 'sent', to: 'Trade Partner', amount: '-$1,200.00', time: '1 hour ago', icon: ArrowUpRight },
    { type: 'vault', action: 'Deposit Synced', amount: '+5.2 g', time: '3 hours ago', icon: Building }
  ];

  return (
    <section className="relative py-32 overflow-hidden">
      {/* Light Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#FAFBFF] via-[#F4F6FC] to-[#FAFBFF]" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(138,43,226,0.05)_0%,_transparent_50%)]" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-[#0D0D0D] mb-4">
            {t('finapay.wallet.title')} <span className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent">{t('finapay.wallet.titleHighlight')}</span>
          </h2>
          <p className="text-[#4A4A4A] text-lg max-w-2xl mx-auto">
            {t('finapay.wallet.subtitle')}
          </p>
        </motion.div>

        <div className="flex justify-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="relative w-full max-w-md"
          >
            {/* Phone Frame */}
            <div className="absolute -inset-2 bg-gradient-to-r from-[#8A2BE2] via-[#FF2FBF] to-[#8A2BE2] rounded-[3.5rem] opacity-20 blur-xl" />
            <div className="relative bg-white rounded-[3rem] border border-[#8A2BE2]/20 p-3 shadow-[0_8px_32px_rgba(138,43,226,0.15)]">
              <div className="absolute top-6 left-1/2 -translate-x-1/2 w-24 h-6 bg-[#F4F6FC] rounded-full border border-[#8A2BE2]/10" />
              
              <div className="bg-gradient-to-b from-[#FAFBFF] to-white rounded-[2.5rem] p-6 min-h-[600px]">
                {/* Header */}
                <div className="flex items-center justify-between mb-8 pt-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#8A2BE2] to-[#FF2FBF] flex items-center justify-center shadow-[0_0_15px_rgba(138,43,226,0.3)]">
                      <Wallet className="w-5 h-5 text-white" />
                    </div>
                    <span className="text-[#0D0D0D] font-bold">FinaPay</span>
                  </div>
                  <motion.button
                    whileTap={{ scale: 0.9 }}
                    className="w-10 h-10 rounded-full bg-[#8A2BE2]/10 border border-[#8A2BE2]/20 flex items-center justify-center"
                  >
                    <Sparkles className="w-5 h-5 text-[#8A2BE2]" />
                  </motion.button>
                </div>

                {/* Balance */}
                <div className="text-center mb-8">
                  <p className="text-[#4A4A4A] text-sm mb-2 font-medium">Gold Balance</p>
                  <AnimatePresence mode="wait">
                    <motion.div
                      key={currency}
                      initial={{ opacity: 0, y: -20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 20 }}
                      className="text-4xl font-bold bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent mb-4"
                    >
                      {balances[currency]}
                    </motion.div>
                  </AnimatePresence>
                  
                  {/* Currency Toggle */}
                  <div className="flex justify-center gap-2">
                    {currencies.map((c) => (
                      <motion.button
                        key={c}
                        onClick={() => setCurrency(c)}
                        className={`px-4 py-2 rounded-full text-sm font-bold transition-all ${
                          currency === c 
                            ? 'bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white shadow-[0_0_15px_rgba(138,43,226,0.3)]' 
                            : 'bg-[#8A2BE2]/10 text-[#8A2BE2] border border-[#8A2BE2]/20'
                        }`}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        {c}
                      </motion.button>
                    ))}
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex justify-center gap-4 mb-8">
                  {[
                    { icon: Send, label: 'Send' },
                    { icon: ArrowDownLeft, label: 'Receive' },
                    { icon: RefreshCw, label: 'Convert' }
                  ].map((action, i) => (
                    <motion.button
                      key={action.label}
                      className="flex flex-col items-center gap-2"
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.5 + i * 0.1 }}
                    >
                      <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#8A2BE2]/10 to-[#FF2FBF]/10 border border-[#8A2BE2]/20 flex items-center justify-center">
                        <action.icon className="w-6 h-6 text-[#8A2BE2]" />
                      </div>
                      <span className="text-[#4A4A4A] text-xs font-medium">{action.label}</span>
                    </motion.button>
                  ))}
                </div>

                {/* Transactions */}
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-[#0D0D0D] font-bold">Recent Activity</span>
                    <span className="text-[#8A2BE2] text-sm font-medium">View All</span>
                  </div>
                  <div className="space-y-3">
                    {transactions.map((tx, i) => (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.8 + i * 0.15 }}
                        className="flex items-center justify-between p-3 rounded-xl bg-white border border-[#8A2BE2]/10 shadow-sm"
                      >
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                            tx.type === 'received' ? 'bg-green-500/10 border border-green-500/20' : 
                            tx.type === 'sent' ? 'bg-red-500/10 border border-red-500/20' : 'bg-[#8A2BE2]/10 border border-[#8A2BE2]/20'
                          }`}>
                            <tx.icon className={`w-5 h-5 ${
                              tx.type === 'received' ? 'text-green-500' : 
                              tx.type === 'sent' ? 'text-red-500' : 'text-[#8A2BE2]'
                            }`} />
                          </div>
                          <div>
                            <p className="text-[#0D0D0D] text-sm font-medium">{tx.from || tx.to || tx.action}</p>
                            <p className="text-[#4A4A4A]/70 text-xs">{tx.time}</p>
                          </div>
                        </div>
                        <span className={`font-bold ${
                          tx.type === 'received' ? 'text-green-500' : 
                          tx.type === 'sent' ? 'text-red-500' : 'text-[#8A2BE2]'
                        }`}>{tx.amount}</span>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

// Gold Transfer Animation Section
const GoldTransferSection = () => {
  const { t } = useLanguage() || { t: (key) => key };
  const [transferProgress, setTransferProgress] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setTransferProgress(p => p >= 100 ? 0 : p + 2);
    }, 100);
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="relative py-32 overflow-hidden">
      {/* Light Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#FAFBFF] via-[#F4F6FC] to-[#FAFBFF]" />
      <div className="absolute inset-0 bg-gradient-to-r from-[#8A2BE2]/5 via-transparent to-[#FF2FBF]/5" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-[#0D0D0D] mb-4">
            {t('finapay.transfer.title')} <span className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent">{t('finapay.transfer.titleHighlight')}</span>
          </h2>
          <p className="text-[#4A4A4A] text-lg max-w-2xl mx-auto">
            {t('finapay.transfer.subtitle')}
          </p>
        </motion.div>

        <div className="flex flex-col md:flex-row items-center justify-center gap-8 md:gap-16">
          {/* FinaVault */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="w-40 h-40 rounded-3xl bg-white border border-[#8A2BE2]/20 flex flex-col items-center justify-center shadow-[0_8px_32px_rgba(138,43,226,0.1)]">
              <Building className="w-12 h-12 text-[#8A2BE2] mb-2" />
              <span className="text-[#0D0D0D] font-bold">FinaVault</span>
              <span className="text-[#4A4A4A] text-sm">Physical Gold</span>
            </div>
            <motion.div
              className="absolute -inset-2 rounded-3xl border-2 border-[#8A2BE2]/20"
              animate={{ scale: [1, 1.1, 1], opacity: [0.5, 0, 0.5] }}
              transition={{ duration: 2, repeat: Infinity }}
            />
          </motion.div>

          {/* Transfer Animation */}
          <div className="relative w-48 h-24 md:w-64 md:h-16">
            {/* Arrow Path */}
            <div className="absolute inset-y-0 left-0 right-0 flex items-center">
              <div className="w-full h-1 bg-[#8A2BE2]/20 rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF]"
                  style={{ width: `${transferProgress}%` }}
                />
              </div>
            </div>
            
            {/* Floating Particles */}
            {[...Array(5)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-3 h-3 rounded-full bg-[#8A2BE2]"
                style={{ top: '50%', translateY: '-50%' }}
                animate={{
                  x: [0, 256],
                  opacity: [0, 1, 1, 0],
                  scale: [0.5, 1, 1, 0.5]
                }}
                transition={{
                  duration: 2,
                  delay: i * 0.4,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              />
            ))}
            
            {/* Direction Arrows */}
            <motion.div
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"
              animate={{ x: [-10, 10, -10] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            >
              <ArrowRight className="w-8 h-8 text-[#8A2BE2]" />
            </motion.div>
          </div>

          {/* FinaPay */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="w-40 h-40 rounded-3xl bg-white border border-[#8A2BE2]/20 flex flex-col items-center justify-center shadow-[0_8px_32px_rgba(138,43,226,0.1)]">
              <Wallet className="w-12 h-12 text-[#FF2FBF] mb-2" />
              <span className="text-[#0D0D0D] font-bold">FinaPay</span>
              <span className="text-[#4A4A4A] text-sm">Digital Wallet</span>
            </div>
            <motion.div
              className="absolute -inset-2 rounded-3xl border-2 border-[#FF2FBF]/20"
              animate={{ scale: [1, 1.1, 1], opacity: [0.5, 0, 0.5] }}
              transition={{ duration: 2, repeat: Infinity, delay: 1 }}
            />
          </motion.div>
        </div>

        {/* Ledger Update */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-16 max-w-md mx-auto"
        >
          <div className="p-6 rounded-2xl bg-white border border-[#8A2BE2]/20 shadow-[0_8px_32px_rgba(138,43,226,0.1)]">
            <div className="flex items-center gap-3 mb-4">
              <Database className="w-5 h-5 text-[#8A2BE2]" />
              <span className="text-[#0D0D0D] font-bold">Gold Ledger</span>
              <motion.span
                className="ml-auto px-2 py-1 rounded-full bg-green-500/10 text-green-600 text-xs font-bold border border-green-500/20"
                animate={{ opacity: [1, 0.5, 1] }}
                transition={{ duration: 1.5, repeat: Infinity }}
              >
                Live
              </motion.span>
            </div>
            <div className="space-y-2 font-mono text-sm">
              <div className="flex justify-between text-[#4A4A4A]">
                <span>Transfer ID:</span>
                <span className="text-[#8A2BE2]">TXN-2024-{Math.floor(transferProgress * 100)}</span>
              </div>
              <div className="flex justify-between text-[#4A4A4A]">
                <span>Amount:</span>
                <span className="text-[#0D0D0D] font-bold">5.25 oz</span>
              </div>
              <div className="flex justify-between text-[#4A4A4A]">
                <span>Status:</span>
                <motion.span
                  className="text-green-600 font-bold"
                  animate={{ opacity: [1, 0.5, 1] }}
                  transition={{ duration: 0.5, repeat: Infinity }}
                >
                  Confirming...
                </motion.span>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

// Global Payment Network Section
const GlobalNetworkSection = () => {
  const { t } = useLanguage() || { t: (key) => key };
  const nodes = [
    { x: 15, y: 40, label: 'New York' },
    { x: 45, y: 35, label: 'London' },
    { x: 52, y: 45, label: 'Geneva' },
    { x: 55, y: 55, label: 'Dubai' },
    { x: 75, y: 50, label: 'Singapore' },
    { x: 85, y: 40, label: 'Hong Kong' }
  ];

  return (
    <section className="relative py-32 overflow-hidden">
      {/* Light Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#FAFBFF] via-[#F4F6FC] to-[#FAFBFF]" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(138,43,226,0.05)_0%,_transparent_50%)]" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-[#0D0D0D] mb-4">
            {t('finapay.network.title')} <span className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent">{t('finapay.network.titleHighlight')}</span>
          </h2>
          <p className="text-[#4A4A4A] text-lg max-w-2xl mx-auto">
            {t('finapay.network.subtitle')}
          </p>
        </motion.div>

        <div className="relative aspect-[2/1] max-w-4xl mx-auto bg-white rounded-3xl border border-[#8A2BE2]/10 shadow-[0_8px_32px_rgba(138,43,226,0.08)] p-8">
          {/* World Map Dots */}
          <div className="absolute inset-0 opacity-20">
            {[...Array(200)].map((_, i) => (
              <div
                key={i}
                className="absolute w-1 h-1 rounded-full bg-[#8A2BE2]/50"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`
                }}
              />
            ))}
          </div>

          {/* Connection Lines */}
          <svg className="absolute inset-0 w-full h-full">
            {nodes.map((node, i) => 
              nodes.slice(i + 1).map((target, j) => (
                <motion.line
                  key={`${i}-${j}`}
                  x1={`${node.x}%`}
                  y1={`${node.y}%`}
                  x2={`${target.x}%`}
                  y2={`${target.y}%`}
                  stroke="#8A2BE2"
                  strokeWidth="1"
                  strokeOpacity="0.3"
                  initial={{ pathLength: 0 }}
                  whileInView={{ pathLength: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 2, delay: i * 0.2 }}
                />
              ))
            )}
          </svg>

          {/* Animated Pulse Lines */}
          <svg className="absolute inset-0 w-full h-full">
            {nodes.slice(0, -1).map((node, i) => (
              <motion.circle
                key={i}
                r="4"
                fill="#FF2FBF"
                initial={{ cx: `${node.x}%`, cy: `${node.y}%` }}
                animate={{
                  cx: [`${node.x}%`, `${nodes[i + 1].x}%`],
                  cy: [`${node.y}%`, `${nodes[i + 1].y}%`],
                  opacity: [0, 1, 0]
                }}
                transition={{
                  duration: 3,
                  delay: i * 0.5,
                  repeat: Infinity,
                  repeatDelay: 2
                }}
              />
            ))}
          </svg>

          {/* Nodes */}
          {nodes.map((node, i) => (
            <motion.div
              key={i}
              className="absolute"
              style={{ left: `${node.x}%`, top: `${node.y}%` }}
              initial={{ scale: 0, opacity: 0 }}
              whileInView={{ scale: 1, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, type: "spring" }}
            >
              <div className="relative -translate-x-1/2 -translate-y-1/2">
                <motion.div
                  className="absolute w-8 h-8 rounded-full bg-[#8A2BE2]/20"
                  animate={{ scale: [1, 2, 1], opacity: [0.5, 0, 0.5] }}
                  transition={{ duration: 2, repeat: Infinity, delay: i * 0.2 }}
                />
                <div className="relative w-4 h-4 rounded-full bg-gradient-to-br from-[#8A2BE2] to-[#FF2FBF] border-2 border-white" />
                <div className="absolute top-6 left-1/2 -translate-x-1/2 whitespace-nowrap">
                  <span className="text-[#4A4A4A] text-xs font-medium">{node.label}</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

// Transaction History Section
const TransactionHistorySection = () => {
  const { t } = useLanguage() || { t: (key) => key };
  const transactions = [
    { type: 'received', title: 'Gold Received', amount: '+$5,000.00', from: 'Trade Partner Ltd', icon: ArrowDownLeft, color: 'green' },
    { type: 'complete', title: 'Transfer Completed', amount: '-$2,350.00', to: 'John Smith', icon: CheckCircle, color: 'purple' },
    { type: 'vault', title: 'Vault Deposit Synced', amount: '+15.5 g', from: 'FinaVault', icon: Building, color: 'purple' }
  ];

  return (
    <section className="relative py-32 overflow-hidden">
      {/* Light Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#FAFBFF] via-[#F4F6FC] to-[#FAFBFF]" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(138,43,226,0.05)_0%,_transparent_50%)]" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-[#0D0D0D] mb-4">
            {t('finapay.history.title')} <span className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent">{t('finapay.history.titleHighlight')}</span>
          </h2>
          <p className="text-[#4A4A4A] text-lg max-w-2xl mx-auto">
            {t('finapay.history.subtitle')}
          </p>
        </motion.div>

        <div className="flex flex-wrap justify-center gap-6">
          {transactions.map((tx, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 50, rotateX: 20 }}
              whileInView={{ opacity: 1, y: 0, rotateX: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.2 }}
              whileHover={{ y: -10, scale: 1.02 }}
              className="w-full max-w-sm"
            >
              <div className="relative p-6 rounded-2xl bg-white border border-[#8A2BE2]/20 overflow-hidden shadow-[0_8px_32px_rgba(138,43,226,0.08)] hover:shadow-[0_16px_48px_rgba(138,43,226,0.15)] transition-shadow">
                <div className="relative z-10">
                  <div className="flex items-start justify-between mb-4">
                    <motion.div
                      className={`w-12 h-12 rounded-xl flex items-center justify-center border ${
                        tx.color === 'green' ? 'bg-green-500/10 border-green-500/20' : 'bg-[#8A2BE2]/10 border-[#8A2BE2]/20'
                      }`}
                      animate={{ scale: [1, 1.1, 1] }}
                      transition={{ duration: 2, repeat: Infinity, delay: i * 0.3 }}
                    >
                      <tx.icon className={`w-6 h-6 ${
                        tx.color === 'green' ? 'text-green-500' : 'text-[#8A2BE2]'
                      }`} />
                    </motion.div>
                    <span className={`text-lg font-bold ${
                      tx.color === 'green' ? 'text-green-500' : 'text-[#8A2BE2]'
                    }`}>{tx.amount}</span>
                  </div>
                  
                  <h3 className="text-[#0D0D0D] font-bold mb-1">{tx.title}</h3>
                  <p className="text-[#4A4A4A] text-sm">
                    {tx.from ? `From: ${tx.from}` : `To: ${tx.to}`}
                  </p>
                  
                  <div className="mt-4 pt-4 border-t border-[#8A2BE2]/10 flex items-center justify-between">
                    <span className="text-[#4A4A4A]/70 text-xs">Just now</span>
                    <span className="text-[#8A2BE2] text-xs font-medium">View Details →</span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

// Security Section
const SecuritySection = () => {
  const { t } = useLanguage() || { t: (key) => key };
  const features = [
    { icon: Lock, title: 'Bank-Level Encryption', desc: 'AES-256 encryption for all data' },
    { icon: Fingerprint, title: 'Device Authentication', desc: 'Biometric and 2FA protection' },
    { icon: Database, title: 'Ledger Verification', desc: 'Immutable transaction records' },
    { icon: Shield, title: 'Swiss Compliance', desc: 'Fully regulated operations' }
  ];

  return (
    <section className="relative py-32 overflow-hidden">
      {/* Light Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#FAFBFF] via-[#F4F6FC] to-[#FAFBFF]" />
      <div className="absolute inset-0 bg-gradient-to-r from-[#8A2BE2]/5 via-transparent to-[#FF2FBF]/5" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Visual */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative flex justify-center"
          >
            <div className="relative w-64 h-64">
              {/* Shield */}
              <motion.div
                className="absolute inset-0 flex items-center justify-center"
                animate={{ rotateY: [0, 360] }}
                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
              >
                <div className="w-48 h-48 rounded-3xl bg-white border border-[#8A2BE2]/20 flex items-center justify-center shadow-[0_8px_32px_rgba(138,43,226,0.15)]">
                  <Shield className="w-20 h-20 text-[#8A2BE2]" />
                </div>
              </motion.div>
              
              {/* Orbiting Elements */}
              {[Lock, Fingerprint, Database].map((Icon, i) => (
                <motion.div
                  key={i}
                  className="absolute w-12 h-12 rounded-xl bg-white border border-[#8A2BE2]/20 flex items-center justify-center shadow-md"
                  style={{
                    top: '50%',
                    left: '50%',
                  }}
                  animate={{
                    x: [
                      Math.cos((i * 120 * Math.PI) / 180) * 100 - 24,
                      Math.cos(((i * 120 + 120) * Math.PI) / 180) * 100 - 24,
                      Math.cos(((i * 120 + 240) * Math.PI) / 180) * 100 - 24,
                      Math.cos((i * 120 * Math.PI) / 180) * 100 - 24
                    ],
                    y: [
                      Math.sin((i * 120 * Math.PI) / 180) * 100 - 24,
                      Math.sin(((i * 120 + 120) * Math.PI) / 180) * 100 - 24,
                      Math.sin(((i * 120 + 240) * Math.PI) / 180) * 100 - 24,
                      Math.sin((i * 120 * Math.PI) / 180) * 100 - 24
                    ]
                  }}
                  transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
                >
                  <Icon className="w-6 h-6 text-[#8A2BE2]" />
                </motion.div>
              ))}
              
              {/* Encryption Waves */}
              {[...Array(3)].map((_, i) => (
                <motion.div
                  key={i}
                  className="absolute inset-0 rounded-full border border-[#8A2BE2]/20"
                  animate={{
                    scale: [1, 2],
                    opacity: [0.5, 0]
                  }}
                  transition={{
                    duration: 2,
                    delay: i * 0.6,
                    repeat: Infinity
                  }}
                />
              ))}
            </div>
          </motion.div>

          {/* Content */}
          <div>
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-4xl md:text-5xl font-bold text-[#0D0D0D] mb-4">
                {t('finapay.security.title')} <span className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent">{t('finapay.security.titleHighlight')}</span>
              </h2>
              <p className="text-[#4A4A4A] text-lg mb-8">
                {t('finapay.security.subtitle')}
              </p>
            </motion.div>

            <div className="grid sm:grid-cols-2 gap-4">
              {features.map((feature, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="p-4 rounded-xl bg-white border border-[#8A2BE2]/20 shadow-[0_4px_16px_rgba(138,43,226,0.08)]"
                >
                  <feature.icon className="w-8 h-8 text-[#8A2BE2] mb-3" />
                  <h3 className="text-[#0D0D0D] font-bold mb-1">{feature.title}</h3>
                  <p className="text-[#4A4A4A] text-sm">{feature.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

// Premium Fintech Debit Card Component
const PremiumDebitCard = () => {
  const [isHovered, setIsHovered] = useState(false);
  const [mousePos, setMousePos] = useState({ x: 0.5, y: 0.5 });

  const handleMouseMove = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setMousePos({
      x: (e.clientX - rect.left) / rect.width,
      y: (e.clientY - rect.top) / rect.height,
    });
  };

  return (
    <div className="relative w-full max-w-sm sm:max-w-md mx-auto" style={{ perspective: '1500px' }}>
      {/* Soft glow effect */}
      <motion.div
        className="absolute -inset-6 rounded-[40px] blur-3xl"
        animate={{
          background: isHovered 
            ? 'radial-gradient(circle at 50% 50%, rgba(99,102,241,0.25) 0%, rgba(139,92,246,0.15) 40%, transparent 70%)'
            : 'radial-gradient(circle at 50% 50%, rgba(99,102,241,0.15) 0%, rgba(139,92,246,0.08) 40%, transparent 70%)',
          scale: isHovered ? 1.1 : 1
        }}
        transition={{ duration: 0.5 }}
      />

      {/* Floating dots */}
      {[...Array(8)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full bg-indigo-500/40"
          style={{
            width: 4 + Math.random() * 4,
            height: 4 + Math.random() * 4,
            top: `${15 + Math.random() * 70}%`,
            left: `${-5 + Math.random() * 110}%`,
          }}
          animate={{
            y: [0, -20, 0],
            opacity: [0, 0.6, 0],
          }}
          transition={{
            duration: 3 + Math.random() * 2,
            delay: i * 0.4,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      ))}

      {/* Main Card */}
      <motion.div
        className="relative aspect-[1.6/1] rounded-2xl overflow-hidden cursor-pointer"
        style={{ transformStyle: 'preserve-3d' }}
        animate={{
          rotateY: isHovered ? (mousePos.x - 0.5) * 12 : 0,
          rotateX: isHovered ? (mousePos.y - 0.5) * -8 : 0,
          y: [0, -8, 0],
        }}
        whileHover={{ scale: 1.02 }}
        onMouseMove={handleMouseMove}
        onHoverStart={() => setIsHovered(true)}
        onHoverEnd={() => { setIsHovered(false); setMousePos({ x: 0.5, y: 0.5 }); }}
        transition={{ 
          rotateY: { duration: 0.15 },
          rotateX: { duration: 0.15 },
          y: { duration: 4, repeat: Infinity, ease: "easeInOut" }
        }}
      >
        {/* Clean dark gradient background */}
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900" />
        
        {/* Subtle mesh gradient overlay */}
        <div 
          className="absolute inset-0 opacity-60"
          style={{
            background: `radial-gradient(ellipse at 20% 20%, rgba(99,102,241,0.15) 0%, transparent 50%),
                         radial-gradient(ellipse at 80% 80%, rgba(139,92,246,0.1) 0%, transparent 50%)`
          }}
        />

        {/* Glass reflection */}
        <motion.div
          className="absolute inset-0"
          style={{
            background: 'linear-gradient(135deg, rgba(255,255,255,0.1) 0%, transparent 50%, rgba(255,255,255,0.05) 100%)',
          }}
          animate={{
            opacity: isHovered ? 0.8 : 0.5
          }}
        />
        
        {/* Animated light sweep */}
        <motion.div
          className="absolute inset-0"
          style={{
            background: 'linear-gradient(105deg, transparent 40%, rgba(255,255,255,0.08) 48%, rgba(255,255,255,0.12) 50%, rgba(255,255,255,0.08) 52%, transparent 60%)',
          }}
          animate={{ x: ['-100%', '200%'] }}
          transition={{ duration: 3, repeat: Infinity, repeatDelay: 4, ease: "easeInOut" }}
        />

        {/* Border */}
        <div className="absolute inset-0 rounded-2xl border border-white/10" />
        
        {/* Card Content */}
        <div className="relative h-full p-6 flex flex-col justify-between">
          {/* Top Row */}
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-2">
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69293bd8e52dce0074daa668/ce96e4d2b_FINANEWLOGO-GOLDANDWHITENB.png" 
                alt="Finatrades" 
                className="h-8"
                style={{ filter: 'brightness(0) invert(1)' }}
              />
            </div>
            <div className="flex items-center gap-2">
              <motion.div 
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/20 border border-emerald-500/30"
                animate={{ borderColor: ['rgba(16,185,129,0.3)', 'rgba(16,185,129,0.6)', 'rgba(16,185,129,0.3)'] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <motion.div
                  className="w-1.5 h-1.5 rounded-full bg-emerald-400"
                  animate={{ scale: [1, 1.3, 1] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                />
                <span className="text-[9px] text-emerald-400 font-semibold">ACTIVE</span>
              </motion.div>
              <Wifi className="w-5 h-5 text-white/60" />
            </div>
          </div>

          {/* Chip */}
          <div className="flex items-center gap-4">
            <motion.div 
              className="relative w-12 h-9 rounded-md overflow-hidden"
              animate={{ 
                boxShadow: isHovered 
                  ? '0 0 20px rgba(251,191,36,0.3)' 
                  : '0 0 10px rgba(251,191,36,0.15)' 
              }}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-amber-300 via-yellow-400 to-amber-500" />
              <div className="absolute inset-0 flex flex-col justify-center gap-0.5 px-1">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="flex gap-0.5">
                    <div className="flex-1 h-0.5 bg-amber-600/40 rounded-full" />
                    <div className="w-2 h-0.5 bg-amber-600/40 rounded-full" />
                  </div>
                ))}
              </div>
            </motion.div>
            
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-white/60 tracking-widest uppercase">Debit</span>
              <span className="text-[10px] text-indigo-400 tracking-widest uppercase font-medium">Gold-Backed</span>
            </div>
          </div>

          {/* Card Number */}
          <div>
            <span className="text-xl sm:text-2xl font-mono text-white/90 tracking-[0.2em]">
              4789 •••• •••• 4892
            </span>
          </div>

          {/* Bottom Row */}
          <div className="flex items-end justify-between">
            <div>
              <p className="text-[9px] text-white/40 uppercase tracking-widest mb-0.5">Card Holder</p>
              <p className="text-white font-medium tracking-wide text-sm">GOLD MEMBER</p>
            </div>
            
            <div className="text-center">
              <p className="text-[9px] text-white/40 uppercase tracking-widest mb-0.5">Expires</p>
              <p className="text-white font-medium text-sm">12/28</p>
            </div>

            <div className="flex items-center gap-3">
              <motion.div
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 border border-white/20"
                whileHover={{ backgroundColor: 'rgba(255,255,255,0.15)' }}
              >
                <Shield className="w-3.5 h-3.5 text-indigo-400" />
                <span className="text-[10px] text-white/80 font-medium">Secured</span>
              </motion.div>
            </div>
          </div>
        </div>

        {/* Corner accent */}
        <div className="absolute top-0 right-0 w-32 h-32">
          <div className="absolute inset-0 bg-gradient-to-bl from-indigo-500/10 via-transparent to-transparent" />
        </div>
        
        {/* Bottom accent line */}
        <motion.div 
          className="absolute bottom-0 left-6 right-6 h-[1px]"
          style={{
            background: 'linear-gradient(90deg, transparent 0%, rgba(99,102,241,0.5) 50%, transparent 100%)'
          }}
          animate={{ opacity: [0.3, 0.6, 0.3] }}
          transition={{ duration: 3, repeat: Infinity }}
        />
      </motion.div>
    </div>
  );
};

// FinaPay Card Section
const FinaPayCardSection = () => {
  const { t } = useLanguage() || { t: (key) => key };
  return (
    <section className="relative py-32 overflow-hidden">
      {/* Light Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#FAFBFF] via-[#F4F6FC] to-[#FAFBFF]" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(138,43,226,0.05)_0%,_transparent_50%)]" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#8A2BE2]/10 border border-[#8A2BE2]/30 text-[#8A2BE2] text-sm mb-6 font-bold">
              <CreditCard className="w-4 h-4" />
              {t('finapay.card.badge')}
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-[#0D0D0D] mb-4">
              {t('finapay.card.title')} <span className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent">{t('finapay.card.titleHighlight')}</span>
            </h2>
            <p className="text-[#4A4A4A] text-lg mb-8">
              {t('finapay.card.description')}
            </p>
            <Link to={createPageUrl("Home")} onClick={() => window.scrollTo(0, 0)}>
              <motion.button
                className="px-8 py-4 rounded-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white font-bold flex items-center gap-2 shadow-[0_0_20px_rgba(138,43,226,0.3)]"
                whileHover={{ scale: 1.05, boxShadow: '0 0 40px rgba(138,43,226,0.5)' }}
              >
                {t('finapay.card.cta')}
                <ArrowRight className="w-4 h-4" />
              </motion.button>
            </Link>
          </motion.div>

          {/* 3D Premium Card */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="flex justify-center"
          >
            <PremiumDebitCard />
          </motion.div>
        </div>
      </div>
    </section>
  );
};

// CTA Section
const CTASection = () => {
  const { t } = useLanguage() || { t: (key) => key };
  return (
    <section className="relative py-32 overflow-hidden">
      {/* Light Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#FAFBFF] via-[#F4F6FC] to-[#FAFBFF]" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(138,43,226,0.08)_0%,_transparent_50%)]" />
      
      {/* Light Rays */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(5)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute h-[200%] w-32 bg-gradient-to-b from-transparent via-[#8A2BE2]/10 to-transparent"
            style={{
              left: `${i * 25}%`,
              top: '-50%',
              transform: 'rotate(15deg)'
            }}
            animate={{
              x: [0, 100, 0],
              opacity: [0, 0.4, 0]
            }}
            transition={{
              duration: 4,
              delay: i * 0.5,
              repeat: Infinity,
              repeatDelay: 2
            }}
          />
        ))}
      </div>

      <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <div className="w-20 h-20 mx-auto rounded-2xl bg-gradient-to-br from-[#8A2BE2] to-[#FF2FBF] flex items-center justify-center mb-8 shadow-[0_0_40px_rgba(138,43,226,0.3)]">
            <Wallet className="w-10 h-10 text-white" />
          </div>
          
          <h2 className="text-4xl md:text-6xl font-bold text-[#0D0D0D] mb-6">
            {t('finapay.cta.title')}<br />
            <span className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent">{t('finapay.cta.titleHighlight')}</span>
          </h2>
          
          <p className="text-[#4A4A4A] text-xl mb-10 max-w-2xl mx-auto">
            {t('finapay.cta.subtitle')}
          </p>

          <Link to={createPageUrl("Home")} onClick={() => window.scrollTo(0, 0)}>
            <motion.button
              className="group px-10 py-5 rounded-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white text-lg font-bold flex items-center justify-center gap-3 mx-auto shadow-[0_0_30px_rgba(138,43,226,0.3)]"
              whileHover={{ scale: 1.05, boxShadow: '0 0 60px rgba(138,43,226,0.5)' }}
              whileTap={{ scale: 0.95 }}
              animate={{ boxShadow: ['0 0 30px rgba(138,43,226,0.3)', '0 0 50px rgba(138,43,226,0.4)', '0 0 30px rgba(138,43,226,0.3)'] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <Wallet className="w-6 h-6" />
              {t('finapay.cta.button')}
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </motion.button>
          </Link>
        </motion.div>
      </div>
    </section>
  );
};

// Main Component
export default function FinaPay() {
  return (
    <div className="bg-gradient-to-br from-[#FAFBFF] via-[#F4F6FC] to-[#FFFFFF] min-h-screen">
      <HeroSection />
      <ValuePillars />
      <WalletUIDemo />
      <GoldTransferSection />
      <GlobalNetworkSection />
      <TransactionHistorySection />
      <SecuritySection />
      <FinaPayCardSection />
      <CTASection />
    </div>
  );
}