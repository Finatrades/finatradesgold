import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion, AnimatePresence } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { 
  User, Building2, Mail, Shield, Camera, Upload, CheckCircle, 
  ArrowRight, ArrowLeft, Eye, EyeOff, Loader2, Globe, FileText,
  HelpCircle, Briefcase, MapPin, AlertTriangle
} from 'lucide-react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";

const steps = [
  { id: 1, title: 'Account Type', icon: User },
  { id: 2, title: 'Personal Info', icon: FileText },
  { id: 3, title: 'Security', icon: Shield },
  { id: 4, title: 'Business Info', icon: Briefcase },
  { id: 5, title: 'Terms', icon: FileText },
  { id: 6, title: 'Verify Email', icon: Mail }
];

const securityQuestions = [
  "What is your mother's maiden name?",
  "What was the name of your first pet?",
  "What city were you born in?",
  "What is your favorite book?",
  "What was your childhood nickname?",
  "What is the name of your first school?"
];

const countries = [
  "Switzerland", "United Arab Emirates", "United Kingdom", "United States", 
  "Germany", "France", "Singapore", "Hong Kong", "Japan", "Australia",
  "Canada", "Netherlands", "Luxembourg", "Ireland", "Belgium"
];

export default function Register() {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [formData, setFormData] = useState({
    account_type: '',
    full_name: '',
    email: '',
    password: '',
    confirm_password: '',
    security_question: '',
    security_answer: '',
    business_role: '',
    jurisdiction: '',
    tax_residency: '',
    terms_accepted: false,
    privacy_accepted: false,
    risk_disclosure_accepted: false
  });
  const [errors, setErrors] = useState({});
  const [verificationCode, setVerificationCode] = useState('');
  const [registeredEmail, setRegisteredEmail] = useState('');

  const validateStep = (step) => {
    const newErrors = {};
    
    if (step === 1) {
      if (!formData.account_type) newErrors.account_type = 'Please select an account type';
    }
    
    if (step === 2) {
      if (!formData.full_name.trim()) newErrors.full_name = formData.account_type === 'corporate' ? 'Legal entity name is required' : 'Full name is required';
      if (!formData.email.trim()) newErrors.email = 'Email is required';
      else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) newErrors.email = 'Invalid email format';
      if (!formData.password) newErrors.password = 'Password is required';
      else if (formData.password.length < 8) newErrors.password = 'Password must be at least 8 characters';
      else if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(formData.password)) newErrors.password = 'Password must contain uppercase, lowercase, and number';
      if (formData.password !== formData.confirm_password) newErrors.confirm_password = 'Passwords do not match';
    }
    
    if (step === 3) {
      if (!formData.security_question) newErrors.security_question = 'Please select a security question';
      if (!formData.security_answer.trim()) newErrors.security_answer = 'Security answer is required';
      else if (formData.security_answer.length < 3) newErrors.security_answer = 'Answer must be at least 3 characters';
    }
    
    if (step === 4) {
      if (!formData.business_role) newErrors.business_role = 'Please select your business role';
      if (!formData.jurisdiction) newErrors.jurisdiction = 'Please select your jurisdiction';
      if (!formData.tax_residency) newErrors.tax_residency = 'Please select your tax residency';
    }
    
    if (step === 5) {
      if (!formData.terms_accepted) newErrors.terms = 'You must accept the Terms & Conditions';
      if (!formData.privacy_accepted) newErrors.privacy = 'You must accept the Privacy Policy';
      if (!formData.risk_disclosure_accepted) newErrors.risk = 'You must accept the Risk Disclosures';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(currentStep)) {
      setCurrentStep(prev => Math.min(prev + 1, 6));
    }
  };

  const handleBack = () => {
    setCurrentStep(prev => Math.max(prev - 1, 1));
  };



  const generateVerificationCode = () => {
    return Math.floor(100000 + Math.random() * 900000).toString();
  };

  const handleSubmit = async () => {
    if (!validateStep(5)) return;
    
    setIsLoading(true);
    try {
      // Check if email already exists
      const existingUsers = await base44.entities.UserProfile.filter({ email: formData.email });
      if (existingUsers.length > 0) {
        setErrors({ submit: 'An account with this email already exists.' });
        setIsLoading(false);
        return;
      }
      
      // Generate verification code
      const code = generateVerificationCode();
      const expiresAt = new Date(Date.now() + 30 * 60 * 1000).toISOString(); // 30 minutes
      
      // Create user profile (without selfie - will be captured in KYC)
      await base44.entities.UserProfile.create({
        account_type: formData.account_type,
        full_name: formData.full_name,
        email: formData.email,
        password_hash: formData.password, // In production, hash this on backend
        security_question: formData.security_question,
        security_answer: formData.security_answer.toLowerCase().trim(),
        business_role: formData.business_role,
        jurisdiction: formData.jurisdiction,
        tax_residency: formData.tax_residency,
        terms_accepted: true,
        privacy_accepted: true,
        risk_disclosure_accepted: true,
        email_verified: false,
        verification_code: code,
        verification_code_expires: expiresAt,
        registration_status: 'email_not_verified',
        kyc_status: 'not_started'
      });

      // Send verification email
      await base44.integrations.Core.SendEmail({
        to: formData.email,
        subject: 'Verify Your Finatrades Account',
        body: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #8A2BE2;">Welcome to Finatrades!</h2>
            <p>Thank you for registering. Please verify your email address using the code below:</p>
            <div style="background: linear-gradient(135deg, #8A2BE2, #FF2FBF); color: white; padding: 20px; text-align: center; border-radius: 10px; margin: 20px 0;">
              <h1 style="margin: 0; letter-spacing: 8px;">${code}</h1>
            </div>
            <p>This code will expire in 30 minutes.</p>
            <p>If you didn't create this account, please ignore this email.</p>
            <hr style="border: none; border-top: 1px solid #eee; margin: 20px 0;">
            <p style="color: #666; font-size: 12px;">Finatrades Finance SA | Geneva, Switzerland</p>
          </div>
        `
      });
      
      setRegisteredEmail(formData.email);
      setCurrentStep(6);
    } catch (error) {
      setErrors({ submit: error.message || 'Registration failed. Please try again.' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyEmail = async () => {
    if (!verificationCode || verificationCode.length !== 6) {
      setErrors({ verification: 'Please enter a valid 6-digit code' });
      return;
    }

    setIsLoading(true);
    try {
      const profiles = await base44.entities.UserProfile.filter({ email: registeredEmail });
      
      if (profiles.length === 0) {
        setErrors({ verification: 'Account not found. Please register again.' });
        return;
      }

      const profile = profiles[0];
      
      // Check if code matches and not expired
      if (profile.verification_code !== verificationCode) {
        setErrors({ verification: 'Invalid verification code' });
        return;
      }

      const expiresAt = new Date(profile.verification_code_expires);
      if (new Date() > expiresAt) {
        setErrors({ verification: 'Verification code has expired. Please request a new one.' });
        return;
      }

      // Update profile to verified
      await base44.entities.UserProfile.update(profile.id, {
        email_verified: true,
        registration_status: 'pending_review',
        verification_code: null,
        verification_code_expires: null
      });

      // Show success and redirect to sign in
      navigate(createPageUrl("EmailVerified"));
      
    } catch (error) {
      setErrors({ verification: error.message || 'Verification failed. Please try again.' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleResendCode = async () => {
    setIsLoading(true);
    try {
      const profiles = await base44.entities.UserProfile.filter({ email: registeredEmail });
      if (profiles.length === 0) return;

      const profile = profiles[0];
      const newCode = generateVerificationCode();
      const expiresAt = new Date(Date.now() + 30 * 60 * 1000).toISOString();

      await base44.entities.UserProfile.update(profile.id, {
        verification_code: newCode,
        verification_code_expires: expiresAt
      });

      await base44.integrations.Core.SendEmail({
        to: registeredEmail,
        subject: 'Your New Finatrades Verification Code',
        body: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #8A2BE2;">New Verification Code</h2>
            <p>Here is your new verification code:</p>
            <div style="background: linear-gradient(135deg, #8A2BE2, #FF2FBF); color: white; padding: 20px; text-align: center; border-radius: 10px; margin: 20px 0;">
              <h1 style="margin: 0; letter-spacing: 8px;">${newCode}</h1>
            </div>
            <p>This code will expire in 30 minutes.</p>
          </div>
        `
      });

      setErrors({ verification: null });
      alert('New verification code sent to your email!');
    } catch (error) {
      setErrors({ verification: 'Failed to resend code. Please try again.' });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0D001E] via-[#2A0055] to-[#4B0082] flex items-center justify-center p-4 py-8">
      {/* Background effects */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#8A2BE2]/20 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-[#FF2FBF]/20 rounded-full blur-3xl" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative w-full max-w-2xl"
      >
        {/* Logo */}
        <Link to={createPageUrl("Home")} className="flex flex-col items-center mb-6">
          <img 
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69293bd8e52dce0074daa668/ce96e4d2b_FINANEWLOGO-GOLDANDWHITENB.png" 
            alt="Finatrades" 
            className="h-10"
            style={{ filter: 'brightness(0) invert(1)' }}
          />
          <span className="text-white/50 text-xs mt-2 font-mono">portal.finatrades.com</span>
        </Link>

        {/* Progress Steps */}
        <div className="flex items-center justify-center mb-6 overflow-x-auto pb-2">
          {steps.map((step, index) => (
            <React.Fragment key={step.id}>
              <div className="flex flex-col items-center flex-shrink-0">
                <div className={`w-8 h-8 md:w-10 md:h-10 rounded-full flex items-center justify-center transition-all ${
                  currentStep >= step.id 
                    ? 'bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white' 
                    : 'bg-white/10 text-white/50'
                }`}>
                  <step.icon className="w-4 h-4 md:w-5 md:h-5" />
                </div>
                <span className={`text-[10px] md:text-xs mt-1 whitespace-nowrap ${currentStep >= step.id ? 'text-white' : 'text-white/50'}`}>
                  {step.title}
                </span>
              </div>
              {index < steps.length - 1 && (
                <div className={`w-6 md:w-10 h-0.5 mx-1 transition-all flex-shrink-0 ${
                  currentStep > step.id ? 'bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF]' : 'bg-white/20'
                }`} />
              )}
            </React.Fragment>
          ))}
        </div>

        {/* Form Card */}
        <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl p-6 md:p-8">
          <AnimatePresence mode="wait">
            {/* Step 1: Account Type */}
            {currentStep === 1 && (
              <motion.div
                key="step1"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="text-center mb-6">
                  <h2 className="text-2xl font-bold text-white mb-2">Choose Account Type</h2>
                  <p className="text-white/70">Select the type of account you want to create</p>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <button
                    onClick={() => setFormData({ ...formData, account_type: 'individual' })}
                    className={`p-6 rounded-2xl border-2 transition-all text-left ${
                      formData.account_type === 'individual'
                        ? 'border-[#8A2BE2] bg-[#8A2BE2]/20'
                        : 'border-white/20 bg-white/5 hover:border-white/40'
                    }`}
                  >
                    <User className={`w-10 h-10 mb-4 ${formData.account_type === 'individual' ? 'text-[#FF2FBF]' : 'text-white/70'}`} />
                    <h3 className="text-lg font-semibold text-white mb-2">Individual</h3>
                    <p className="text-white/60 text-sm">Personal account for individual investors and traders</p>
                  </button>

                  <button
                    onClick={() => setFormData({ ...formData, account_type: 'corporate' })}
                    className={`p-6 rounded-2xl border-2 transition-all text-left ${
                      formData.account_type === 'corporate'
                        ? 'border-[#8A2BE2] bg-[#8A2BE2]/20'
                        : 'border-white/20 bg-white/5 hover:border-white/40'
                    }`}
                  >
                    <Building2 className={`w-10 h-10 mb-4 ${formData.account_type === 'corporate' ? 'text-[#FF2FBF]' : 'text-white/70'}`} />
                    <h3 className="text-lg font-semibold text-white mb-2">Corporate Entity</h3>
                    <p className="text-white/60 text-sm">Business account for companies and organizations</p>
                  </button>
                </div>
                {errors.account_type && <p className="text-red-400 text-sm text-center">{errors.account_type}</p>}
              </motion.div>
            )}

            {/* Step 2: Personal Info */}
            {currentStep === 2 && (
              <motion.div
                key="step2"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-5"
              >
                <div className="text-center mb-6">
                  <h2 className="text-2xl font-bold text-white mb-2">
                    {formData.account_type === 'corporate' ? 'Company Details' : 'Personal Details'}
                  </h2>
                  <p className="text-white/70">Enter your account information</p>
                </div>

                <div>
                  <label className="block text-sm text-white/80 mb-2">
                    {formData.account_type === 'corporate' ? 'Legal Entity Name' : 'Full Name'} *
                  </label>
                  <div className="relative">
                    {formData.account_type === 'corporate' ? (
                      <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-white/50" />
                    ) : (
                      <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-white/50" />
                    )}
                    <Input
                      placeholder={formData.account_type === 'corporate' ? 'Company Ltd.' : 'John Smith'}
                      className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/40 focus:border-[#8A2BE2]"
                      value={formData.full_name}
                      onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                    />
                  </div>
                  {errors.full_name && <p className="text-red-400 text-sm mt-1">{errors.full_name}</p>}
                </div>

                <div>
                  <label className="block text-sm text-white/80 mb-2">Email Address *</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-white/50" />
                    <Input
                      type="email"
                      placeholder="john@example.com"
                      className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/40 focus:border-[#8A2BE2]"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    />
                  </div>
                  {errors.email && <p className="text-red-400 text-sm mt-1">{errors.email}</p>}
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm text-white/80 mb-2">Password *</label>
                    <div className="relative">
                      <Shield className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-white/50" />
                      <Input
                        type={showPassword ? 'text' : 'password'}
                        placeholder="••••••••"
                        className="pl-10 pr-10 bg-white/10 border-white/20 text-white placeholder:text-white/40 focus:border-[#8A2BE2]"
                        value={formData.password}
                        onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-white/50 hover:text-white"
                      >
                        {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                      </button>
                    </div>
                    {errors.password && <p className="text-red-400 text-sm mt-1">{errors.password}</p>}
                  </div>

                  <div>
                    <label className="block text-sm text-white/80 mb-2">Confirm Password *</label>
                    <div className="relative">
                      <Shield className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-white/50" />
                      <Input
                        type={showConfirmPassword ? 'text' : 'password'}
                        placeholder="••••••••"
                        className="pl-10 pr-10 bg-white/10 border-white/20 text-white placeholder:text-white/40 focus:border-[#8A2BE2]"
                        value={formData.confirm_password}
                        onChange={(e) => setFormData({ ...formData, confirm_password: e.target.value })}
                      />
                      <button
                        type="button"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-white/50 hover:text-white"
                      >
                        {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                      </button>
                    </div>
                    {errors.confirm_password && <p className="text-red-400 text-sm mt-1">{errors.confirm_password}</p>}
                  </div>
                </div>
              </motion.div>
            )}

            {/* Step 3: Security Question */}
            {currentStep === 3 && (
              <motion.div
                key="step3"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="text-center mb-6">
                  <h2 className="text-2xl font-bold text-white mb-2">Security Question</h2>
                  <p className="text-white/70">For account recovery purposes</p>
                </div>

                <div>
                  <label className="block text-sm text-white/80 mb-2">Security Question *</label>
                  <Select 
                    value={formData.security_question} 
                    onValueChange={(value) => setFormData({ ...formData, security_question: value })}
                  >
                    <SelectTrigger className="bg-white/10 border-white/20 text-white">
                      <SelectValue placeholder="Select a security question" />
                    </SelectTrigger>
                    <SelectContent className="bg-[#1A002F] border-white/20">
                      {securityQuestions.map((q) => (
                        <SelectItem key={q} value={q} className="text-white hover:bg-white/10">{q}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.security_question && <p className="text-red-400 text-sm mt-1">{errors.security_question}</p>}
                </div>

                <div>
                  <label className="block text-sm text-white/80 mb-2">Your Answer *</label>
                  <div className="relative">
                    <HelpCircle className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-white/50" />
                    <Input
                      placeholder="Your answer"
                      className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/40 focus:border-[#8A2BE2]"
                      value={formData.security_answer}
                      onChange={(e) => setFormData({ ...formData, security_answer: e.target.value })}
                    />
                  </div>
                  {errors.security_answer && <p className="text-red-400 text-sm mt-1">{errors.security_answer}</p>}
                </div>

                <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                  <div className="flex items-start gap-3">
                    <Shield className="w-5 h-5 text-[#8A2BE2] mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-white text-sm font-medium">Keep your answer safe</p>
                      <p className="text-white/60 text-xs">This will be used to recover your account if you forget your password.</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Step 4: Business Info */}
            {currentStep === 4 && (
              <motion.div
                key="step4"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-5"
              >
                <div className="text-center mb-6">
                  <h2 className="text-2xl font-bold text-white mb-2">Business Information</h2>
                  <p className="text-white/70">Tell us about your business activities</p>
                </div>

                <div>
                  <label className="block text-sm text-white/80 mb-2">Business Role *</label>
                  <Select 
                    value={formData.business_role} 
                    onValueChange={(value) => setFormData({ ...formData, business_role: value })}
                  >
                    <SelectTrigger className="bg-white/10 border-white/20 text-white">
                      <SelectValue placeholder="Select your role" />
                    </SelectTrigger>
                    <SelectContent className="bg-[#1A002F] border-white/20">
                      <SelectItem value="importer" className="text-white hover:bg-white/10">Importer</SelectItem>
                      <SelectItem value="exporter" className="text-white hover:bg-white/10">Exporter</SelectItem>
                      <SelectItem value="both" className="text-white hover:bg-white/10">Both (Importer & Exporter)</SelectItem>
                      <SelectItem value="investor" className="text-white hover:bg-white/10">Investor</SelectItem>
                      <SelectItem value="other" className="text-white hover:bg-white/10">Other</SelectItem>
                    </SelectContent>
                  </Select>
                  {errors.business_role && <p className="text-red-400 text-sm mt-1">{errors.business_role}</p>}
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm text-white/80 mb-2">Jurisdiction *</label>
                    <Select 
                      value={formData.jurisdiction} 
                      onValueChange={(value) => setFormData({ ...formData, jurisdiction: value })}
                    >
                      <SelectTrigger className="bg-white/10 border-white/20 text-white">
                        <SelectValue placeholder="Select country" />
                      </SelectTrigger>
                      <SelectContent className="bg-[#1A002F] border-white/20 max-h-60">
                        {countries.map((c) => (
                          <SelectItem key={c} value={c} className="text-white hover:bg-white/10">{c}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {errors.jurisdiction && <p className="text-red-400 text-sm mt-1">{errors.jurisdiction}</p>}
                  </div>

                  <div>
                    <label className="block text-sm text-white/80 mb-2">Tax Residency *</label>
                    <Select 
                      value={formData.tax_residency} 
                      onValueChange={(value) => setFormData({ ...formData, tax_residency: value })}
                    >
                      <SelectTrigger className="bg-white/10 border-white/20 text-white">
                        <SelectValue placeholder="Select country" />
                      </SelectTrigger>
                      <SelectContent className="bg-[#1A002F] border-white/20 max-h-60">
                        {countries.map((c) => (
                          <SelectItem key={c} value={c} className="text-white hover:bg-white/10">{c}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {errors.tax_residency && <p className="text-red-400 text-sm mt-1">{errors.tax_residency}</p>}
                  </div>
                </div>
              </motion.div>
            )}

            {/* Step 5: Terms & Agreements */}
            {currentStep === 5 && (
              <motion.div
                key="step5"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="text-center mb-6">
                  <h2 className="text-2xl font-bold text-white mb-2">Terms & Agreements</h2>
                  <p className="text-white/70">Please review and accept our terms</p>
                </div>

                {/* Info Box */}
                <div className="bg-gradient-to-r from-[#8A2BE2]/20 to-[#FF2FBF]/20 rounded-xl p-4 border border-[#8A2BE2]/30">
                  <div className="flex items-start gap-3">
                    <Shield className="w-5 h-5 text-[#8A2BE2] mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-white font-medium text-sm">Swiss-Grade Security</p>
                      <p className="text-white/60 text-xs mt-1">After email verification, you'll complete identity verification (selfie + ID) for full platform access.</p>
                    </div>
                  </div>
                </div>

                {/* Terms & Conditions */}
                <div className="space-y-4 bg-white/5 rounded-xl p-4 border border-white/10">
                  <div className="flex items-start gap-3">
                    <Checkbox 
                      id="terms"
                      checked={formData.terms_accepted}
                      onCheckedChange={(checked) => setFormData({ ...formData, terms_accepted: checked })}
                      className="mt-1 border-white/30 data-[state=checked]:bg-[#8A2BE2]"
                    />
                    <label htmlFor="terms" className="text-white/80 text-sm cursor-pointer">
                      I accept the <Link to={createPageUrl("TermsAndConditions")} className="text-[#FF2FBF] hover:underline" target="_blank">Terms & Conditions</Link> *
                    </label>
                  </div>
                  {errors.terms && <p className="text-red-400 text-sm ml-7">{errors.terms}</p>}

                  <div className="flex items-start gap-3">
                    <Checkbox 
                      id="privacy"
                      checked={formData.privacy_accepted}
                      onCheckedChange={(checked) => setFormData({ ...formData, privacy_accepted: checked })}
                      className="mt-1 border-white/30 data-[state=checked]:bg-[#8A2BE2]"
                    />
                    <label htmlFor="privacy" className="text-white/80 text-sm cursor-pointer">
                      I accept the <Link to={createPageUrl("PrivacyPolicy")} className="text-[#FF2FBF] hover:underline" target="_blank">Privacy Policy</Link> *
                    </label>
                  </div>
                  {errors.privacy && <p className="text-red-400 text-sm ml-7">{errors.privacy}</p>}

                  <div className="flex items-start gap-3">
                    <Checkbox 
                      id="risk"
                      checked={formData.risk_disclosure_accepted}
                      onCheckedChange={(checked) => setFormData({ ...formData, risk_disclosure_accepted: checked })}
                      className="mt-1 border-white/30 data-[state=checked]:bg-[#8A2BE2]"
                    />
                    <label htmlFor="risk" className="text-white/80 text-sm cursor-pointer">
                      I accept the <Link to={createPageUrl("Disclaimer")} className="text-[#FF2FBF] hover:underline" target="_blank">Risk Disclosures</Link> *
                    </label>
                  </div>
                  {errors.risk && <p className="text-red-400 text-sm ml-7">{errors.risk}</p>}
                </div>
              </motion.div>
            )}

            {/* Step 6: Email Verification */}
            {currentStep === 6 && (
              <motion.div
                key="step6"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="text-center mb-6">
                  <div className="w-16 h-16 mx-auto rounded-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] flex items-center justify-center mb-4">
                    <Mail className="w-8 h-8 text-white" />
                  </div>
                  <h2 className="text-2xl font-bold text-white mb-2">Verify Your Email</h2>
                  <p className="text-white/70">We've sent a 6-digit code to</p>
                  <p className="text-[#FF2FBF] font-medium">{registeredEmail}</p>
                </div>

                <div>
                  <label className="block text-sm text-white/80 mb-2 text-center">Enter Verification Code</label>
                  <Input
                    type="text"
                    placeholder="000000"
                    maxLength={6}
                    className="text-center text-2xl tracking-[0.5em] bg-white/10 border-white/20 text-white placeholder:text-white/40 focus:border-[#8A2BE2]"
                    value={verificationCode}
                    onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, ''))}
                  />
                  {errors.verification && <p className="text-red-400 text-sm mt-2 text-center">{errors.verification}</p>}
                </div>

                <Button
                  onClick={handleVerifyEmail}
                  disabled={isLoading || verificationCode.length !== 6}
                  className="w-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white font-bold py-6 rounded-xl hover:shadow-[0_0_30px_rgba(138,43,226,0.5)]"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Verifying...
                    </>
                  ) : (
                    <>
                      Verify Email
                      <CheckCircle className="w-5 h-5 ml-2" />
                    </>
                  )}
                </Button>

                <p className="text-center text-white/60">
                  Didn't receive the code?{' '}
                  <button 
                    onClick={handleResendCode} 
                    disabled={isLoading}
                    className="text-[#FF2FBF] hover:underline"
                  >
                    Resend
                  </button>
                </p>
              </motion.div>
            )}
          </AnimatePresence>

          {errors.submit && (
            <div className="bg-red-500/20 border border-red-500/50 rounded-lg p-3 mt-4">
              <p className="text-red-300 text-sm text-center">{errors.submit}</p>
            </div>
          )}

          {/* Navigation Buttons */}
          {currentStep < 6 && (
            <div className="flex gap-4 mt-8">
              {currentStep > 1 && (
                <Button
                  variant="outline"
                  onClick={handleBack}
                  className="flex-1 border-white/20 text-white hover:bg-white/10"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back
                </Button>
              )}
              
              {currentStep < 5 ? (
                <Button
                  onClick={handleNext}
                  className="flex-1 bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white font-bold hover:shadow-[0_0_30px_rgba(138,43,226,0.5)]"
                >
                  Continue
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              ) : (
                <Button
                  onClick={handleSubmit}
                  disabled={isLoading}
                  className="flex-1 bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white font-bold hover:shadow-[0_0_30px_rgba(138,43,226,0.5)]"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Creating Account...
                    </>
                  ) : (
                    <>
                      Create Account
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </>
                  )}
                </Button>
              )}
            </div>
          )}

          {/* Login Link */}
          {currentStep < 6 && (
            <p className="text-center text-white/60 mt-6">
              Already have an account?{' '}
              <Link to={createPageUrl("SignIn")} className="text-[#FF2FBF] hover:underline">
                Sign In
              </Link>
            </p>
          )}
        </div>
      </motion.div>
    </div>
  );
}