import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Clock, Shield, ArrowRight, CheckCircle } from 'lucide-react';
import { Button } from "@/components/ui/button";
import GoldPriceBanner from '@/components/ui/GoldPriceBanner';

export default function KYCPending() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#000000] via-[#0D0717] to-[#1a0a2e]">
      <GoldPriceBanner />
      
      <div className="flex items-center justify-center min-h-[calc(100vh-44px)] p-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-md w-full text-center"
        >
          {/* Animated Clock */}
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 200, delay: 0.2 }}
            className="w-24 h-24 mx-auto rounded-full bg-gradient-to-br from-[#D1A954] to-[#B8963E] flex items-center justify-center mb-8 shadow-[0_0_40px_rgba(209,169,84,0.3)]"
          >
            <Clock className="w-12 h-12 text-black" />
          </motion.div>

          <h1 className="text-3xl font-bold text-white mb-4">Verification in Progress</h1>
          <p className="text-white/70 mb-8 leading-relaxed">
            Your identity verification documents have been submitted successfully. Our compliance team is reviewing your application.
          </p>

          {/* Timeline */}
          <div className="bg-white/5 backdrop-blur-xl border border-[#D1A954]/20 rounded-2xl p-6 mb-8">
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <div className="w-8 h-8 rounded-full bg-[#D1A954] flex items-center justify-center">
                  <CheckCircle className="w-4 h-4 text-black" />
                </div>
                <div className="text-left">
                  <p className="text-white font-medium">Documents Submitted</p>
                  <p className="text-white/50 text-sm">Completed</p>
                </div>
              </div>
              
              <div className="flex items-center gap-4">
                <div className="w-8 h-8 rounded-full bg-[#D1A954]/20 border-2 border-[#D1A954] flex items-center justify-center">
                  <div className="w-2 h-2 rounded-full bg-[#D1A954] animate-pulse" />
                </div>
                <div className="text-left">
                  <p className="text-white font-medium">Under Review</p>
                  <p className="text-white/50 text-sm">Usually 1-24 hours</p>
                </div>
              </div>
              
              <div className="flex items-center gap-4">
                <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center">
                  <Shield className="w-4 h-4 text-white/40" />
                </div>
                <div className="text-left">
                  <p className="text-white/50 font-medium">Verification Complete</p>
                  <p className="text-white/30 text-sm">Pending</p>
                </div>
              </div>
            </div>
          </div>

          <p className="text-white/50 text-sm mb-6">
            You'll receive an email notification once your verification is complete. In the meantime, you can explore the platform in limited mode.
          </p>

          <Link to={createPageUrl("UserDashboard")}>
            <Button className="w-full bg-[#D1A954] text-black font-bold hover:bg-[#D1A954]/90">
              Go to Dashboard
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </Link>
        </motion.div>
      </div>
    </div>
  );
}