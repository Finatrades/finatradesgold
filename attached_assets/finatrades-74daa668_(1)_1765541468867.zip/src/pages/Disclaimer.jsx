import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { AlertCircle, Info, Server, Link2, Scale, ArrowLeft } from 'lucide-react';

export default function Disclaimer() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FAFBFF] via-[#F4F6FC] to-white text-[#0D0D0D]">
      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(138,43,226,0.08)_0%,_transparent_50%)]" />
        <div className="max-w-4xl mx-auto px-6 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <Link 
              to={createPageUrl("Home")} 
              onClick={() => window.scrollTo(0, 0)}
              className="inline-flex items-center gap-2 text-[#8A2BE2] hover:text-[#FF2FBF] transition-colors mb-6"
            >
              <ArrowLeft className="w-4 h-4" />
              <span className="text-sm">Back to Home</span>
            </Link>
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#D4AF37]/10 border border-[#8A2BE2]/30 mb-6">
              <AlertCircle className="w-4 h-4 text-[#8A2BE2]" />
              <span className="text-sm text-[#8A2BE2]">Legal Document</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-extralight mb-4">
              <span className="text-[#8A2BE2]">Disclaimer</span>
            </h1>
            <p className="text-[#4A4A4A]">FINATRADES.COM • Last Updated: 21/11/2025</p>
          </motion.div>
        </div>
      </section>

      {/* Content */}
      <section className="pb-20">
        <div className="max-w-4xl mx-auto px-6">
          
          {/* Introduction */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white shadow-[0_8px_32px_rgba(160,50,255,0.12)] rounded-2xl border border-[#8A2BE2]/20 p-8 mb-8"
          >
            <p className="text-[#333333] leading-relaxed">
              This Disclaimer ("Disclaimer") governs your use of the website <a href="https://finatrades.com" className="text-[#8A2BE2] hover:underline">https://finatrades.com</a> (the "Site") and the Finatrades Platform (the "Platform") operated by <strong className="text-[#0D0D0D]">Finatrades Finance SA</strong> ("Finatrades," "we," "us," "our"). By accessing the Site or using the Platform, you expressly acknowledge and agree to the terms set forth below.
            </p>
          </motion.div>

          {/* Section 1 */}
          <Section number="1" title="NATURE OF INFORMATION; NO PROFESSIONAL ADVICE" icon={Info} delay={0.2}>
            <p className="text-[#333333] mb-4">
              All content, materials, and information presented on the Site and Platform are provided for general informational purposes only. Nothing contained herein constitutes:
            </p>
            <ul className="space-y-3 text-[#333333] mb-4">
              <li className="flex items-start gap-2">
                <span className="text-[#8A2BE2] mt-1">•</span>
                <div><strong className="text-[#0D0D0D]">Investment Advice:</strong> A recommendation, solicitation, or offer to buy or sell any financial instrument or commodity.</div>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#8A2BE2] mt-1">•</span>
                <div><strong className="text-[#0D0D0D]">Financial Advice:</strong> Guidance on investment strategies, financial planning, or the suitability of using gold for trade finance.</div>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#8A2BE2] mt-1">•</span>
                <div><strong className="text-[#0D0D0D]">Legal or Tax Advice:</strong> An opinion on your legal rights, obligations, or the tax implications of your transactions.</div>
              </li>
            </ul>
            <p className="text-[#333333]">
              You are solely responsible for consulting with qualified professional advisors (legal, tax, financial) before engaging in any transactions.
            </p>
          </Section>

          {/* Section 2 */}
          <Section number="2" title="NO RELIANCE ON ACCURACY" icon={AlertCircle} delay={0.25}>
            <p className="text-[#333333] mb-4">
              While Finatrades strives to provide reliable information, we do not warrant or guarantee the accuracy, completeness, timeliness, or reliability of any data, including but not limited to:
            </p>
            <ul className="space-y-2 text-[#333333] mb-4">
              <li className="flex items-start gap-2">
                <span className="text-[#8A2BE2] mt-1">•</span>
                Gold price feeds and market data.
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#8A2BE2] mt-1">•</span>
                Information regarding third-party vaults and assayers.
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#8A2BE2] mt-1">•</span>
                Transactional data and settlement statuses.
              </li>
            </ul>
            <p className="text-[#333333]">
              All information is subject to change without notice and may include estimates or delays.
            </p>
          </Section>

          {/* Section 3 */}
          <Section number="3" title='SERVICE PROVISION "AS IS"' icon={Server} delay={0.3}>
            <p className="text-[#333333] mb-4">
              The Platform and all related services are provided on an <strong className="text-[#0D0D0D]">"as is"</strong> and <strong className="text-[#0D0D0D]">"as available"</strong> basis. To the fullest extent permitted under Swiss law, Finatrades expressly disclaims all warranties of any kind, whether express or implied, including, but not limited to, implied warranties of merchantability, fitness for a particular purpose, and non-infringement. We do not guarantee that:
            </p>
            <ul className="space-y-2 text-[#333333]">
              <li className="flex items-start gap-2">
                <span className="text-[#8A2BE2] mt-1">•</span>
                The Platform will be uninterrupted, secure, or error-free.
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#8A2BE2] mt-1">•</span>
                The services will meet your specific requirements.
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#8A2BE2] mt-1">•</span>
                Any errors in the software or systems will be corrected.
              </li>
            </ul>
          </Section>

          {/* Section 4 */}
          <Section number="4" title="THIRD-PARTY SERVICES AND LINKS" icon={Link2} delay={0.35}>
            <p className="text-[#333333] mb-4">
              The Platform relies on and may contain links to third-party services, including vault operators, assayers, payment processors, and financial institutions. Finatrades is not responsible or liable for:
            </p>
            <ul className="space-y-2 text-[#333333] mb-4">
              <li className="flex items-start gap-2">
                <span className="text-[#8A2BE2] mt-1">•</span>
                The acts, omissions, performance, or solvency of any third-party service provider.
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#8A2BE2] mt-1">•</span>
                The content, accuracy, or security of any third-party websites or platforms.
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#8A2BE2] mt-1">•</span>
                Any loss or damage incurred as a result of your interactions with such third parties.
              </li>
            </ul>
            <p className="text-[#333333]">
              Your relationship with any third-party provider is governed solely by your agreements with them.
            </p>
          </Section>

          {/* Section 5 */}
          <Section number="5" title="LIMITATION OF LIABILITY" icon={Scale} delay={0.4} highlight>
            <p className="text-[#333333] mb-4">
              To the maximum extent permitted by the Swiss Code of Obligations, Finatrades shall not be liable for any direct, indirect, incidental, special, consequential, or punitive damages, including but not limited to:
            </p>
            <ul className="space-y-2 text-[#333333] mb-4">
              <li className="flex items-start gap-2">
                <span className="text-[#8A2BE2] mt-1">•</span>
                Loss of profits, revenue, or business opportunities.
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#8A2BE2] mt-1">•</span>
                Loss of or damage to your Gold Certificates or the Underlying Gold held in vaults.
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#8A2BE2] mt-1">•</span>
                Damages arising from cyber-attacks, system failures, unauthorized access, or data breaches.
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#8A2BE2] mt-1">•</span>
                Damages resulting from the default, insolvency, or fraudulent actions of a vault operator or other Service Provider.
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#8A2BE2] mt-1">•</span>
                Any trading losses or operational losses you may incur.
              </li>
            </ul>
            <p className="text-[#333333]">
              In accordance with Swiss law, particularly regarding the exclusion of liability for slight negligence, Finatrades's liability is strictly limited as defined in our Terms and Conditions.
            </p>
          </Section>

          {/* Closing */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.45 }}
            className="bg-white shadow-[0_8px_32px_rgba(160,50,255,0.12)] rounded-2xl border border-[#8A2BE2]/20 p-8 mt-8"
          >
            <div className="border-t border-[#8A2BE2]/20 pt-6">
              <p className="text-[#0D0D0D] font-medium">Finatrades Finance SA</p>
              <p className="text-[#4A4A4A]">Rue Robert Céard 6</p>
              <p className="text-[#4A4A4A]">1204 Geneva</p>
              <p className="text-[#4A4A4A]">Switzerland</p>
            </div>
            <div className="mt-8 text-center">
              <Link 
                to={createPageUrl("Home")} 
                onClick={() => window.scrollTo(0, 0)}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white font-medium hover:shadow-[0_0_20px_rgba(138,43,226,0.3)] transition-all"
              >
                <ArrowLeft className="w-4 h-4" />
                Back to Home
              </Link>
            </div>
          </motion.div>

        </div>
      </section>
    </div>
  );
}

function Section({ number, title, icon: Icon, children, delay = 0, highlight = false }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      className={`mb-8 ${highlight ? 'bg-gradient-to-br from-[#8A2BE2]/5 to-transparent rounded-2xl border border-[#8A2BE2]/20 p-8' : ''}`}
    >
      <h3 className="text-2xl font-light text-[#0D0D0D] mb-6 flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#8A2BE2]/20 to-[#FF2FBF]/10 flex items-center justify-center">
          <Icon className="w-5 h-5 text-[#8A2BE2]" />
        </div>
        <span className="text-[#8A2BE2]">{number}.</span>
        {title}
      </h3>
      {children}
    </motion.div>
  );
}