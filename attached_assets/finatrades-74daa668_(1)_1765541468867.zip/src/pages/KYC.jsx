import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  User, FileText, Camera, MapPin, CheckCircle, ArrowRight, ArrowLeft,
  Upload, X, Loader2, Shield, Globe, Calendar, Home, Building2
} from 'lucide-react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import GoldPriceBanner from '@/components/ui/GoldPriceBanner';

const kycSteps = [
  { id: 1, title: 'Personal Details', icon: User },
  { id: 2, title: 'ID Document', icon: FileText },
  { id: 3, title: 'Face Scan', icon: Camera },
  { id: 4, title: 'Address Proof', icon: MapPin }
];

const countries = [
  "Switzerland", "United Arab Emirates", "United Kingdom", "United States",
  "Germany", "France", "Singapore", "Hong Kong", "Japan", "Australia",
  "Canada", "Netherlands", "Luxembourg", "Ireland", "Belgium", "India",
  "Saudi Arabia", "Qatar", "Kuwait", "Bahrain", "Oman"
];

const idTypes = [
  { value: 'passport', label: 'Passport' },
  { value: 'national_id', label: 'National ID Card' },
  { value: 'residence_permit', label: 'Residence Permit' }
];

export default function KYC() {
  const navigate = useNavigate();
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const [user, setUser] = useState(null);
  const [currentStep, setCurrentStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [faceCaptured, setFaceCaptured] = useState(false);
  
  const [formData, setFormData] = useState({
    nationality: '',
    date_of_birth: '',
    country_of_residence: '',
    address: '',
    city: '',
    zip_code: '',
    id_type: '',
    id_front: null,
    id_back: null,
    face_scan: null,
    address_proof: null
  });
  
  const [previews, setPreviews] = useState({
    id_front: null,
    id_back: null,
    face_scan: null,
    address_proof: null
  });
  
  const [errors, setErrors] = useState({});

  useEffect(() => {
    const storedUser = localStorage.getItem('finatrades_user');
    if (!storedUser) {
      navigate(createPageUrl("SignIn"));
      return;
    }
    setUser(JSON.parse(storedUser));
  }, [navigate]);

  const handleFileUpload = (field, e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.size > 10 * 1024 * 1024) {
        setErrors({ ...errors, [field]: 'File size must be less than 10MB' });
        return;
      }
      setFormData({ ...formData, [field]: file });
      const reader = new FileReader();
      reader.onloadend = () => setPreviews({ ...previews, [field]: reader.result });
      reader.readAsDataURL(file);
      setErrors({ ...errors, [field]: null });
    }
  };

  const removeFile = (field) => {
    setFormData({ ...formData, [field]: null });
    setPreviews({ ...previews, [field]: null });
  };

  const validateStep = (step) => {
    const newErrors = {};
    
    if (step === 1) {
      if (!formData.nationality) newErrors.nationality = 'Required';
      if (!formData.date_of_birth) newErrors.date_of_birth = 'Required';
      if (!formData.country_of_residence) newErrors.country_of_residence = 'Required';
      if (!formData.address) newErrors.address = 'Required';
      if (!formData.city) newErrors.city = 'Required';
      if (!formData.zip_code) newErrors.zip_code = 'Required';
    }
    
    if (step === 2) {
      if (!formData.id_type) newErrors.id_type = 'Please select ID type';
      if (!formData.id_front) newErrors.id_front = 'Front side required';
      if (formData.id_type !== 'passport' && !formData.id_back) newErrors.id_back = 'Back side required';
    }
    
    if (step === 3) {
      if (!formData.face_scan) newErrors.face_scan = 'Face verification required';
    }
    
    if (step === 4) {
      if (!formData.address_proof) newErrors.address_proof = 'Address proof required';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(currentStep)) {
      setCurrentStep(prev => Math.min(prev + 1, 4));
    }
  };

  const handleBack = () => {
    setCurrentStep(prev => Math.max(prev - 1, 1));
  };

  const startFaceScan = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setIsCameraActive(true);
        
        // Simulate scan progress
        let progress = 0;
        const interval = setInterval(() => {
          progress += 10;
          setScanProgress(progress);
          if (progress >= 100) {
            clearInterval(interval);
            captureFace(stream);
          }
        }, 300);
      }
    } catch (err) {
      setErrors({ ...errors, face_scan: 'Camera access denied. Please allow camera access.' });
    }
  };

  const captureFace = (stream) => {
    if (videoRef.current && canvasRef.current) {
      const canvas = canvasRef.current;
      const video = videoRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      canvas.getContext('2d').drawImage(video, 0, 0);
      
      canvas.toBlob((blob) => {
        const file = new File([blob], 'face_scan.jpg', { type: 'image/jpeg' });
        setFormData({ ...formData, face_scan: file });
        setPreviews({ ...previews, face_scan: canvas.toDataURL('image/jpeg') });
        setFaceCaptured(true);
      }, 'image/jpeg', 0.9);
      
      stream.getTracks().forEach(track => track.stop());
      setIsCameraActive(false);
    }
  };

  const handleSubmit = async () => {
    if (!validateStep(4)) return;
    
    setIsLoading(true);
    try {
      // Upload all documents
      const uploads = {};
      
      if (formData.id_front) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file: formData.id_front });
        uploads.id_front_url = file_url;
      }
      if (formData.id_back) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file: formData.id_back });
        uploads.id_back_url = file_url;
      }
      if (formData.face_scan) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file: formData.face_scan });
        uploads.face_scan_url = file_url;
      }
      if (formData.address_proof) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file: formData.address_proof });
        uploads.address_proof_url = file_url;
      }

      // Get user profile and update with KYC data
      const profiles = await base44.entities.UserProfile.filter({ email: user.email });
      if (profiles.length > 0) {
        await base44.entities.UserProfile.update(profiles[0].id, {
          nationality: formData.nationality,
          date_of_birth: formData.date_of_birth,
          country_of_residence: formData.country_of_residence,
          address_line: formData.address,
          city: formData.city,
          zip_code: formData.zip_code,
          id_type: formData.id_type,
          ...uploads,
          kyc_status: 'pending_review',
          kyc_submitted_at: new Date().toISOString()
        });
      }

      navigate(createPageUrl("KYCPending"));
    } catch (error) {
      setErrors({ submit: error.message || 'Submission failed' });
    } finally {
      setIsLoading(false);
    }
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#000000] via-[#0D0717] to-[#1a0a2e]">
      <GoldPriceBanner />
      
      {/* Header */}
      <header className="border-b border-[#D1A954]/20 px-6 py-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate(createPageUrl("UserDashboard"))}
              className="w-10 h-10 rounded-full bg-white/5 border border-white/20 flex items-center justify-center text-white/70 hover:bg-white/10 hover:border-[#D1A954]/40 transition-all"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <Link to={createPageUrl("Home")}>
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69293bd8e52dce0074daa668/ce96e4d2b_FINANEWLOGO-GOLDANDWHITENB.png" 
                alt="Finatrades" 
                className="h-8"
                style={{ filter: 'brightness(0) invert(1)' }}
              />
            </Link>
          </div>
          <div className="flex items-center gap-2 text-[#D1A954]">
            <Shield className="w-5 h-5" />
            <span className="text-sm font-medium">Identity Verification</span>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-6 py-8">
        {/* Progress Steps */}
        <div className="flex items-center justify-center mb-10">
          {kycSteps.map((step, index) => (
            <React.Fragment key={step.id}>
              <div className="flex flex-col items-center">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${
                  currentStep > step.id 
                    ? 'bg-[#D1A954] text-black' 
                    : currentStep === step.id 
                      ? 'bg-[#D1A954]/20 border-2 border-[#D1A954] text-[#D1A954]' 
                      : 'bg-white/5 border border-white/20 text-white/40'
                }`}>
                  {currentStep > step.id ? (
                    <CheckCircle className="w-6 h-6" />
                  ) : (
                    <step.icon className="w-5 h-5" />
                  )}
                </div>
                <span className={`text-xs mt-2 whitespace-nowrap ${
                  currentStep >= step.id ? 'text-[#D1A954]' : 'text-white/40'
                }`}>
                  {step.title}
                </span>
              </div>
              {index < kycSteps.length - 1 && (
                <div className={`w-16 md:w-24 h-0.5 mx-2 transition-all ${
                  currentStep > step.id ? 'bg-[#D1A954]' : 'bg-white/20'
                }`} />
              )}
            </React.Fragment>
          ))}
        </div>

        {/* Form Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/5 backdrop-blur-xl border border-[#D1A954]/20 rounded-2xl p-8"
        >
          <AnimatePresence mode="wait">
            {/* Step 1: Personal Details */}
            {currentStep === 1 && (
              <motion.div
                key="step1"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="text-center mb-8">
                  <h2 className="text-2xl font-bold text-white mb-2">Personal Details</h2>
                  <p className="text-white/60">Please provide your personal information</p>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm text-[#D1A954] mb-2">Nationality *</label>
                    <Select value={formData.nationality} onValueChange={(v) => setFormData({...formData, nationality: v})}>
                      <SelectTrigger className="bg-white/5 border-[#D1A954]/30 text-white">
                        <SelectValue placeholder="Select country" />
                      </SelectTrigger>
                      <SelectContent className="bg-[#1a0a2e] border-[#D1A954]/30 max-h-60">
                        {countries.map(c => (
                          <SelectItem key={c} value={c} className="text-white hover:bg-[#D1A954]/20">{c}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {errors.nationality && <p className="text-red-400 text-xs mt-1">{errors.nationality}</p>}
                  </div>

                  <div>
                    <label className="block text-sm text-[#D1A954] mb-2">Date of Birth *</label>
                    <Input
                      type="date"
                      className="bg-white/5 border-[#D1A954]/30 text-white"
                      value={formData.date_of_birth}
                      onChange={(e) => setFormData({...formData, date_of_birth: e.target.value})}
                    />
                    {errors.date_of_birth && <p className="text-red-400 text-xs mt-1">{errors.date_of_birth}</p>}
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-sm text-[#D1A954] mb-2">Country of Residence *</label>
                    <Select value={formData.country_of_residence} onValueChange={(v) => setFormData({...formData, country_of_residence: v})}>
                      <SelectTrigger className="bg-white/5 border-[#D1A954]/30 text-white">
                        <SelectValue placeholder="Select country" />
                      </SelectTrigger>
                      <SelectContent className="bg-[#1a0a2e] border-[#D1A954]/30 max-h-60">
                        {countries.map(c => (
                          <SelectItem key={c} value={c} className="text-white hover:bg-[#D1A954]/20">{c}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {errors.country_of_residence && <p className="text-red-400 text-xs mt-1">{errors.country_of_residence}</p>}
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-sm text-[#D1A954] mb-2">Address *</label>
                    <Input
                      placeholder="Street address"
                      className="bg-white/5 border-[#D1A954]/30 text-white placeholder:text-white/40"
                      value={formData.address}
                      onChange={(e) => setFormData({...formData, address: e.target.value})}
                    />
                    {errors.address && <p className="text-red-400 text-xs mt-1">{errors.address}</p>}
                  </div>

                  <div>
                    <label className="block text-sm text-[#D1A954] mb-2">City *</label>
                    <Input
                      placeholder="City"
                      className="bg-white/5 border-[#D1A954]/30 text-white placeholder:text-white/40"
                      value={formData.city}
                      onChange={(e) => setFormData({...formData, city: e.target.value})}
                    />
                    {errors.city && <p className="text-red-400 text-xs mt-1">{errors.city}</p>}
                  </div>

                  <div>
                    <label className="block text-sm text-[#D1A954] mb-2">Zip/Postal Code *</label>
                    <Input
                      placeholder="Zip code"
                      className="bg-white/5 border-[#D1A954]/30 text-white placeholder:text-white/40"
                      value={formData.zip_code}
                      onChange={(e) => setFormData({...formData, zip_code: e.target.value})}
                    />
                    {errors.zip_code && <p className="text-red-400 text-xs mt-1">{errors.zip_code}</p>}
                  </div>
                </div>
              </motion.div>
            )}

            {/* Step 2: ID Document */}
            {currentStep === 2 && (
              <motion.div
                key="step2"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="text-center mb-8">
                  <h2 className="text-2xl font-bold text-white mb-2">ID Document</h2>
                  <p className="text-white/60">Upload a valid government-issued ID</p>
                </div>

                <div>
                  <label className="block text-sm text-[#D1A954] mb-3">Document Type *</label>
                  <div className="grid grid-cols-3 gap-3">
                    {idTypes.map(type => (
                      <button
                        key={type.value}
                        onClick={() => setFormData({...formData, id_type: type.value})}
                        className={`p-4 rounded-xl border-2 transition-all text-center ${
                          formData.id_type === type.value
                            ? 'border-[#D1A954] bg-[#D1A954]/10'
                            : 'border-white/20 bg-white/5 hover:border-white/40'
                        }`}
                      >
                        <FileText className={`w-6 h-6 mx-auto mb-2 ${formData.id_type === type.value ? 'text-[#D1A954]' : 'text-white/60'}`} />
                        <span className={`text-sm ${formData.id_type === type.value ? 'text-[#D1A954]' : 'text-white/80'}`}>
                          {type.label}
                        </span>
                      </button>
                    ))}
                  </div>
                  {errors.id_type && <p className="text-red-400 text-xs mt-2">{errors.id_type}</p>}
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm text-[#D1A954] mb-2">Front Side *</label>
                    {previews.id_front ? (
                      <div className="relative">
                        <img src={previews.id_front} alt="ID Front" className="w-full h-40 object-cover rounded-xl border border-[#D1A954]/30" />
                        <button
                          onClick={() => removeFile('id_front')}
                          className="absolute top-2 right-2 w-8 h-8 bg-red-500 rounded-full flex items-center justify-center"
                        >
                          <X className="w-4 h-4 text-white" />
                        </button>
                      </div>
                    ) : (
                      <label className="flex flex-col items-center justify-center h-40 border-2 border-dashed border-[#D1A954]/30 rounded-xl cursor-pointer hover:border-[#D1A954]/60 transition-colors bg-white/5">
                        <Upload className="w-8 h-8 text-[#D1A954]/60 mb-2" />
                        <span className="text-white/60 text-sm">Click to upload</span>
                        <input type="file" accept="image/*" className="hidden" onChange={(e) => handleFileUpload('id_front', e)} />
                      </label>
                    )}
                    {errors.id_front && <p className="text-red-400 text-xs mt-1">{errors.id_front}</p>}
                  </div>

                  {formData.id_type !== 'passport' && (
                    <div>
                      <label className="block text-sm text-[#D1A954] mb-2">Back Side *</label>
                      {previews.id_back ? (
                        <div className="relative">
                          <img src={previews.id_back} alt="ID Back" className="w-full h-40 object-cover rounded-xl border border-[#D1A954]/30" />
                          <button
                            onClick={() => removeFile('id_back')}
                            className="absolute top-2 right-2 w-8 h-8 bg-red-500 rounded-full flex items-center justify-center"
                          >
                            <X className="w-4 h-4 text-white" />
                          </button>
                        </div>
                      ) : (
                        <label className="flex flex-col items-center justify-center h-40 border-2 border-dashed border-[#D1A954]/30 rounded-xl cursor-pointer hover:border-[#D1A954]/60 transition-colors bg-white/5">
                          <Upload className="w-8 h-8 text-[#D1A954]/60 mb-2" />
                          <span className="text-white/60 text-sm">Click to upload</span>
                          <input type="file" accept="image/*" className="hidden" onChange={(e) => handleFileUpload('id_back', e)} />
                        </label>
                      )}
                      {errors.id_back && <p className="text-red-400 text-xs mt-1">{errors.id_back}</p>}
                    </div>
                  )}
                </div>
              </motion.div>
            )}

            {/* Step 3: Face Scan */}
            {currentStep === 3 && (
              <motion.div
                key="step3"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="text-center mb-8">
                  <h2 className="text-2xl font-bold text-white mb-2">Face Verification</h2>
                  <p className="text-white/60">Complete a quick face scan for identity verification</p>
                </div>

                <div className="flex flex-col items-center">
                  {faceCaptured && previews.face_scan ? (
                    <div className="relative">
                      <img src={previews.face_scan} alt="Face scan" className="w-64 h-64 object-cover rounded-full border-4 border-[#D1A954]" />
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-16 h-16 rounded-full bg-[#D1A954] flex items-center justify-center">
                          <CheckCircle className="w-8 h-8 text-black" />
                        </div>
                      </div>
                      <button
                        onClick={() => {
                          setFaceCaptured(false);
                          setScanProgress(0);
                          removeFile('face_scan');
                        }}
                        className="absolute -bottom-2 left-1/2 -translate-x-1/2 px-4 py-2 bg-white/10 rounded-full text-white text-sm hover:bg-white/20"
                      >
                        Retake
                      </button>
                    </div>
                  ) : isCameraActive ? (
                    <div className="relative">
                      <video
                        ref={videoRef}
                        autoPlay
                        playsInline
                        muted
                        className="w-64 h-64 object-cover rounded-full border-4 border-[#D1A954]"
                      />
                      <canvas ref={canvasRef} className="hidden" />
                      {/* Scan overlay */}
                      <div className="absolute inset-0 rounded-full">
                        <svg className="w-full h-full" viewBox="0 0 100 100">
                          <circle
                            cx="50"
                            cy="50"
                            r="48"
                            fill="none"
                            stroke="#D1A954"
                            strokeWidth="2"
                            strokeDasharray={`${scanProgress * 3} 300`}
                            transform="rotate(-90 50 50)"
                          />
                        </svg>
                      </div>
                      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 text-[#D1A954] text-sm font-medium">
                        Scanning... {scanProgress}%
                      </div>
                    </div>
                  ) : (
                    <div className="text-center">
                      <div className="w-64 h-64 rounded-full border-4 border-dashed border-[#D1A954]/40 flex flex-col items-center justify-center bg-white/5 mb-6">
                        <Camera className="w-16 h-16 text-[#D1A954]/60 mb-4" />
                        <p className="text-white/60 text-sm px-8">Position your face in the center and look straight at the camera</p>
                      </div>
                      <Button
                        onClick={startFaceScan}
                        className="bg-[#D1A954] text-black font-bold hover:bg-[#D1A954]/90"
                      >
                        <Camera className="w-5 h-5 mr-2" />
                        Start Face Scan
                      </Button>
                    </div>
                  )}
                </div>
                {errors.face_scan && <p className="text-red-400 text-xs text-center mt-4">{errors.face_scan}</p>}
              </motion.div>
            )}

            {/* Step 4: Address Proof */}
            {currentStep === 4 && (
              <motion.div
                key="step4"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="text-center mb-8">
                  <h2 className="text-2xl font-bold text-white mb-2">Address Proof</h2>
                  <p className="text-white/60">Upload a document showing your current address</p>
                </div>

                <div className="bg-white/5 rounded-xl p-4 border border-[#D1A954]/20 mb-6">
                  <p className="text-white/80 text-sm">
                    <strong className="text-[#D1A954]">Accepted documents:</strong> Utility bill, bank statement, or government letter dated within the last 90 days.
                  </p>
                </div>

                <div>
                  {previews.address_proof ? (
                    <div className="relative">
                      <img src={previews.address_proof} alt="Address proof" className="w-full max-h-80 object-contain rounded-xl border border-[#D1A954]/30" />
                      <button
                        onClick={() => removeFile('address_proof')}
                        className="absolute top-2 right-2 w-8 h-8 bg-red-500 rounded-full flex items-center justify-center"
                      >
                        <X className="w-4 h-4 text-white" />
                      </button>
                    </div>
                  ) : (
                    <label className="flex flex-col items-center justify-center h-48 border-2 border-dashed border-[#D1A954]/30 rounded-xl cursor-pointer hover:border-[#D1A954]/60 transition-colors bg-white/5">
                      <Upload className="w-12 h-12 text-[#D1A954]/60 mb-3" />
                      <span className="text-white font-medium mb-1">Drop file here or click to upload</span>
                      <span className="text-white/50 text-sm">PDF, JPG, PNG up to 10MB</span>
                      <input type="file" accept="image/*,.pdf" className="hidden" onChange={(e) => handleFileUpload('address_proof', e)} />
                    </label>
                  )}
                  {errors.address_proof && <p className="text-red-400 text-xs mt-2">{errors.address_proof}</p>}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {errors.submit && (
            <div className="bg-red-500/20 border border-red-500/50 rounded-lg p-3 mt-6">
              <p className="text-red-300 text-sm text-center">{errors.submit}</p>
            </div>
          )}

          {/* Navigation */}
          <div className="flex gap-4 mt-8 pt-6 border-t border-white/10">
            {currentStep > 1 && (
              <Button variant="outline" onClick={handleBack} className="flex-1 border-[#D1A954]/30 text-[#D1A954] hover:bg-[#D1A954]/10">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
            )}
            
            {currentStep < 4 ? (
              <Button onClick={handleNext} className="flex-1 bg-[#D1A954] text-black font-bold hover:bg-[#D1A954]/90">
                Continue
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            ) : (
              <Button onClick={handleSubmit} disabled={isLoading} className="flex-1 bg-[#D1A954] text-black font-bold hover:bg-[#D1A954]/90">
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Submitting...
                  </>
                ) : (
                  <>
                    Submit KYC
                    <CheckCircle className="w-4 h-4 ml-2" />
                  </>
                )}
              </Button>
            )}
          </div>
        </motion.div>
      </main>
    </div>
  );
}