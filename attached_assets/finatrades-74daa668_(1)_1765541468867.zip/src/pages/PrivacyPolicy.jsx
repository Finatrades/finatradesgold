import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Shield, User, Database, Share2, Globe, UserCheck, Clock, Lock, Cookie, RefreshCw, ArrowLeft } from 'lucide-react';

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FAFBFF] via-[#F4F6FC] to-white text-[#0D0D0D]">
      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(138,43,226,0.08)_0%,_transparent_50%)]" />
        <div className="max-w-4xl mx-auto px-6 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <Link 
              to={createPageUrl("Home")} 
              onClick={() => window.scrollTo(0, 0)}
              className="inline-flex items-center gap-2 text-[#8A2BE2] hover:text-[#FF2FBF] transition-colors mb-6"
            >
              <ArrowLeft className="w-4 h-4" />
              <span className="text-sm">Back to Home</span>
            </Link>
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#D4AF37]/10 border border-[#8A2BE2]/30 mb-6">
              <Shield className="w-4 h-4 text-[#8A2BE2]" />
              <span className="text-sm text-[#8A2BE2]">Legal Document</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-extralight mb-4">
              Privacy <span className="text-[#8A2BE2]">Policy</span>
            </h1>
            <p className="text-[#4A4A4A]">FINATRADES.COM • Last Updated: 21/11/2025</p>
          </motion.div>
        </div>
      </section>

      {/* Content */}
      <section className="pb-20">
        <div className="max-w-4xl mx-auto px-6">
          
          {/* Introduction */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white shadow-[0_8px_32px_rgba(160,50,255,0.12)] rounded-2xl border border-[#8A2BE2]/20 p-8 mb-8"
          >
            <p className="text-[#333333] leading-relaxed mb-4">
              This Privacy Policy ("Policy") describes the principles and practices followed by <strong className="text-[#0D0D0D]">Finatrades Finance SA</strong>, Rue Robert Céard 6, 1204 Geneva, Switzerland ("Finatrades", "we", "us", "our"), regarding the collection, use, processing, disclosure, and protection of your personal data.
            </p>
            <p className="text-[#333333] leading-relaxed mb-4">
              We process your personal data in strict compliance with the <strong className="text-[#0D0D0D]">Swiss Federal Act on Data Protection (FADP)</strong> and its corresponding ordinances. Where applicable, and particularly concerning the personal data of individuals located in the European Economic Area (EEA), we also adhere to the provisions of the <strong className="text-[#0D0D0D]">European Union General Data Protection Regulation (EU GDPR)</strong>.
            </p>
            <p className="text-[#333333] leading-relaxed">
              By using the Finatrades Platform, you acknowledge that you have read and understood how we process your personal data as described in this Policy.
            </p>
          </motion.div>

          {/* Section 1 */}
          <Section number="1" title="DATA CONTROLLER & CONTACT INFORMATION" icon={User} delay={0.15}>
            <p className="text-[#333333] mb-4">The data controller responsible for your personal data is:</p>
            <div className="bg-gradient-to-br from-[#FAFBFF] via-[#F4F6FC] to-white rounded-xl border border-[#8A2BE2]/10 p-5">
              <p className="text-[#0D0D0D] font-medium">Finatrades Finance SA</p>
              <p className="text-[#4A4A4A]">Rue Robert Céard 6</p>
              <p className="text-[#4A4A4A]">1204 Geneva</p>
              <p className="text-[#4A4A4A] mb-3">Switzerland</p>
              <p className="text-[#333333]">Email for Data Privacy Inquiries: <a href="mailto:info@finatrades.com" className="text-[#8A2BE2] hover:underline">info@finatrades.com</a></p>
            </div>
          </Section>

          {/* Section 2 */}
          <Section number="2" title="CATEGORIES OF PERSONAL DATA WE COLLECT" icon={Database} delay={0.2}>
            <p className="text-[#333333] mb-4">To provide our services and meet our legal obligations, we collect and process the following categories of personal data:</p>
            <ul className="space-y-4 text-[#333333]">
              <li>
                <strong className="text-[#0D0D0D]">Identification and KYC Data:</strong> Full name, date of birth, nationality, government-issued identification numbers (e.g., passport, national ID), copies of identity documents, and photographs.
              </li>
              <li>
                <strong className="text-[#0D0D0D]">Contact Information:</strong> Residential address, email address, telephone number.
              </li>
              <li>
                <strong className="text-[#0D0D0D]">Financial and Background Information:</strong> Source of wealth and funds, bank account details, payment card information, and professional background as required for our "know-your-customer" (KYC) and anti-money laundering (AML) checks.
              </li>
              <li>
                <strong className="text-[#0D0D0D]">Gold Transaction Data:</strong> Details of your gold deposits, purchases, sales, and all transactions involving Gold Certificates, including counterparty information, dates, amounts, and vaulting records.
              </li>
              <li>
                <strong className="text-[#0D0D0D]">Technical and Usage Data:</strong> IP address, device identifier, browser type, operating system, log data, pages visited, and other information collected through cookies and similar tracking technologies.
              </li>
              <li>
                <strong className="text-[#0D0D0D]">Communication Data:</strong> Records of your communications with us, including support tickets, emails, and chat logs.
              </li>
            </ul>
          </Section>

          {/* Section 3 */}
          <Section number="3" title="PURPOSES & LEGAL BASIS FOR PROCESSING" icon={Database} delay={0.25}>
            <p className="text-[#333333] mb-4">We process your personal data for the following purposes and based on the corresponding legal grounds:</p>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-[#8A2BE2]/20">
                    <th className="text-left py-3 px-4 text-[#8A2BE2] font-medium">Purpose</th>
                    <th className="text-left py-3 px-4 text-[#8A2BE2] font-medium">Legal Basis (under FADP/GDPR)</th>
                  </tr>
                </thead>
                <tbody className="text-[#333333]">
                  <tr className="border-b border-[#E8E0F0]">
                    <td className="py-3 px-4">To onboard you as a customer and perform KYC/AML checks</td>
                    <td className="py-3 px-4">Legal Obligation by Law & Legitimate Interest</td>
                  </tr>
                  <tr className="border-b border-[#E8E0F0]">
                    <td className="py-3 px-4">To provide Platform services (issuing/managing Gold Certificates, facilitating payments through 3rd party)</td>
                    <td className="py-3 px-4">Performance as stated on Platform</td>
                  </tr>
                  <tr className="border-b border-[#E8E0F0]">
                    <td className="py-3 px-4">To prevent, detect, and investigate fraud, money laundering, and other financial crimes</td>
                    <td className="py-3 px-4">Legitimate Interest & Legal Obligation by Law</td>
                  </tr>
                  <tr className="border-b border-[#E8E0F0]">
                    <td className="py-3 px-4">To communicate with you and provide customer support</td>
                    <td className="py-3 px-4">Performance as stated on Platform & Legitimate Interest</td>
                  </tr>
                  <tr className="border-b border-[#E8E0F0]">
                    <td className="py-3 px-4">To ensure the security and integrity of our IT systems and the Platform</td>
                    <td className="py-3 px-4">Legitimate Interest</td>
                  </tr>
                  <tr>
                    <td className="py-3 px-4">To comply with ongoing regulatory reporting and record-keeping requirements</td>
                    <td className="py-3 px-4">Legal Obligation by Law</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </Section>

          {/* Section 4 */}
          <Section number="4" title="DISCLOSURE OF PERSONAL DATA TO THIRD PARTIES" icon={Share2} delay={0.3}>
            <p className="text-[#333333] mb-4">We may share your personal data with the following categories of recipients, strictly where necessary and under contractual obligations of confidentiality:</p>
            <ul className="space-y-4 text-[#333333]">
              <li>
                <strong className="text-[#0D0D0D]">Regulatory and Governmental Authorities:</strong> Swiss Financial Market Supervisory Authority (FINMA), self-regulatory organizations (SROs), the Swiss Money Laundering Reporting Office (MROS), tax authorities, and other competent bodies, as required by law.
              </li>
              <li>
                <strong className="text-[#0D0D0D]">Service Providers (Processors):</strong> Entities that process data on our instructions, including:
                <ul className="mt-2 ml-4 space-y-1 text-[#4A4A4A]">
                  <li>• KYC/AML & Identity Verification Vendors</li>
                  <li>• Vault Operators & Assayers (for gold deposit and storage verification)</li>
                  <li>• Cloud Hosting and IT Infrastructure Providers</li>
                  <li>• Auditors, Legal Advisors, and Compliance Consultants</li>
                  <li>• Customer Relationship Management (CRM) and Communication Platforms</li>
                </ul>
              </li>
              <li>
                <strong className="text-[#0D0D0D]">Financial Institutions:</strong> Correspondent banks and payment processors to facilitate fiat currency transactions.
              </li>
              <li>
                <strong className="text-[#0D0D0D]">Other Users:</strong> As an integral part of our service, when you initiate a payment using a Gold Certificate, certain necessary data (e.g., your registered name and the transaction details) will be disclosed to the recipient User to enable the transaction and for their record-keeping.
              </li>
            </ul>
          </Section>

          {/* Section 5 */}
          <Section number="5" title="INTERNATIONAL DATA TRANSFERS" icon={Globe} delay={0.35}>
            <p className="text-[#333333]">
              Your personal data may be transferred to and processed in countries outside Switzerland. We ensure all such international data transfers are conducted lawfully and protected through appropriate legal safeguards, which may include transferring to countries with officially recognized adequate data protection standards, or where necessary to fulfill legal obligations, establish legal claims, or defend our legitimate interests in accordance with applicable data protection laws.
            </p>
          </Section>

          {/* Section 6 */}
          <Section number="6" title="YOUR DATA SUBJECT RIGHTS" icon={UserCheck} delay={0.4} highlight>
            <p className="text-[#333333] mb-4">Under the FADP and, where applicable, the GDPR, you have the following rights regarding your personal data:</p>
            <ul className="space-y-3 text-[#333333] mb-6">
              <li><strong className="text-[#0D0D0D]">Right of Access:</strong> You can request a copy of the personal data we hold about you.</li>
              <li><strong className="text-[#0D0D0D]">Right to Rectification:</strong> You can request correction of inaccurate or incomplete data.</li>
              <li><strong className="text-[#0D0D0D]">Right to Erasure (Right to be Forgotten):</strong> You can request the deletion of your data, subject to our legal obligations to retain it (e.g., under Swiss AML law).</li>
              <li><strong className="text-[#0D0D0D]">Right to Restriction of Processing:</strong> You can request that we temporarily halt the processing of your data under certain conditions.</li>
              <li><strong className="text-[#0D0D0D]">Right to Data Portability:</strong> You have the right to receive your data in a structured, machine-readable format.</li>
              <li><strong className="text-[#0D0D0D]">Right to Object:</strong> You can object to the processing of your data based on our legitimate interests.</li>
            </ul>
            <p className="text-[#333333]">
              To exercise any of these rights, please contact us at <a href="mailto:info@finatrades.com" className="text-[#8A2BE2] hover:underline">info@finatrades.com</a>. We will respond to your request within 30 days.
            </p>
          </Section>

          {/* Section 7 */}
          <Section number="7" title="DATA RETENTION PERIODS" icon={Clock} delay={0.45}>
            <p className="text-[#333333]">
              We retain your personal data only for as long as necessary to fulfill the purposes outlined in this Policy, unless a longer retention period is required or permitted by law. In accordance with Swiss Anti-Money Laundering Law, we are required to retain your identification data, transaction records, and business correspondence for a minimum of <strong className="text-[#0D0D0D]">ten (10) years</strong> after the termination of our business relationship or the execution of an individual transaction.
            </p>
          </Section>

          {/* Section 8 */}
          <Section number="8" title="DATA SECURITY MEASURES" icon={Lock} delay={0.5}>
            <p className="text-[#333333] mb-4">
              We implement robust technical and organizational measures to protect your personal data from unauthorized access, loss, misuse, or alteration. These measures include:
            </p>
            <ul className="space-y-2 text-[#333333] mb-4">
              <li className="flex items-start gap-2">
                <span className="text-[#8A2BE2] mt-1">•</span>
                Encryption of data in transit (using TLS/SSL protocols) and at rest.
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#8A2BE2] mt-1">•</span>
                Multi-Factor Authentication (MFA) for access to the Platform and our internal systems.
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#8A2BE2] mt-1">•</span>
                Strict physical and logical access controls to our premises and IT infrastructure.
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#8A2BE2] mt-1">•</span>
                Regular security testing, vulnerability assessments, and penetration tests.
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#8A2BE2] mt-1">•</span>
                Comprehensive logging and monitoring to detect and respond to security incidents.
              </li>
            </ul>
            <p className="text-[#4A4A4A] text-sm">
              Despite these measures, no method of transmission over the Internet or electronic storage is 100% secure. Therefore, we cannot guarantee its absolute security.
            </p>
          </Section>

          {/* Section 9 */}
          <Section number="9" title="USE OF COOKIES AND SIMILAR TECHNOLOGIES" icon={Cookie} delay={0.55}>
            <p className="text-[#333333] mb-4">
              Our Platform uses cookies to ensure essential functionality, enhance security, and analyze user behavior to improve our services.
            </p>
            <ul className="space-y-3 text-[#333333] mb-4">
              <li><strong className="text-[#0D0D0D]">Essential Cookies:</strong> Required for the Platform to function (e.g., login sessions, security).</li>
              <li><strong className="text-[#0D0D0D]">Analytical/Performance Cookies:</strong> Allow us to analyze how users interact with our site to improve its performance.</li>
              <li><strong className="text-[#0D0D0D]">Functionality Cookies:</strong> Remember your preferences to personalize your experience.</li>
            </ul>
            <p className="text-[#333333]">
              You can manage your cookie preferences through your browser settings. Please note that disabling certain cookies may impact the functionality of the Platform.
            </p>
          </Section>

          {/* Section 10 */}
          <Section number="10" title="POLICY UPDATES & NOTIFICATION" icon={RefreshCw} delay={0.6}>
            <p className="text-[#333333]">
              We may update this Privacy Policy from time to time to reflect changes in our practices, services, or legal obligations. The updated version will be indicated by a "Last Revised" date at the top of this page and will be effective immediately upon posting. We will notify you of any material changes via email or a prominent notice on our Platform. Your continued use of our services after such notification constitutes your acceptance of the updated Policy.
            </p>
          </Section>

          {/* Back to Home Button */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.65 }}
            className="mt-8 text-center"
          >
            <Link 
              to={createPageUrl("Home")} 
              onClick={() => window.scrollTo(0, 0)}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white font-medium hover:shadow-[0_0_20px_rgba(138,43,226,0.3)] transition-all"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Home
            </Link>
          </motion.div>

        </div>
      </section>
    </div>
  );
}

function Section({ number, title, icon: Icon, children, delay = 0, highlight = false }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      className={`mb-8 ${highlight ? 'bg-gradient-to-br from-[#8A2BE2]/5 to-transparent rounded-2xl border border-[#8A2BE2]/20 p-8' : ''}`}
    >
      <h3 className="text-xl font-light text-[#0D0D0D] mb-6 flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#8A2BE2]/20 to-[#FF2FBF]/10 flex items-center justify-center flex-shrink-0">
          <Icon className="w-5 h-5 text-[#8A2BE2]" />
        </div>
        <span className="text-[#8A2BE2]">{number}.</span>
        {title}
      </h3>
      {children}
    </motion.div>
  );
}