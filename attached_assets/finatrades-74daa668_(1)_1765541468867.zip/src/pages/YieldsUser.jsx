import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { TrendingUp, Info } from 'lucide-react';

import DashboardSidebar from '@/components/dashboard/DashboardSidebar';
import YieldsSummaryCards from '@/components/yields/YieldsSummaryCards';
import DailyAccrualChart from '@/components/yields/DailyAccrualChart';
import PlansBreakdownTable from '@/components/yields/PlansBreakdownTable';
import HowAccrualWorksCard from '@/components/yields/HowAccrualWorksCard';
import YieldsDisclaimer from '@/components/yields/YieldsDisclaimer';

// Sample active BNSL plans
const samplePlans = [
  {
    id: 'BNSL-2024-001',
    tenure: 12,
    rate: 10,
    principalGold: 100.000,
    lockedInPrice: 85.00,
    lockedPrincipalValue: 8500.00,
    quarterlyValue: 212.50,
    dailyAccrual: 0.0278,
    qtdAccumulated: 1.668,
    nextDistribution: '12 Mar 2025',
    progressData: Array.from({ length: 60 }, (_, i) => ({ value: i * 0.0278 }))
  },
  {
    id: 'BNSL-2024-002',
    tenure: 24,
    rate: 11,
    principalGold: 250.000,
    lockedInPrice: 84.50,
    lockedPrincipalValue: 21125.00,
    quarterlyValue: 580.94,
    dailyAccrual: 0.0760,
    qtdAccumulated: 4.560,
    nextDistribution: '01 Mar 2025',
    progressData: Array.from({ length: 60 }, (_, i) => ({ value: i * 0.076 }))
  },
  {
    id: 'BNSL-2024-003',
    tenure: 36,
    rate: 12,
    principalGold: 75.000,
    lockedInPrice: 82.00,
    lockedPrincipalValue: 6150.00,
    quarterlyValue: 184.50,
    dailyAccrual: 0.0241,
    qtdAccumulated: 1.446,
    nextDistribution: '15 Mar 2025',
    progressData: Array.from({ length: 60 }, (_, i) => ({ value: i * 0.0241 }))
  }
];

export default function YieldsUser() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [plans, setPlans] = useState(samplePlans);
  const [selectedPlan, setSelectedPlan] = useState(null);
  
  // Current gold price for calculations
  const goldPrice = 85.00;
  
  // Current day in quarter (1-90)
  const currentDay = 60;

  useEffect(() => {
    const storedUser = localStorage.getItem('finatrades_user');
    if (!storedUser) {
      navigate(createPageUrl("Home"));
      return;
    }
    setUser(JSON.parse(storedUser));
  }, [navigate]);

  // Calculate aggregate stats
  const totalDailyAccrual = plans.reduce((sum, p) => sum + p.dailyAccrual, 0);
  const totalQTD = plans.reduce((sum, p) => sum + p.qtdAccumulated, 0);
  const totalQuarterlyValue = plans.reduce((sum, p) => sum + p.quarterlyValue, 0);
  const avgRate = plans.reduce((sum, p) => sum + p.rate, 0) / plans.length;
  
  // Get earliest next distribution
  const nextDist = plans.reduce((earliest, p) => {
    return earliest || p.nextDistribution;
  }, null);

  // Generate chart data for 90-day quarter
  const chartData = Array.from({ length: 91 }, (_, i) => ({
    day: i,
    accumulated: (totalDailyAccrual * i),
    dailyRate: totalDailyAccrual
  }));

  const handleViewPlan = (plan) => {
    navigate(createPageUrl("FinaEarnUser") + `?planId=${plan.id}`);
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FAFBFF] via-[#F4F6FC] to-[#FFFFFF]">
      
      <div className="flex">
        {/* Sidebar */}
        <DashboardSidebar currentPage="YieldsUser" user={user} />

        {/* Main Content */}
        <main className="flex-1 min-h-screen">
          {/* Top Header */}
          <header className="sticky top-0 z-30 bg-white border-b border-[#8A2BE2]/20 px-4 sm:px-6 py-3 sm:py-4 shadow-sm">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 sm:gap-4 ml-12 lg:ml-0">
                <div className="flex items-center gap-2 sm:gap-3">
                  <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg sm:rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 flex items-center justify-center">
                    <TrendingUp className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
                  </div>
                  <div>
                    <h1 className="text-base sm:text-xl font-bold text-[#0D0D0D]">
                      <span className="hidden sm:inline">Yields — BNSL Accrued Rewards</span>
                      <span className="sm:hidden">Yields</span>
                    </h1>
                    <p className="text-[#4A4A4A] text-[10px] sm:text-xs hidden sm:block">
                      Track your daily accrual toward quarterly gold distributions
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </header>

          <div className="p-4 sm:p-6 space-y-4 sm:space-y-6">
            {/* Context Banner */}
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-start gap-2 sm:gap-3 p-3 sm:p-4 bg-[#F4F6FC] rounded-lg sm:rounded-xl border border-[#8A2BE2]/10"
            >
              <Info className="w-4 h-4 sm:w-5 sm:h-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-[#4A4A4A] text-xs sm:text-sm leading-relaxed">
                  Visual representation of your growing distribution. 
                  <strong className="text-[#0D0D0D]"> Gold credited every 3 months.</strong>
                </p>
                <p className="text-[#4A4A4A] text-[10px] sm:text-xs mt-1 hidden sm:block">
                  BNSL is a structured gold holding plan, not a deposit or savings account.
                </p>
              </div>
            </motion.div>

            {/* Summary Cards */}
            <YieldsSummaryCards
              dailyAccrual={totalDailyAccrual}
              quarterToDate={totalQTD}
              nextDistribution={nextDist}
              avgPlanRate={avgRate}
            />

            {/* Main Content Grid */}
            <div className="grid lg:grid-cols-3 gap-4 sm:gap-6">
              {/* Chart - Takes 2 columns */}
              <div className="lg:col-span-2">
                <DailyAccrualChart
                  data={chartData}
                  currentDay={currentDay}
                  quarterlyTotal={totalQuarterlyValue / goldPrice}
                />
              </div>

              {/* Info Card - Takes 1 column */}
              <div className="lg:col-span-1">
                <HowAccrualWorksCard selectedPlan={plans[0]} />
              </div>
            </div>

            {/* Plans Breakdown Table */}
            <PlansBreakdownTable plans={plans} onViewPlan={handleViewPlan} />

            {/* Disclaimer */}
            <YieldsDisclaimer />
          </div>
        </main>
      </div>
    </div>
  );
}