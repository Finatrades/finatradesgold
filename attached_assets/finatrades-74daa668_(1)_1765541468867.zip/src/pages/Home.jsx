import React, { useState, useEffect } from 'react';
import { useLocation, Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { AccountTypeProvider, useAccountType } from '@/components/AccountTypeContext';
import { LanguageProvider, useLanguage } from '@/components/LanguageContext';
import LanguageSwitcher from '@/components/LanguageSwitcher';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Menu, X, ChevronRight, User, Building2,
  Vault, Wallet, TrendingUp, ArrowLeftRight, GitBranch,
  Target, Compass, Shield, Globe, Eye, Zap, Award, Users, Lock, Building,
  FileText, QrCode, CheckCircle, Hash, Calendar, Warehouse,
  UserPlus, ShieldCheck, LayoutDashboard, Coins, ArrowRight,
  MapPin, Mail, Phone, Clock, Send, MessageSquare
} from 'lucide-react';

// Import home section components
import PremiumHeroSection from '@/components/home/PremiumHeroSection';
import GlobalPaymentRouting from '@/components/home/GlobalPaymentRouting';
import BusinessGlobe from '@/components/home/BusinessGlobe';
import SmartphoneNetworkHero from '@/components/home/SmartphoneNetworkHero';
import ProductSuite from '@/components/home/ProductSuite';
import HowItWorksAnimated from '@/components/home/HowItWorksAnimated';
import HowItWorksSnake from '@/components/home/HowItWorksSnake';

import BNSLPreview from '@/components/home/BNSLPreview';
import PersonalToolsSection from '@/components/home/PersonalToolsSection';
import WhyFinatrades from '@/components/home/WhyFinatrades';
import FinalCTA from '@/components/home/FinalCTA';
import SectionTitle from '@/components/ui/SectionTitle';
import GoldButton from '@/components/ui/GoldButton';
import GoldCard from '@/components/ui/GoldCard';
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

// Scroll to top on page load
function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

// Navigation items
const navItems = [
  { id: 'home', label: 'Home' },
  { id: 'products', label: 'Products' },
  { id: 'how-it-works', label: 'How It Works' },
  { id: 'about', label: 'About' },
  { id: 'contact', label: 'Contact' }
];

// Products data - Different for Personal vs Business
const getProducts = (accountType) => {
  if (accountType === 'business') {
    return [
      {
        id: "finavault",
        icon: Vault,
        name: "FinaVault Corporate",
        tagline: "Corporate Gold Reserve Ledger",
        description: "Complete visibility across bar numbers, batch origins, purity, and vault locations.",
        page: "FinaVault"
      },
      {
        id: "finapay",
        icon: Wallet,
        name: "FinaPay Business",
        tagline: "Operational Gold Dashboard",
        description: "Real-time value tracking for treasury, risk monitoring, and allocation.",
        page: "FinaPay"
      },
      {
        id: "finabridge",
        icon: GitBranch,
        name: "FinaBridge",
        tagline: "Trade Support Layer",
        description: "Documentation and workflows that support trade deals backed by gold value.",
        featured: true,
        page: "FinaBridge"
      },
      {
        id: "bnsl",
        icon: TrendingUp,
        name: "FinaEarn (B'N'SL)",
        tagline: "Programmatic Holding",
        description: "Lock gold into structured terms aligned with business cycles.",
        page: "BNSL"
      }
    ];
  }
  
  // Personal mode - only 3 products (no FinaBridge/FinaFinance)
  return [
    {
      id: "finavault",
      icon: Vault,
      name: "FinaVault",
      tagline: "Personal Gold Locker",
      description: "A secure digital ledger showing your stored gold, certificates, and purity details.",
      page: "FinaVault"
    },
    {
      id: "finapay",
      icon: Wallet,
      name: "FinaPay Wallet",
      tagline: "Gold Value View",
      description: "Displays your gold in grams and estimated value. Helps plan expenses and savings.",
      page: "FinaPay"
    },
    {
      id: "bnsl",
      icon: TrendingUp,
      name: "FinaEarn (B'N'SL)",
      tagline: "Holding Plans",
      description: "Choose defined durations (12, 24, or 36 months) for structured holding.",
      page: "BNSL"
    }
  ];
};

// About data - Different for Personal vs Business
const getMissionPoints = (accountType) => {
  if (accountType === 'business') {
    return [
      { icon: Building, text: "Enterprise-grade infrastructure" },
      { icon: Shield, text: "Corporate compliance & governance" },
      { icon: Globe, text: "Global trade finance solutions" },
      { icon: Users, text: "Multi-user corporate access" },
      { icon: Award, text: "Institutional reporting standards" }
    ];
  }
  return [
    { icon: Eye, text: "Transparent access to gold" },
    { icon: Shield, text: "Reliable storage and certification" },
    { icon: Zap, text: "Modern, secure financial tools" },
    { icon: Lock, text: "Personal wealth protection" },
    { icon: Award, text: "Simple, intuitive experience" }
  ];
};

const getDifferentiators = (accountType) => {
  if (accountType === 'business') {
    return [
      { icon: Building, title: "Enterprise Infrastructure", description: "Multi-user access, role management, and corporate controls." },
      { icon: GitBranch, title: "Trade Finance Platform", description: "End-to-end importer/exporter deal management with FinaBridge." },
      { icon: Shield, title: "Corporate Compliance", description: "Full regulatory compliance with enterprise-grade KYC/AML." },
      { icon: Globe, title: "Global Settlement", description: "Cross-border B2B payments with gold-backed guarantees." },
      { icon: Users, title: "Team Management", description: "Invite team members with granular permission controls." },
      { icon: FileText, title: "Enterprise Reporting", description: "Detailed analytics, audit trails, and financial reports." }
    ];
  }
  return [
    { icon: Building, title: "Swiss Operational Standards", description: "Operating under strict Swiss regulatory framework." },
    { icon: Lock, title: "Real Vault-Backed Infrastructure", description: "Every digital representation backed by physical gold." },
    { icon: Shield, title: "No Synthetic Assets", description: "Real, physical gold only. No derivatives." },
    { icon: Eye, title: "Auditable Processes", description: "Complete transparency with regular audits." },
    { icon: Wallet, title: "Easy Gold Management", description: "Simple buy, sell, and transfer operations." },
    { icon: TrendingUp, title: "Wealth Growth Plans", description: "Structured savings with guaranteed gold returns." }
  ];
};



// How It Works steps - Different for Personal vs Business
const getSteps = (accountType) => {
  if (accountType === 'business') {
    return [
      { number: "01", icon: Building, title: "Register Your Company", description: "Complete corporate onboarding with business documents." },
      { number: "02", icon: ShieldCheck, title: "Corporate KYC/AML", description: "Full compliance verification for your organization." },
      { number: "03", icon: Users, title: "Setup Team Access", description: "Invite team members and assign roles & permissions." },
      { number: "04", icon: LayoutDashboard, title: "Corporate Dashboard", description: "Access enterprise analytics and treasury management." },
      { number: "05", icon: Vault, title: "Manage Corporate Gold", description: "Deposit, custody, and manage company gold reserves." },
      { number: "06", icon: GitBranch, title: "Trade with FinaBridge", description: "Connect with partners for gold-backed trade deals." },
      { number: "07", icon: TrendingUp, title: "Treasury Optimization", description: "Enterprise B'N'SL plans for corporate treasury growth." }
    ];
  }
  return [
    { number: "01", icon: UserPlus, title: "Create Your Account", description: "Quick personal registration in minutes." },
    { number: "02", icon: ShieldCheck, title: "Verify Your Identity", description: "Simple KYC verification process." },
    { number: "03", icon: LayoutDashboard, title: "Access Your Dashboard", description: "View your gold balance and transactions." },
    { number: "04", icon: Coins, title: "Buy or Deposit Gold", description: "Purchase gold or deposit your existing holdings." },
    { number: "05", icon: Vault, title: "Secure Storage", description: "Your gold safely stored in Swiss vaults." },
    { number: "06", icon: Wallet, title: "Use Your Gold", description: "Transfer, sell, or use for payments." },
    { number: "07", icon: TrendingUp, title: "Grow Your Wealth", description: "Earn returns with B'N'SL savings plans." }
  ];
};



// Floating Navigation Component
function FloatingNav({ activeSection, accountType, setAccountType, scrollToSection }) {
  const { t } = useLanguage();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      scrolled ? 'bg-gradient-to-r from-[#0D001E] via-[#2A0055] to-[#4B0082] shadow-[0_4px_20px_rgba(212,175,55,0.2)]' : 'bg-gradient-to-r from-[#0D001E] via-[#2A0055] to-[#4B0082]'
    }`}>
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <button onClick={() => scrollToSection('home')} className="flex items-center group">
            <img 
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69293bd8e52dce0074daa668/ce96e4d2b_FINANEWLOGO-GOLDANDWHITENB.png" 
              alt="Finatrades" 
              className="h-10 group-hover:opacity-90 transition-opacity"
              style={{ filter: 'brightness(0) invert(1)' }}
            />
          </button>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className={`px-4 py-2 rounded-full text-sm transition-all duration-300 ${
                  activeSection === item.id
                    ? 'text-white bg-white/20'
                    : 'text-white/80 hover:text-white hover:bg-white/10'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          {/* Account Type Switcher + CTA */}
          <div className="hidden lg:flex items-center gap-3">
            {/* Language Switcher */}
            <LanguageSwitcher variant="light" />

            {/* Account Type Segmented Toggle */}
            <div className="relative flex items-center p-1 rounded-full bg-white/20 border border-white/30 backdrop-blur-sm">
              <motion.div 
                className="absolute top-1 bottom-1 rounded-full bg-white shadow-lg"
                animate={{ 
                  left: accountType === 'personal' ? 4 : '50%',
                  width: accountType === 'personal' ? 'calc(50% - 4px)' : 'calc(50% - 4px)'
                }}
                transition={{ type: "spring", stiffness: 300, damping: 30 }}
              />
              <button
                onClick={() => setAccountType('personal')}
                className={`relative z-10 flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-medium transition-colors ${
                  accountType === 'personal' ? 'text-[#4B0082]' : 'text-white/80 hover:text-white'
                }`}
              >
                <User className="w-3.5 h-3.5" />
                {t('nav.personal')}
              </button>
              <button
                onClick={() => setAccountType('business')}
                className={`relative z-10 flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-medium transition-colors ${
                  accountType === 'business' ? 'text-[#4B0082]' : 'text-white/80 hover:text-white'
                }`}
              >
                <Building2 className="w-3.5 h-3.5" />
                {t('nav.business')}
              </button>
            </div>

            <a
              href="https://portal.finatrades.com/"
              className="px-5 py-2 rounded-full border border-white/40 text-white text-sm font-medium hover:bg-white/10 transition-all"
            >
              Sign In
            </a>

            <a
              href="https://portal.finatrades.com/register"
              className="px-5 py-2 rounded-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white text-sm font-bold hover:shadow-[0_0_30px_rgba(138,43,226,0.5)] transition-all"
            >
              Get Started
            </a>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden w-10 h-10 rounded-lg border border-white/30 flex items-center justify-center text-white hover:bg-white/10 transition-colors"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden bg-gradient-to-b from-[#1A002F] to-[#0D001E] backdrop-blur-lg border-b border-[#D4AF37]/30 shadow-[0_8px_32px_rgba(212,175,55,0.15)]"
          >
            <nav className="max-w-7xl mx-auto px-6 py-6 space-y-2">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => { scrollToSection(item.id); setMobileMenuOpen(false); }}
                  className={`flex items-center justify-between w-full px-4 py-3 rounded-xl transition-all ${
                    activeSection === item.id
                      ? 'text-[#D4AF37] bg-white/10'
                      : 'text-white/80 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {item.label}
                  <ChevronRight className="w-4 h-4" />
                </button>
              ))}
              
              {/* Mobile Account Type Toggle */}
              <div className="pt-4 pb-2 px-4">
                <div className="relative flex items-center justify-center p-1 rounded-full bg-white/10 border border-white/20">
                  <motion.div 
                    className="absolute top-1 bottom-1 rounded-full bg-white shadow-lg"
                    animate={{ 
                      left: accountType === 'personal' ? 4 : '50%',
                      width: 'calc(50% - 4px)'
                    }}
                    transition={{ type: "spring", stiffness: 300, damping: 30 }}
                  />
                  <button
                    onClick={() => setAccountType('personal')}
                    className={`relative z-10 flex items-center justify-center gap-2 flex-1 py-2 rounded-full text-sm font-medium transition-colors ${
                      accountType === 'personal' ? 'text-[#4B0082]' : 'text-white/80'
                    }`}
                  >
                    <User className="w-4 h-4" />
                    Personal
                  </button>
                  <button
                    onClick={() => setAccountType('business')}
                    className={`relative z-10 flex items-center justify-center gap-2 flex-1 py-2 rounded-full text-sm font-medium transition-colors ${
                      accountType === 'business' ? 'text-[#4B0082]' : 'text-white/80'
                    }`}
                  >
                    <Building2 className="w-4 h-4" />
                    Business
                  </button>
                </div>
              </div>

              <div className="pt-2 space-y-2">
                <a
                  href="https://portal.finatrades.com/"
                  className="block w-full px-6 py-3 rounded-full border border-white/40 text-white text-center font-medium hover:bg-white/10 transition-all"
                >
                  Sign In
                </a>
                <a
                  href="https://portal.finatrades.com/register"
                  className="block w-full px-6 py-3 rounded-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white text-center font-bold shadow-[0_0_20px_rgba(138,43,226,0.4)]"
                >
                  Get Started
                </a>
              </div>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}



// How It Works Section
function HowItWorksSection({ accountType }) {
  const steps = getSteps(accountType);
  
  return (
    <section id="how-it-works" className="py-20 border-t border-[#8A2BE2]/10">
      <div className="max-w-5xl mx-auto px-6">
        <SectionTitle 
          title={accountType === 'business' ? "How It Works for Business" : "How It Works"}
          subtitle={accountType === 'business' 
            ? "Enterprise onboarding to gold-backed corporate treasury management."
            : "A simple journey from account creation to gold-backed wealth."}
        />
        
        <div className="space-y-6">
          {steps.map((step, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="flex gap-4 items-start"
            >
              <div className="flex-shrink-0 w-16 h-16 rounded-full bg-gradient-to-br from-[#8A2BE2] to-[#FF2FBF] p-0.5">
                <div className="w-full h-full rounded-full bg-white flex items-center justify-center">
                  <span className="text-lg font-light bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent">{step.number}</span>
                </div>
              </div>
              <GoldCard className="flex-1">
                <div className="flex items-start gap-4">
                  <div className="hidden sm:flex w-12 h-12 rounded-xl bg-gradient-to-br from-[#8A2BE2]/20 to-[#FF2FBF]/10 items-center justify-center flex-shrink-0">
                    <step.icon className="w-5 h-5 bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-[#0D0D0D] mb-2">{step.title}</h3>
                    <p className="text-[#4A4A4A]">{step.description}</p>
                  </div>
                </div>
              </GoldCard>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}



// About Section
function AboutSection({ accountType }) {
  const missionPoints = getMissionPoints(accountType);
  const differentiators = getDifferentiators(accountType);
  
  return (
    <section id="about" className="py-20 border-t border-[#8A2BE2]/10">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col items-center mb-8">
          {accountType === 'business' && (
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-[#8A2BE2] to-[#FF2FBF] flex items-center justify-center mb-6 shadow-[0_0_30px_rgba(138,43,226,0.3)]">
              <Building className="w-10 h-10 text-white" />
            </div>
          )}
          <SectionTitle 
            title={accountType === 'business' ? "Enterprise Solutions" : "About Finatrades"}
            subtitle={accountType === 'business' 
              ? "Institutional-grade gold infrastructure for modern businesses."
              : "Swiss-based fintech for personal gold-backed wealth management."}
          />
        </div>
        
        {/* Vision & Mission */}
        <div className="grid md:grid-cols-2 gap-8 mb-12">
          <GoldCard>
            <div className="flex items-center gap-4 mb-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#8A2BE2] to-[#FF2FBF] flex items-center justify-center shadow-[0_0_15px_rgba(138,43,226,0.3)]">
                <Target className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-[#0D0D0D]">
                                    {accountType === 'business' ? 'For Enterprise' : 'Our Vision'}
                                  </h3>
            </div>
            <p className="text-[#4A4A4A]">
              {accountType === 'business' 
                ? <>Build your <strong className="text-[#0D0D0D]">corporate treasury</strong> on gold-backed infrastructure with enterprise controls.</>
                : <>Build a new financial system where <strong className="text-[#0D0D0D]">real assets</strong> drive stability.</>
              }
            </p>
          </GoldCard>

          <GoldCard>
            <div className="flex items-center gap-4 mb-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#8A2BE2] to-[#FF2FBF] flex items-center justify-center shadow-[0_0_15px_rgba(138,43,226,0.3)]">
                <Compass className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-[#0D0D0D]">
                                    {accountType === 'business' ? 'Key Benefits' : 'Our Mission'}
                                  </h3>
            </div>
            <div className="space-y-2">
              {missionPoints.slice(0, 4).map((point, i) => (
                <div key={i} className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <span className="text-[#333333] text-sm">{point.text}</span>
                </div>
              ))}
            </div>
          </GoldCard>
        </div>

        {/* Differentiators */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {differentiators.map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
            >
              <GoldCard className="h-full">
                    <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#8A2BE2] to-[#FF2FBF] flex items-center justify-center mb-3 shadow-[0_0_15px_rgba(138,43,226,0.3)]">
                      <item.icon className="w-5 h-5 text-white" />
                    </div>
                    <h3 className="text-lg font-semibold text-[#0D0D0D] mb-2">{item.title}</h3>
                    <p className="text-[#4A4A4A] text-sm">{item.description}</p>
                  </GoldCard>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

// Contact Section
function ContactSection() {
  const [formData, setFormData] = useState({
    name: '', email: '', company: '', type: '', message: ''
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <section id="contact" className="py-20 border-t border-[#8A2BE2]/10">
      <div className="max-w-3xl mx-auto px-6">
        <SectionTitle 
          title="Get in Touch"
          subtitle="Ready to start your gold-backed financial journey? Our team is here to help."
        />
        
        <GoldCard>
          {submitted ? (
            <div className="text-center py-12">
              <div className="w-20 h-20 mx-auto rounded-full bg-gradient-to-br from-[#8A2BE2] to-[#FF2FBF] p-0.5 mb-6">
                <div className="w-full h-full rounded-full bg-white flex items-center justify-center">
                  <CheckCircle className="w-10 h-10 bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent" />
                </div>
              </div>
              <h3 className="text-2xl font-light text-[#0D0D0D] mb-4">Message Sent</h3>
              <p className="text-[#4A4A4A] mb-6">We'll contact you within 24-48 hours.</p>
              <GoldButton variant="outline" onClick={() => setSubmitted(false)}>
                Send Another Message
              </GoldButton>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              <h3 className="text-2xl font-light text-[#0D0D0D] mb-6">Send us a Message</h3>
              
              <div className="grid sm:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm text-[#4A4A4A] mb-2">Full Name *</label>
                  <Input
                    required
                    placeholder="John Smith"
                    className="bg-white border-[#8A2BE2]/20 focus:border-[#8A2BE2] text-[#0D0D0D] placeholder:text-[#4A4A4A]/80"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-sm text-[#4A4A4A] mb-2">Email Address *</label>
                  <Input
                    required
                    type="email"
                    placeholder="john@company.com"
                    className="bg-white border-[#8A2BE2]/20 focus:border-[#8A2BE2] text-[#0D0D0D] placeholder:text-[#4A4A4A]/80"
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                  />
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm text-[#4A4A4A] mb-2">Company</label>
                  <Input
                    placeholder="Company Name"
                    className="bg-white border-[#8A2BE2]/20 focus:border-[#8A2BE2] text-[#0D0D0D] placeholder:text-[#4A4A4A]/80"
                    value={formData.company}
                    onChange={(e) => setFormData({...formData, company: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-sm text-[#4A4A4A] mb-2">Account Type *</label>
                  <Select 
                    value={formData.type} 
                    onValueChange={(value) => setFormData({...formData, type: value})}
                  >
                    <SelectTrigger className="bg-white border-[#8A2BE2]/20 focus:border-[#8A2BE2] text-[#0D0D0D]">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent className="bg-white border-[#8A2BE2]/20">
                      <SelectItem value="individual">Individual</SelectItem>
                      <SelectItem value="corporate">Corporate</SelectItem>
                      <SelectItem value="importer">Importer</SelectItem>
                      <SelectItem value="exporter">Exporter</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <label className="block text-sm text-[#4A4A4A] mb-2">Message *</label>
                <Textarea
                  required
                  placeholder="Tell us about your needs..."
                  className="min-h-[120px] bg-white border-[#8A2BE2]/20 focus:border-[#8A2BE2] text-[#0D0D0D] placeholder:text-[#4A4A4A]/80"
                  value={formData.message}
                  onChange={(e) => setFormData({...formData, message: e.target.value})}
                />
              </div>

              <GoldButton type="submit" variant="primary" className="w-full">
                <span className="flex items-center justify-center gap-2">
                  <Send className="w-4 h-4" />
                  Send Message
                </span>
              </GoldButton>
            </form>
          )}
        </GoldCard>
      </div>
    </section>
  );
}

// Footer
function Footer({ scrollToSection }) {
  return (
    <footer className="bg-gradient-to-b from-[#1A002F] to-[#0D001E] border-t border-[#8A2BE2]/30">
      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="grid md:grid-cols-3 gap-12 mb-12">
          {/* Brand */}
          <div>
            <button onClick={() => scrollToSection('home')} className="flex items-center mb-6">
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69293bd8e52dce0074daa668/ce96e4d2b_FINANEWLOGO-GOLDANDWHITENB.png" 
                alt="Finatrades" 
                className="h-10"
                style={{ filter: 'brightness(0) invert(1)' }}
              />
            </button>
            <p className="text-white/70 mb-6 max-w-md">
              Swiss-regulated gold-backed digital finance platform. Building a new standard in asset-backed financial infrastructure.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-medium mb-4 tracking-wide">Quick Links</h4>
            <ul className="space-y-3">
              {navItems.map((item) => (
                <li key={item.id}>
                  <button
                                        onClick={() => scrollToSection(item.id)}
                                        className="text-white/70 hover:text-[#FF2FBF] transition-colors text-sm"
                                      >
                                        {item.label}
                                      </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className="text-white font-medium mb-4 tracking-wide">Legal</h4>
            <ul className="space-y-3">
              <li>
                <Link to={createPageUrl("PrivacyPolicy")} className="text-white/70 hover:text-[#FF2FBF] transition-colors text-sm">
                                      Privacy Policy
                                    </Link>
                                  </li>
                                  <li>
                                    <Link to={createPageUrl("TermsAndConditions")} className="text-white/70 hover:text-[#FF2FBF] transition-colors text-sm">
                                      Terms & Conditions
                                    </Link>
                                  </li>
                                  <li>
                                    <Link to={createPageUrl("Disclaimer")} className="text-white/70 hover:text-[#FF2FBF] transition-colors text-sm">
                                      Disclaimer
                                    </Link>
              </li>
            </ul>

            {/* App Store Buttons */}
            <div className="flex items-center gap-3 mt-6">
              {/* App Store Button */}
              <div className="relative group cursor-pointer">
                <div className="flex items-center gap-2 px-3 py-2 bg-black border border-white/20 rounded-lg opacity-60 group-hover:opacity-80 transition-all">
                  <svg viewBox="0 0 24 24" className="w-5 h-5 text-white" fill="currentColor">
                    <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/>
                  </svg>
                  <div className="text-left">
                    <div className="text-[7px] text-white/70 leading-none">Download on the</div>
                    <div className="text-xs text-white font-semibold leading-tight">App Store</div>
                  </div>
                </div>
                <div className="absolute inset-0 flex items-center justify-center bg-black/70 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity">
                  <span className="text-[9px] text-white font-medium px-2 py-0.5 bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] rounded-full">Coming Soon</span>
                </div>
              </div>

              {/* Google Play Button */}
              <div className="relative group cursor-pointer">
                <div className="flex items-center gap-2 px-3 py-2 bg-black border border-white/20 rounded-lg opacity-60 group-hover:opacity-80 transition-all">
                  <svg viewBox="0 0 24 24" className="w-5 h-5" fill="none">
                    <path d="M3.609 1.814L13.792 12 3.61 22.186a.996.996 0 01-.61-.92V2.734a1 1 0 01.609-.92z" fill="#4285F4"/>
                    <path d="M17.558 8.236L14.51 5.19 3.609 1.814 13.792 12l3.766-3.764z" fill="#EA4335"/>
                    <path d="M3.609 22.186L13.792 12l3.766 3.764-3.047 3.046-10.902 3.376z" fill="#34A853"/>
                    <path d="M20.855 10.097l-3.297-1.861-3.766 3.764 3.766 3.764 3.297-1.861c.95-.536.95-1.87 0-2.406z" fill="#FBBC04"/>
                  </svg>
                  <div className="text-left">
                    <div className="text-[7px] text-white/70 leading-none">GET IT ON</div>
                    <div className="text-xs text-white font-semibold leading-tight">Google Play</div>
                  </div>
                </div>
                <div className="absolute inset-0 flex items-center justify-center bg-black/70 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity">
                  <span className="text-[9px] text-white font-medium px-2 py-0.5 bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] rounded-full">Coming Soon</span>
                </div>
              </div>
            </div>
          </div>
          </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-4">
                      <p className="text-sm text-white/60">
                        © {new Date().getFullYear()} Finatrades Finance SA. All rights reserved.
                      </p>
                      <div className="flex flex-wrap items-center justify-center gap-4 md:gap-6">
                        <Link to={createPageUrl("PrivacyPolicy")} className="text-sm text-white/60 hover:text-[#FF2FBF] transition-colors">Privacy Policy</Link>
                        <Link to={createPageUrl("Disclaimer")} className="text-sm text-white/60 hover:text-[#FF2FBF] transition-colors">Disclaimer</Link>
                        <Link to={createPageUrl("TermsAndConditions")} className="text-sm text-white/60 hover:text-[#FF2FBF] transition-colors">Terms of Service</Link>
                      </div>
                    </div>
      </div>
    </footer>
  );
}

function HomeContent() {
  const { accountType, setAccountType } = useAccountType();
  const [activeSection, setActiveSection] = useState('home');

  // Scroll to section
  const scrollToSection = (sectionId) => {
    if (sectionId === 'home') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      const element = document.getElementById(sectionId);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  // Track active section on scroll
  useEffect(() => {
    const handleScroll = () => {
      const sections = navItems.map(item => item.id);
      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const rect = element.getBoundingClientRect();
          if (rect.top <= 100 && rect.bottom >= 100) {
            setActiveSection(section);
            break;
          }
        }
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <main className="bg-gradient-to-br from-[#FAFBFF] via-[#F4F6FC] to-[#FFFFFF] min-h-screen overflow-hidden text-[#0D0D0D]">
      <ScrollToTop />
      {/* Floating Navigation */}
      <FloatingNav 
        activeSection={activeSection}
        accountType={accountType}
        setAccountType={setAccountType}
        scrollToSection={scrollToSection}
      />

      {/* Home Section */}
      <section id="home">
        <PremiumHeroSection />
      </section>

      {/* Products Section */}
      <section id="products">
        <ProductSuite accountType={accountType} />
      </section>

      {/* How It Works Section */}
      <section id="how-it-works">
        <HowItWorksSnake mode={accountType} />
      </section>



      <BNSLPreview />
      <WhyFinatrades />





      {/* About Section */}
              <AboutSection accountType={accountType} />

              {/* Swiss Standards Section */}
              <section className="py-20 border-t border-[#8A2BE2]/10">
                <div className="max-w-4xl mx-auto px-6 text-center">
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                  >
                    <p className="text-sm font-bold bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent tracking-widest uppercase mb-4">Built on</p>
                                  <h2 className="text-3xl md:text-4xl font-bold text-[#0D0D0D] mb-6 flex items-center justify-center gap-3">
                                                            <span className="text-red-600 text-4xl md:text-5xl font-bold">+</span>
                                                            Swiss Financial <span className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent">Standards</span>
                                                          </h2>
                                                            <p className="text-[#4A4A4A] font-medium max-w-2xl mx-auto mb-8">
                                                              Operating under strict Swiss regulations, Finatrades ensures security, compliance, and reliability for businesses worldwide.
                                                            </p>
                    <Link
                                    to={createPageUrl("RegulatoryInformation")}
                                    onClick={() => window.scrollTo(0, 0)}
                                    className="inline-flex items-center gap-2 px-6 py-3 rounded-full border border-[#8A2BE2]/30 bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent hover:bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF]/10 transition-all"
                                  >
                                    View Regulatory Information
                                    <ChevronRight className="w-4 h-4" />
                                  </Link>
                  </motion.div>
                </div>
              </section>

              {/* Contact Section */}
      <ContactSection />

      {/* Final CTA */}
      <FinalCTA />

      {/* Footer */}
      <Footer scrollToSection={scrollToSection} />
    </main>
  );
}

export default function Home() {
  return <HomeContent />;
}