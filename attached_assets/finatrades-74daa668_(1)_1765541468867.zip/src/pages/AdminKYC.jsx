import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { UserCheck, Download, Eye, CheckCircle, XCircle, AlertTriangle, User, Building2 } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

import AdminSidebar from '@/components/admin/AdminSidebar';
import AdminTopBar from '@/components/admin/AdminTopBar';
import AdminTable from '@/components/admin/AdminTable';
import AdminFilterBar from '@/components/admin/AdminFilterBar';
import AdminStatusBadge from '@/components/admin/AdminStatusBadge';
import AdminDrawer from '@/components/admin/AdminDrawer';

const sampleKYCList = [
  { id: 'KYC-4521', name: 'Ahmed Al-Rashid', type: 'Personal', country: 'UAE', riskScore: 'Low', status: 'pending', submittedDate: '2024-12-04', email: 'ahmed@email.com', dob: '1985-03-15', nationality: 'UAE', docType: 'Passport', docNumber: 'A12345678', address: 'Dubai Marina, Dubai, UAE', sourceOfFunds: 'Employment', faceMatchScore: 94 },
  { id: 'KYC-4522', name: 'Swiss Metals AG', type: 'Corporate', country: 'Switzerland', riskScore: 'Medium', status: 'in_review', submittedDate: '2024-12-03', email: 'compliance@swissmetals.ch', incorporation: '2015-06-20', regNumber: 'CHE-123.456.789', address: 'Zurich, Switzerland', businessType: 'Precious Metals Trading' },
  { id: 'KYC-4523', name: 'Sarah Thompson', type: 'Personal', country: 'UK', riskScore: 'Low', status: 'approved', submittedDate: '2024-12-02', email: 'sarah@email.com', dob: '1990-07-22', nationality: 'British', docType: 'Passport', docNumber: 'GB9876543', address: 'London, UK', sourceOfFunds: 'Investments', faceMatchScore: 98 },
];

export default function AdminKYC() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [role, setRole] = useState('Compliance');
  const [searchValue, setSearchValue] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedKYC, setSelectedKYC] = useState(null);
  const [drawerOpen, setDrawerOpen] = useState(false);

  useEffect(() => {
    const storedUser = localStorage.getItem('finatrades_user');
    if (!storedUser) {
      navigate(createPageUrl("SignIn"));
      return;
    }
    const userData = JSON.parse(storedUser);
    if (!userData.is_admin) {
      navigate(createPageUrl("UserDashboard"));
      return;
    }
    setUser(userData);
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('finatrades_user');
    navigate(createPageUrl("Home"));
  };

  const handleReview = (kyc) => {
    setSelectedKYC(kyc);
    setDrawerOpen(true);
  };

  const kycColumns = [
    { header: 'KYC ID', accessor: 'id' },
    { header: 'Name', accessor: 'name', render: (val, row) => (
      <div className="flex items-center gap-2">
        {row.type === 'Personal' ? <User className="w-4 h-4 text-blue-400" /> : <Building2 className="w-4 h-4 text-purple-400" />}
        <span>{val}</span>
      </div>
    )},
    { header: 'Type', accessor: 'type', render: (val) => (
      <span className={`px-2 py-1 rounded text-xs ${val === 'Personal' ? 'bg-blue-500/20 text-blue-400' : 'bg-purple-500/20 text-purple-400'}`}>
        {val}
      </span>
    )},
    { header: 'Country', accessor: 'country' },
    { header: 'Risk', accessor: 'riskScore', render: (val) => <AdminStatusBadge status={val.toLowerCase()} /> },
    { header: 'Status', accessor: 'status', render: (val) => <AdminStatusBadge status={val} /> },
    { header: 'Submitted', accessor: 'submittedDate' },
  ];

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FAFBFF] via-[#F4F6FC] to-[#FFFFFF]">
      <AdminSidebar currentSection="kyc" onLogout={handleLogout} />
      
      <div className="ml-64">
        <AdminTopBar user={user} role={role} onRoleChange={setRole} />
        
        <main className="p-6 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-[#0D0D0D] flex items-center gap-3">
                <UserCheck className="w-7 h-7 text-[#8A2BE2]" />
                KYC & Onboarding
              </h1>
              <p className="text-[#4A4A4A] text-sm">Review and manage customer verification requests</p>
            </div>
          </div>

          <AdminFilterBar
            searchPlaceholder="Search by name or KYC ID..."
            searchValue={searchValue}
            onSearchChange={setSearchValue}
            filters={[
              { value: typeFilter, onChange: setTypeFilter, placeholder: 'Type', allLabel: 'All Types', options: [{ value: 'personal', label: 'Personal' }, { value: 'corporate', label: 'Corporate' }] },
              { value: statusFilter, onChange: setStatusFilter, placeholder: 'Status', allLabel: 'All Status', options: [{ value: 'pending', label: 'Pending' }, { value: 'in_review', label: 'In Review' }, { value: 'approved', label: 'Approved' }] }
            ]}
          />

          <AdminTable columns={kycColumns} data={sampleKYCList} onRowAction={handleReview} actionLabel="Review" />
        </main>
      </div>

      <AdminDrawer
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        title={selectedKYC?.name || 'KYC Review'}
        subtitle={selectedKYC?.id}
        footer={
          <div className="flex items-center justify-end gap-3">
            <Button variant="outline" className="border-red-500/30 text-red-400 hover:bg-red-500/10">
              <XCircle className="w-4 h-4 mr-2" />
              Reject
            </Button>
            <Button className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white font-bold">
              <CheckCircle className="w-4 h-4 mr-2" />
              Approve KYC
            </Button>
          </div>
        }
      >
        {selectedKYC && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white/5 rounded-lg p-4 border border-white/10">
                <p className="text-white/40 text-xs uppercase mb-1">Full Name</p>
                <p className="text-white">{selectedKYC.name}</p>
              </div>
              <div className="bg-white/5 rounded-lg p-4 border border-white/10">
                <p className="text-white/40 text-xs uppercase mb-1">Email</p>
                <p className="text-white">{selectedKYC.email}</p>
              </div>
              <div className="bg-white/5 rounded-lg p-4 border border-white/10">
                <p className="text-white/40 text-xs uppercase mb-1">Country</p>
                <p className="text-white">{selectedKYC.country}</p>
              </div>
              <div className="bg-white/5 rounded-lg p-4 border border-white/10">
                <p className="text-white/40 text-xs uppercase mb-1">Type</p>
                <p className="text-white">{selectedKYC.type}</p>
              </div>
            </div>
          </div>
        )}
      </AdminDrawer>
    </div>
  );
}