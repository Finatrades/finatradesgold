import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Vault, Wallet, TrendingUp, Bell, Settings
} from 'lucide-react';
import { Button } from "@/components/ui/button";

import DepositRequestList from '@/components/finavault/DepositRequestList';
import NewDepositForm from '@/components/finavault/NewDepositForm';
import DepositRequestDetails from '@/components/finavault/DepositRequestDetails';
import DashboardSidebar from '@/components/dashboard/DashboardSidebar';

// Sample data for demonstration
const sampleDeposits = [
  {
    id: '1',
    requestId: 'DEP-2024-001',
    vaultLocation: 'dubai',
    totalWeight: 500,
    depositType: 'bars',
    status: 'stored',
    submittedDate: '2024-11-15',
    items: [
      { type: 'bar', quantity: 5, weightPerUnit: 100, purity: '999.9', brand: 'PAMP Suisse', notes: '' }
    ],
    deliveryMethod: 'personal',
    documents: [
      { name: 'Invoice_PAMP.pdf', type: 'invoice' },
      { name: 'Assay_Cert.pdf', type: 'certificate' }
    ],
    timeline: {
      submitted: 'Nov 15, 10:30 AM',
      under_review: 'Nov 15, 2:45 PM',
      approved: 'Nov 16, 9:00 AM',
      received: 'Nov 18, 11:20 AM',
      stored: 'Nov 18, 3:00 PM'
    },
    storageStartDate: 'November 18, 2024',
    vaultReference: 'DXB-VAULT-2024-1847'
  },
  {
    id: '2',
    requestId: 'DEP-2024-002',
    vaultLocation: 'swiss',
    totalWeight: 1000,
    depositType: 'mixed',
    status: 'approved',
    submittedDate: '2024-12-01',
    items: [
      { type: 'bar', quantity: 2, weightPerUnit: 400, purity: '999.9', brand: 'Argor-Heraeus', notes: '' },
      { type: 'coin', quantity: 20, weightPerUnit: 10, purity: '999.9', brand: 'Austrian Mint', notes: 'Vienna Philharmonic' }
    ],
    deliveryMethod: 'courier',
    documents: [
      { name: 'Purchase_Receipt.pdf', type: 'invoice' }
    ],
    timeline: {
      submitted: 'Dec 1, 8:15 AM',
      under_review: 'Dec 1, 11:00 AM',
      approved: 'Dec 2, 10:30 AM'
    }
  },
  {
    id: '3',
    requestId: 'DEP-2024-003',
    vaultLocation: 'dubai',
    totalWeight: 250,
    depositType: 'coins',
    status: 'under_review',
    submittedDate: '2024-12-03',
    items: [
      { type: 'coin', quantity: 25, weightPerUnit: 10, purity: '999.9', brand: 'Perth Mint', notes: 'Kangaroo coins' }
    ],
    deliveryMethod: 'pickup',
    pickupDetails: {
      address: '123 Gold Street, Dubai Marina, UAE',
      contact: 'Ahmed Hassan',
      phone: '+971 50 123 4567',
      date: '2024-12-10',
      timeSlot: '10:00 - 12:00'
    },
    documents: [],
    timeline: {
      submitted: 'Dec 3, 4:20 PM',
      under_review: 'Dec 4, 9:00 AM'
    }
  }
];

export default function FinaVaultUser() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  
  const [deposits, setDeposits] = useState(sampleDeposits);
  const [view, setView] = useState('list'); // 'list', 'new', 'details'
  const [selectedDeposit, setSelectedDeposit] = useState(null);

  useEffect(() => {
    const storedUser = localStorage.getItem('finatrades_user');
    if (!storedUser) {
      navigate(createPageUrl("Home"));
      return;
    }
    const userData = JSON.parse(storedUser);
    setUser(userData);
    loadProfile(userData.email);
  }, [navigate]);

  const loadProfile = async (email) => {
    try {
      const allProfiles = await base44.entities.UserProfile.list();
      const profiles = allProfiles.filter(p => p.email === email);
      if (profiles.length > 0) {
        setProfile(profiles[0]);
      }
    } catch (error) {
      console.error('Failed to load profile:', error);
    }
  };

  const handleViewDetails = (deposit) => {
    setSelectedDeposit(deposit);
    setView('details');
  };

  const handleNewDeposit = () => {
    setView('new');
  };

  const handleBack = () => {
    setView('list');
    setSelectedDeposit(null);
  };

  const handleSubmitDeposit = (formData) => {
    const newDeposit = {
      id: Date.now().toString(),
      requestId: `DEP-2024-${String(deposits.length + 1).padStart(3, '0')}`,
      vaultLocation: formData.vaultLocation,
      totalWeight: formData.items.reduce((sum, item) => sum + (item.quantity * item.weightPerUnit), 0),
      depositType: formData.depositType,
      status: 'submitted',
      submittedDate: new Date().toISOString().split('T')[0],
      items: formData.items,
      deliveryMethod: formData.deliveryMethod,
      pickupDetails: formData.deliveryMethod === 'pickup' ? {
        address: formData.pickupAddress,
        contact: formData.pickupContact,
        phone: formData.pickupPhone,
        date: formData.pickupDate,
        timeSlot: formData.pickupTimeSlot
      } : null,
      documents: formData.documents.map(d => ({ name: d.name, type: d.type })),
      timeline: {
        submitted: new Date().toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit', hour12: true })
      }
    };
    setDeposits([newDeposit, ...deposits]);
    setSelectedDeposit(newDeposit);
    setView('details');
  };

  if (!user) return null;

  const kycApproved = profile?.kyc_status === 'approved';

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FAFBFF] via-[#F4F6FC] to-[#FFFFFF]">
      
      <div className="flex">
        {/* Sidebar */}
        <DashboardSidebar currentPage="FinaVaultUser" user={user} />

        {/* Main Content */}
        <main className="flex-1 min-h-screen">
          {/* Top Header */}
          <header className="sticky top-0 z-30 bg-white border-b border-[#8A2BE2]/20 px-4 sm:px-6 py-3 sm:py-4 shadow-sm">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 sm:gap-4 ml-12 lg:ml-0">
                <h1 className="text-base sm:text-xl font-bold text-[#0D0D0D] flex items-center gap-2">
                  <Vault className="w-4 h-4 sm:w-5 sm:h-5 text-amber-600" />
                  <span className="hidden sm:inline">FinaVault — Gold Deposit</span>
                  <span className="sm:hidden">FinaVault</span>
                </h1>
              </div>
              <div className="flex items-center gap-3">
                <button className="w-10 h-10 rounded-full bg-[#F4F6FC] border border-[#8A2BE2]/20 flex items-center justify-center text-[#4A4A4A] hover:bg-[#8A2BE2]/10 hover:border-[#8A2BE2]/40">
                  <Bell className="w-5 h-5" />
                </button>
                <button className="w-10 h-10 rounded-full bg-[#F4F6FC] border border-[#8A2BE2]/20 flex items-center justify-center text-[#4A4A4A] hover:bg-[#8A2BE2]/10 hover:border-[#8A2BE2]/40">
                  <Settings className="w-5 h-5" />
                </button>
              </div>
            </div>
          </header>

          <div className="p-4 sm:p-6">
            <AnimatePresence mode="wait">
              {view === 'list' && (
                <motion.div
                  key="list"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  className="space-y-6"
                >
                  {/* Summary Cards */}
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-4">
                    <div className="bg-gradient-to-br from-amber-500/10 to-transparent border border-amber-500/30 rounded-xl sm:rounded-2xl p-3 sm:p-5 shadow-sm">
                      <div className="flex items-center justify-between mb-2 sm:mb-3">
                        <span className="text-[#4A4A4A] text-[10px] sm:text-sm">Total Gold</span>
                        <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg sm:rounded-xl bg-amber-500/20 flex items-center justify-center">
                          <Vault className="w-4 h-4 sm:w-5 sm:h-5 text-amber-600" />
                        </div>
                      </div>
                      <p className="text-xl sm:text-3xl font-bold text-[#0D0D0D]">1,500.00 <span className="text-sm sm:text-lg text-[#4A4A4A]">g</span></p>
                      <p className="text-[#4A4A4A] text-[10px] sm:text-sm mt-1">48.23 oz</p>
                    </div>
                    
                    <div className="bg-white border border-[#8A2BE2]/20 rounded-xl sm:rounded-2xl p-3 sm:p-5 shadow-sm">
                      <div className="flex items-center justify-between mb-2 sm:mb-3">
                        <span className="text-[#4A4A4A] text-[10px] sm:text-sm">Locked Gold</span>
                        <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg sm:rounded-xl bg-amber-500/20 flex items-center justify-center">
                          <TrendingUp className="w-4 h-4 sm:w-5 sm:h-5 text-amber-400" />
                        </div>
                      </div>
                      <p className="text-xl sm:text-3xl font-bold text-[#0D0D0D]">500.00 <span className="text-sm sm:text-lg text-[#4A4A4A]">g</span></p>
                      <p className="text-[#4A4A4A] text-[10px] sm:text-sm mt-1">In BNSL</p>
                    </div>
                    
                    <div className="bg-white border border-[#8A2BE2]/20 rounded-xl sm:rounded-2xl p-3 sm:p-5 shadow-sm">
                      <div className="flex items-center justify-between mb-2 sm:mb-3">
                        <span className="text-[#4A4A4A] text-[10px] sm:text-sm">Value (USD)</span>
                        <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg sm:rounded-xl bg-green-500/20 flex items-center justify-center">
                          <Wallet className="w-4 h-4 sm:w-5 sm:h-5 text-green-400" />
                        </div>
                      </div>
                      <p className="text-xl sm:text-3xl font-bold text-amber-600">$127,830</p>
                      <p className="text-[#4A4A4A] text-[10px] sm:text-sm mt-1">@ $85.22/g</p>
                    </div>
                    
                    <div className="bg-white border border-[#8A2BE2]/20 rounded-xl sm:rounded-2xl p-3 sm:p-5 shadow-sm">
                      <div className="flex items-center justify-between mb-2 sm:mb-3">
                        <span className="text-[#4A4A4A] text-[10px] sm:text-sm">Value (AED)</span>
                        <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg sm:rounded-xl bg-blue-500/20 flex items-center justify-center">
                          <Wallet className="w-4 h-4 sm:w-5 sm:h-5 text-blue-400" />
                        </div>
                      </div>
                      <p className="text-xl sm:text-3xl font-bold text-[#0D0D0D]">د.إ469K</p>
                      <p className="text-[#4A4A4A] text-[10px] sm:text-sm mt-1">@ د.إ312.76/g</p>
                    </div>
                  </div>

                  {/* Deposit List */}
                  <div className="bg-white border border-[#8A2BE2]/20 rounded-xl sm:rounded-2xl p-3 sm:p-6 shadow-sm">
                    <DepositRequestList 
                      deposits={deposits}
                      onNewDeposit={handleNewDeposit}
                      onViewDetails={handleViewDetails}
                    />
                  </div>
                </motion.div>
              )}

              {view === 'new' && (
                <motion.div
                  key="new"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="max-w-3xl mx-auto bg-white border border-[#8A2BE2]/20 rounded-xl sm:rounded-2xl p-3 sm:p-6 shadow-sm"
                >
                  <NewDepositForm 
                    kycApproved={kycApproved}
                    onSubmit={handleSubmitDeposit}
                    onSaveDraft={() => {}}
                    onGoToKYC={() => navigate(createPageUrl("KYC"))}
                    onBack={handleBack}
                  />
                </motion.div>
              )}

              {view === 'details' && selectedDeposit && (
                <motion.div
                  key="details"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="max-w-4xl mx-auto bg-white border border-[#8A2BE2]/20 rounded-xl sm:rounded-2xl p-3 sm:p-6 shadow-sm"
                >
                  <DepositRequestDetails 
                    deposit={selectedDeposit}
                    onBack={handleBack}
                    onCancel={(id) => {
                      setDeposits(deposits.filter(d => d.id !== id));
                      handleBack();
                    }}
                  />
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </main>
      </div>
    </div>
  );
}