import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Camera, CheckCircle, ArrowRight, ArrowLeft, Shield, Loader2, 
  FileText, Upload, X, AlertCircle, RefreshCw, Eye, Lock
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const kycSteps = [
  { id: 1, title: 'Email Verified', completed: true },
  { id: 2, title: 'Selfie Capture', icon: Camera },
  { id: 3, title: 'ID Document', icon: FileText }
];

const idTypes = [
  { value: 'passport', label: 'Passport', requiresBack: false },
  { value: 'national_id', label: 'National ID Card', requiresBack: true },
  { value: 'residence_permit', label: 'Residence Permit', requiresBack: true }
];

export default function SelfieKYC() {
  const navigate = useNavigate();
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  
  const [currentStep, setCurrentStep] = useState(2);
  const [isLoading, setIsLoading] = useState(false);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [cameraStream, setCameraStream] = useState(null);
  const [scanProgress, setScanProgress] = useState(0);
  const [scanPhase, setScanPhase] = useState(''); // 'detecting', 'analyzing', 'complete'
  
  const [selfieCapture, setSelfieCapture] = useState(null);
  const [idType, setIdType] = useState('');
  const [idFront, setIdFront] = useState(null);
  const [idFrontPreview, setIdFrontPreview] = useState(null);
  const [idBack, setIdBack] = useState(null);
  const [idBackPreview, setIdBackPreview] = useState(null);
  
  const [error, setError] = useState('');
  const [userEmail, setUserEmail] = useState('');

  useEffect(() => {
    // Get email from localStorage or URL params
    const storedUser = localStorage.getItem('finatrades_pending_email');
    if (storedUser) {
      setUserEmail(storedUser);
    }
    
    return () => {
      // Cleanup camera on unmount
      if (cameraStream) {
        cameraStream.getTracks().forEach(track => track.stop());
      }
    };
  }, [cameraStream]);

  const startCamera = async () => {
    setError('');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          facingMode: 'user',
          width: { ideal: 640 },
          height: { ideal: 480 }
        } 
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setCameraStream(stream);
        setIsCameraActive(true);
      }
    } catch (err) {
      setError('Camera access denied. Please allow camera access to continue.');
    }
  };

  const startScan = () => {
    setScanProgress(0);
    setScanPhase('detecting');
    
    // Simulate face detection phases
    const phases = [
      { phase: 'detecting', duration: 1500, progress: 30 },
      { phase: 'analyzing', duration: 1500, progress: 70 },
      { phase: 'complete', duration: 1000, progress: 100 }
    ];
    
    let delay = 0;
    phases.forEach(({ phase, duration, progress }) => {
      setTimeout(() => {
        setScanPhase(phase);
        setScanProgress(progress);
        
        if (phase === 'complete') {
          captureSelfie();
        }
      }, delay);
      delay += duration;
    });
  };

  const captureSelfie = () => {
    if (videoRef.current && canvasRef.current) {
      const canvas = canvasRef.current;
      const video = videoRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      canvas.getContext('2d').drawImage(video, 0, 0);
      
      canvas.toBlob((blob) => {
        const file = new File([blob], 'selfie.jpg', { type: 'image/jpeg' });
        setSelfieCapture({
          file,
          preview: canvas.toDataURL('image/jpeg')
        });
        
        // Stop camera
        if (cameraStream) {
          cameraStream.getTracks().forEach(track => track.stop());
        }
        setIsCameraActive(false);
        setCameraStream(null);
      }, 'image/jpeg', 0.9);
    }
  };

  const retakeSelfie = () => {
    setSelfieCapture(null);
    setScanProgress(0);
    setScanPhase('');
    startCamera();
  };

  const handleIdUpload = (side, e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.size > 10 * 1024 * 1024) {
        setError('File size must be less than 10MB');
        return;
      }
      
      const reader = new FileReader();
      reader.onloadend = () => {
        if (side === 'front') {
          setIdFront(file);
          setIdFrontPreview(reader.result);
        } else {
          setIdBack(file);
          setIdBackPreview(reader.result);
        }
      };
      reader.readAsDataURL(file);
      setError('');
    }
  };

  const handleSubmit = async () => {
    setIsLoading(true);
    setError('');
    
    try {
      // Upload all files
      const uploads = {};
      
      if (selfieCapture?.file) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file: selfieCapture.file });
        uploads.selfie_url = file_url;
        uploads.face_scan_url = file_url;
      }
      
      if (idFront) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file: idFront });
        uploads.id_front_url = file_url;
      }
      
      if (idBack) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file: idBack });
        uploads.id_back_url = file_url;
      }

      // Find user profile and update
      const email = userEmail || localStorage.getItem('finatrades_pending_email');
      if (email) {
        const profiles = await base44.entities.UserProfile.filter({ email });
        if (profiles.length > 0) {
          await base44.entities.UserProfile.update(profiles[0].id, {
            ...uploads,
            id_type: idType,
            kyc_status: 'pending_review',
            kyc_submitted_at: new Date().toISOString(),
            registration_status: 'pending_review'
          });
        }
      }

      // Navigate to pending page
      navigate(createPageUrl("KYCPending"));
      
    } catch (err) {
      setError(err.message || 'Submission failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const selectedIdType = idTypes.find(t => t.value === idType);
  const canProceedToStep3 = selfieCapture !== null;
  const canSubmit = selfieCapture && idType && idFront && (!selectedIdType?.requiresBack || idBack);

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#000000] via-[#0D0717] to-[#1a0a2e] flex items-center justify-center p-4 py-8">
      {/* Background effects */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#8A2BE2]/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-[#FF2FBF]/10 rounded-full blur-3xl" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative w-full max-w-2xl"
      >
        {/* Logo */}
        <Link to={createPageUrl("Home")} className="flex flex-col items-center mb-6">
          <img 
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69293bd8e52dce0074daa668/ce96e4d2b_FINANEWLOGO-GOLDANDWHITENB.png" 
            alt="Finatrades" 
            className="h-10"
            style={{ filter: 'brightness(0) invert(1)' }}
          />
          <span className="text-white/50 text-xs mt-2 font-mono">kyc.finatrades.com</span>
        </Link>

        {/* Progress Steps */}
        <div className="flex items-center justify-center mb-8">
          {kycSteps.map((step, index) => (
            <React.Fragment key={step.id}>
              <div className="flex flex-col items-center">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                  step.completed || currentStep > step.id
                    ? 'bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white'
                    : currentStep === step.id
                      ? 'bg-[#8A2BE2]/20 border-2 border-[#8A2BE2] text-[#8A2BE2]'
                      : 'bg-white/10 text-white/40'
                }`}>
                  {step.completed || currentStep > step.id ? (
                    <CheckCircle className="w-5 h-5" />
                  ) : step.icon ? (
                    <step.icon className="w-5 h-5" />
                  ) : (
                    <span className="text-sm font-bold">{step.id}</span>
                  )}
                </div>
                <span className={`text-xs mt-2 whitespace-nowrap ${
                  currentStep >= step.id ? 'text-[#FF2FBF]' : 'text-white/40'
                }`}>
                  {step.title}
                </span>
              </div>
              {index < kycSteps.length - 1 && (
                <div className={`w-16 h-0.5 mx-2 transition-all ${
                  currentStep > step.id ? 'bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF]' : 'bg-white/20'
                }`} />
              )}
            </React.Fragment>
          ))}
        </div>

        {/* Main Card */}
        <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl p-6 md:p-8">
          <AnimatePresence mode="wait">
            {/* Step 2: Selfie Capture */}
            {currentStep === 2 && (
              <motion.div
                key="step2"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="text-center mb-6">
                  <h2 className="text-2xl font-bold text-white mb-2">Verify Your Identity</h2>
                  <p className="text-white/70">We require a real-time selfie for security & compliance</p>
                </div>

                {/* Selfie Area */}
                <div className="flex flex-col items-center">
                  {selfieCapture ? (
                    // Captured selfie preview
                    <div className="relative">
                      <div className="w-64 h-64 rounded-full overflow-hidden border-4 border-[#8A2BE2] shadow-[0_0_30px_rgba(138,43,226,0.4)]">
                        <img src={selfieCapture.preview} alt="Selfie" className="w-full h-full object-cover" />
                      </div>
                      <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-2 px-4 py-2 bg-green-500 rounded-full">
                        <CheckCircle className="w-4 h-4 text-white" />
                        <span className="text-white text-sm font-medium">Captured</span>
                      </div>
                    </div>
                  ) : isCameraActive ? (
                    // Live camera feed
                    <div className="relative">
                      <div className="w-64 h-64 rounded-full overflow-hidden border-4 border-[#8A2BE2] relative">
                        <video
                          ref={videoRef}
                          autoPlay
                          playsInline
                          muted
                          className="w-full h-full object-cover"
                        />
                        <canvas ref={canvasRef} className="hidden" />
                        
                        {/* Face guide overlay */}
                        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                          <div className="w-48 h-56 border-2 border-dashed border-white/50 rounded-[50%]" />
                        </div>
                        
                        {/* Scan progress overlay */}
                        {scanProgress > 0 && (
                          <div className="absolute inset-0 flex items-center justify-center">
                            <svg className="w-full h-full absolute" viewBox="0 0 100 100">
                              <circle
                                cx="50"
                                cy="50"
                                r="48"
                                fill="none"
                                stroke="url(#scanGradient)"
                                strokeWidth="3"
                                strokeDasharray={`${scanProgress * 3} 300`}
                                transform="rotate(-90 50 50)"
                                className="drop-shadow-[0_0_10px_rgba(138,43,226,0.8)]"
                              />
                              <defs>
                                <linearGradient id="scanGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                                  <stop offset="0%" stopColor="#8A2BE2" />
                                  <stop offset="100%" stopColor="#FF2FBF" />
                                </linearGradient>
                              </defs>
                            </svg>
                          </div>
                        )}
                      </div>
                      
                      {/* Scan status */}
                      {scanPhase && (
                        <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 whitespace-nowrap">
                          <span className="text-[#FF2FBF] text-sm font-medium">
                            {scanPhase === 'detecting' && '🔍 Detecting face...'}
                            {scanPhase === 'analyzing' && '✨ Analyzing...'}
                            {scanPhase === 'complete' && '✓ Complete!'}
                          </span>
                        </div>
                      )}
                    </div>
                  ) : (
                    // Camera not started
                    <div className="w-64 h-64 rounded-full border-4 border-dashed border-white/30 flex flex-col items-center justify-center bg-white/5">
                      <Camera className="w-16 h-16 text-white/40 mb-4" />
                      <p className="text-white/60 text-sm text-center px-8">
                        Position your face in the center
                      </p>
                    </div>
                  )}
                </div>

                {/* Instructions */}
                {!selfieCapture && (
                  <div className="grid grid-cols-3 gap-3 mt-8">
                    {[
                      { icon: Eye, text: 'Face clearly visible' },
                      { icon: Shield, text: 'Remove sunglasses' },
                      { icon: Camera, text: 'Good lighting' }
                    ].map((hint, i) => (
                      <div key={i} className="flex flex-col items-center text-center p-3 bg-white/5 rounded-xl">
                        <hint.icon className="w-5 h-5 text-[#8A2BE2] mb-2" />
                        <span className="text-white/70 text-xs">{hint.text}</span>
                      </div>
                    ))}
                  </div>
                )}

                {/* Action Buttons */}
                <div className="flex flex-col gap-3 mt-6">
                  {selfieCapture ? (
                    <>
                      <Button
                        onClick={() => setCurrentStep(3)}
                        className="w-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white font-bold py-6 rounded-xl"
                      >
                        Use This Photo
                        <ArrowRight className="w-5 h-5 ml-2" />
                      </Button>
                      <Button
                        variant="ghost"
                        onClick={retakeSelfie}
                        className="text-white/70 hover:text-white"
                      >
                        <RefreshCw className="w-4 h-4 mr-2" />
                        Retake
                      </Button>
                    </>
                  ) : isCameraActive ? (
                    <Button
                      onClick={startScan}
                      disabled={scanProgress > 0}
                      className="w-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white font-bold py-6 rounded-xl"
                    >
                      {scanProgress > 0 ? (
                        <>
                          <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                          Scanning...
                        </>
                      ) : (
                        <>
                          <Camera className="w-5 h-5 mr-2" />
                          Capture Selfie
                        </>
                      )}
                    </Button>
                  ) : (
                    <Button
                      onClick={startCamera}
                      className="w-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white font-bold py-6 rounded-xl"
                    >
                      <Camera className="w-5 h-5 mr-2" />
                      Start Camera
                    </Button>
                  )}
                </div>

                {/* Security Notice */}
                <div className="flex items-center justify-center gap-2 mt-4 text-white/50">
                  <Lock className="w-4 h-4" />
                  <span className="text-xs">Your data is encrypted & never shared without consent</span>
                </div>
              </motion.div>
            )}

            {/* Step 3: ID Document */}
            {currentStep === 3 && (
              <motion.div
                key="step3"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="text-center mb-6">
                  <h2 className="text-2xl font-bold text-white mb-2">Upload Your ID</h2>
                  <p className="text-white/70">Select and upload your identity document</p>
                </div>

                {/* ID Type Selection */}
                <div>
                  <label className="text-[#FF2FBF] text-sm mb-3 block">Document Type</label>
                  <div className="grid grid-cols-3 gap-3">
                    {idTypes.map(type => (
                      <button
                        key={type.value}
                        onClick={() => setIdType(type.value)}
                        className={`p-4 rounded-xl border-2 flex flex-col items-center gap-2 transition-all ${
                          idType === type.value
                            ? 'border-[#8A2BE2] bg-[#8A2BE2]/20'
                            : 'border-white/20 bg-white/5 hover:border-white/40'
                        }`}
                      >
                        <FileText className={`w-6 h-6 ${idType === type.value ? 'text-[#FF2FBF]' : 'text-white/60'}`} />
                        <span className={`text-xs text-center ${idType === type.value ? 'text-[#FF2FBF]' : 'text-white/70'}`}>
                          {type.label}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Upload Areas */}
                {idType && (
                  <div className="grid md:grid-cols-2 gap-4">
                    {/* Front Side */}
                    <div>
                      <label className="text-white/80 text-sm mb-2 block">Front Side *</label>
                      {idFrontPreview ? (
                        <div className="relative">
                          <img src={idFrontPreview} alt="ID Front" className="w-full h-40 object-cover rounded-xl border border-[#8A2BE2]/50" />
                          <button
                            onClick={() => { setIdFront(null); setIdFrontPreview(null); }}
                            className="absolute top-2 right-2 w-8 h-8 bg-red-500 rounded-full flex items-center justify-center"
                          >
                            <X className="w-4 h-4 text-white" />
                          </button>
                        </div>
                      ) : (
                        <label className="flex flex-col items-center justify-center h-40 border-2 border-dashed border-white/30 rounded-xl cursor-pointer hover:border-[#8A2BE2]/50 transition-colors bg-white/5">
                          <Upload className="w-8 h-8 text-white/50 mb-2" />
                          <span className="text-white/60 text-sm">Click to upload</span>
                          <input type="file" accept="image/*" className="hidden" onChange={(e) => handleIdUpload('front', e)} />
                        </label>
                      )}
                    </div>

                    {/* Back Side (if required) */}
                    {selectedIdType?.requiresBack && (
                      <div>
                        <label className="text-white/80 text-sm mb-2 block">Back Side *</label>
                        {idBackPreview ? (
                          <div className="relative">
                            <img src={idBackPreview} alt="ID Back" className="w-full h-40 object-cover rounded-xl border border-[#8A2BE2]/50" />
                            <button
                              onClick={() => { setIdBack(null); setIdBackPreview(null); }}
                              className="absolute top-2 right-2 w-8 h-8 bg-red-500 rounded-full flex items-center justify-center"
                            >
                              <X className="w-4 h-4 text-white" />
                            </button>
                          </div>
                        ) : (
                          <label className="flex flex-col items-center justify-center h-40 border-2 border-dashed border-white/30 rounded-xl cursor-pointer hover:border-[#8A2BE2]/50 transition-colors bg-white/5">
                            <Upload className="w-8 h-8 text-white/50 mb-2" />
                            <span className="text-white/60 text-sm">Click to upload</span>
                            <input type="file" accept="image/*" className="hidden" onChange={(e) => handleIdUpload('back', e)} />
                          </label>
                        )}
                      </div>
                    )}
                  </div>
                )}

                {/* Checklist */}
                <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                  <p className="text-white/80 text-sm mb-3">Document Requirements:</p>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    {['Full document visible', 'No glare or shadows', 'Readable text', 'Not expired'].map((req, i) => (
                      <div key={i} className="flex items-center gap-2 text-white/60">
                        <CheckCircle className="w-3 h-3 text-green-400" />
                        {req}
                      </div>
                    ))}
                  </div>
                </div>

                {error && (
                  <div className="bg-red-500/20 border border-red-500/50 rounded-lg p-3">
                    <p className="text-red-300 text-sm text-center">{error}</p>
                  </div>
                )}

                {/* Actions */}
                <div className="flex gap-4">
                  <Button
                    variant="outline"
                    onClick={() => setCurrentStep(2)}
                    className="flex-1 border-white/20 text-white hover:bg-white/10"
                  >
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Back
                  </Button>
                  <Button
                    onClick={handleSubmit}
                    disabled={isLoading || !canSubmit}
                    className="flex-1 bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white font-bold"
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Submitting...
                      </>
                    ) : (
                      <>
                        Submit for Verification
                        <CheckCircle className="w-4 h-4 ml-2" />
                      </>
                    )}
                  </Button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
}