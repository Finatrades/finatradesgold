
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Menu, X, ChevronRight, User, Building2 } from 'lucide-react';
import { AccountTypeProvider, useAccountType } from '@/components/AccountTypeContext';
import { LanguageProvider, useLanguage } from '@/components/LanguageContext';
import LanguageSwitcher from '@/components/LanguageSwitcher';
import FloatingAgentChat from '@/components/FloatingAgentChat';

const getNavLinks = (accountType, t) => accountType === 'business' ? [
  { name: t('nav.home'), page: "Home" },
  { name: t('nav.finavault'), page: "FinaVault" },
  { name: t('nav.finapay'), page: "FinaPay" },
  { name: t('nav.finabridge'), page: "FinaBridge" },
  { name: t('nav.bnsl'), page: "BNSL" }
] : [
  { name: t('nav.home'), page: "Home" },
  { name: t('nav.finavault'), page: "FinaVault" },
  { name: t('nav.finapay'), page: "FinaPay" },
  { name: t('nav.bnsl'), page: "BNSL" }
];

const getFooterLinks = (accountType, t) => ({
  products: accountType === 'business' ? [
    { name: t('nav.finavault'), page: "FinaVault" },
    { name: t('nav.finapay'), page: "FinaPay" },
    { name: t('nav.finabridge'), page: "FinaBridge" },
    { name: t('nav.bnsl'), page: "BNSL" }
  ] : [
    { name: t('nav.finavault'), page: "FinaVault" },
    { name: t('nav.finapay'), page: "FinaPay" },
    { name: t('nav.bnsl'), page: "BNSL" }
  ]
});

export default function Layout({ children, currentPageName }) {
  return (
    <LanguageProvider>
      <AccountTypeProvider>
        <LayoutContent currentPageName={currentPageName}>
          {children}
        </LayoutContent>
      </AccountTypeProvider>
    </LanguageProvider>
  );
}

// Business-only pages that should redirect to Home when switching to Personal
const businessOnlyPages = ['FinaBridge'];

// Pages that should render without header/footer (authenticated user pages)
const authPagesWithoutLayout = [
  'UserDashboard', 'FinaVaultUser', 'FinaPayUser', 'FinaEarnUser', 
  'FinaFinanceUser', 'SettingsUser', 'YieldsUser', 'AdminDashboard',
  'KYC', 'SelfieKYC', 'KYCPending', 'Dashboard', 'DebitCardUser',
  'AdminKYC', 'AdminVault', 'AdminFinaPay', 'AdminFinaBridge',
  'AdminBNSL', 'AdminCards', 'AdminYields', 'AdminAuditLogs', 'AdminSettings',
  'AdminKYCModule', 'AdminVaultModule', 'AdminBNSLModule'
];

function LayoutContent({ children, currentPageName }) {
  const { accountType, setAccountType } = useAccountType();
  const { t } = useLanguage();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [navLinks, setNavLinks] = useState(getNavLinks(accountType, t));
  const [footerLinks, setFooterLinks] = useState(getFooterLinks(accountType, t));
  const navigate = useNavigate();

  // Update nav/footer when accountType or language changes
  useEffect(() => {
    setNavLinks(getNavLinks(accountType, t));
    setFooterLinks(getFooterLinks(accountType, t));
  }, [accountType, t]);

  useEffect(() => {
    if (currentPageName === 'Home') return;
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [currentPageName]);

  useEffect(() => {
    setMobileMenuOpen(false);
  }, [currentPageName]);

  // Handle account type change with redirect for business-only pages
  const handleAccountTypeChange = (newType) => {
    if (newType === 'personal' && businessOnlyPages.includes(currentPageName)) {
      navigate(createPageUrl('Home'));
    }
    setAccountType(newType);
  };

  // For Home page, render without layout wrapper (it has its own navigation)
  if (currentPageName === 'Home') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#FAFBFF] via-[#F4F6FC] to-[#FFFFFF] text-[#0D0D0D] pb-16 md:pb-0">
        <meta name="dmca-site-verification" content="bWJvRWNmNGhZWUs3MHVEbUdUbkxJQT090" />
                    <style>{`
                      @import url('https://fonts.googleapis.com/css2?family=Inter:wght@200;300;400;500;600&display=swap');

                      * {
                        font-family: 'Inter', sans-serif;
                      }
          
          ::-webkit-scrollbar {
            width: 8px;
          }
          ::-webkit-scrollbar-track {
            background: #F4F6FC;
          }
          ::-webkit-scrollbar-thumb {
            background: linear-gradient(180deg, #8A2BE2, #FF2FBF);
            border-radius: 4px;
          }
          ::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(180deg, #A342FF, #FF4CD6);
          }

          .scrollbar-hide::-webkit-scrollbar {
            display: none;
          }
          .scrollbar-hide {
            -ms-overflow-style: none;
            scrollbar-width: none;
          }
        `}</style>
        {children}
        <FloatingAgentChat />

        {/* Mobile Bottom Menu Bar */}
        <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-[#8A2BE2]/20 z-50 shadow-[0_-4px_20px_rgba(138,43,226,0.1)]">
          <div className="flex items-center justify-around py-2">
            {navLinks.map((link) => (
              <Link
                key={link.page}
                to={createPageUrl(link.page)}
                onClick={() => window.scrollTo(0, 0)}
                className={`flex flex-col items-center gap-1 px-3 py-2 rounded-lg transition-colors ${
                  currentPageName === link.page
                    ? 'text-[#8A2BE2]'
                    : 'text-[#4A4A4A]'
                }`}
              >
                <div className={`w-1.5 h-1.5 rounded-full ${
                  currentPageName === link.page ? 'bg-[#8A2BE2]' : 'bg-transparent'
                }`} />
                <span className="text-[10px] font-medium">{link.name}</span>
              </Link>
            ))}
          </div>
        </div>
        </div>
        );
        }

  // For authenticated user pages, render without header/footer
  if (authPagesWithoutLayout.includes(currentPageName)) {
    return (
      <div className="min-h-screen">
        <style>{`
          @import url('https://fonts.googleapis.com/css2?family=Inter:wght@200;300;400;500;600;700&display=swap');
          * { font-family: 'Inter', sans-serif; }
          ::-webkit-scrollbar { width: 8px; }
          ::-webkit-scrollbar-track { background: #0D001E; }
          ::-webkit-scrollbar-thumb { background: linear-gradient(180deg, #8A2BE2, #FF2FBF); border-radius: 4px; }
          ::-webkit-scrollbar-thumb:hover { background: linear-gradient(180deg, #A342FF, #FF2FBF); }
        `}</style>
        {children}
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FAFBFF] via-[#F4F6FC] to-[#FFFFFF] text-[#0D0D0D]">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@200;300;400;500;600&display=swap');
        
        * {
          font-family: 'Inter', sans-serif;
        }
        
        ::-webkit-scrollbar {
          width: 8px;
        }
        ::-webkit-scrollbar-track {
          background: #F4F6FC;
        }
        ::-webkit-scrollbar-thumb {
          background: linear-gradient(180deg, #8A2BE2, #FF2FBF);
          border-radius: 4px;
        }
        ::-webkit-scrollbar-thumb:hover {
          background: linear-gradient(180deg, #A342FF, #FF4CD6);
        }

        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}</style>

      {/* Header */}
      <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-gradient-to-r from-[#0D001E] via-[#2A0055] to-[#4B0082] shadow-[0_4px_20px_rgba(212,175,55,0.2)]' : 'bg-gradient-to-r from-[#0D001E] via-[#2A0055] to-[#4B0082]'
      }`}>
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <Link to={createPageUrl("Home")} onClick={() => window.scrollTo(0, 0)} className="flex items-center group">
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69293bd8e52dce0074daa668/ce96e4d2b_FINANEWLOGO-GOLDANDWHITENB.png" 
                alt="Finatrades" 
                className="h-10 group-hover:opacity-90 transition-opacity"
                style={{ filter: 'brightness(0) invert(1)' }}
              />
            </Link>

            {/* Desktop Nav */}
            <nav className="hidden lg:flex items-center gap-1">
              {navLinks.map((link) => (
                <Link
                  key={link.page}
                  to={createPageUrl(link.page)}
                  onClick={() => window.scrollTo(0, 0)}
                  className={`relative px-4 py-2 rounded-full text-sm transition-all duration-300 ${
                    currentPageName === link.page
                      ? 'text-white bg-white/20'
                      : 'text-white/80 hover:text-white hover:bg-white/10'
                  }`}
                >
                  {link.name}
                  {currentPageName === link.page && (
                    <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-8 h-0.5 bg-gradient-to-r from-[#D4AF37] to-[#FFD500] rounded-full shadow-[0_0_10px_rgba(212,175,55,0.5)]" />
                  )}
                </Link>
              ))}
            </nav>

            {/* Language Switcher + Account Type Switcher + CTA Button */}
            <div className="hidden lg:flex items-center gap-4">
              {/* Language Switcher */}
              <LanguageSwitcher variant="light" />

              {/* Account Type Segmented Toggle */}
              <div className="relative flex items-center p-1 rounded-full bg-white/20 border border-white/30 backdrop-blur-sm">
                <div 
                  className={`absolute top-1 bottom-1 rounded-full bg-white shadow-lg transition-all duration-300 ${
                    accountType === 'personal' ? 'left-1 w-[calc(50%-4px)]' : 'left-[50%] w-[calc(50%-4px)]'
                  }`}
                />
                <button
                  onClick={() => handleAccountTypeChange('personal')}
                  className={`relative z-10 flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-medium transition-colors ${
                    accountType === 'personal' ? 'text-[#4B0082]' : 'text-white/80 hover:text-white'
                  }`}
                >
                  <User className="w-3.5 h-3.5" />
                  {t('nav.personal')}
                </button>
                <button
                  onClick={() => handleAccountTypeChange('business')}
                  className={`relative z-10 flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-medium transition-colors ${
                    accountType === 'business' ? 'text-[#4B0082]' : 'text-white/80 hover:text-white'
                  }`}
                >
                  <Building2 className="w-3.5 h-3.5" />
                  {t('nav.business')}
                </button>
              </div>

              <a
                href="https://portal.finatrades.com/"
                className="px-5 py-2 rounded-full border border-white/40 text-white text-sm font-medium hover:bg-white/10 transition-all"
              >
                Sign In
              </a>

              <a
                href="https://portal.finatrades.com/register"
                className="px-5 py-2 rounded-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white text-sm font-bold hover:shadow-[0_0_30px_rgba(138,43,226,0.5)] transition-all"
              >
                Get Started
              </a>
              </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden w-10 h-10 rounded-lg border border-white/30 flex items-center justify-center text-white hover:bg-white/10 transition-colors"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden absolute top-20 left-0 right-0 bg-gradient-to-b from-[#1A002F] to-[#0D001E] backdrop-blur-lg border-b border-[#D4AF37]/30 shadow-[0_8px_32px_rgba(212,175,55,0.15)]">
            <nav className="max-w-7xl mx-auto px-6 py-6 space-y-2">
              {navLinks.map((link) => (
                <Link
                  key={link.page}
                  to={createPageUrl(link.page)}
                  onClick={() => window.scrollTo(0, 0)}
                  className={`flex items-center justify-between px-4 py-3 rounded-xl transition-all ${
                    currentPageName === link.page
                      ? 'text-[#D4AF37] bg-white/10'
                      : 'text-white/80 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {link.name}
                  <ChevronRight className="w-4 h-4" />
                </Link>
              ))}
              {/* Mobile Language Switcher */}
              <div className="pt-4 pb-2 px-4 flex justify-center">
                <LanguageSwitcher variant="light" />
              </div>

              {/* Mobile Account Type Segmented Toggle */}
              <div className="pb-2 px-4">
                <div className="relative flex items-center justify-center p-1 rounded-full bg-white/10 border border-white/20">
                  <div 
                    className={`absolute top-1 bottom-1 rounded-full bg-white shadow-lg transition-all duration-300 ${
                      accountType === 'personal' ? 'left-1 w-[calc(50%-4px)]' : 'left-[50%] w-[calc(50%-4px)]'
                    }`}
                  />
                  <button
                    onClick={() => handleAccountTypeChange('personal')}
                    className={`relative z-10 flex items-center justify-center gap-2 flex-1 py-2 rounded-full text-sm font-medium transition-colors ${
                      accountType === 'personal' ? 'text-[#4B0082]' : 'text-white/80'
                    }`}
                  >
                    <User className="w-4 h-4" />
                    {t('nav.personal')}
                  </button>
                  <button
                    onClick={() => handleAccountTypeChange('business')}
                    className={`relative z-10 flex items-center justify-center gap-2 flex-1 py-2 rounded-full text-sm font-medium transition-colors ${
                      accountType === 'business' ? 'text-[#4B0082]' : 'text-white/80'
                    }`}
                  >
                    <Building2 className="w-4 h-4" />
                    {t('nav.business')}
                  </button>
                </div>
              </div>

              <div className="pt-2 space-y-2">
                  <a
                    href="https://portal.finatrades.com/"
                    className="block w-full px-6 py-3 rounded-full border border-white/40 text-white text-center font-medium hover:bg-white/10 transition-all"
                  >
                    Sign In
                  </a>
                  <a
                    href="https://portal.finatrades.com/register"
                    className="block w-full px-6 py-3 rounded-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white text-center font-bold shadow-[0_0_20px_rgba(138,43,226,0.4)]"
                  >
                    Get Started
                  </a>
                </div>
            </nav>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="pt-20">
        {children}
      </main>

      {/* Floating Agent Chat */}
      <FloatingAgentChat />

      {/* Footer */}
      <footer className="bg-gradient-to-b from-[#1A002F] to-[#0D001E] border-t border-[#8A2BE2]/30">
        <div className="max-w-7xl mx-auto px-6 py-16">
          <div className="grid md:grid-cols-3 gap-12 mb-12">
            {/* Brand */}
            <div>
              <Link to={createPageUrl("Home")} onClick={() => window.scrollTo(0, 0)} className="flex items-center mb-6">
                  <img 
                    src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69293bd8e52dce0074daa668/ce96e4d2b_FINANEWLOGO-GOLDANDWHITENB.png" 
                    alt="Finatrades" 
                    className="h-10"
                    style={{ filter: 'brightness(0) invert(1)' }}
                  />
                </Link>
              <p className="text-white/70 mb-6 max-w-md">
                {t('footer.description')}
              </p>
            </div>

            {/* Products */}
            <div>
              <h4 className="text-white font-medium mb-4 tracking-wide">{t('footer.products')}</h4>
              <ul className="space-y-3">
                {footerLinks.products.map((link) => (
                  <li key={link.name}>
                    <Link
                      to={createPageUrl(link.page)}
                      onClick={() => window.scrollTo(0, 0)}
                      className="text-white/70 hover:text-[#FF2FBF] transition-colors text-sm"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Legal */}
            <div>
              <h4 className="text-white font-medium mb-4 tracking-wide">{t('footer.legal')}</h4>
              <ul className="space-y-3">
                <li>
                  <Link
                    to={createPageUrl("PrivacyPolicy")}
                    onClick={() => setTimeout(() => window.scrollTo(0, 0), 0)}
                    className="text-white/70 hover:text-[#FF2FBF] transition-colors text-sm"
                  >
                    {t('footer.privacyPolicy')}
                  </Link>
                </li>
                <li>
                  <Link
                    to={createPageUrl("TermsAndConditions")}
                    onClick={() => setTimeout(() => window.scrollTo(0, 0), 0)}
                    className="text-white/70 hover:text-[#FF2FBF] transition-colors text-sm"
                  >
                    {t('footer.termsConditions')}
                  </Link>
                </li>
                <li>
                  <Link
                    to={createPageUrl("Disclaimer")}
                    onClick={() => setTimeout(() => window.scrollTo(0, 0), 0)}
                    className="text-white/70 hover:text-[#FF2FBF] transition-colors text-sm"
                  >
                    {t('footer.disclaimer')}
                  </Link>
                </li>
              </ul>

              {/* App Store Buttons */}
              <div className="flex items-center gap-3 mt-6">
                {/* App Store Button */}
                <div className="relative group cursor-pointer">
                  <div className="flex items-center gap-2 px-3 py-2 bg-black border border-white/20 rounded-lg opacity-60 group-hover:opacity-80 transition-all">
                    <svg viewBox="0 0 24 24" className="w-5 h-5 text-white" fill="currentColor">
                      <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/>
                    </svg>
                    <div className="text-left">
                      <div className="text-[7px] text-white/70 leading-none">Download on the</div>
                      <div className="text-xs text-white font-semibold leading-tight">App Store</div>
                    </div>
                  </div>
                  <div className="absolute inset-0 flex items-center justify-center bg-black/70 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity">
                    <span className="text-[9px] text-white font-medium px-2 py-0.5 bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] rounded-full">Coming Soon</span>
                  </div>
                </div>

                {/* Google Play Button */}
                <div className="relative group cursor-pointer">
                  <div className="flex items-center gap-2 px-3 py-2 bg-black border border-white/20 rounded-lg opacity-60 group-hover:opacity-80 transition-all">
                    <svg viewBox="0 0 24 24" className="w-5 h-5" fill="none">
                      <path d="M3.609 1.814L13.792 12 3.61 22.186a.996.996 0 01-.61-.92V2.734a1 1 0 01.609-.92z" fill="#4285F4"/>
                      <path d="M17.558 8.236L14.51 5.19 3.609 1.814 13.792 12l3.766-3.764z" fill="#EA4335"/>
                      <path d="M3.609 22.186L13.792 12l3.766 3.764-3.047 3.046-10.902 3.376z" fill="#34A853"/>
                      <path d="M20.855 10.097l-3.297-1.861-3.766 3.764 3.766 3.764 3.297-1.861c.95-.536.95-1.87 0-2.406z" fill="#FBBC04"/>
                    </svg>
                    <div className="text-left">
                      <div className="text-[7px] text-white/70 leading-none">GET IT ON</div>
                      <div className="text-xs text-white font-semibold leading-tight">Google Play</div>
                    </div>
                  </div>
                  <div className="absolute inset-0 flex items-center justify-center bg-black/70 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity">
                    <span className="text-[9px] text-white font-medium px-2 py-0.5 bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] rounded-full">Coming Soon</span>
                  </div>
                </div>
              </div>
            </div>
            </div>

          {/* Bottom Bar */}
                      <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-4">
                        <p className="text-sm text-white/60">
                          {t('footer.copyright', { year: new Date().getFullYear() })}
                        </p>
                        <div className="flex items-center gap-6">
                          <Link to={createPageUrl("PrivacyPolicy")} onClick={() => setTimeout(() => window.scrollTo(0, 0), 0)} className="text-sm text-white/60 hover:text-[#FF2FBF] transition-colors">{t('footer.privacyPolicy')}</Link>
                          <Link to={createPageUrl("Disclaimer")} onClick={() => setTimeout(() => window.scrollTo(0, 0), 0)} className="text-sm text-white/60 hover:text-[#FF2FBF] transition-colors">{t('footer.disclaimer')}</Link>
                          <Link to={createPageUrl("TermsAndConditions")} onClick={() => setTimeout(() => window.scrollTo(0, 0), 0)} className="text-sm text-white/60 hover:text-[#FF2FBF] transition-colors">{t('footer.termsConditions')}</Link>
                        </div>
                      </div>
        </div>
      </footer>
    </div>
  );
}
