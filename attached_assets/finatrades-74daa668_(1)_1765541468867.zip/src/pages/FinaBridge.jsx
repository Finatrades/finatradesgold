import React from 'react';

// Import new FinaBridge Import & Export components
import FinaBridgeHero from '../components/finabridge/FinaBridgeHero';
import WhatIsFinaBridge from '../components/finabridge/WhatIsFinaBridge';
import WhyUsFinaBridge from '../components/finabridge/WhyUsFinaBridge';
import FinaBridgeTradeFlow from '../components/finabridge/FinaBridgeTradeFlow';
import GoldDocumentation from '../components/finabridge/GoldDocumentation';

import RiskCompliance from '../components/finabridge/RiskCompliance';
import FinaBridgeCTA from '../components/finabridge/FinaBridgeCTA';

export default function FinaBridge() {
  return (
    <main className="bg-gradient-to-br from-[#FAFBFF] via-[#F4F6FC] to-[#FFFFFF]">
      {/* Section 1: Hero */}
      <FinaBridgeHero />

      {/* Section 2: What is FinaBridge? */}
      <WhatIsFinaBridge />

      {/* Section 3: Why Importers & Exporters Use FinaBridge */}
      <WhyUsFinaBridge />

      {/* Section 4: How FinaBridge Works (Snake-style Trade Flow) */}
      <FinaBridgeTradeFlow />

      {/* Section 5: Documentation & Evidence */}
      <GoldDocumentation />



      {/* Section 7: Risk, Compliance & Positioning */}
      <RiskCompliance />

      {/* Section 8: Final CTA Banner */}
      <FinaBridgeCTA />
    </main>
  );
}