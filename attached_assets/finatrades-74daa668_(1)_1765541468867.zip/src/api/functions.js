import { base44 } from './base44Client';


export const getGoldPrice = base44.functions.getGoldPrice;

