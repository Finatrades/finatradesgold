import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Lock, Calendar, TrendingUp, Coins, ChevronRight, X, Calculator } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";

const features = [
  { icon: Lock, label: 'Locked Principal', desc: 'Your gold grams are locked at a fixed price' },
  { icon: Calendar, label: 'Quarterly Distribution', desc: 'Fixed monetary value credited every 3 months' },
  { icon: TrendingUp, label: 'Daily Accrual Meter', desc: 'Visual progress toward quarterly distribution' },
  { icon: Coins, label: 'Variable Grams', desc: 'Gold received varies with market price at payout' }
];

function CalculationDrawer({ plan }) {
  const principalValue = plan?.principalGold * plan?.lockedInPrice || 5500;
  const annualValue = principalValue * (plan?.rate || 12) / 100;
  const quarterlyValue = annualValue / 4;
  const dailyValue = quarterlyValue / 90;

  return (
    <div className="space-y-6 py-4">
      {/* Section A */}
      <div className="p-4 bg-white/5 rounded-xl border border-white/10">
        <h4 className="text-[#D1A954] font-medium mb-3">A. Quarterly Monetary Value</h4>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-white/60">Principal</span>
            <span className="text-white">{plan?.principalGold || 100} g × ${plan?.lockedInPrice || 55}/g = ${principalValue.toLocaleString()}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-white/60">Annual Rate</span>
            <span className="text-white">{plan?.rate || 12}% p.a. → ${annualValue.toFixed(2)}/year</span>
          </div>
          <div className="flex justify-between pt-2 border-t border-white/10">
            <span className="text-white/60">Quarterly Distribution</span>
            <span className="text-[#D1A954] font-bold">${quarterlyValue.toFixed(2)}/quarter</span>
          </div>
        </div>
      </div>

      {/* Section B */}
      <div className="p-4 bg-white/5 rounded-xl border border-white/10">
        <h4 className="text-[#D1A954] font-medium mb-3">B. Daily Value Allocation</h4>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-white/60">Quarter Length</span>
            <span className="text-white">90 days</span>
          </div>
          <div className="flex justify-between">
            <span className="text-white/60">Daily Allocation</span>
            <span className="text-white">${quarterlyValue.toFixed(2)} ÷ 90 = ${dailyValue.toFixed(4)}/day</span>
          </div>
        </div>
      </div>

      {/* Section C */}
      <div className="p-4 bg-white/5 rounded-xl border border-white/10">
        <h4 className="text-[#D1A954] font-medium mb-3">C. Convert to Gold (at payout)</h4>
        <div className="p-3 bg-amber-500/10 rounded-lg border border-amber-500/20 mb-3">
          <p className="text-amber-400 text-xs font-medium">Daily meter ≠ actual daily payout</p>
        </div>
        <p className="text-white/60 text-sm mb-3">
          ${quarterlyValue.toFixed(2)} is converted to gold at market price on distribution day:
        </p>
        <div className="grid grid-cols-2 gap-3">
          <div className="p-3 bg-green-500/10 rounded-lg border border-green-500/20">
            <p className="text-white/50 text-xs mb-1">If price = $50/g</p>
            <p className="text-green-400 font-bold">{(quarterlyValue / 50).toFixed(3)} g</p>
          </div>
          <div className="p-3 bg-red-500/10 rounded-lg border border-red-500/20">
            <p className="text-white/50 text-xs mb-1">If price = $60/g</p>
            <p className="text-red-400 font-bold">{(quarterlyValue / 60).toFixed(3)} g</p>
          </div>
        </div>
      </div>

      {/* Conclusion */}
      <div className="p-4 bg-[#D1A954]/10 rounded-xl border border-[#D1A954]/30">
        <p className="text-white/80 text-sm leading-relaxed">
          <strong className="text-[#D1A954]">Conclusion:</strong> The daily meter is a visualization of monetary allocation progress, 
          not an actual daily payout. Your gold distribution is calculated and credited once per quarter.
        </p>
      </div>
    </div>
  );
}

export default function HowAccrualWorksCard({ selectedPlan }) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.4 }}
      className="bg-white border-2 border-[#8A2BE2]/30 rounded-2xl p-6 h-full shadow-lg"
    >
      <h3 className="text-lg font-semibold text-[#0D0D0D] mb-4">How Daily Accrual Works</h3>
      
      <div className="space-y-3 mb-6">
        <p className="text-[#4A4A4A] text-sm leading-relaxed">
          Quarterly distribution is a <strong className="text-[#0D0D0D]">fixed monetary value</strong> (e.g. 10%/11%/12% p.a. of your principal).
        </p>
        <p className="text-[#4A4A4A] text-sm leading-relaxed">
          The system shows a daily progression of that monetary value converted to grams across the quarter, <strong className="text-amber-600">for visual tracking only</strong>.
        </p>
        <p className="text-[#4A4A4A] text-sm leading-relaxed">
          Actual gold is only credited every 3 months at the market price on distribution day.
        </p>
      </div>

      {/* Feature Icons */}
      <div className="grid grid-cols-2 gap-3 mb-6">
        {features.map((feature, i) => (
          <div key={i} className="flex items-start gap-3 p-3 bg-gradient-to-r from-[#F4F6FC] to-white rounded-xl border border-[#8A2BE2]/10">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-r from-amber-500 to-yellow-600 flex items-center justify-center flex-shrink-0 shadow-md">
              <feature.icon className="w-4 h-4 text-white" />
            </div>
            <div>
              <p className="text-[#0D0D0D] text-xs font-medium">{feature.label}</p>
              <p className="text-[#4A4A4A] text-[10px] leading-tight">{feature.desc}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Variable grams explanation */}
      <div className="p-3 bg-gradient-to-r from-amber-50 to-yellow-50 rounded-xl border border-amber-200 mb-4">
        <p className="text-[#4A4A4A] text-xs">
          <span className="text-green-600 font-semibold">↓ Low prices</span> = more grams received
          <br />
          <span className="text-amber-600 font-semibold">↑ High prices</span> = fewer grams received
        </p>
      </div>

      <Sheet open={isOpen} onOpenChange={setIsOpen}>
        <SheetTrigger asChild>
          <Button className="w-full bg-gradient-to-r from-amber-500 to-yellow-600 text-white hover:from-amber-600 hover:to-yellow-700 shadow-md">
            <Calculator className="w-4 h-4 mr-2" />
            View Calculation
          </Button>
        </SheetTrigger>
        <SheetContent className="bg-gradient-to-br from-[#0D0515] to-[#1a0a2e] border-l border-[#D1A954]/20 w-full sm:max-w-lg">
          <SheetHeader>
            <SheetTitle className="text-white flex items-center gap-2">
              <Calculator className="w-5 h-5 text-[#D1A954]" />
              Daily Accrual Calculation
            </SheetTitle>
          </SheetHeader>
          <CalculationDrawer plan={selectedPlan} />
        </SheetContent>
      </Sheet>
    </motion.div>
  );
}