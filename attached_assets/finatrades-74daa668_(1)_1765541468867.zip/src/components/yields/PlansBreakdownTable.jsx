import React from 'react';
import { motion } from 'framer-motion';
import { ChevronRight, TrendingUp } from 'lucide-react';
import { AreaChart, Area, ResponsiveContainer } from 'recharts';

function MiniChart({ data }) {
  return (
    <div className="w-20 h-8">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data}>
          <defs>
            <linearGradient id="miniGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#D1A954" stopOpacity={0.5} />
              <stop offset="100%" stopColor="#D1A954" stopOpacity={0} />
            </linearGradient>
          </defs>
          <Area 
            type="monotone" 
            dataKey="value" 
            stroke="#D1A954" 
            strokeWidth={1.5}
            fill="url(#miniGradient)" 
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

export default function PlansBreakdownTable({ plans, onViewPlan }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
      className="bg-white/[0.03] backdrop-blur-xl border border-[#D1A954]/20 rounded-xl sm:rounded-2xl overflow-hidden"
    >
      <div className="p-3 sm:p-6 border-b border-[#8A2BE2]/10">
        <h3 className="text-sm sm:text-lg font-semibold text-[#0D0D0D]">Active Plans Breakdown</h3>
        <p className="text-[#4A4A4A] text-[10px] sm:text-sm mt-1">Daily accrual details per BNSL plan</p>
      </div>

      {/* Desktop Table */}
      <div className="overflow-x-auto hidden sm:block">
        <table className="w-full">
          <thead>
            <tr className="text-left text-[#4A4A4A] text-xs uppercase tracking-wider bg-[#F4F6FC]">
              <th className="px-6 py-4">Plan ID</th>
              <th className="px-6 py-4">Tenure</th>
              <th className="px-6 py-4">Principal (g)</th>
              <th className="px-6 py-4">Locked Price</th>
              <th className="px-6 py-4">Quarterly Value</th>
              <th className="px-6 py-4">Daily Accrual</th>
              <th className="px-6 py-4">QTD Accumulated</th>
              <th className="px-6 py-4">Progress</th>
              <th className="px-6 py-4">Next Dist.</th>
              <th className="px-6 py-4"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#8A2BE2]/10">
            {plans.map((plan, i) => (
              <motion.tr
                key={plan.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.1 + i * 0.05 }}
                className="hover:bg-white/5 transition-colors group"
              >
                <td className="px-6 py-4">
                  <span className="text-amber-600 font-mono font-medium">{plan.id}</span>
                </td>
                <td className="px-6 py-4">
                  <span className="px-2 py-1 rounded-lg bg-[#F4F6FC] text-[#0D0D0D] text-sm">{plan.tenure}M</span>
                </td>
                <td className="px-6 py-4 text-[#0D0D0D] font-medium">{plan.principalGold.toFixed(3)} g</td>
                <td className="px-6 py-4 text-[#4A4A4A]">${plan.lockedInPrice.toFixed(2)}/g</td>
                <td className="px-6 py-4 text-amber-600 font-medium">${plan.quarterlyValue.toFixed(2)}</td>
                <td className="px-6 py-4">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="w-3 h-3 text-green-400" />
                    <span className="text-green-400 font-medium">{plan.dailyAccrual.toFixed(4)} g</span>
                  </div>
                </td>
                <td className="px-6 py-4 text-white font-medium">{plan.qtdAccumulated.toFixed(4)} g</td>
                <td className="px-6 py-4">
                  <MiniChart data={plan.progressData} />
                </td>
                <td className="px-6 py-4 text-white/60 text-sm">{plan.nextDistribution}</td>
                <td className="px-6 py-4">
                  <button
                    onClick={() => onViewPlan(plan)}
                    className="opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1 text-[#D1A954] text-sm font-medium"
                  >
                    View <ChevronRight className="w-4 h-4" />
                  </button>
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Mobile Cards */}
      <div className="sm:hidden space-y-2 p-3">
        {plans.map((plan, i) => (
          <motion.div
            key={plan.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 + i * 0.05 }}
            className="bg-white/5 rounded-xl p-3 cursor-pointer active:bg-white/10"
            onClick={() => onViewPlan(plan)}
          >
            <div className="flex items-start justify-between mb-2">
              <span className="text-amber-600 font-mono text-xs">{plan.id}</span>
              <span className="px-2 py-0.5 rounded-lg bg-white text-[#0D0D0D] text-[10px]">{plan.tenure}M</span>
            </div>
            <div className="grid grid-cols-3 gap-2 text-xs mb-2">
              <div>
                <p className="text-[#4A4A4A] text-[10px]">Principal</p>
                <p className="text-[#0D0D0D] font-medium">{plan.principalGold.toFixed(3)} g</p>
              </div>
              <div>
                <p className="text-[#4A4A4A] text-[10px]">Quarterly</p>
                <p className="text-amber-600 font-medium">${plan.quarterlyValue.toFixed(2)}</p>
              </div>
              <div>
                <p className="text-[#4A4A4A] text-[10px]">Daily</p>
                <p className="text-green-600 font-medium">{plan.dailyAccrual.toFixed(4)} g</p>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[#4A4A4A] text-[10px]">QTD: {plan.qtdAccumulated.toFixed(4)} g</span>
              <span className="text-[#4A4A4A] text-[10px]">Next: {plan.nextDistribution}</span>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}