import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, ReferenceDot } from 'recharts';
import { Info } from 'lucide-react';

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-[#0a0a1a]/95 backdrop-blur-xl border border-[#D1A954]/30 rounded-xl p-4 shadow-2xl">
        <p className="text-[#D1A954] font-medium mb-2">Day {label}</p>
        <div className="space-y-1">
          <p className="text-white text-sm">
            Accrued so far: <span className="text-[#D1A954] font-bold">{payload[0].value.toFixed(4)} g</span>
          </p>
          <p className="text-white/60 text-xs">
            Daily accrual: {(payload[0].payload.dailyRate || 0).toFixed(4)} g
          </p>
        </div>
      </div>
    );
  }
  return null;
};

export default function DailyAccrualChart({ data, currentDay, quarterlyTotal }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 }}
      className="relative overflow-hidden bg-white/[0.03] backdrop-blur-xl border border-[#D1A954]/20 rounded-2xl p-6"
    >
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-amber-500/5 via-transparent to-transparent pointer-events-none" />

      <div className="relative">
        {/* Header */}
        <div className="flex items-start justify-between mb-6">
          <div>
            <h3 className="text-lg font-semibold text-[#0D0D0D] mb-1">Daily Accrual Progression</h3>
            <p className="text-[#4A4A4A] text-sm">
              Quarterly distribution: <span className="text-amber-600">{quarterlyTotal.toFixed(4)} g</span> over 90 days
            </p>
          </div>
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-amber-500/10 border border-amber-500/20">
            <div className="w-2 h-2 rounded-full bg-amber-600 animate-pulse" />
            <span className="text-amber-600 text-xs font-medium">Day {currentDay}/90</span>
          </div>
        </div>

        {/* Chart */}
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="accrualGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#D1A954" stopOpacity={0.4} />
                  <stop offset="50%" stopColor="#D1A954" stopOpacity={0.1} />
                  <stop offset="100%" stopColor="#D1A954" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="lineGradient" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#D1A954" />
                  <stop offset="100%" stopColor="#B8963E" />
                </linearGradient>
              </defs>
              <XAxis 
                dataKey="day" 
                stroke="#ffffff20" 
                tick={{ fill: '#ffffff40', fontSize: 11 }}
                tickLine={false}
                axisLine={false}
                tickFormatter={(value) => value % 15 === 0 ? `Day ${value}` : ''}
              />
              <YAxis 
                stroke="#ffffff20" 
                tick={{ fill: '#ffffff40', fontSize: 11 }}
                tickLine={false}
                axisLine={false}
                tickFormatter={(value) => `${value.toFixed(2)}g`}
                width={50}
              />
              <Tooltip content={<CustomTooltip />} />
              <Area 
                type="monotone" 
                dataKey="accumulated" 
                stroke="url(#lineGradient)" 
                strokeWidth={2}
                fill="url(#accrualGradient)" 
              />
              {/* Current day marker */}
              <ReferenceDot 
                x={currentDay} 
                y={data.find(d => d.day === currentDay)?.accumulated || 0}
                r={6}
                fill="#D1A954"
                stroke="#000"
                strokeWidth={2}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Footer note */}
        <div className="mt-4 flex items-start gap-2 p-3 bg-[#F4F6FC] rounded-xl">
          <Info className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
          <p className="text-[#4A4A4A] text-xs leading-relaxed">
            This line represents the daily fraction of your fixed quarterly monetary distribution, converted to estimated grams for visual tracking. 
            Actual gold is credited once every quarter at the prevailing market price.
          </p>
        </div>
      </div>
    </motion.div>
  );
}