import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { AlertTriangle, FileText } from 'lucide-react';
import { Button } from "@/components/ui/button";

export default function YieldsDisclaimer() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.5 }}
      className="bg-gradient-to-br from-orange-50 to-amber-50 backdrop-blur-xl border border-orange-200 rounded-2xl p-5"
    >
      <div className="flex items-start gap-4">
        <div className="w-10 h-10 rounded-xl bg-amber-500/20 flex items-center justify-center flex-shrink-0">
          <AlertTriangle className="w-5 h-5 text-amber-600" />
        </div>
        <div className="flex-1">
          <h4 className="text-amber-600 font-semibold mb-2">Important Disclaimer</h4>
          <p className="text-[#4A4A4A] text-xs leading-relaxed mb-4">
            BNSL is a structured physical gold plan with quarterly distributions. 
            The daily accrual shown here reflects estimated accumulation of the predetermined quarterly monetary distribution, for tracking purposes only. 
            <strong className="text-[#0D0D0D]"> No daily gold is credited.</strong> 
            This is not interest, not a savings account, not a deposit, and carries early termination penalties.
          </p>
          <Link to={createPageUrl("TermsAndConditions")}>
            <Button variant="outline" size="sm" className="border-amber-500/40 text-amber-600 hover:bg-amber-500/10">
              <FileText className="w-4 h-4 mr-2" />
              View Full Terms & Conditions
            </Button>
          </Link>
        </div>
      </div>
    </motion.div>
  );
}