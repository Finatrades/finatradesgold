import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, Calendar, Percent, Clock } from 'lucide-react';

export default function YieldsSummaryCards({ dailyAccrual, quarterToDate, nextDistribution, avgPlanRate }) {
  const cards = [
    {
      label: 'Daily Accrual',
      value: `${dailyAccrual.toFixed(4)} g`,
      subtext: 'Estimated daily accrual toward quarterly distribution',
      icon: TrendingUp,
      color: 'from-[#8A2BE2] to-[#FF2FBF]'
    },
    {
      label: 'Quarter-to-Date',
      value: `${quarterToDate.toFixed(4)} g`,
      subtext: 'Gold accrued since last distribution date',
      icon: Clock,
      color: 'from-emerald-500 to-green-600'
    },
    {
      label: 'Next Distribution',
      value: nextDistribution,
      subtext: 'Quarterly gold credit date',
      icon: Calendar,
      color: 'from-blue-500 to-cyan-600'
    },
    {
      label: 'Avg Plan Rate',
      value: `${avgPlanRate.toFixed(1)}% p.a.`,
      subtext: 'Monetary value of quarterly distribution fixed',
      icon: Percent,
      color: 'from-purple-500 to-violet-600'
    }
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {cards.map((card, i) => (
        <motion.div
          key={card.label}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.1 }}
          className="relative overflow-hidden bg-white border border-[#8A2BE2]/20 rounded-2xl p-5 shadow-sm"
        >
          {/* Subtle gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-br from-[#8A2BE2]/5 to-transparent pointer-events-none" />
          
          <div className="relative">
            <div className={`w-10 h-10 rounded-xl bg-gradient-to-r ${card.color} flex items-center justify-center mb-4 shadow-lg`}>
              <card.icon className="w-5 h-5 text-white" />
            </div>
            <p className="text-[#4A4A4A] text-xs uppercase tracking-wider mb-1">{card.label}</p>
            <p className="text-2xl font-bold text-[#0D0D0D] mb-1">{card.value}</p>
            <p className="text-[#4A4A4A] text-xs leading-relaxed">{card.subtext}</p>
          </div>
        </motion.div>
      ))}
    </div>
  );
}