import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Search, Filter, ChevronRight, Plus, Vault, MapPin, 
  Scale, Coins, LayoutGrid, Calendar, Eye
} from 'lucide-react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

const statusConfig = {
  'submitted': { label: 'Submitted', shortLabel: 'Submitted', color: 'bg-blue-500/20 text-blue-400 border-blue-500/30' },
  'under_review': { label: 'Under Review', shortLabel: 'Review', color: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30' },
  'approved': { label: 'Approved', shortLabel: 'Approved', color: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' },
  'received': { label: 'Received at Vault', shortLabel: 'Received', color: 'bg-purple-500/20 text-purple-400 border-purple-500/30' },
  'stored': { label: 'Stored in Vault', shortLabel: 'Stored', color: 'bg-green-500/20 text-green-400 border-green-500/30' },
  'rejected': { label: 'Rejected', shortLabel: 'Rejected', color: 'bg-red-500/20 text-red-400 border-red-500/30' }
};

const depositTypeIcons = {
  'bars': <LayoutGrid className="w-3 h-3 sm:w-4 sm:h-4" />,
  'coins': <Coins className="w-3 h-3 sm:w-4 sm:h-4" />,
  'mixed': <Scale className="w-3 h-3 sm:w-4 sm:h-4" />
};

export default function DepositRequestList({ deposits = [], onNewDeposit, onViewDetails }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [vaultFilter, setVaultFilter] = useState('all');

  const filteredDeposits = deposits.filter(deposit => {
    const matchesSearch = deposit.requestId?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || deposit.status === statusFilter;
    const matchesVault = vaultFilter === 'all' || deposit.vaultLocation === vaultFilter;
    return matchesSearch && matchesStatus && matchesVault;
  });

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 sm:mb-6">
        <div>
          <h2 className="text-base sm:text-xl font-semibold text-[#0D0D0D] flex items-center gap-2">
            <Vault className="w-4 h-4 sm:w-5 sm:h-5 text-amber-600" />
            Gold Deposits — My Requests
          </h2>
          <p className="text-[#4A4A4A] text-xs sm:text-sm mt-1">Track all current and past gold deposit requests.</p>
        </div>
        <Button 
          onClick={onNewDeposit}
          className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white font-semibold hover:opacity-90 rounded-full px-3 sm:px-5 h-9 sm:h-10 text-xs sm:text-sm w-full sm:w-auto"
        >
          <Plus className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
          New Deposit Request
        </Button>
      </div>

      {/* Search & Filters */}
      <div className="flex flex-col sm:flex-row gap-2 sm:gap-3 mb-4 sm:mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#4A4A4A]" />
          <Input
            placeholder="Search by Request ID..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 bg-[#F4F6FC] border-[#8A2BE2]/20 text-[#0D0D0D] placeholder:text-[#4A4A4A] focus:border-[#8A2BE2]/50 h-9 sm:h-10 text-sm"
          />
        </div>
        <div className="flex gap-2">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full sm:w-[140px] bg-[#F4F6FC] border-[#8A2BE2]/20 text-[#0D0D0D] h-9 sm:h-10 text-xs sm:text-sm">
              <Filter className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2 text-amber-600" />
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent className="bg-white border-[#8A2BE2]/20">
              <SelectItem value="all" className="text-[#0D0D0D] hover:bg-[#F4F6FC] text-sm">All Status</SelectItem>
              {Object.entries(statusConfig).map(([key, { label }]) => (
                <SelectItem key={key} value={key} className="text-[#0D0D0D] hover:bg-[#F4F6FC] text-sm">{label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={vaultFilter} onValueChange={setVaultFilter}>
            <SelectTrigger className="w-full sm:w-[140px] bg-[#F4F6FC] border-[#8A2BE2]/20 text-[#0D0D0D] h-9 sm:h-10 text-xs sm:text-sm">
              <MapPin className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2 text-amber-600" />
              <SelectValue placeholder="Vault" />
            </SelectTrigger>
            <SelectContent className="bg-white border-[#8A2BE2]/20">
              <SelectItem value="all" className="text-[#0D0D0D] hover:bg-[#F4F6FC] text-sm">All Vaults</SelectItem>
              <SelectItem value="dubai" className="text-[#0D0D0D] hover:bg-[#F4F6FC] text-sm">Dubai Vault</SelectItem>
              <SelectItem value="swiss" className="text-[#0D0D0D] hover:bg-[#F4F6FC] text-sm">Swiss Vault</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Table - Desktop */}
      <div className="flex-1 overflow-auto hidden sm:block">
        <table className="w-full">
          <thead className="sticky top-0 bg-[#F4F6FC]">
            <tr className="border-b border-[#8A2BE2]/20">
              <th className="text-left py-3 px-4 text-amber-600 text-xs font-medium uppercase tracking-wider">Request ID</th>
              <th className="text-left py-3 px-4 text-amber-600 text-xs font-medium uppercase tracking-wider">Vault</th>
              <th className="text-left py-3 px-4 text-amber-600 text-xs font-medium uppercase tracking-wider">Weight</th>
              <th className="text-left py-3 px-4 text-amber-600 text-xs font-medium uppercase tracking-wider">Type</th>
              <th className="text-left py-3 px-4 text-amber-600 text-xs font-medium uppercase tracking-wider">Status</th>
              <th className="text-left py-3 px-4 text-amber-600 text-xs font-medium uppercase tracking-wider">Submitted</th>
              <th className="text-right py-3 px-4"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#8A2BE2]/10">
            {filteredDeposits.length === 0 ? (
              <tr>
                <td colSpan={7} className="py-12 text-center">
                  <Vault className="w-12 h-12 mx-auto text-[#4A4A4A]/30 mb-3" />
                  <p className="text-[#4A4A4A]">No deposit requests found</p>
                  <p className="text-[#4A4A4A] text-sm mt-1">Create your first deposit request to get started</p>
                </td>
              </tr>
            ) : (
              filteredDeposits.map((deposit, index) => (
                <motion.tr
                  key={deposit.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="group hover:bg-white/5 transition-colors cursor-pointer"
                  onClick={() => onViewDetails(deposit)}
                >
                  <td className="py-4 px-4">
                    <span className="text-amber-600 font-mono text-sm hover:underline">
                      {deposit.requestId}
                    </span>
                  </td>
                  <td className="py-4 px-4">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-[#4A4A4A]" />
                      <span className="text-[#0D0D0D] text-sm">
                        {deposit.vaultLocation === 'dubai' ? 'Dubai Vault' : 'Swiss Vault'}
                      </span>
                    </div>
                  </td>
                  <td className="py-4 px-4">
                    <div>
                      <span className="text-[#0D0D0D] font-semibold">{deposit.totalWeight?.toLocaleString()} g</span>
                      <span className="text-[#4A4A4A] text-xs block">{(deposit.totalWeight / 31.1035).toFixed(2)} oz</span>
                    </div>
                  </td>
                  <td className="py-4 px-4">
                    <div className="flex items-center gap-2 text-[#4A4A4A]">
                      {depositTypeIcons[deposit.depositType]}
                      <span className="capitalize text-sm">{deposit.depositType}</span>
                    </div>
                  </td>
                  <td className="py-4 px-4">
                    <Badge className={`${statusConfig[deposit.status]?.color} border font-medium text-xs`}>
                      {statusConfig[deposit.status]?.label}
                    </Badge>
                  </td>
                  <td className="py-4 px-4">
                    <div className="flex items-center gap-2 text-[#4A4A4A] text-sm">
                      <Calendar className="w-4 h-4" />
                      {deposit.submittedDate}
                    </div>
                  </td>
                  <td className="py-4 px-4 text-right">
                    <Button 
                      variant="ghost" 
                      size="sm"
                      className="text-[#FF2FBF] hover:text-[#FF2FBF]/80 hover:bg-[#8A2BE2]/10 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <Eye className="w-4 h-4 mr-1" />
                      View
                      <ChevronRight className="w-4 h-4 ml-1" />
                    </Button>
                  </td>
                </motion.tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Mobile Cards View */}
      <div className="flex-1 overflow-auto sm:hidden space-y-2">
        {filteredDeposits.length === 0 ? (
          <div className="py-12 text-center">
            <Vault className="w-10 h-10 mx-auto text-[#4A4A4A]/30 mb-3" />
            <p className="text-[#4A4A4A] text-sm">No deposit requests found</p>
            <p className="text-[#4A4A4A] text-xs mt-1">Create your first deposit request</p>
          </div>
        ) : (
          filteredDeposits.map((deposit, index) => (
            <motion.div
              key={deposit.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="bg-white/5 rounded-xl p-3 cursor-pointer active:bg-white/10"
              onClick={() => onViewDetails(deposit)}
            >
              <div className="flex items-start justify-between mb-2">
                <span className="text-amber-600 font-mono text-xs">{deposit.requestId}</span>
                <Badge className={`${statusConfig[deposit.status]?.color} border font-medium text-[10px] px-1.5 py-0.5`}>
                  {statusConfig[deposit.status]?.shortLabel}
                </Badge>
              </div>
              <div className="grid grid-cols-3 gap-2 text-xs">
                <div>
                  <p className="text-[#4A4A4A]">Vault</p>
                  <p className="text-[#0D0D0D]">{deposit.vaultLocation === 'dubai' ? 'Dubai' : 'Swiss'}</p>
                </div>
                <div>
                  <p className="text-[#4A4A4A]">Weight</p>
                  <p className="text-[#0D0D0D] font-semibold">{deposit.totalWeight}g</p>
                </div>
                <div>
                  <p className="text-[#4A4A4A]">Type</p>
                  <div className="flex items-center gap-1 text-[#4A4A4A]">
                    {depositTypeIcons[deposit.depositType]}
                    <span className="capitalize">{deposit.depositType}</span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
}