import React from 'react';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, MapPin, Calendar, Scale, Package, FileText, Truck, 
  Check, Clock, AlertCircle, Download, XCircle, Vault, Phone, User,
  LayoutGrid, Coins, Copy, CheckCircle
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const statusConfig = {
  'submitted': { label: 'Submitted', color: 'bg-blue-500', textColor: 'text-blue-400' },
  'under_review': { label: 'Under Review', color: 'bg-yellow-500', textColor: 'text-yellow-400' },
  'approved': { label: 'Approved – Awaiting Delivery', color: 'bg-emerald-500', textColor: 'text-emerald-400' },
  'received': { label: 'Received at Vault', color: 'bg-purple-500', textColor: 'text-purple-400' },
  'stored': { label: 'Stored in Vault', color: 'bg-green-500', textColor: 'text-green-400' },
  'rejected': { label: 'Rejected', color: 'bg-red-500', textColor: 'text-red-400' }
};

const timelineSteps = [
  { key: 'submitted', label: 'Submitted', icon: FileText },
  { key: 'under_review', label: 'Under Review', icon: Clock },
  { key: 'approved', label: 'Approved', icon: Check },
  { key: 'received', label: 'Received', icon: Package },
  { key: 'stored', label: 'Stored', icon: Vault }
];

const getStepIndex = (status) => {
  const index = timelineSteps.findIndex(s => s.key === status);
  return index === -1 ? 0 : index;
};

export default function DepositRequestDetails({ deposit, onBack, onCancel }) {
  if (!deposit) return null;

  const currentStepIndex = getStepIndex(deposit.status);
  const isRejected = deposit.status === 'rejected';

  const [copied, setCopied] = React.useState(false);
  const copyRequestId = () => {
    navigator.clipboard.writeText(deposit.requestId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="h-full overflow-auto">
      {/* Header */}
      <div className="bg-white border-2 border-[#8A2BE2]/30 rounded-2xl p-6 shadow-lg mb-6">
        <div className="flex items-center gap-4">
          <Button 
            variant="outline" 
            onClick={onBack}
            className="border-2 border-[#8A2BE2]/30 text-[#8A2BE2] hover:bg-[#8A2BE2]/10 font-bold"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <h2 className="text-2xl font-bold text-amber-600 font-mono">{deposit.requestId}</h2>
              <button 
                onClick={copyRequestId}
                className="text-[#4A4A4A] hover:text-amber-600 transition-colors"
              >
                {copied ? <CheckCircle className="w-5 h-5 text-green-600" /> : <Copy className="w-5 h-5" />}
              </button>
            </div>
            <div className="flex items-center gap-3">
              <Badge className={`px-4 py-1.5 rounded-lg text-sm font-bold border-2 ${
                deposit.status === 'stored' ? 'bg-green-100 text-green-700 border-green-400' :
                deposit.status === 'approved' ? 'bg-emerald-100 text-emerald-700 border-emerald-400' :
                deposit.status === 'under_review' ? 'bg-yellow-100 text-yellow-700 border-yellow-400' :
                deposit.status === 'rejected' ? 'bg-red-100 text-red-700 border-red-400' :
                'bg-blue-100 text-blue-700 border-blue-400'
              }`}>
                {statusConfig[deposit.status]?.label}
              </Badge>
              <span className="text-[#4A4A4A] text-sm font-semibold flex items-center gap-1.5">
                <MapPin className="w-4 h-4" />
                {deposit.vaultLocation === 'dubai' ? 'Dubai Vault' : 'Swiss Vault'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Status Timeline */}
      <section className="mb-8">
        <h3 className="text-[#0D0D0D] font-bold text-lg uppercase tracking-wider mb-4">Status Timeline</h3>
        <div className="relative bg-white border-2 border-[#8A2BE2]/30 rounded-2xl p-6 shadow-lg">
          {/* Timeline Line */}
          <div className="absolute top-14 left-14 right-14 h-1 bg-gray-200 rounded-full" />
          <div 
            className="absolute top-14 left-14 h-1 bg-gradient-to-r from-amber-500 to-yellow-600 rounded-full transition-all"
            style={{ width: `calc(${(currentStepIndex / (timelineSteps.length - 1)) * 100}% - 56px)` }}
          />
          
          {/* Timeline Steps */}
          <div className="relative flex justify-between">
            {timelineSteps.map((step, index) => {
              const isCompleted = index <= currentStepIndex && !isRejected;
              const isCurrent = index === currentStepIndex && !isRejected;
              const Icon = step.icon;
              
              return (
                <motion.div
                  key={step.key}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="flex flex-col items-center"
                >
                  <div className={`w-14 h-14 rounded-full flex items-center justify-center border-4 transition-all shadow-lg ${
                    isCompleted 
                      ? 'bg-gradient-to-r from-amber-500 to-yellow-600 border-amber-600 text-white' 
                      : 'bg-white border-gray-300 text-gray-400'
                  } ${isCurrent ? 'ring-4 ring-amber-400/40 scale-110' : ''}`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <span className={`mt-3 text-sm font-bold text-center ${isCompleted ? 'text-amber-600' : 'text-gray-400'}`}>
                    {step.label}
                  </span>
                  {deposit.timeline?.[step.key] && (
                    <span className="text-[#4A4A4A] text-xs mt-1 font-medium">{deposit.timeline[step.key]}</span>
                  )}
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Rejection Notice */}
        {isRejected && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-6 bg-red-100 border-2 border-red-400 rounded-xl p-5"
          >
            <div className="flex items-start gap-3">
              <XCircle className="w-6 h-6 text-red-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-red-600 font-bold text-lg">Request Rejected</p>
                <p className="text-[#4A4A4A] text-sm mt-2 font-medium">{deposit.rejectionReason || 'No reason provided.'}</p>
              </div>
            </div>
          </motion.div>
        )}
      </section>

      {/* Gold Summary */}
      <section className="mb-8">
        <h3 className="text-[#0D0D0D] font-bold text-lg uppercase tracking-wider mb-4">Gold Summary</h3>
        <div className="grid grid-cols-3 gap-4">
          <div className="bg-gradient-to-br from-amber-100 to-yellow-100 rounded-xl p-5 border-2 border-amber-400 shadow-lg">
            <Scale className="w-7 h-7 text-amber-600 mb-3" />
            <p className="text-[#4A4A4A] text-xs font-semibold mb-1">Total Declared Weight</p>
            <p className="text-3xl font-bold text-[#0D0D0D] mb-1">{deposit.totalWeight?.toLocaleString()} g</p>
            <p className="text-amber-600 text-sm font-bold">{(deposit.totalWeight / 31.1035).toFixed(2)} oz</p>
          </div>
          <div className="bg-white rounded-xl p-5 border-2 border-[#8A2BE2]/30 shadow-lg">
            {deposit.depositType === 'bars' && <LayoutGrid className="w-7 h-7 text-purple-600 mb-3" />}
            {deposit.depositType === 'coins' && <Coins className="w-7 h-7 text-purple-600 mb-3" />}
            {deposit.depositType === 'mixed' && <Scale className="w-7 h-7 text-purple-600 mb-3" />}
            <p className="text-[#4A4A4A] text-xs font-semibold mb-1">Deposit Type</p>
            <p className="text-2xl font-bold text-[#0D0D0D] capitalize">{deposit.depositType}</p>
          </div>
          <div className="bg-white rounded-xl p-5 border-2 border-[#8A2BE2]/30 shadow-lg">
            <Package className="w-7 h-7 text-blue-600 mb-3" />
            <p className="text-[#4A4A4A] text-xs font-semibold mb-1">Number of Items</p>
            <p className="text-2xl font-bold text-[#0D0D0D]">{deposit.items?.length || 0}</p>
          </div>
        </div>
      </section>

      {/* Gold Item List */}
      <section className="mb-8">
        <h3 className="text-[#0D0D0D] font-bold text-lg uppercase tracking-wider mb-4">Gold Items</h3>
        <div className="space-y-3">
          {deposit.items?.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.05 }}
              className="bg-white rounded-xl p-5 border-2 border-[#8A2BE2]/30 shadow-lg hover:border-[#8A2BE2]/60 transition-all"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-lg bg-gradient-to-br from-amber-100 to-yellow-100 flex items-center justify-center border-2 border-amber-400">
                    {item.type === 'bar' ? <LayoutGrid className="w-7 h-7 text-amber-600" /> : <Coins className="w-7 h-7 text-amber-600" />}
                  </div>
                  <div>
                    <p className="text-[#0D0D0D] font-bold text-lg capitalize">{item.type} × {item.quantity}</p>
                    <p className="text-[#4A4A4A] text-sm font-semibold">{item.brand || 'Unknown Brand'} • Purity: {item.purity}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-amber-600 font-bold text-2xl">{(item.quantity * item.weightPerUnit).toLocaleString()} g</p>
                  <p className="text-[#4A4A4A] text-sm font-medium">{item.weightPerUnit}g × {item.quantity}</p>
                </div>
              </div>
              {item.notes && <p className="text-[#4A4A4A] text-sm mt-3 pl-16 italic font-medium">{item.notes}</p>}
            </motion.div>
          ))}
        </div>
      </section>

      {/* Delivery Details */}
      <section className="mb-8">
        <h3 className="text-[#0D0D0D] font-bold text-lg uppercase tracking-wider mb-4">Delivery Details</h3>
        <div className="bg-white rounded-xl p-6 border-2 border-[#8A2BE2]/30 shadow-lg">
          <div className="flex items-center gap-3 mb-5 pb-5 border-b-2 border-[#8A2BE2]/20">
            <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-blue-100 to-cyan-100 flex items-center justify-center border-2 border-blue-400">
              <Truck className="w-6 h-6 text-blue-600" />
            </div>
            <span className="text-[#0D0D0D] font-bold text-lg capitalize">
              {deposit.deliveryMethod === 'personal' && 'Personal Delivery'}
              {deposit.deliveryMethod === 'courier' && 'Courier / Self-Arranged Logistics'}
              {deposit.deliveryMethod === 'pickup' && 'Pickup Requested'}
            </span>
          </div>
          {deposit.deliveryMethod === 'pickup' && deposit.pickupDetails && (
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-blue-600 mt-0.5" />
                <div>
                  <p className="text-[#4A4A4A] text-xs font-semibold">Pickup Address</p>
                  <p className="text-[#0D0D0D] text-sm font-bold">{deposit.pickupDetails.address}</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <User className="w-5 h-5 text-blue-600 mt-0.5" />
                <div>
                  <p className="text-[#4A4A4A] text-xs font-semibold">Contact Person</p>
                  <p className="text-[#0D0D0D] text-sm font-bold">{deposit.pickupDetails.contact}</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Phone className="w-5 h-5 text-blue-600 mt-0.5" />
                <div>
                  <p className="text-[#4A4A4A] text-xs font-semibold">Phone</p>
                  <p className="text-[#0D0D0D] text-sm font-bold">{deposit.pickupDetails.phone}</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Calendar className="w-5 h-5 text-blue-600 mt-0.5" />
                <div>
                  <p className="text-[#4A4A4A] text-xs font-semibold">Scheduled Date & Time</p>
                  <p className="text-[#0D0D0D] text-sm font-bold">{deposit.pickupDetails.date} • {deposit.pickupDetails.timeSlot}</p>
                </div>
              </div>
            </div>
          )}
          {deposit.deliveryMethod === 'personal' && deposit.status === 'approved' && (
            <div className="mt-4 bg-emerald-100 border-2 border-emerald-400 rounded-lg p-4">
              <p className="text-emerald-700 text-sm font-bold">
                Please bring your gold to the vault with this reference ID: <strong>{deposit.requestId}</strong>
              </p>
            </div>
          )}
        </div>
      </section>

      {/* Documents */}
      <section className="mb-8">
        <h3 className="text-[#0D0D0D] font-bold text-lg uppercase tracking-wider mb-4">Documents</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {deposit.documents?.map((doc, index) => (
            <div 
              key={index}
              className="bg-white rounded-xl p-4 border-2 border-[#8A2BE2]/30 flex items-center justify-between shadow-lg hover:border-[#8A2BE2]/60 transition-all"
            >
              <div className="flex items-center gap-3 min-w-0">
                <FileText className="w-6 h-6 text-purple-600 flex-shrink-0" />
                <div className="min-w-0">
                  <p className="text-[#0D0D0D] text-sm font-bold truncate">{doc.name}</p>
                  <p className="text-[#4A4A4A] text-xs capitalize font-medium">{doc.type}</p>
                </div>
              </div>
              <button className="text-amber-600 hover:text-amber-700 transition-colors flex-shrink-0">
                <Download className="w-5 h-5" />
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Vault Confirmation (When Stored) */}
      {deposit.status === 'stored' && (
        <section className="mb-8">
          <h3 className="text-[#0D0D0D] font-bold text-lg uppercase tracking-wider mb-4">Vault Confirmation</h3>
          <div className="bg-gradient-to-r from-green-100 to-emerald-100 rounded-xl p-6 border-2 border-green-400 shadow-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[#4A4A4A] text-sm font-semibold mb-2">Storage Start Date</p>
                <p className="text-[#0D0D0D] font-bold text-lg">{deposit.storageStartDate}</p>
                <p className="text-[#4A4A4A] text-sm font-semibold mt-4 mb-2">Vault Internal Reference</p>
                <p className="text-green-600 font-mono font-bold text-lg">{deposit.vaultReference}</p>
              </div>
              <Button className="bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold hover:opacity-90">
                <Download className="w-5 h-5 mr-2" />
                Download PDF
              </Button>
            </div>
          </div>
        </section>
      )}

      {/* User Actions */}
      {deposit.status === 'submitted' && (
        <div className="border-t-2 border-[#8A2BE2]/20 pt-6">
          <Button 
            onClick={() => onCancel?.(deposit.id)}
            variant="outline" 
            className="border-2 border-red-500 text-red-600 font-bold hover:bg-red-50"
          >
            <XCircle className="w-5 h-5 mr-2" />
            Cancel Request
          </Button>
        </div>
      )}
    </div>
  );
}