import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  AlertTriangle, MapPin, Clock, Info, LayoutGrid, Coins, Scale,
  Trash2, Plus, Upload, FileText, X, Check, Save, Send,
  Truck, User, Package, Calendar as CalendarIcon, Phone, Building, ArrowLeft, Vault
} from 'lucide-react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";

const vaultInfo = {
  dubai: {
    name: 'Dubai Vault',
    address: 'DMCC Free Zone, Almas Tower, Dubai, UAE',
    hours: 'Sun-Thu: 9:00 AM - 5:00 PM',
    instructions: 'Please bring valid ID and deposit confirmation. Security screening required.'
  },
  swiss: {
    name: 'Swiss Vault',
    address: 'Bahnhofstrasse 45, 8001 Zürich, Switzerland',
    hours: 'Mon-Fri: 9:00 AM - 4:00 PM',
    instructions: 'Appointment required. Bring passport and proof of ownership.'
  }
};

const purityOptions = ['999.9', '999.5', '995', '916', 'Other'];
const sourceOptions = [
  { value: 'salary', label: 'Salary/Savings' },
  { value: 'business', label: 'Business Profits' },
  { value: 'inheritance', label: 'Inheritance' },
  { value: 'mining', label: 'Mining/Refinery' },
  { value: 'other', label: 'Other' }
];

export default function NewDepositForm({ kycApproved = false, onSubmit, onSaveDraft, onGoToKYC, onBack }) {
  const [formData, setFormData] = useState({
    vaultLocation: '',
    depositType: '',
    items: [{ id: 1, type: 'bar', quantity: 1, weightPerUnit: '', purity: '999.9', brand: '', notes: '' }],
    isBeneficialOwner: false,
    sourceOfMetal: '',
    sourceOther: '',
    deliveryMethod: '',
    pickupAddress: '',
    pickupContact: '',
    pickupPhone: '',
    pickupDate: '',
    pickupTimeSlot: '',
    documents: [],
    confirmNoLien: false,
    acceptTerms: false
  });

  const addItem = () => {
    setFormData({
      ...formData,
      items: [...formData.items, { 
        id: Date.now(), 
        type: 'bar', 
        quantity: 1, 
        weightPerUnit: '', 
        purity: '999.9', 
        brand: '', 
        notes: '' 
      }]
    });
  };

  const removeItem = (id) => {
    if (formData.items.length > 1) {
      setFormData({
        ...formData,
        items: formData.items.filter(item => item.id !== id)
      });
    }
  };

  const updateItem = (id, field, value) => {
    setFormData({
      ...formData,
      items: formData.items.map(item => 
        item.id === id ? { ...item, [field]: value } : item
      )
    });
  };

  const handleFileUpload = (e, docType) => {
    const files = Array.from(e.target.files);
    const newDocs = files.map(file => ({
      id: Date.now() + Math.random(),
      name: file.name,
      type: docType,
      file
    }));
    setFormData({
      ...formData,
      documents: [...formData.documents, ...newDocs]
    });
  };

  const removeDocument = (docId) => {
    setFormData({
      ...formData,
      documents: formData.documents.filter(doc => doc.id !== docId)
    });
  };

  const totalItems = formData.items.reduce((sum, item) => sum + (parseInt(item.quantity) || 0), 0);
  const totalWeight = formData.items.reduce((sum, item) => 
    sum + ((parseInt(item.quantity) || 0) * (parseFloat(item.weightPerUnit) || 0)), 0
  );
  const totalOz = totalWeight / 31.1035;

  const selectedVault = vaultInfo[formData.vaultLocation];

  return (
    <div className="h-full overflow-auto pr-2 scrollbar-thin scrollbar-thumb-[#D1A954]/20 scrollbar-track-transparent">
      <div className="space-y-6">
        {/* Header with Back Button */}
        {onBack && (
          <div className="flex items-center gap-4 mb-2">
            <button 
              onClick={onBack}
              className="flex items-center gap-2 text-[#4A4A4A] hover:text-[#0D0D0D] transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>Back</span>
            </button>
            <h2 className="text-xl font-semibold text-[#0D0D0D] flex items-center gap-2">
              <Vault className="w-5 h-5 text-[#8A2BE2]" />
              New Deposit Request
            </h2>
          </div>
        )}

        {/* KYC Warning */}
        {!kycApproved && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-4"
          >
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="text-amber-600 font-medium">KYC Verification Required</p>
                <p className="text-[#4A4A4A] text-sm mt-1">Please complete your KYC verification before requesting a gold deposit.</p>
              </div>
              <Button onClick={onGoToKYC} className="bg-amber-500 text-black hover:bg-amber-400 font-semibold">
                Go to KYC
              </Button>
            </div>
          </motion.div>
        )}

        {/* Section 1: Vault Selection */}
        <section className="space-y-4">
          <h3 className="text-[#0D0D0D] font-semibold flex items-center gap-2 text-sm uppercase tracking-wider">
            <Building className="w-4 h-4 text-[#8A2BE2]" />
            Vault Selection
          </h3>
          <div className="h-px bg-gradient-to-r from-[#8A2BE2]/30 to-transparent" />
          
          <Select 
            value={formData.vaultLocation} 
            onValueChange={(value) => setFormData({ ...formData, vaultLocation: value })}
            disabled={!kycApproved}
          >
            <SelectTrigger className="bg-[#F4F6FC] border-[#8A2BE2]/20 text-[#0D0D0D]">
              <SelectValue placeholder="Select Vault Location" />
            </SelectTrigger>
            <SelectContent className="bg-white border-[#8A2BE2]/20">
              <SelectItem value="dubai" className="text-[#0D0D0D] hover:bg-[#F4F6FC]">Dubai Vault</SelectItem>
              <SelectItem value="swiss" className="text-[#0D0D0D] hover:bg-[#F4F6FC]">Swiss Vault</SelectItem>
            </SelectContent>
          </Select>

          <AnimatePresence>
            {selectedVault && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="bg-[#F4F6FC] rounded-xl p-4 space-y-3 border border-[#8A2BE2]/10"
              >
                <div className="flex items-start gap-3">
                  <MapPin className="w-4 h-4 text-[#8A2BE2] mt-0.5" />
                  <div>
                    <p className="text-[#4A4A4A] text-xs">Address</p>
                    <p className="text-[#0D0D0D] text-sm">{selectedVault.address}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Clock className="w-4 h-4 text-[#8A2BE2] mt-0.5" />
                  <div>
                    <p className="text-[#4A4A4A] text-xs">Operating Hours</p>
                    <p className="text-[#0D0D0D] text-sm">{selectedVault.hours}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Info className="w-4 h-4 text-[#8A2BE2] mt-0.5" />
                  <div>
                    <p className="text-[#4A4A4A] text-xs">Instructions</p>
                    <p className="text-[#0D0D0D] text-sm">{selectedVault.instructions}</p>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </section>

        {/* Section 2: Deposit Type */}
        <section className="space-y-4">
          <h3 className="text-[#0D0D0D] font-semibold flex items-center gap-2 text-sm uppercase tracking-wider">
            <Scale className="w-4 h-4 text-[#8A2BE2]" />
            Deposit Type
          </h3>
          <div className="h-px bg-gradient-to-r from-[#8A2BE2]/30 to-transparent" />
          
          <RadioGroup 
            value={formData.depositType} 
            onValueChange={(value) => setFormData({ ...formData, depositType: value })}
            className="grid grid-cols-3 gap-3"
            disabled={!kycApproved}
          >
            {[
              { value: 'bars', icon: LayoutGrid, label: 'Bars' },
              { value: 'coins', icon: Coins, label: 'Coins' },
              { value: 'mixed', icon: Scale, label: 'Mixed' }
            ].map(({ value, icon: Icon, label }) => (
              <Label
                key={value}
                className={`flex flex-col items-center gap-2 p-4 rounded-xl border cursor-pointer transition-all ${
                  formData.depositType === value
                    ? 'bg-[#8A2BE2]/10 border-[#8A2BE2] text-[#8A2BE2]'
                    : 'bg-[#F4F6FC] border-[#8A2BE2]/20 text-[#4A4A4A] hover:border-[#8A2BE2]/50'
                }`}
              >
                <RadioGroupItem value={value} className="sr-only" />
                <Icon className="w-6 h-6" />
                <span className="text-sm font-medium">{label}</span>
              </Label>
            ))}
          </RadioGroup>
        </section>

        {/* Section 3: Gold Item Details */}
        <section className="space-y-4">
          <h3 className="text-[#0D0D0D] font-semibold flex items-center gap-2 text-sm uppercase tracking-wider">
            <Package className="w-4 h-4 text-[#8A2BE2]" />
            Gold Item Details
          </h3>
          <div className="h-px bg-gradient-to-r from-[#8A2BE2]/30 to-transparent" />
          
          <div className="space-y-3">
            {formData.items.map((item, index) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="bg-[#F4F6FC] rounded-xl p-4 border border-[#8A2BE2]/10"
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[#4A4A4A] text-xs">Item {index + 1}</span>
                  {formData.items.length > 1 && (
                    <button 
                      onClick={() => removeItem(item.id)}
                      className="text-red-400 hover:text-red-300 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <Select 
                    value={item.type} 
                    onValueChange={(value) => updateItem(item.id, 'type', value)}
                    disabled={!kycApproved}
                  >
                    <SelectTrigger className="bg-white border-[#8A2BE2]/20 text-[#0D0D0D] text-sm">
                      <SelectValue placeholder="Type" />
                    </SelectTrigger>
                    <SelectContent className="bg-white border-[#8A2BE2]/20">
                      <SelectItem value="bar" className="text-[#0D0D0D]">Bar</SelectItem>
                      <SelectItem value="coin" className="text-[#0D0D0D]">Coin</SelectItem>
                    </SelectContent>
                  </Select>
                  <Input
                    type="number"
                    placeholder="Qty"
                    value={item.quantity}
                    onChange={(e) => updateItem(item.id, 'quantity', e.target.value)}
                    className="bg-white border-[#8A2BE2]/20 text-[#0D0D0D] text-sm"
                    disabled={!kycApproved}
                  />
                  <Input
                    type="number"
                    placeholder="Weight (g)"
                    value={item.weightPerUnit}
                    onChange={(e) => updateItem(item.id, 'weightPerUnit', e.target.value)}
                    className="bg-white border-[#8A2BE2]/20 text-[#0D0D0D] text-sm"
                    disabled={!kycApproved}
                  />
                  <Select 
                    value={item.purity} 
                    onValueChange={(value) => updateItem(item.id, 'purity', value)}
                    disabled={!kycApproved}
                  >
                    <SelectTrigger className="bg-white border-[#8A2BE2]/20 text-[#0D0D0D] text-sm">
                      <SelectValue placeholder="Purity" />
                    </SelectTrigger>
                    <SelectContent className="bg-white border-[#8A2BE2]/20">
                      {purityOptions.map(p => (
                        <SelectItem key={p} value={p} className="text-[#0D0D0D]">{p}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-3 mt-3">
                  <Input
                    placeholder="Brand/Mint"
                    value={item.brand}
                    onChange={(e) => updateItem(item.id, 'brand', e.target.value)}
                    className="bg-white border-[#8A2BE2]/20 text-[#0D0D0D] text-sm"
                    disabled={!kycApproved}
                  />
                  <Input
                    placeholder="Notes"
                    value={item.notes}
                    onChange={(e) => updateItem(item.id, 'notes', e.target.value)}
                    className="bg-white border-[#8A2BE2]/20 text-[#0D0D0D] text-sm"
                    disabled={!kycApproved}
                  />
                </div>
                <div className="mt-3 text-right">
                  <span className="text-[#4A4A4A] text-xs">Total: </span>
                  <span className="text-[#FF2FBF] font-semibold">
                    {((parseInt(item.quantity) || 0) * (parseFloat(item.weightPerUnit) || 0)).toLocaleString()} g
                  </span>
                </div>
              </motion.div>
            ))}
          </div>

          <Button 
            onClick={addItem} 
            variant="outline" 
            className="w-full border-dashed border-[#8A2BE2]/30 text-[#FF2FBF] hover:bg-[#8A2BE2]/10"
            disabled={!kycApproved}
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Item
          </Button>

          {/* Summary Box */}
          <div className="bg-gradient-to-r from-[#8A2BE2]/10 to-[#FF2FBF]/5 rounded-xl p-4 border border-[#8A2BE2]/20">
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <p className="text-[#4A4A4A] text-xs">Total Items</p>
                <p className="text-2xl font-bold text-[#0D0D0D]">{totalItems}</p>
              </div>
              <div>
                <p className="text-[#4A4A4A] text-xs">Total Weight</p>
                <p className="text-2xl font-bold text-[#FF2FBF]">{totalWeight.toLocaleString()} g</p>
              </div>
              <div>
                <p className="text-[#4A4A4A] text-xs">Troy Ounces</p>
                <p className="text-2xl font-bold text-[#0D0D0D]">≈ {totalOz.toFixed(2)} oz</p>
              </div>
            </div>
          </div>
        </section>

        {/* Section 4: Ownership & Source */}
        <section className="space-y-4">
          <h3 className="text-[#0D0D0D] font-semibold flex items-center gap-2 text-sm uppercase tracking-wider">
            <User className="w-4 h-4 text-[#8A2BE2]" />
            Ownership & Source
          </h3>
          <div className="h-px bg-gradient-to-r from-[#8A2BE2]/30 to-transparent" />
          
          <div className="flex items-start gap-3">
            <Checkbox 
              id="beneficial-owner"
              checked={formData.isBeneficialOwner}
              onCheckedChange={(checked) => setFormData({ ...formData, isBeneficialOwner: checked })}
              className="mt-1 border-[#8A2BE2]/50 data-[state=checked]:bg-[#8A2BE2] data-[state=checked]:border-[#8A2BE2]"
              disabled={!kycApproved}
            />
            <label htmlFor="beneficial-owner" className="text-[#0D0D0D] text-sm cursor-pointer">
              I am the beneficial owner of this gold.
            </label>
          </div>

          <Select 
            value={formData.sourceOfMetal} 
            onValueChange={(value) => setFormData({ ...formData, sourceOfMetal: value })}
            disabled={!kycApproved}
          >
            <SelectTrigger className="bg-[#F4F6FC] border-[#8A2BE2]/20 text-[#0D0D0D]">
              <SelectValue placeholder="Source of Metal" />
            </SelectTrigger>
            <SelectContent className="bg-white border-[#8A2BE2]/20">
              {sourceOptions.map(opt => (
                <SelectItem key={opt.value} value={opt.value} className="text-[#0D0D0D]">{opt.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <AnimatePresence>
            {formData.sourceOfMetal === 'other' && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
              >
                <Input
                  placeholder="Please specify source..."
                  value={formData.sourceOther}
                  onChange={(e) => setFormData({ ...formData, sourceOther: e.target.value })}
                  className="bg-white border-[#8A2BE2]/20 text-[#0D0D0D]"
                  disabled={!kycApproved}
                />
              </motion.div>
            )}
          </AnimatePresence>
        </section>

        {/* Section 5: Delivery Method */}
        <section className="space-y-4">
          <h3 className="text-[#0D0D0D] font-semibold flex items-center gap-2 text-sm uppercase tracking-wider">
            <Truck className="w-4 h-4 text-[#8A2BE2]" />
            Delivery Method
          </h3>
          <div className="h-px bg-gradient-to-r from-[#8A2BE2]/30 to-transparent" />
          
          <RadioGroup 
            value={formData.deliveryMethod} 
            onValueChange={(value) => setFormData({ ...formData, deliveryMethod: value })}
            className="space-y-3"
            disabled={!kycApproved}
          >
            {[
              { value: 'personal', label: 'I will personally bring the gold to the vault' },
              { value: 'courier', label: 'Courier / Logistics arranged by me' },
              { value: 'pickup', label: 'Pickup required from my address' }
            ].map(({ value, label }) => (
              <Label
                key={value}
                className={`flex items-center gap-3 p-4 rounded-xl border cursor-pointer transition-all ${
                  formData.deliveryMethod === value
                    ? 'bg-[#8A2BE2]/10 border-[#8A2BE2]/50'
                    : 'bg-[#F4F6FC] border-[#8A2BE2]/20 hover:border-[#8A2BE2]/40'
                }`}
              >
                <RadioGroupItem value={value} className="border-[#8A2BE2] text-[#8A2BE2]" />
                <span className="text-[#0D0D0D] text-sm">{label}</span>
              </Label>
            ))}
          </RadioGroup>

          <AnimatePresence>
            {formData.deliveryMethod === 'personal' && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="bg-[#F4F6FC] rounded-xl p-4 border border-[#8A2BE2]/10"
              >
                <p className="text-[#4A4A4A] text-sm">
                  Please bring your gold to the selected vault during operating hours. 
                  Ensure you have valid identification and this deposit confirmation reference.
                </p>
              </motion.div>
            )}
            {formData.deliveryMethod === 'pickup' && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="space-y-3"
              >
                <Textarea
                  placeholder="Pickup Address"
                  value={formData.pickupAddress}
                  onChange={(e) => setFormData({ ...formData, pickupAddress: e.target.value })}
                  className="bg-white border-[#8A2BE2]/20 text-[#0D0D0D] min-h-[80px]"
                  disabled={!kycApproved}
                />
                <div className="grid grid-cols-2 gap-3">
                  <Input
                    placeholder="Contact Person Name"
                    value={formData.pickupContact}
                    onChange={(e) => setFormData({ ...formData, pickupContact: e.target.value })}
                    className="bg-white border-[#8A2BE2]/20 text-[#0D0D0D]"
                    disabled={!kycApproved}
                  />
                  <Input
                    placeholder="Contact Mobile"
                    value={formData.pickupPhone}
                    onChange={(e) => setFormData({ ...formData, pickupPhone: e.target.value })}
                    className="bg-white border-[#8A2BE2]/20 text-[#0D0D0D]"
                    disabled={!kycApproved}
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <Input
                    type="date"
                    value={formData.pickupDate}
                    onChange={(e) => setFormData({ ...formData, pickupDate: e.target.value })}
                    className="bg-white border-[#8A2BE2]/20 text-[#0D0D0D]"
                    disabled={!kycApproved}
                  />
                  <Select 
                    value={formData.pickupTimeSlot} 
                    onValueChange={(value) => setFormData({ ...formData, pickupTimeSlot: value })}
                    disabled={!kycApproved}
                  >
                    <SelectTrigger className="bg-white border-[#8A2BE2]/20 text-[#0D0D0D]">
                      <SelectValue placeholder="Time Slot" />
                    </SelectTrigger>
                    <SelectContent className="bg-white border-[#8A2BE2]/20">
                      <SelectItem value="10-12" className="text-[#0D0D0D]">10:00 - 12:00</SelectItem>
                      <SelectItem value="12-14" className="text-[#0D0D0D]">12:00 - 14:00</SelectItem>
                      <SelectItem value="14-16" className="text-[#0D0D0D]">14:00 - 16:00</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </section>

        {/* Section 6: Document Uploads */}
        <section className="space-y-4">
          <h3 className="text-[#0D0D0D] font-semibold flex items-center gap-2 text-sm uppercase tracking-wider">
            <FileText className="w-4 h-4 text-[#8A2BE2]" />
            Documents
          </h3>
          <div className="h-px bg-gradient-to-r from-[#8A2BE2]/30 to-transparent" />
          
          <div className="space-y-3">
            {[
              { type: 'invoice', label: 'Invoice / Purchase Receipt' },
              { type: 'certificate', label: 'Assay / Purity Certificate' },
              { type: 'other', label: 'Other Supporting Documents' }
            ].map(({ type, label }) => (
              <div key={type} className="bg-[#F4F6FC] rounded-xl p-4 border border-[#8A2BE2]/10">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[#0D0D0D] text-sm">{label}</span>
                  <label className="cursor-pointer">
                    <input 
                      type="file" 
                      className="hidden" 
                      accept=".pdf,.jpg,.jpeg,.png"
                      multiple
                      onChange={(e) => handleFileUpload(e, type)}
                      disabled={!kycApproved}
                    />
                    <span className="flex items-center gap-2 text-[#FF2FBF] text-sm hover:text-[#FF2FBF]/80 transition-colors">
                      <Upload className="w-4 h-4" />
                      Upload
                    </span>
                  </label>
                </div>
                <div className="flex flex-wrap gap-2">
                  {formData.documents.filter(d => d.type === type).map(doc => (
                    <div key={doc.id} className="flex items-center gap-2 bg-white rounded-lg px-3 py-1.5 border border-[#8A2BE2]/20">
                      <FileText className="w-3 h-3 text-[#8A2BE2]" />
                      <span className="text-[#0D0D0D] text-xs truncate max-w-[120px]">{doc.name}</span>
                      <button onClick={() => removeDocument(doc.id)} className="text-[#4A4A4A] hover:text-red-600">
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Section 7: Fees & Terms */}
        <section className="space-y-4">
          <h3 className="text-[#0D0D0D] font-semibold flex items-center gap-2 text-sm uppercase tracking-wider">
            <Check className="w-4 h-4 text-[#8A2BE2]" />
            Fees & Terms
          </h3>
          <div className="h-px bg-gradient-to-r from-[#8A2BE2]/30 to-transparent" />
          
          <div className="bg-[#F4F6FC] rounded-xl p-4 border border-[#8A2BE2]/10 space-y-2">
            <p className="text-[#4A4A4A] text-sm">• Estimated storage fee: as per tariff.</p>
            <p className="text-[#4A4A4A] text-sm">• Handling/inspection charges may apply.</p>
          </div>

          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <Checkbox 
                id="confirm-no-lien"
                checked={formData.confirmNoLien}
                onCheckedChange={(checked) => setFormData({ ...formData, confirmNoLien: checked })}
                className="mt-1 border-[#8A2BE2]/50 data-[state=checked]:bg-[#8A2BE2] data-[state=checked]:border-[#8A2BE2]"
                disabled={!kycApproved}
              />
              <label htmlFor="confirm-no-lien" className="text-[#0D0D0D] text-sm cursor-pointer">
                I confirm the gold is free from any lien or dispute.
              </label>
            </div>
            <div className="flex items-start gap-3">
              <Checkbox 
                id="accept-terms"
                checked={formData.acceptTerms}
                onCheckedChange={(checked) => setFormData({ ...formData, acceptTerms: checked })}
                className="mt-1 border-[#8A2BE2]/50 data-[state=checked]:bg-[#8A2BE2] data-[state=checked]:border-[#8A2BE2]"
                disabled={!kycApproved}
              />
              <label htmlFor="accept-terms" className="text-[#0D0D0D] text-sm cursor-pointer">
                I accept the vault storage terms and fee structure.
              </label>
            </div>
          </div>
        </section>

        {/* Section 8: Action Buttons */}
        <div className="flex gap-3 pt-4 border-t border-[#8A2BE2]/20">
          <Button 
            onClick={() => onSaveDraft?.(formData)}
            variant="outline" 
            className="flex-1 border-[#8A2BE2]/30 text-[#FF2FBF] hover:bg-[#8A2BE2]/10"
            disabled={!kycApproved}
          >
            <Save className="w-4 h-4 mr-2" />
            Save as Draft
          </Button>
          <Button 
            onClick={() => onSubmit?.(formData)}
            className="flex-1 bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white font-semibold hover:opacity-90"
            disabled={!kycApproved || !formData.confirmNoLien || !formData.acceptTerms}
          >
            <Send className="w-4 h-4 mr-2" />
            Submit Request
          </Button>
        </div>
      </div>
    </div>
  );
}