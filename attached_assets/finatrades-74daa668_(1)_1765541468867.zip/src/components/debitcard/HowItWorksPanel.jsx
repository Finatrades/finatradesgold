import React from 'react';
import { motion } from 'framer-motion';
import { Coins, ArrowRight, RefreshCw, CreditCard } from 'lucide-react';

export default function HowItWorksPanel() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 }}
      className="bg-white border border-[#8A2BE2]/20 rounded-2xl p-6 shadow-sm"
    >
      <h3 className="text-[#0D0D0D] font-medium mb-2">How It Works</h3>
      <p className="text-[#4A4A4A] text-sm mb-6">Gold-to-fiat conversion at point of sale</p>

      {/* Flow Diagram */}
      <div className="flex flex-col md:flex-row items-center justify-center gap-4 md:gap-8">
        {/* Step 1 */}
        <div className="flex flex-col items-center text-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-500/20 to-amber-500/5 flex items-center justify-center border border-amber-500/20 mb-3">
            <Coins className="w-7 h-7 text-amber-600" />
          </div>
          <p className="text-[#0D0D0D] text-sm font-medium">Gold (grams)</p>
          <p className="text-[#4A4A4A] text-xs">Your holdings</p>
        </div>

        {/* Arrow */}
        <ArrowRight className="w-6 h-6 text-[#8A2BE2] rotate-90 md:rotate-0" />

        {/* Step 2 */}
        <div className="flex flex-col items-center text-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#8A2BE2]/20 to-[#8A2BE2]/5 flex items-center justify-center border border-[#8A2BE2]/20 mb-3">
            <RefreshCw className="w-7 h-7 text-[#8A2BE2]" />
          </div>
          <p className="text-[#0D0D0D] text-sm font-medium">FX Conversion</p>
          <p className="text-[#4A4A4A] text-xs">Live market price</p>
        </div>

        {/* Arrow */}
        <ArrowRight className="w-6 h-6 text-[#8A2BE2] rotate-90 md:rotate-0" />

        {/* Step 3 */}
        <div className="flex flex-col items-center text-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#FF2FBF]/20 to-[#FF2FBF]/5 flex items-center justify-center border border-[#FF2FBF]/20 mb-3">
            <CreditCard className="w-7 h-7 text-[#FF2FBF]" />
          </div>
          <p className="text-[#0D0D0D] text-sm font-medium">Card Spend</p>
          <p className="text-[#4A4A4A] text-xs">In local currency</p>
        </div>
      </div>

      {/* Explanation */}
      <div className="mt-6 p-4 bg-[#F4F6FC] rounded-xl border border-[#8A2BE2]/10">
        <ul className="space-y-2 text-[#4A4A4A] text-xs">
          <li className="flex items-start gap-2">
            <span className="text-[#8A2BE2]">•</span>
            You hold gold in grams in your Card Wallet
          </li>
          <li className="flex items-start gap-2">
            <span className="text-[#8A2BE2]">•</span>
            When spending in USD/EUR/AED/Local currency, system converts fractions of gold → fiat at live market price
          </li>
          <li className="flex items-start gap-2">
            <span className="text-[#8A2BE2]">•</span>
            Executes card payment instantly and posts debit transaction to Card Wallet
          </li>
        </ul>
      </div>
    </motion.div>
  );
}