import React from 'react';
import { motion } from 'framer-motion';
import { TrendingDown, ExternalLink } from 'lucide-react';
import { Button } from "@/components/ui/button";

const transactions = [
  { id: 1, date: '10 Jan 2026', merchant: 'Apple Store', location: 'Dubai, UAE', currency: 'AED', goldDebited: 0.2374, spotPrice: 58.00, fiatAmount: 13.77, fxRate: 3.67 },
  { id: 2, date: '09 Jan 2026', merchant: 'Emirates NBD ATM', location: 'Dubai, UAE', currency: 'AED', goldDebited: 1.7200, spotPrice: 57.80, fiatAmount: 99.42, fxRate: 3.67 },
  { id: 3, date: '08 Jan 2026', merchant: 'Carrefour', location: 'Abu Dhabi, UAE', currency: 'AED', goldDebited: 0.4521, spotPrice: 57.90, fiatAmount: 26.18, fxRate: 3.67 },
  { id: 4, date: '07 Jan 2026', merchant: 'Amazon EU', location: 'Luxembourg', currency: 'EUR', goldDebited: 0.8643, spotPrice: 58.10, fiatAmount: 50.21, fxRate: 0.92 },
  { id: 5, date: '05 Jan 2026', merchant: 'Uber', location: 'London, UK', currency: 'GBP', goldDebited: 0.3156, spotPrice: 57.75, fiatAmount: 18.23, fxRate: 0.79 },
];

export default function TransactionsTable() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.4 }}
      className="bg-white border border-[#8A2BE2]/20 rounded-2xl p-6 shadow-sm"
    >
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-[#0D0D0D] font-medium">Recent Transactions</h3>
        <Button variant="ghost" className="text-[#FF2FBF] text-sm hover:bg-[#8A2BE2]/10">
          View Full Statement
          <ExternalLink className="w-3 h-3 ml-1" />
        </Button>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="text-left text-[#4A4A4A] text-[10px] uppercase tracking-wider border-b border-[#8A2BE2]/10">
              <th className="pb-3 pr-4">Date</th>
              <th className="pb-3 pr-4">Merchant</th>
              <th className="pb-3 pr-4">Location</th>
              <th className="pb-3 pr-4 text-right">Gold Debited</th>
              <th className="pb-3 pr-4 text-right">Spot Price</th>
              <th className="pb-3 pr-4 text-right">Fiat Amount</th>
              <th className="pb-3 text-right">FX Rate</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#8A2BE2]/10">
            {transactions.map(tx => (
              <tr key={tx.id} className="text-sm hover:bg-[#F4F6FC] transition-colors">
                <td className="py-4 pr-4 text-[#4A4A4A]">{tx.date}</td>
                <td className="py-4 pr-4 text-[#0D0D0D]">{tx.merchant}</td>
                <td className="py-4 pr-4 text-[#4A4A4A]">{tx.location}</td>
                <td className="py-4 pr-4 text-right">
                  <div className="flex items-center justify-end gap-1">
                    <TrendingDown className="w-3 h-3 text-red-400" />
                    <span className="text-red-400">-{tx.goldDebited.toFixed(4)} g</span>
                  </div>
                </td>
                <td className="py-4 pr-4 text-right text-[#4A4A4A]">${tx.spotPrice.toFixed(2)}/g</td>
                <td className="py-4 pr-4 text-right">
                  <span className="text-[#0D0D0D] font-medium">
                    {tx.currency === 'AED' && 'د.إ'}
                    {tx.currency === 'EUR' && '€'}
                    {tx.currency === 'GBP' && '£'}
                    {tx.currency === 'USD' && '$'}
                    {tx.fiatAmount.toFixed(2)}
                  </span>
                </td>
                <td className="py-4 text-right text-[#4A4A4A] text-xs">{tx.fxRate}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </motion.div>
  );
}