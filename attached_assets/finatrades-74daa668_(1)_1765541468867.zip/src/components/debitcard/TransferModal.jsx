import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ArrowRight, Info, Loader2, CheckCircle } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

export default function TransferModal({ isOpen, onClose, availableGold, goldPrice, onConfirm }) {
  const [amount, setAmount] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const amountNum = parseFloat(amount) || 0;
  const ozEquivalent = amountNum / 31.1035;
  const usdValue = amountNum * goldPrice;
  const aedValue = usdValue * 3.67;

  const handleConfirm = async () => {
    if (amountNum <= 0 || amountNum > availableGold) return;
    
    setIsLoading(true);
    await new Promise(r => setTimeout(r, 1500));
    onConfirm(amountNum);
    setAmount('');
    setIsLoading(false);
    toast.success('Added to Card Wallet', {
      description: `${amountNum.toFixed(4)}g transferred successfully`
    });
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          onClick={e => e.stopPropagation()}
          className="w-full max-w-md bg-gradient-to-b from-[#1a0a2e] to-[#0d0515] border border-[#d1a954]/20 rounded-2xl overflow-hidden"
        >
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-white/5">
            <div>
              <h2 className="text-lg font-semibold text-white">Transfer Gold to Card Wallet</h2>
              <p className="text-white/40 text-xs">Convert gold for card spending</p>
            </div>
            <button onClick={onClose} className="text-white/40 hover:text-white transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Content */}
          <div className="p-6 space-y-6">
            {/* Available Balance */}
            <div className="bg-black/30 rounded-xl p-4">
              <p className="text-white/40 text-xs uppercase tracking-wider mb-1">Available Gold</p>
              <p className="text-2xl font-light text-white">{availableGold.toFixed(4)} <span className="text-base text-white/50">g</span></p>
            </div>

            {/* Amount Input */}
            <div>
              <label className="block text-white/60 text-sm mb-2">Amount to Transfer (g)</label>
              <Input
                type="number"
                placeholder="0.0000"
                value={amount}
                onChange={e => setAmount(e.target.value)}
                className="bg-black/30 border-[#d1a954]/20 text-white text-lg h-14 focus:border-[#d1a954]/50"
                step="0.0001"
                max={availableGold}
              />
              <div className="flex justify-between mt-2">
                <button 
                  onClick={() => setAmount((availableGold * 0.25).toFixed(4))}
                  className="text-[#d1a954]/60 text-xs hover:text-[#d1a954]"
                >
                  25%
                </button>
                <button 
                  onClick={() => setAmount((availableGold * 0.5).toFixed(4))}
                  className="text-[#d1a954]/60 text-xs hover:text-[#d1a954]"
                >
                  50%
                </button>
                <button 
                  onClick={() => setAmount((availableGold * 0.75).toFixed(4))}
                  className="text-[#d1a954]/60 text-xs hover:text-[#d1a954]"
                >
                  75%
                </button>
                <button 
                  onClick={() => setAmount(availableGold.toFixed(4))}
                  className="text-[#d1a954]/60 text-xs hover:text-[#d1a954]"
                >
                  Max
                </button>
              </div>
            </div>

            {/* Conversion Display */}
            {amountNum > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-[#d1a954]/5 border border-[#d1a954]/20 rounded-xl p-4 space-y-2"
              >
                <div className="flex justify-between text-sm">
                  <span className="text-white/50">≈ Ounces</span>
                  <span className="text-white">{ozEquivalent.toFixed(6)} oz</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-white/50">≈ Market Value (USD)</span>
                  <span className="text-[#d1a954]">${usdValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-white/50">≈ AED Equivalent</span>
                  <span className="text-white">د.إ{aedValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                </div>
              </motion.div>
            )}

            {/* Note */}
            <div className="flex gap-2 p-3 bg-white/[0.02] rounded-lg">
              <Info className="w-4 h-4 text-[#d1a954] flex-shrink-0 mt-0.5" />
              <p className="text-white/40 text-xs leading-relaxed">
                Gold transferred will be converted into card spending balance when you tap, swipe, or pay online. It is not sold until actual usage.
              </p>
            </div>

            {/* Actions */}
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={onClose}
                className="flex-1 border-white/10 text-white/60 hover:bg-white/5 py-5"
              >
                Cancel
              </Button>
              <Button
                onClick={handleConfirm}
                disabled={amountNum <= 0 || amountNum > availableGold || isLoading}
                className="flex-1 bg-gradient-to-r from-[#d1a954] to-[#b8963e] text-black font-semibold py-5 disabled:opacity-50"
              >
                {isLoading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <>
                    Confirm Transfer
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </>
                )}
              </Button>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}