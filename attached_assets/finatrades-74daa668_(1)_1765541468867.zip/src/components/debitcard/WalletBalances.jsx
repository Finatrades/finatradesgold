import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Wallet, CreditCard, ArrowRight, ChevronDown } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function WalletBalances({ finaPayBalance, cardWalletBalance, goldPrice, onTransferClick }) {
  const [baseCurrency, setBaseCurrency] = useState('USD');
  
  const fxRates = {
    USD: 1,
    EUR: 0.92,
    AED: 3.67
  };

  const convertedBalance = cardWalletBalance.spendingBalanceUSD * fxRates[baseCurrency];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.1 }}
    >
      <div className="grid md:grid-cols-2 gap-3 sm:gap-6">
        {/* FinaPay Wallet */}
        <div className="bg-white/[0.02] backdrop-blur-xl border border-[#d1a954]/20 rounded-xl sm:rounded-2xl p-3 sm:p-6">
          <div className="flex items-center gap-2 sm:gap-3 mb-3 sm:mb-6">
            <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg sm:rounded-xl bg-gradient-to-br from-[#d1a954]/20 to-[#d1a954]/5 flex items-center justify-center border border-[#d1a954]/20">
              <Wallet className="w-4 h-4 sm:w-5 sm:h-5 text-[#d1a954]" />
            </div>
            <div>
              <h3 className="text-[#0D0D0D] font-medium text-sm sm:text-base">FinaPay Wallet</h3>
              <p className="text-[#4A4A4A] text-[10px] sm:text-xs">Source Balance</p>
            </div>
          </div>

          <div className="space-y-3 sm:space-y-4">
            <div>
              <p className="text-[#4A4A4A] text-[10px] sm:text-xs uppercase tracking-wider mb-1">Gold Balance</p>
              <p className="text-xl sm:text-3xl font-light text-[#0D0D0D]">{finaPayBalance.goldGrams.toFixed(4)} <span className="text-sm sm:text-lg text-[#4A4A4A]">g</span></p>
            </div>

            <div className="grid grid-cols-2 gap-2 sm:gap-4">
              <div className="bg-[#F4F6FC] rounded-lg sm:rounded-xl p-2 sm:p-3 border border-[#8A2BE2]/10">
                <p className="text-[#4A4A4A] text-[9px] sm:text-[10px] uppercase tracking-wider mb-1">Value (USD)</p>
                <p className="text-[#0D0D0D] font-medium text-xs sm:text-base">${finaPayBalance.goldValueUSD.toLocaleString()}</p>
              </div>
              <div className="bg-[#F4F6FC] rounded-lg sm:rounded-xl p-2 sm:p-3 border border-[#8A2BE2]/10">
                <p className="text-[#4A4A4A] text-[9px] sm:text-[10px] uppercase tracking-wider mb-1">Value (AED)</p>
                <p className="text-[#0D0D0D] font-medium text-xs sm:text-base">د.إ{finaPayBalance.goldValueAED.toLocaleString()}</p>
              </div>
            </div>

            <div className="pt-1 sm:pt-2">
              <p className="text-[#4A4A4A] text-[9px] sm:text-[10px]">Available for transfer to Card Wallet</p>
            </div>
          </div>
        </div>

        {/* Debit Card Wallet */}
        <div className="bg-white/[0.02] backdrop-blur-xl border border-[#d1a954]/20 rounded-xl sm:rounded-2xl p-3 sm:p-6">
          <div className="flex items-center justify-between mb-3 sm:mb-6">
            <div className="flex items-center gap-2 sm:gap-3">
              <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg sm:rounded-xl bg-gradient-to-br from-[#d1a954]/20 to-[#d1a954]/5 flex items-center justify-center border border-[#d1a954]/20">
                <CreditCard className="w-4 h-4 sm:w-5 sm:h-5 text-[#d1a954]" />
              </div>
              <div>
                <h3 className="text-[#0D0D0D] font-medium text-sm sm:text-base">Debit Card Wallet</h3>
                <p className="text-[#4A4A4A] text-[10px] sm:text-xs">Spending Balance</p>
              </div>
            </div>
            <Select value={baseCurrency} onValueChange={setBaseCurrency}>
              <SelectTrigger className="w-16 sm:w-24 bg-[#F4F6FC] border-[#8A2BE2]/20 text-[#0D0D0D] text-xs sm:text-sm h-8 sm:h-10">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-white border-[#8A2BE2]/20">
                <SelectItem value="USD">USD</SelectItem>
                <SelectItem value="EUR">EUR</SelectItem>
                <SelectItem value="AED">AED</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-3 sm:space-y-4">
            <div>
              <p className="text-[#4A4A4A] text-[10px] sm:text-xs uppercase tracking-wider mb-1">Spending Balance</p>
              <p className="text-xl sm:text-3xl font-light text-amber-600">
                {baseCurrency === 'USD' && '$'}
                {baseCurrency === 'EUR' && '€'}
                {baseCurrency === 'AED' && 'د.إ'}
                {convertedBalance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </p>
            </div>

            <div className="grid grid-cols-2 gap-2 sm:gap-4">
              <div className="bg-[#F4F6FC] rounded-lg sm:rounded-xl p-2 sm:p-3 border border-[#8A2BE2]/10">
                <p className="text-[#4A4A4A] text-[9px] sm:text-[10px] uppercase tracking-wider mb-1">Gold Equivalent</p>
                <p className="text-[#0D0D0D] font-medium text-xs sm:text-base">{cardWalletBalance.goldGrams.toFixed(4)} g</p>
              </div>
              <div className="bg-[#F4F6FC] rounded-lg sm:rounded-xl p-2 sm:p-3 border border-[#8A2BE2]/10">
                <p className="text-[#4A4A4A] text-[9px] sm:text-[10px] uppercase tracking-wider mb-1">Live FX Rate</p>
                <p className="text-[#0D0D0D] font-medium text-xs sm:text-base">1 USD = {fxRates[baseCurrency]}</p>
              </div>
            </div>

            <Button 
              onClick={onTransferClick}
              className="w-full bg-gradient-to-r from-[#d1a954] to-[#b8963e] text-black font-semibold py-3 sm:py-5 rounded-lg sm:rounded-xl hover:shadow-[0_0_20px_rgba(209,169,84,0.3)] transition-all text-sm"
            >
              Transfer to Card Wallet
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </div>
      </div>

      <p className="text-center text-[#4A4A4A] text-[10px] sm:text-xs mt-3 sm:mt-4">
        Your card draws funds from your Card Wallet, not directly from FinaPay.
      </p>
    </motion.div>
  );
}