import React from 'react';
import { motion } from 'framer-motion';
import { Shield, ExternalLink } from 'lucide-react';
import { Button } from "@/components/ui/button";

export default function ComplianceCard() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.6 }}
      className="bg-white border border-[#8A2BE2]/20 rounded-2xl p-6 shadow-sm"
    >
      <div className="flex items-start gap-4">
        <div className="w-10 h-10 rounded-xl bg-[#8A2BE2]/10 flex items-center justify-center flex-shrink-0">
          <Shield className="w-5 h-5 text-[#8A2BE2]" />
        </div>
        <div className="flex-1">
          <h3 className="text-[#0D0D0D] font-medium mb-3">Important Information</h3>
          <ul className="space-y-2 text-[#4A4A4A] text-xs leading-relaxed">
            <li>• You are using real physical gold value as spending balance.</li>
            <li>• Conversion occurs only when you spend.</li>
            <li>• This is not a bank account, not a deposit, not savings, and not an investment product.</li>
            <li>• Gold is held in FinaVault, card operations are executed via licensed card issuer(s).</li>
            <li>• FX rates and gold spot pricing fluctuate.</li>
            <li>• Network fees and FX spread may apply.</li>
          </ul>
          <Button 
            variant="ghost" 
            className="text-[#FF2FBF] text-xs mt-4 p-0 h-auto hover:bg-transparent hover:underline"
          >
            Read Full Terms
            <ExternalLink className="w-3 h-3 ml-1" />
          </Button>
        </div>
      </div>
    </motion.div>
  );
}