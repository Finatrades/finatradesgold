import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Lock, Unlock, Banknote, Wifi, Globe, ShoppingBag, 
  Gauge, FileText, Key, AlertTriangle, RefreshCw, Shield, Edit2, Check, X, Clock
} from 'lucide-react';
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";

export default function CardControls() {
  const [controls, setControls] = useState({
    frozen: false,
    tempLocked: false,
    atmEnabled: true,
    contactless: true,
    onlinePayments: true,
    internationalUse: true
  });

  const [limits, setLimits] = useState({
    daily: 5000,
    monthly: 25000
  });

  const [editingLimit, setEditingLimit] = useState(null);
  const [tempLimitValue, setTempLimitValue] = useState('');

  // Current spending (mock data)
  const currentSpending = {
    daily: 3750,
    monthly: 18500
  };

  const dailyPercentage = Math.min((currentSpending.daily / limits.daily) * 100, 100);
  const monthlyPercentage = Math.min((currentSpending.monthly / limits.monthly) * 100, 100);

  const getProgressColor = (percentage) => {
    if (percentage >= 90) return 'bg-red-500';
    if (percentage >= 75) return 'bg-amber-500';
    return 'bg-emerald-500';
  };

  const getAlertLevel = (percentage) => {
    if (percentage >= 90) return { show: true, type: 'critical', color: 'text-red-400 bg-red-500/20 border-red-500/30', message: 'Limit almost reached!' };
    if (percentage >= 75) return { show: true, type: 'warning', color: 'text-amber-400 bg-amber-500/20 border-amber-500/30', message: 'High usage' };
    return { show: false };
  };

  const handleEditLimit = (type) => {
    setEditingLimit(type);
    setTempLimitValue(limits[type].toString());
  };

  const handleSaveLimit = (type) => {
    const value = parseInt(tempLimitValue);
    if (value && value > 0) {
      setLimits(prev => ({ ...prev, [type]: value }));
    }
    setEditingLimit(null);
    setTempLimitValue('');
  };

  const handleCancelEdit = () => {
    setEditingLimit(null);
    setTempLimitValue('');
  };

  const toggleControl = (key) => {
    setControls(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const dailyAlert = getAlertLevel(dailyPercentage);
  const monthlyAlert = getAlertLevel(monthlyPercentage);

  const controlItems = [
    { key: 'atmEnabled', label: 'ATM Withdrawal', description: 'Allow cash withdrawals from ATMs', icon: Banknote },
    { key: 'contactless', label: 'Contactless Payments', description: 'Tap to pay enabled', icon: Wifi },
    { key: 'onlinePayments', label: 'Online Payments', description: 'E-commerce and subscriptions', icon: ShoppingBag },
    { key: 'internationalUse', label: 'International Use', description: 'Cross-border transactions', icon: Globe },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
      className="bg-white border border-[#8A2BE2]/20 rounded-xl sm:rounded-2xl p-3 sm:p-6 shadow-sm"
    >
      <h3 className="text-[#0D0D0D] font-medium mb-3 sm:mb-6 text-sm sm:text-base">Card Controls</h3>

      {/* Temporary Lock Banner */}
      <AnimatePresence>
        {controls.tempLocked && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="mb-3 sm:mb-6 bg-amber-500/20 border border-amber-500/30 rounded-lg sm:rounded-xl p-2.5 sm:p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2"
          >
            <div className="flex items-center gap-2 sm:gap-3">
              <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-amber-500/30 flex items-center justify-center">
                <Clock className="w-4 h-4 sm:w-5 sm:h-5 text-amber-400" />
              </div>
              <div>
                <p className="text-amber-600 font-medium text-xs sm:text-base">Card Temporarily Locked</p>
                <p className="text-amber-600/60 text-[10px] sm:text-xs">All transactions disabled</p>
              </div>
            </div>
            <Button
              onClick={() => setControls(prev => ({ ...prev, tempLocked: false }))}
              className="bg-amber-500 hover:bg-amber-600 text-black font-medium text-xs sm:text-sm h-8 sm:h-10 w-full sm:w-auto"
            >
              <Unlock className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
              Unlock Now
            </Button>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid md:grid-cols-2 gap-3 sm:gap-6">
        {/* Left Column - Controls */}
        <div className="space-y-2 sm:space-y-4">
          {/* Temporary Lock Card */}
          <div 
            className={`p-2.5 sm:p-4 rounded-lg sm:rounded-xl border transition-all ${
            controls.tempLocked
              ? 'bg-amber-500/10 border-amber-500/30'
              : 'bg-[#F4F6FC] border-[#8A2BE2]/10 hover:border-[#8A2BE2]/30'
            }`}
          >
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 sm:gap-3 min-w-0">
                <div className={`w-8 h-8 sm:w-10 sm:h-10 rounded-md sm:rounded-lg flex items-center justify-center flex-shrink-0 ${
                  controls.tempLocked ? 'bg-amber-500/20' : 'bg-amber-500/10'
                }`}>
                  {controls.tempLocked ? (
                    <Lock className="w-4 h-4 sm:w-5 sm:h-5 text-amber-600" />
                  ) : (
                    <Shield className="w-4 h-4 sm:w-5 sm:h-5 text-amber-600" />
                  )}
                </div>
                <div className="min-w-0">
                  <p className="text-[#0D0D0D] text-xs sm:text-sm font-medium">Temporary Lock</p>
                  <p className="text-[#4A4A4A] text-[10px] sm:text-xs truncate">Quick, reversible disable</p>
                </div>
              </div>
              <Button
                variant={controls.tempLocked ? "default" : "outline"}
                size="sm"
                onClick={() => toggleControl('tempLocked')}
                className={`text-[10px] sm:text-sm h-7 sm:h-9 px-2 sm:px-3 flex-shrink-0 ${controls.tempLocked 
                  ? "bg-amber-500 hover:bg-amber-600 text-white" 
                  : "border-[#8A2BE2]/30 text-[#FF2FBF] hover:bg-[#8A2BE2]/10"
                }`}
              >
                {controls.tempLocked ? 'Unlock' : 'Lock'}
              </Button>
            </div>
          </div>

          {/* Permanent Freeze */}
          <div 
            className={`flex items-center justify-between p-2.5 sm:p-4 rounded-lg sm:rounded-xl border transition-all gap-2 ${
              controls.frozen
                ? 'bg-red-500/10 border-red-500/30'
                : 'bg-[#F4F6FC] border-[#8A2BE2]/10 hover:border-[#8A2BE2]/30'
            }`}
          >
            <div className="flex items-center gap-2 sm:gap-3 min-w-0">
              <div className={`w-8 h-8 sm:w-10 sm:h-10 rounded-md sm:rounded-lg flex items-center justify-center flex-shrink-0 ${
                controls.frozen ? 'bg-red-500/20' : 'bg-amber-500/10'
              }`}>
                <Lock className={`w-4 h-4 sm:w-5 sm:h-5 ${controls.frozen ? 'text-red-600' : 'text-amber-600'}`} />
              </div>
              <div className="min-w-0">
                <p className="text-[#0D0D0D] text-xs sm:text-sm font-medium">Freeze Card</p>
                <p className="text-[#4A4A4A] text-[10px] sm:text-xs truncate">Permanently disable</p>
              </div>
            </div>
            <Switch
              checked={controls.frozen}
              onCheckedChange={() => toggleControl('frozen')}
              className="data-[state=checked]:bg-red-500 flex-shrink-0"
            />
          </div>

          {/* Other Controls */}
          {controlItems.map(item => (
            <div 
              key={item.key}
              className="flex items-center justify-between p-2.5 sm:p-4 rounded-lg sm:rounded-xl border bg-[#F4F6FC] border-[#8A2BE2]/10 hover:border-[#8A2BE2]/30 transition-all gap-2"
            >
              <div className="flex items-center gap-2 sm:gap-3 min-w-0">
                <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-md sm:rounded-lg flex items-center justify-center bg-amber-500/10 flex-shrink-0">
                  <item.icon className="w-4 h-4 sm:w-5 sm:h-5 text-amber-600" />
                </div>
                <div className="min-w-0">
                  <p className="text-[#0D0D0D] text-xs sm:text-sm font-medium">{item.label}</p>
                  <p className="text-[#4A4A4A] text-[10px] sm:text-xs truncate hidden sm:block">{item.description}</p>
                </div>
              </div>
              <Switch
                checked={controls[item.key]}
                onCheckedChange={() => toggleControl(item.key)}
                className="data-[state=checked]:bg-amber-600 flex-shrink-0"
                disabled={controls.frozen || controls.tempLocked}
              />
            </div>
          ))}
        </div>

        {/* Right Column - Limits & Actions */}
        <div className="space-y-3 sm:space-y-4">
          {/* Spend Limits with Progress */}
          <div className="bg-[#F4F6FC] border border-[#8A2BE2]/10 rounded-lg sm:rounded-xl p-2.5 sm:p-4">
            <div className="flex items-center gap-2 mb-3 sm:mb-4">
              <Gauge className="w-4 h-4 sm:w-5 sm:h-5 text-[#8A2BE2]" />
              <p className="text-[#0D0D0D] font-medium text-xs sm:text-base">Spend Limits</p>
            </div>

            {/* Daily Limit */}
            <div className="mb-4 sm:mb-5">
              <div className="flex items-center justify-between mb-2">
                <label className="text-[#4A4A4A] text-[10px] sm:text-sm">Daily Limit</label>
                {editingLimit === 'daily' ? (
                  <div className="flex items-center gap-1 sm:gap-2">
                    <Input
                      type="number"
                      value={tempLimitValue}
                      onChange={e => setTempLimitValue(e.target.value)}
                      className="w-16 sm:w-24 h-6 sm:h-7 bg-white border-[#8A2BE2]/30 text-[#0D0D0D] text-xs sm:text-sm"
                      autoFocus
                    />
                    <button onClick={() => handleSaveLimit('daily')} className="text-green-600 hover:text-green-700">
                      <Check className="w-3 h-3 sm:w-4 sm:h-4" />
                    </button>
                    <button onClick={handleCancelEdit} className="text-red-400 hover:text-red-300">
                      <X className="w-3 h-3 sm:w-4 sm:h-4" />
                    </button>
                  </div>
                ) : (
                  <button 
                    onClick={() => handleEditLimit('daily')}
                    className="flex items-center gap-1 text-[#FF2FBF] hover:text-[#FF2FBF]/80 text-[10px] sm:text-sm"
                  >
                    ${limits.daily.toLocaleString()}
                    <Edit2 className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
                  </button>
                )}
              </div>
              <div className="relative">
                <div className="h-1.5 sm:h-2 bg-gray-200 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${dailyPercentage}%` }}
                    className={`h-full rounded-full ${getProgressColor(dailyPercentage)}`}
                  />
                </div>
                <div className="flex items-center justify-between mt-1">
                  <span className="text-[#4A4A4A] text-[9px] sm:text-xs">${currentSpending.daily.toLocaleString()} spent</span>
                  <span className="text-[#4A4A4A] text-[9px] sm:text-xs">{dailyPercentage.toFixed(0)}%</span>
                </div>
              </div>
              <AnimatePresence>
                {dailyAlert.show && (
                  <motion.div
                    initial={{ opacity: 0, y: -5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -5 }}
                    className={`mt-1.5 sm:mt-2 px-2 sm:px-3 py-1 sm:py-1.5 rounded-md sm:rounded-lg border text-[9px] sm:text-xs flex items-center gap-1 sm:gap-2 ${dailyAlert.color}`}
                  >
                    <AlertTriangle className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
                    {dailyAlert.message}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Monthly Limit */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-[#4A4A4A] text-[10px] sm:text-sm">Monthly Limit</label>
                {editingLimit === 'monthly' ? (
                  <div className="flex items-center gap-1 sm:gap-2">
                    <Input
                      type="number"
                      value={tempLimitValue}
                      onChange={e => setTempLimitValue(e.target.value)}
                      className="w-16 sm:w-24 h-6 sm:h-7 bg-white border-[#8A2BE2]/30 text-[#0D0D0D] text-xs sm:text-sm"
                      autoFocus
                    />
                    <button onClick={() => handleSaveLimit('monthly')} className="text-green-600 hover:text-green-700">
                      <Check className="w-3 h-3 sm:w-4 sm:h-4" />
                    </button>
                    <button onClick={handleCancelEdit} className="text-red-400 hover:text-red-300">
                      <X className="w-3 h-3 sm:w-4 sm:h-4" />
                    </button>
                  </div>
                ) : (
                  <button 
                    onClick={() => handleEditLimit('monthly')}
                    className="flex items-center gap-1 text-[#FF2FBF] hover:text-[#FF2FBF]/80 text-[10px] sm:text-sm"
                  >
                    ${limits.monthly.toLocaleString()}
                    <Edit2 className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
                  </button>
                )}
              </div>
              <div className="relative">
                <div className="h-1.5 sm:h-2 bg-gray-200 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${monthlyPercentage}%` }}
                    className={`h-full rounded-full ${getProgressColor(monthlyPercentage)}`}
                  />
                </div>
                <div className="flex items-center justify-between mt-1">
                  <span className="text-[#4A4A4A] text-[9px] sm:text-xs">${currentSpending.monthly.toLocaleString()} spent</span>
                  <span className="text-[#4A4A4A] text-[9px] sm:text-xs">{monthlyPercentage.toFixed(0)}%</span>
                </div>
              </div>
              <AnimatePresence>
                {monthlyAlert.show && (
                  <motion.div
                    initial={{ opacity: 0, y: -5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -5 }}
                    className={`mt-1.5 sm:mt-2 px-2 sm:px-3 py-1 sm:py-1.5 rounded-md sm:rounded-lg border text-[9px] sm:text-xs flex items-center gap-1 sm:gap-2 ${monthlyAlert.color}`}
                  >
                    <AlertTriangle className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
                    {monthlyAlert.message}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-2 gap-1.5 sm:gap-3">
            <Button variant="outline" className="border-[#8A2BE2]/20 text-[#4A4A4A] hover:bg-[#8A2BE2]/10 h-auto py-2 sm:py-3 flex-col">
              <FileText className="w-3 h-3 sm:w-4 sm:h-4 mb-0.5 sm:mb-1" />
              <span className="text-[9px] sm:text-xs">Statement</span>
            </Button>
            <Button variant="outline" className="border-[#8A2BE2]/20 text-[#4A4A4A] hover:bg-[#8A2BE2]/10 h-auto py-2 sm:py-3 flex-col">
              <Key className="w-3 h-3 sm:w-4 sm:h-4 mb-0.5 sm:mb-1" />
              <span className="text-[9px] sm:text-xs">Change PIN</span>
            </Button>
            <Button variant="outline" className="border-[#8A2BE2]/20 text-[#4A4A4A] hover:bg-[#8A2BE2]/10 h-auto py-2 sm:py-3 flex-col">
              <AlertTriangle className="w-3 h-3 sm:w-4 sm:h-4 mb-0.5 sm:mb-1" />
              <span className="text-[9px] sm:text-xs">Report Lost</span>
            </Button>
            <Button variant="outline" className="border-[#8A2BE2]/20 text-[#4A4A4A] hover:bg-[#8A2BE2]/10 h-auto py-2 sm:py-3 flex-col">
              <RefreshCw className="w-3 h-3 sm:w-4 sm:h-4 mb-0.5 sm:mb-1" />
              <span className="text-[9px] sm:text-xs">Replace</span>
            </Button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}