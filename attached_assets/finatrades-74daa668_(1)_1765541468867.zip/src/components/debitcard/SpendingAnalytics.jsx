import React from 'react';
import { motion } from 'framer-motion';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend } from 'recharts';

const regionData = [
  { name: 'UAE', value: 45, color: '#d1a954' },
  { name: 'EU', value: 30, color: '#8A2BE2' },
  { name: 'Asia', value: 20, color: '#FF2FBF' },
  { name: 'US', value: 5, color: '#3b82f6' },
];

const categoryData = [
  { name: 'Retail', value: 35, color: '#d1a954' },
  { name: 'Travel', value: 25, color: '#8A2BE2' },
  { name: 'Food', value: 20, color: '#FF2FBF' },
  { name: 'Subscriptions', value: 12, color: '#3b82f6' },
  { name: 'ATM', value: 8, color: '#10b981' },
];

export default function SpendingAnalytics() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.5 }}
    >
      <h3 className="text-[#0D0D0D] font-medium mb-4">Spending Analytics</h3>
      
      <div className="grid md:grid-cols-2 gap-6">
        {/* By Region */}
        <div className="bg-white border border-[#8A2BE2]/20 rounded-2xl p-6 shadow-sm">
          <p className="text-[#4A4A4A] text-sm mb-4">Spending by Region</p>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={regionData}
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={70}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {regionData.map((entry, index) => (
                    <Cell key={index} fill={entry.color} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex flex-wrap justify-center gap-4 mt-4">
            {regionData.map(item => (
              <div key={item.name} className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
                <span className="text-[#4A4A4A] text-xs">{item.name} {item.value}%</span>
              </div>
            ))}
          </div>
        </div>

        {/* By Category */}
        <div className="bg-white border border-[#8A2BE2]/20 rounded-2xl p-6 shadow-sm">
          <p className="text-[#4A4A4A] text-sm mb-4">Spending by Category</p>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={70}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={index} fill={entry.color} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex flex-wrap justify-center gap-4 mt-4">
            {categoryData.map(item => (
              <div key={item.name} className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
                <span className="text-[#4A4A4A] text-xs">{item.name} {item.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <p className="text-center text-[#4A4A4A] text-xs mt-4">
        All spending converted from gold in grams at point-of-sale price.
      </p>
    </motion.div>
  );
}