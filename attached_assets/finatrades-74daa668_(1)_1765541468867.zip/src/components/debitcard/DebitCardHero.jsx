import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Wifi, Shield, CreditCard } from 'lucide-react';

export default function DebitCardHero({ userName }) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="text-center"
    >
      {/* 3D Card */}
      <div className="relative w-full max-w-[280px] sm:max-w-md mx-auto mb-4 sm:mb-8 perspective-1000">
        {/* Glow effect */}
        <motion.div
          className="absolute inset-0 rounded-xl sm:rounded-2xl"
          animate={{
            boxShadow: isHovered 
              ? '0 0 80px rgba(209,169,84,0.4), 0 0 120px rgba(209,169,84,0.2)'
              : '0 0 40px rgba(209,169,84,0.2), 0 0 60px rgba(209,169,84,0.1)'
          }}
          transition={{ duration: 0.5 }}
        />

        {/* Card */}
        <motion.div
          className="relative aspect-[1.6/1] rounded-xl sm:rounded-2xl overflow-hidden cursor-pointer"
          style={{ transformStyle: 'preserve-3d' }}
          animate={{
            rotateY: isHovered ? 8 : 0,
            rotateX: isHovered ? -5 : 0,
            y: [0, -8, 0],
          }}
          whileHover={{ scale: 1.02 }}
          onHoverStart={() => setIsHovered(true)}
          onHoverEnd={() => setIsHovered(false)}
          transition={{ 
            rotateY: { duration: 0.4 },
            rotateX: { duration: 0.4 },
            y: { duration: 3, repeat: Infinity, ease: "easeInOut" }
          }}
        >
          {/* Card background */}
          <div className="absolute inset-0 bg-gradient-to-br from-[#1a1a1a] via-[#0d0d0d] to-[#000000]" />
          
          {/* Gold border */}
          <div className="absolute inset-0 rounded-xl sm:rounded-2xl border border-[#d1a954]/40" />
          
          {/* Shine effect */}
          <motion.div
            className="absolute inset-0 bg-gradient-to-r from-transparent via-[#d1a954]/10 to-transparent"
            animate={{ x: ['-200%', '200%'] }}
            transition={{ duration: 3, repeat: Infinity, repeatDelay: 2, ease: "easeInOut" }}
          />

          {/* Gold accent lines */}
          <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-[#d1a954]/50 to-transparent" />
          <div className="absolute bottom-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-[#d1a954]/30 to-transparent" />

          {/* Card Content */}
          <div className="relative h-full p-3 sm:p-6 flex flex-col justify-between">
            {/* Top */}
            <div className="flex items-start justify-between">
              <div>
                <p className="text-[#d1a954] text-sm sm:text-lg font-semibold tracking-wide">FinaCard</p>
                <p className="text-white/40 text-[8px] sm:text-[10px] tracking-widest uppercase">Gold Backed</p>
              </div>
              <motion.div animate={{ opacity: [0.5, 1, 0.5] }} transition={{ duration: 2, repeat: Infinity }}>
                <Wifi className="w-4 h-4 sm:w-6 sm:h-6 text-[#d1a954] rotate-90" />
              </motion.div>
            </div>

            {/* Chip */}
            <div className="flex items-center gap-2 sm:gap-4">
              <motion.div 
                className="relative w-8 h-6 sm:w-12 sm:h-10 rounded-md sm:rounded-lg overflow-hidden"
                animate={{ boxShadow: isHovered ? '0 0 15px rgba(209,169,84,0.5)' : '0 0 5px rgba(209,169,84,0.2)' }}
              >
                <div className="absolute inset-0 bg-gradient-to-br from-[#d1a954] to-[#b8963e]" />
                <div className="absolute inset-0 flex flex-col justify-center items-center gap-0.5 p-1">
                  {[...Array(4)].map((_, i) => <div key={i} className="w-full h-0.5 bg-[#0A0A0A]/30" />)}
                </div>
                <div className="absolute inset-1 sm:inset-2 bg-gradient-to-br from-[#f7d878] to-[#d1a954] rounded-sm" />
              </motion.div>
            </div>

            {/* Card Number */}
            <div className="flex gap-2 sm:gap-4">
              {[...Array(4)].map((_, groupIndex) => (
                <div key={groupIndex} className="flex gap-0.5 sm:gap-1">
                  {[...Array(4)].map((_, i) => (
                    <span key={i} className="text-xs sm:text-lg text-white/70 font-mono">•</span>
                  ))}
                </div>
              ))}
            </div>

            {/* Bottom */}
            <div className="flex items-end justify-between gap-1">
              <div className="min-w-0 flex-1">
                <p className="text-[7px] sm:text-[9px] text-white/40 uppercase tracking-wider mb-0.5">Card Holder</p>
                <p className="text-white font-light tracking-wide uppercase text-[9px] sm:text-sm truncate">{userName || 'FINATRADES USER'}</p>
              </div>
              <div className="text-right flex-shrink-0">
                <p className="text-[7px] sm:text-[9px] text-white/40 uppercase tracking-wider mb-0.5">Valid Thru</p>
                <p className="text-white font-light text-[9px] sm:text-sm">12/28</p>
              </div>
              <motion.div
                className="hidden sm:flex items-center gap-1 px-2 py-1 rounded-full bg-[#d1a954]/10 border border-[#d1a954]/30 flex-shrink-0"
                animate={{ borderColor: ['rgba(209,169,84,0.3)', 'rgba(209,169,84,0.6)', 'rgba(209,169,84,0.3)'] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <Shield className="w-3 h-3 text-[#d1a954]" />
                <span className="text-[9px] text-[#d1a954]">SECURE</span>
              </motion.div>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Tagline */}
      <h2 className="text-lg sm:text-2xl md:text-3xl font-light text-[#0D0D0D] mb-1 sm:mb-2">
        Spend Your Gold <span className="text-[#8A2BE2]">Anywhere</span>
      </h2>
      <p className="text-[#4A4A4A] text-xs sm:text-sm max-w-md mx-auto mb-2 sm:mb-4 px-4">
        Instant conversion of gold value at point of transaction.
      </p>
      <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-4 text-[#4A4A4A] text-[10px] sm:text-xs">
        <span className="flex items-center gap-1">
          <CreditCard className="w-3 h-3" /> POS
        </span>
        <span>•</span>
        <span>Online</span>
        <span>•</span>
        <span>ATM</span>
        <span className="hidden sm:inline">•</span>
        <span className="hidden sm:inline">Cross-Border</span>
      </div>
      <p className="text-[#4A4A4A]/60 text-[9px] sm:text-[10px] mt-2">Issuer: Licensed Partner Network</p>
    </motion.div>
  );
}