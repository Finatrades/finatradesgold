import React, { useRef, useState } from 'react';
import { motion, useInView, AnimatePresence } from 'framer-motion';
import { FileText, Award, Scale, Hash, MapPin, Leaf, Shield, Link2 } from 'lucide-react';

const documents = [
  { icon: FileText, name: "Assay Certificate", description: "Official certification of gold purity and composition" },
  { icon: Award, name: "Refinery License Info", description: "Accredited refinery credentials and certifications" },
  { icon: Scale, name: "Purity and Weight", description: "Precise measurement documentation (999.9 fineness)" },
  { icon: Hash, name: "Serial & Bar Numbers", description: "Unique identifiers for each gold bar" },
  { icon: MapPin, name: "Vault Location", description: "Secure storage facility details and coordinates" },
  { icon: Leaf, name: "Responsible Gold Confirmation", description: "Ethical sourcing and sustainability verification" },
  { icon: Shield, name: "Ownership Certificate", description: "Legal proof of gold ownership and title" },
  { icon: Link2, name: "Chain-of-Custody Report", description: "Complete tracking from refinery to vault" }
];

function DocumentCard({ doc, index, isActive, onClick }) {
  return (
    <motion.div
      initial={{ opacity: 0, x: 50, rotateY: -15 }}
      whileInView={{ opacity: 1, x: 0, rotateY: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      onClick={() => onClick(index)}
      className={`relative cursor-pointer transition-all duration-500 ${
        isActive ? 'z-20 scale-105' : 'z-10'
      }`}
      style={{
        transform: `translateX(${index * -20}px) translateZ(${isActive ? 50 : 0}px)`,
      }}
    >
      <motion.div
        className={`relative bg-gradient-to-br from-[#1A1A1A] to-[#0D0D0D] backdrop-blur-xl rounded-xl border p-6 min-w-[280px] transition-all duration-300 ${
          isActive 
            ? 'border-[#D4AF37] shadow-[0_0_40px_rgba(212,175,55,0.3)]' 
            : 'border-[#D4AF37]/20 hover:border-[#D4AF37]/50'
        }`}
        whileHover={{ y: -5 }}
      >
        {/* Gold accent line */}
        <div className={`absolute top-0 left-0 right-0 h-1 rounded-t-xl transition-all duration-300 ${
          isActive ? 'bg-gradient-to-r from-[#D4AF37] via-[#F7D878] to-[#D4AF37]' : 'bg-[#D4AF37]/30'
        }`} />

        {/* Icon */}
        <div className={`w-12 h-12 rounded-lg flex items-center justify-center mb-4 transition-all duration-300 ${
          isActive 
            ? 'bg-gradient-to-br from-[#D4AF37] to-[#B8860B]' 
            : 'bg-[#D4AF37]/10'
        }`}>
          <doc.icon className={`w-6 h-6 ${isActive ? 'text-black' : 'text-[#D4AF37]'}`} />
        </div>

        {/* Content */}
        <h4 className="text-lg font-light text-white mb-2">{doc.name}</h4>
        <p className="text-sm text-gray-400">{doc.description}</p>

        {/* Glow effect */}
        {isActive && (
          <motion.div
            className="absolute inset-0 rounded-xl bg-[#D4AF37]/5"
            animate={{ opacity: [0.3, 0.6, 0.3] }}
            transition={{ duration: 2, repeat: Infinity }}
          />
        )}
      </motion.div>
    </motion.div>
  );
}

export default function DocumentationModule() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });
  const [activeDoc, setActiveDoc] = useState(0);

  return (
    <section ref={ref} className="relative py-24 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_rgba(212,175,55,0.1)_0%,_transparent_50%)]" />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <p className="text-[#D4AF37] text-sm tracking-[0.3em] uppercase mb-4">Complete Documentation</p>
          <h2 className="text-4xl md:text-5xl font-extralight text-white mb-4">
            Verified Documentation. Zero Uncertainty.
          </h2>
          <div className="w-24 h-0.5 bg-gradient-to-r from-[#D4AF37] to-[#B8860B] mx-auto" />
        </motion.div>

        {/* Document cards - horizontal scroll on mobile */}
        <div className="overflow-x-auto pb-8 scrollbar-hide">
          <div className="flex gap-4 min-w-max px-4 lg:px-0 lg:grid lg:grid-cols-4 lg:min-w-0">
            {documents.map((doc, i) => (
              <DocumentCard
                key={i}
                doc={doc}
                index={i}
                isActive={activeDoc === i}
                onClick={setActiveDoc}
              />
            ))}
          </div>
        </div>

        {/* Tooltip */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.8 }}
          className="mt-12 text-center"
        >
          <div className="inline-flex items-center gap-3 px-6 py-4 rounded-xl bg-[#1A1A1A]/80 border border-[#D4AF37]/20 backdrop-blur-sm">
            <FileText className="w-5 h-5 text-[#D4AF37]" />
            <p className="text-gray-400">
              All documentation is downloadable and accepted by auditors, compliance teams, and trade counterparts.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}