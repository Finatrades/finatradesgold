import React, { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { CheckCircle, Building2, Ship, Handshake } from 'lucide-react';

const exporterBenefits = [
  "Verified gold worth from buyer",
  "Pre-shipment assurance",
  "Reduced default risk",
  "Stable settlement value",
  "Early shipment confidence"
];

const importerBenefits = [
  "Proof of ability to pay",
  "Avoid heavy upfront cash demand",
  "Lock value using gold worth",
  "Faster contract acceptance",
  "Lower currency exposure"
];

function BenefitColumn({ title, icon: Icon, benefits, delay, isInView }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, delay }}
      className="relative"
    >
      <div className="bg-gradient-to-br from-[#1A1A1A]/90 to-[#0D0D0D]/90 backdrop-blur-xl rounded-2xl border border-[#D4AF37]/20 p-8 h-full">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#D4AF37]/30 to-[#B8860B]/20 flex items-center justify-center">
            <Icon className="w-6 h-6 text-[#D4AF37]" />
          </div>
          <h3 className="text-2xl font-light text-white">{title}</h3>
        </div>

        {/* Benefits list */}
        <div className="space-y-4">
          {benefits.map((benefit, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -20 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ delay: delay + 0.1 + i * 0.1 }}
              className="flex items-start gap-3"
            >
              <CheckCircle className="w-5 h-5 text-[#D4AF37] flex-shrink-0 mt-0.5" />
              <span className="text-gray-300">{benefit}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}

function GoldenHandshake({ isInView }) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={isInView ? { opacity: 1, scale: 1 } : {}}
      transition={{ duration: 0.8, delay: 0.4 }}
      className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-20 hidden lg:block"
    >
      <div className="relative">
        {/* Glowing orb */}
        <motion.div
          className="w-24 h-24 rounded-full bg-gradient-to-br from-[#D4AF37] to-[#B8860B] flex items-center justify-center"
          animate={{
            boxShadow: [
              '0 0 30px rgba(212,175,55,0.4)',
              '0 0 60px rgba(212,175,55,0.6)',
              '0 0 30px rgba(212,175,55,0.4)'
            ]
          }}
          transition={{ duration: 3, repeat: Infinity }}
        >
          <Handshake className="w-10 h-10 text-black" />
        </motion.div>

        {/* Connecting lines */}
        <motion.div
          className="absolute top-1/2 -left-16 w-16 h-0.5 bg-gradient-to-r from-transparent to-[#D4AF37]"
          initial={{ scaleX: 0 }}
          animate={isInView ? { scaleX: 1 } : {}}
          transition={{ delay: 0.6, duration: 0.5 }}
          style={{ transformOrigin: 'right' }}
        />
        <motion.div
          className="absolute top-1/2 -right-16 w-16 h-0.5 bg-gradient-to-l from-transparent to-[#D4AF37]"
          initial={{ scaleX: 0 }}
          animate={isInView ? { scaleX: 1 } : {}}
          transition={{ delay: 0.6, duration: 0.5 }}
          style={{ transformOrigin: 'left' }}
        />
      </div>
    </motion.div>
  );
}

export default function BusinessExplanation() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });

  return (
    <section ref={ref} className="relative py-24 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_left,_rgba(212,175,55,0.08)_0%,_transparent_50%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_right,_rgba(184,134,11,0.08)_0%,_transparent_50%)]" />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <p className="text-[#D4AF37] text-sm tracking-[0.3em] uppercase mb-4">Real-World Application</p>
          <h2 className="text-4xl md:text-5xl font-extralight text-white mb-4">
            How Finatrades Supports Real-World Trade
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto mt-6">
            Finatrades simplifies assurance, stabilizes valuations, and enables evidence-backed settlement discussions between buyers and sellers.
          </p>
          <div className="w-24 h-0.5 bg-gradient-to-r from-[#D4AF37] to-[#B8860B] mx-auto mt-6" />
        </motion.div>

        {/* Two columns with handshake in middle */}
        <div className="relative">
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-32">
            <BenefitColumn
              title="For Exporters"
              icon={Ship}
              benefits={exporterBenefits}
              delay={0.2}
              isInView={isInView}
            />
            <BenefitColumn
              title="For Importers"
              icon={Building2}
              benefits={importerBenefits}
              delay={0.4}
              isInView={isInView}
            />
          </div>
          
          <GoldenHandshake isInView={isInView} />
        </div>
      </div>
    </section>
  );
}