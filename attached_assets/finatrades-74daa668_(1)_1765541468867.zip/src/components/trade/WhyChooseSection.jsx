import React, { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { Lock, Ship, ArrowLeftRight, FileText } from 'lucide-react';

const cards = [
  {
    icon: Lock,
    title: "Stabilized Trade Values",
    description: "Fix values using your verified Worth of Gold to remove pricing instability, currency issues, and negotiation delays."
  },
  {
    icon: Ship,
    title: "Faster Shipment Decisions",
    description: "Exporters gain assurance by verifying the importer's gold-backed financial capability before shipping."
  },
  {
    icon: ArrowLeftRight,
    title: "Settlement Flexibility",
    description: "Settle transactions using gold worth, currency, or a hybrid structure—adapted to your trade agreement."
  },
  {
    icon: FileText,
    title: "Full Documentation Package",
    description: "Each deposit includes refinery details, purity, weight, bar numbers, vault records, and chain-of-custody proof."
  }
];

function PremiumCard({ card, index, isInView }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, delay: index * 0.15 }}
      className="group relative"
    >
      <div className="relative bg-gradient-to-br from-[#1A1A1A]/90 to-[#0D0D0D]/90 backdrop-blur-xl rounded-2xl border border-[#D4AF37]/20 p-8 h-full overflow-hidden transition-all duration-500 hover:border-[#D4AF37]/50 hover:shadow-[0_0_40px_rgba(212,175,55,0.15)]">
        {/* Shimmer effect on hover */}
        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-transparent via-[#D4AF37]/10 to-transparent opacity-0 group-hover:opacity-100"
          initial={{ x: '-100%' }}
          whileHover={{ x: '200%' }}
          transition={{ duration: 0.8 }}
        />

        {/* Icon */}
        <div className="relative mb-6">
          <motion.div
            className="w-14 h-14 rounded-xl bg-gradient-to-br from-[#D4AF37]/20 to-[#B8860B]/10 flex items-center justify-center"
            whileHover={{ scale: 1.1, rotate: 5 }}
            transition={{ duration: 0.3 }}
          >
            <card.icon className="w-7 h-7 text-[#D4AF37]" />
          </motion.div>
          
          {/* Glow behind icon */}
          <div className="absolute inset-0 blur-xl bg-[#D4AF37]/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
        </div>

        {/* Content */}
        <h3 className="text-xl font-light text-white mb-4 relative z-10">{card.title}</h3>
        <p className="text-gray-400 leading-relaxed relative z-10">{card.description}</p>

        {/* Corner accent */}
        <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-bl from-[#D4AF37]/10 to-transparent rounded-bl-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      </div>
    </motion.div>
  );
}

export default function WhyChooseSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });

  return (
    <section ref={ref} className="relative py-24 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(212,175,55,0.08)_0%,_transparent_60%)]" />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <p className="text-[#D4AF37] text-sm tracking-[0.3em] uppercase mb-4">Business Advantages</p>
          <h2 className="text-4xl md:text-5xl font-extralight text-white mb-4">
            Why Importers & Exporters Choose{' '}
            <span className="bg-gradient-to-r from-[#D4AF37] via-[#F7D878] to-[#D4AF37] bg-clip-text text-transparent">
              Finatrades
            </span>
          </h2>
          <div className="w-24 h-0.5 bg-gradient-to-r from-[#D4AF37] to-[#B8860B] mx-auto" />
        </motion.div>

        {/* Cards grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {cards.map((card, i) => (
            <PremiumCard key={i} card={card} index={i} isInView={isInView} />
          ))}
        </div>
      </div>
    </section>
  );
}