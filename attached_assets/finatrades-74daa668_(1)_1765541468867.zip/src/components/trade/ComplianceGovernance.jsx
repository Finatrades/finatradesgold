import React, { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { Shield, Building2, Users, FileSearch, Lock, Database, FolderLock, CheckCircle } from 'lucide-react';

const complianceItems = [
  { icon: Building2, text: "Swiss-aligned operational structure" },
  { icon: Shield, text: "KYB / KYC corporate verification" },
  { icon: Lock, text: "Vault-level physical security" },
  { icon: Users, text: "Multi-user permission system" },
  { icon: FileSearch, text: "Audit trails on every action" },
  { icon: Database, text: "Full document retention" },
  { icon: FolderLock, text: "Secured data rooms" }
];

function VaultShield({ isInView }) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={isInView ? { opacity: 1, scale: 1 } : {}}
      transition={{ duration: 0.8 }}
      className="relative w-48 h-48 mx-auto"
    >
      {/* Outer glow */}
      <motion.div
        className="absolute inset-0 rounded-full bg-[#D4AF37]/20 blur-3xl"
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.3, 0.5, 0.3]
        }}
        transition={{ duration: 3, repeat: Infinity }}
      />

      {/* Shield outline */}
      <motion.div
        className="absolute inset-4 rounded-full border-2 border-[#D4AF37]/50"
        animate={{
          boxShadow: [
            '0 0 20px rgba(212,175,55,0.3)',
            '0 0 40px rgba(212,175,55,0.5)',
            '0 0 20px rgba(212,175,55,0.3)'
          ]
        }}
        transition={{ duration: 2, repeat: Infinity }}
      />

      {/* Inner shield */}
      <motion.div
        className="absolute inset-8 rounded-full bg-gradient-to-br from-[#D4AF37] to-[#B8860B] flex items-center justify-center"
        animate={{
          boxShadow: [
            '0 0 30px rgba(212,175,55,0.4)',
            '0 0 50px rgba(212,175,55,0.6)',
            '0 0 30px rgba(212,175,55,0.4)'
          ]
        }}
        transition={{ duration: 2.5, repeat: Infinity }}
      >
        <Shield className="w-16 h-16 text-black" />
      </motion.div>

      {/* Orbiting particles */}
      {[...Array(6)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-2 h-2 rounded-full bg-[#F7D878]"
          style={{
            top: '50%',
            left: '50%',
          }}
          animate={{
            rotate: [i * 60, i * 60 + 360],
            x: [Math.cos(i * 60 * Math.PI / 180) * 80, Math.cos((i * 60 + 360) * Math.PI / 180) * 80],
            y: [Math.sin(i * 60 * Math.PI / 180) * 80, Math.sin((i * 60 + 360) * Math.PI / 180) * 80],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "linear",
            delay: i * 0.5
          }}
        />
      ))}
    </motion.div>
  );
}

export default function ComplianceGovernance() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });

  return (
    <section ref={ref} className="relative py-24 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(212,175,55,0.08)_0%,_transparent_60%)]" />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <p className="text-[#D4AF37] text-sm tracking-[0.3em] uppercase mb-4">Security & Trust</p>
          <h2 className="text-4xl md:text-5xl font-extralight text-white mb-4">
            Enterprise-Level Security, Compliance & Governance
          </h2>
          <div className="w-24 h-0.5 bg-gradient-to-r from-[#D4AF37] to-[#B8860B] mx-auto" />
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left - Shield visual */}
          <VaultShield isInView={isInView} />

          {/* Right - Compliance list */}
          <div className="space-y-4">
            {complianceItems.map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: 30 }}
                animate={isInView ? { opacity: 1, x: 0 } : {}}
                transition={{ duration: 0.5, delay: 0.2 + i * 0.1 }}
                className="group flex items-center gap-4 p-4 rounded-xl bg-[#1A1A1A]/50 border border-[#D4AF37]/10 hover:border-[#D4AF37]/30 transition-all duration-300"
              >
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#D4AF37]/20 to-[#B8860B]/10 flex items-center justify-center flex-shrink-0 group-hover:from-[#D4AF37]/30 group-hover:to-[#B8860B]/20 transition-all">
                  <item.icon className="w-5 h-5 text-[#D4AF37]" />
                </div>
                <span className="text-gray-300 group-hover:text-white transition-colors">{item.text}</span>
                <CheckCircle className="w-5 h-5 text-[#D4AF37]/50 ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}