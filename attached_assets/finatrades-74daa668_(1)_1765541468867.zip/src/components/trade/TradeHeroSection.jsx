import React, { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { Shield, Award, Globe, FileCheck } from 'lucide-react';

// Floating gold particles
function GoldParticles() {
  const particles = [...Array(30)].map((_, i) => ({
    x: Math.random() * 100,
    y: Math.random() * 100,
    size: 2 + Math.random() * 4,
    delay: Math.random() * 5,
    duration: 8 + Math.random() * 6
  }));

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {particles.map((p, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full bg-gradient-to-br from-[#F7D878] to-[#D4AF37]"
          style={{
            left: `${p.x}%`,
            bottom: '-5%',
            width: p.size,
            height: p.size,
          }}
          animate={{
            y: [0, -800],
            x: [0, Math.sin(i) * 50],
            opacity: [0, 0.8, 0.8, 0],
          }}
          transition={{
            duration: p.duration,
            delay: p.delay,
            repeat: Infinity,
            ease: "linear"
          }}
        />
      ))}
    </div>
  );
}

// 3D Gold Bars Stack
function GoldBarsStack() {
  return (
    <motion.div 
      className="relative w-64 h-64 md:w-80 md:h-80"
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 1.2 }}
    >
      {/* Vault outline behind */}
      <motion.div
        className="absolute inset-0 border-2 border-[#D4AF37]/30 rounded-3xl"
        animate={{
          boxShadow: [
            '0 0 20px rgba(212,175,55,0.1)',
            '0 0 40px rgba(212,175,55,0.2)',
            '0 0 20px rgba(212,175,55,0.1)'
          ]
        }}
        transition={{ duration: 3, repeat: Infinity }}
      />
      
      {/* Gold bars */}
      {[0, 1, 2].map((i) => (
        <motion.div
          key={i}
          className="absolute left-1/2 top-1/2"
          style={{
            transform: `translate(-50%, -50%) translateY(${(i - 1) * 30}px)`,
            zIndex: 3 - i
          }}
          initial={{ opacity: 0, y: 50 }}
          animate={{ 
            opacity: 1, 
            y: (i - 1) * 30,
            rotateX: 15,
            rotateY: -15
          }}
          transition={{ delay: 0.3 + i * 0.2, duration: 0.8 }}
        >
          <motion.div
            className="w-32 h-16 md:w-40 md:h-20 rounded-lg relative overflow-hidden"
            style={{
              background: 'linear-gradient(135deg, #F7D878 0%, #D4AF37 30%, #B8860B 60%, #8B6914 100%)',
              boxShadow: '0 10px 30px rgba(0,0,0,0.5), inset 0 2px 10px rgba(255,255,255,0.3)'
            }}
            animate={{
              y: [0, -5, 0]
            }}
            transition={{
              duration: 3 + i * 0.5,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            {/* Bar shine effect */}
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent"
              animate={{ x: ['-100%', '200%'] }}
              transition={{ duration: 3, repeat: Infinity, repeatDelay: 2 }}
            />
            {/* Serial number */}
            <div className="absolute bottom-2 left-3 text-[8px] text-black/50 font-mono">
              AU.999.{1000 + i}
            </div>
          </motion.div>
        </motion.div>
      ))}

      {/* Glow effect */}
      <motion.div
        className="absolute inset-0 rounded-full blur-3xl bg-[#D4AF37]/20"
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.3, 0.5, 0.3]
        }}
        transition={{ duration: 4, repeat: Infinity }}
      />
    </motion.div>
  );
}

// Trade routes animation
function TradeRoutes() {
  return (
    <svg className="absolute inset-0 w-full h-full opacity-20" viewBox="0 0 100 100">
      <defs>
        <linearGradient id="routeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#D4AF37" stopOpacity="0" />
          <stop offset="50%" stopColor="#F7D878" stopOpacity="1" />
          <stop offset="100%" stopColor="#D4AF37" stopOpacity="0" />
        </linearGradient>
      </defs>
      
      {/* Trade route lines */}
      {[
        "M 10,50 Q 30,30 50,50 T 90,50",
        "M 20,70 Q 40,50 60,70 T 100,70",
        "M 0,30 Q 30,50 50,30 T 80,30"
      ].map((path, i) => (
        <motion.path
          key={i}
          d={path}
          fill="none"
          stroke="url(#routeGradient)"
          strokeWidth="0.5"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 2, delay: i * 0.5, repeat: Infinity, repeatDelay: 3 }}
        />
      ))}
    </svg>
  );
}

const badges = [
  { icon: Shield, text: "Swiss-Regulated Framework" },
  { icon: Award, text: "Physical Gold • No Tokens" },
  { icon: FileCheck, text: "Audit-Ready Documentation" },
  { icon: Globe, text: "Trusted Across Borders" }
];

export default function TradeHeroSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });

  return (
    <section ref={ref} className="relative min-h-[90vh] flex items-center overflow-hidden py-20">
      {/* Background effects */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_rgba(212,175,55,0.15)_0%,_transparent_50%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,_rgba(184,134,11,0.1)_0%,_transparent_50%)]" />
      <GoldParticles />
      <TradeRoutes />

      <div className="relative z-10 max-w-7xl mx-auto px-6 w-full">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8 }}
          >
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.2 }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#D4AF37]/10 border border-[#D4AF37]/30 mb-6"
            >
              <Globe className="w-4 h-4 text-[#D4AF37]" />
              <span className="text-sm text-[#D4AF37]">Import & Export Business Platform</span>
            </motion.div>

            <h1 className="text-4xl md:text-5xl lg:text-6xl font-extralight text-white mb-6 leading-tight">
              Gold-Backed Infrastructure for{' '}
              <span className="bg-gradient-to-r from-[#D4AF37] via-[#F7D878] to-[#D4AF37] bg-clip-text text-transparent">
                Importers & Exporters
              </span>
            </h1>

            <p className="text-xl text-gray-400 mb-8 leading-relaxed max-w-xl">
              Use verified physical gold worth to stabilize trade, reduce settlement risk, and accelerate global transactions.
            </p>

            {/* Badges */}
            <div className="flex flex-wrap gap-3 mb-10">
              {badges.map((badge, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  animate={isInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ delay: 0.4 + i * 0.1 }}
                  className="flex items-center gap-2 px-4 py-2 rounded-full bg-[#1A1A1A]/80 border border-[#D4AF37]/20 backdrop-blur-sm"
                >
                  <badge.icon className="w-4 h-4 text-[#D4AF37]" />
                  <span className="text-sm text-gray-300">{badge.text}</span>
                </motion.div>
              ))}
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-wrap gap-4">
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="px-8 py-4 rounded-full bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-black font-medium hover:shadow-[0_0_30px_rgba(212,175,55,0.4)] transition-shadow"
              >
                Open Corporate Account
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="px-8 py-4 rounded-full border border-[#D4AF37]/50 text-[#D4AF37] font-medium hover:bg-[#D4AF37]/10 transition-all"
              >
                Talk to Trade Specialist
              </motion.button>
            </div>
          </motion.div>

          {/* Right visual */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="flex justify-center items-center"
          >
            <GoldBarsStack />
          </motion.div>
        </div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <div className="w-6 h-10 rounded-full border-2 border-[#D4AF37]/50 flex items-start justify-center p-2">
          <motion.div
            className="w-1.5 h-1.5 rounded-full bg-[#D4AF37]"
            animate={{ y: [0, 12, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
          />
        </div>
      </motion.div>
    </section>
  );
}