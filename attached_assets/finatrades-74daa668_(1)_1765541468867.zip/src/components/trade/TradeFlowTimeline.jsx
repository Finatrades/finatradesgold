import React, { useRef, useState, useEffect } from 'react';
import { motion, useInView } from 'framer-motion';
import { Vault, FileCheck, FileText, Plane, CheckSquare, Banknote } from 'lucide-react';

const steps = [
  {
    number: "01",
    icon: Vault,
    title: "Buyer Locks Worth of Gold",
    description: "The importer locks a defined worth of gold inside FinaVault."
  },
  {
    number: "02",
    icon: FileCheck,
    title: "Exporter Verifies Documentation",
    description: "The exporter receives official documents: refinery details, bar numbers, purity, vault location, and chain-of-custody."
  },
  {
    number: "03",
    icon: FileText,
    title: "Contract Terms Become Stable",
    description: "Both sides finalize quantity, pricing, and delivery based on stable gold worth."
  },
  {
    number: "04",
    icon: Plane,
    title: "Shipment Begins",
    description: "Exporter ships goods with confidence."
  },
  {
    number: "05",
    icon: CheckSquare,
    title: "Delivery Confirmation",
    description: "Importer confirms receipt of goods."
  },
  {
    number: "06",
    icon: Banknote,
    title: "Settlement via Gold Worth",
    description: "Full or partial settlement is completed using the importer's gold worth."
  }
];

function StepNode({ step, index, isActive, isPassed }) {
  const isLeft = index % 2 === 0;
  
  return (
    <motion.div
      initial={{ opacity: 0, x: isLeft ? -50 : 50 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.15 }}
      className={`relative flex items-center ${isLeft ? 'lg:flex-row' : 'lg:flex-row-reverse'} flex-col lg:gap-8 gap-4`}
    >
      {/* Content card */}
      <div className={`lg:w-[calc(50%-3rem)] w-full ${isLeft ? 'lg:text-right' : 'lg:text-left'}`}>
        <motion.div
          className={`relative bg-gradient-to-br from-[#1A1A1A]/90 to-[#0D0D0D]/90 backdrop-blur-xl rounded-2xl border p-6 transition-all duration-500 ${
            isActive 
              ? 'border-[#D4AF37]/60 shadow-[0_0_30px_rgba(212,175,55,0.2)]' 
              : isPassed 
                ? 'border-[#D4AF37]/40' 
                : 'border-[#D4AF37]/10'
          }`}
        >
          {/* Step number */}
          <div className={`flex items-center gap-3 mb-4 ${isLeft ? 'lg:justify-end' : 'lg:justify-start'}`}>
            <span className="text-3xl font-extralight text-[#D4AF37]">{step.number}</span>
          </div>

          <h4 className="text-xl font-light text-white mb-2">{step.title}</h4>
          <p className="text-gray-400">{step.description}</p>

          {/* Active glow */}
          {isActive && (
            <motion.div
              className="absolute inset-0 rounded-2xl bg-gradient-to-r from-[#D4AF37]/5 via-[#F7D878]/10 to-[#D4AF37]/5"
              animate={{ opacity: [0.3, 0.6, 0.3] }}
              transition={{ duration: 2, repeat: Infinity }}
            />
          )}
        </motion.div>
      </div>

      {/* Center node */}
      <div className="relative z-10 flex-shrink-0">
        <motion.div
          className={`w-16 h-16 rounded-full flex items-center justify-center transition-all duration-500 ${
            isActive 
              ? 'bg-gradient-to-br from-[#D4AF37] to-[#B8860B] shadow-[0_0_30px_rgba(212,175,55,0.5)]'
              : isPassed
                ? 'bg-gradient-to-br from-[#D4AF37]/80 to-[#B8860B]/80'
                : 'bg-[#1A1A1A] border-2 border-[#D4AF37]/30'
          }`}
          animate={isActive ? { scale: [1, 1.1, 1] } : {}}
          transition={{ duration: 1.5, repeat: isActive ? Infinity : 0 }}
        >
          <step.icon className={`w-7 h-7 ${isActive || isPassed ? 'text-black' : 'text-[#D4AF37]'}`} />
        </motion.div>
        
        {/* Pulse ring */}
        {isActive && (
          <motion.div
            className="absolute inset-0 rounded-full border-2 border-[#D4AF37]"
            animate={{ scale: [1, 1.5], opacity: [0.8, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          />
        )}
      </div>

      {/* Empty space for alignment */}
      <div className="lg:w-[calc(50%-3rem)] hidden lg:block" />
    </motion.div>
  );
}

function SnakePath({ activeStep }) {
  return (
    <div className="absolute left-1/2 top-0 bottom-0 -translate-x-1/2 w-1 hidden lg:block">
      {/* Background line */}
      <div className="absolute inset-0 bg-[#D4AF37]/10 rounded-full" />
      
      {/* Animated progress */}
      <motion.div
        className="absolute top-0 left-0 right-0 bg-gradient-to-b from-[#D4AF37] to-[#B8860B] rounded-full"
        animate={{ height: `${(activeStep / (steps.length - 1)) * 100}%` }}
        transition={{ duration: 0.5 }}
      />

      {/* Traveling pulse */}
      <motion.div
        className="absolute left-1/2 -translate-x-1/2 w-3 h-3 rounded-full bg-[#F7D878]"
        style={{ top: `${(activeStep / (steps.length - 1)) * 100}%` }}
        animate={{
          boxShadow: [
            '0 0 10px rgba(247,216,120,0.5)',
            '0 0 20px rgba(247,216,120,0.8)',
            '0 0 10px rgba(247,216,120,0.5)'
          ]
        }}
        transition={{ duration: 1.5, repeat: Infinity }}
      />
    </div>
  );
}

export default function TradeFlowTimeline() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });
  const [activeStep, setActiveStep] = useState(0);

  useEffect(() => {
    if (!isInView) return;
    
    const interval = setInterval(() => {
      setActiveStep(prev => (prev + 1) % steps.length);
    }, 3000);

    return () => clearInterval(interval);
  }, [isInView]);

  return (
    <section ref={ref} className="relative py-24 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(212,175,55,0.08)_0%,_transparent_60%)]" />

      <div className="relative z-10 max-w-6xl mx-auto px-6">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <p className="text-[#D4AF37] text-sm tracking-[0.3em] uppercase mb-4">Process Flow</p>
          <h2 className="text-4xl md:text-5xl font-extralight text-white mb-4">
            The Complete Trade Flow
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            From gold lockup to final settlement—a seamless, documented journey.
          </p>
          <div className="w-24 h-0.5 bg-gradient-to-r from-[#D4AF37] to-[#B8860B] mx-auto mt-6" />
        </motion.div>

        {/* Timeline */}
        <div className="relative">
          <SnakePath activeStep={activeStep} />
          
          <div className="space-y-12">
            {steps.map((step, i) => (
              <StepNode
                key={i}
                step={step}
                index={i}
                isActive={activeStep === i}
                isPassed={i < activeStep}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}