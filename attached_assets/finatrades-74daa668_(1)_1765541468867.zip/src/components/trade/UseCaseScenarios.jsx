import React, { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { Globe, Ship, TrendingUp, ArrowRight } from 'lucide-react';

const scenarios = [
  {
    icon: Globe,
    title: "UAE Importer / African Exporter",
    route: { from: "UAE", to: "Africa" },
    description: "Importer locks $250,000 worth of gold. Exporter verifies. Shipment starts faster. Settlement done in hybrid gold + currency mode.",
    animation: "map"
  },
  {
    icon: Ship,
    title: "Exporter Avoids Default",
    description: "Exporter accepts gold-worth documentation as assurance. Shipment moves without payment delays.",
    animation: "ship"
  },
  {
    icon: TrendingUp,
    title: "Commodity Trader Stabilizes Price",
    description: "Locked-In Price prevents volatility disputes. Contracts become stable.",
    animation: "chart"
  }
];

function MapAnimation() {
  return (
    <div className="relative h-32 w-full">
      <svg viewBox="0 0 200 80" className="w-full h-full">
        <defs>
          <linearGradient id="routeGrad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#D4AF37" />
            <stop offset="50%" stopColor="#F7D878" />
            <stop offset="100%" stopColor="#D4AF37" />
          </linearGradient>
        </defs>
        
        {/* UAE marker */}
        <circle cx="60" cy="35" r="6" fill="#D4AF37" />
        <text x="60" y="55" textAnchor="middle" fill="#D4AF37" fontSize="8">UAE</text>
        
        {/* Route line */}
        <path
          d="M 60 35 Q 110 10 160 45"
          fill="none"
          stroke="url(#routeGrad)"
          strokeWidth="2"
          strokeDasharray="5 3"
        />
        
        {/* Traveling dot */}
        <circle r="4" fill="#F7D878">
          <animateMotion
            dur="2s"
            repeatCount="indefinite"
            path="M 60 35 Q 110 10 160 45"
          />
        </circle>
        
        {/* Africa marker */}
        <circle cx="160" cy="45" r="6" fill="#D4AF37" />
        <text x="160" y="65" textAnchor="middle" fill="#D4AF37" fontSize="8">Africa</text>
      </svg>
    </div>
  );
}

function ShipAnimation() {
  return (
    <div className="relative h-32 w-full overflow-hidden">
      <svg viewBox="0 0 200 80" className="w-full h-full">
        {/* Water waves */}
        <path
          d="M 0 60 Q 25 55 50 60 T 100 60 T 150 60 T 200 60"
          fill="none"
          stroke="#D4AF37"
          strokeWidth="1"
          opacity="0.3"
        />
        
        {/* Container ship */}
        <g>
          {/* Hull */}
          <path
            d="M 60 45 L 70 55 L 130 55 L 140 45 L 130 45 L 130 35 L 70 35 L 70 45 Z"
            fill="#D4AF37"
          />
          {/* Containers */}
          <rect x="75" y="37" width="15" height="8" fill="#B8860B" />
          <rect x="92" y="37" width="15" height="8" fill="#F7D878" />
          <rect x="109" y="37" width="15" height="8" fill="#B8860B" />
        </g>
        
        {/* Success checkmark */}
        <circle
          cx="170"
          cy="40"
          r="12"
          fill="#D4AF37"
        />
        <path
          d="M 165 40 L 168 43 L 175 36"
          fill="none"
          stroke="black"
          strokeWidth="2"
        />
      </svg>
    </div>
  );
}

function ChartAnimation() {
  return (
    <div className="relative h-32 w-full">
      <svg viewBox="0 0 200 80" className="w-full h-full">
        {/* Volatile line (before) */}
        <path
          d="M 20 50 L 40 30 L 50 55 L 60 25 L 70 50 L 80 35"
          fill="none"
          stroke="#666"
          strokeWidth="2"
        />
        
        {/* Gold anchor point */}
        <circle cx="80" cy="35" r="6" fill="#D4AF37" />
        
        {/* Stable line (after gold lock) */}
        <path
          d="M 80 35 L 180 35"
          fill="none"
          stroke="#D4AF37"
          strokeWidth="3"
        />
        
        {/* Labels */}
        <text x="50" y="70" fill="#666" fontSize="8" textAnchor="middle">Volatile</text>
        <text x="130" y="70" fill="#D4AF37" fontSize="8" textAnchor="middle">Locked-In Price</text>
      </svg>
    </div>
  );
}

function ScenarioCard({ scenario, index, isInView }) {
  const animations = {
    map: MapAnimation,
    ship: ShipAnimation,
    chart: ChartAnimation
  };
  
  const AnimationComponent = animations[scenario.animation];

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, delay: index * 0.2 }}
      className="group"
    >
      <div className="relative bg-gradient-to-br from-[#1A1A1A]/90 to-[#0D0D0D]/90 backdrop-blur-xl rounded-2xl border border-[#D4AF37]/20 p-6 h-full overflow-hidden transition-all duration-500 hover:border-[#D4AF37]/50 hover:shadow-[0_0_40px_rgba(212,175,55,0.15)]">
        {/* Header */}
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#D4AF37]/20 to-[#B8860B]/10 flex items-center justify-center">
            <scenario.icon className="w-5 h-5 text-[#D4AF37]" />
          </div>
          <h4 className="text-lg font-light text-white">{scenario.title}</h4>
        </div>

        {/* Animation */}
        <div className="mb-4">
          <AnimationComponent />
        </div>

        {/* Description */}
        <p className="text-gray-400 text-sm leading-relaxed">{scenario.description}</p>
      </div>
    </motion.div>
  );
}

export default function UseCaseScenarios() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });

  return (
    <section ref={ref} className="relative py-24 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom,_rgba(212,175,55,0.1)_0%,_transparent_60%)]" />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <p className="text-[#D4AF37] text-sm tracking-[0.3em] uppercase mb-4">Real-World Impact</p>
          <h2 className="text-4xl md:text-5xl font-extralight text-white mb-4">
            Real Trade Scenarios Powered by{' '}
            <span className="bg-gradient-to-r from-[#D4AF37] via-[#F7D878] to-[#D4AF37] bg-clip-text text-transparent">
              Gold Worth
            </span>
          </h2>
          <div className="w-24 h-0.5 bg-gradient-to-r from-[#D4AF37] to-[#B8860B] mx-auto" />
        </motion.div>

        {/* Scenario cards */}
        <div className="grid md:grid-cols-3 gap-8">
          {scenarios.map((scenario, i) => (
            <ScenarioCard key={i} scenario={scenario} index={i} isInView={isInView} />
          ))}
        </div>
      </div>
    </section>
  );
}