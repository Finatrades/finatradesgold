import React, { useRef, useState } from 'react';
import { motion, useInView } from 'framer-motion';
import { Vault, GitMerge, Building } from 'lucide-react';

const settlements = [
  {
    icon: Vault,
    title: "Full Gold Worth Settlement",
    description: "Complete settlement using your documented Worth of Gold.",
    features: ["100% gold-backed", "Instant transfer", "Full documentation"]
  },
  {
    icon: GitMerge,
    title: "Hybrid Settlement",
    description: "Blend gold worth + currency through your banking partners.",
    features: ["Flexible split", "Multiple currencies", "Custom ratios"]
  },
  {
    icon: Building,
    title: "Traditional Banking",
    description: "Use Finatrades only for assurance and documentation, while settlement remains bank-based.",
    features: ["Bank integration", "Assurance layer", "Document support"]
  }
];

function SettlementCard({ settlement, index, isInView }) {
  const [isFlipped, setIsFlipped] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, delay: index * 0.15 }}
      className="relative h-80 cursor-pointer perspective-1000"
      onMouseEnter={() => setIsFlipped(true)}
      onMouseLeave={() => setIsFlipped(false)}
    >
      <motion.div
        className="relative w-full h-full"
        animate={{ rotateY: isFlipped ? 180 : 0 }}
        transition={{ duration: 0.6, type: "spring", stiffness: 100 }}
        style={{ transformStyle: 'preserve-3d' }}
      >
        {/* Front */}
        <div 
          className="absolute inset-0 bg-gradient-to-br from-[#1A1A1A]/90 to-[#0D0D0D]/90 backdrop-blur-xl rounded-2xl border border-[#D4AF37]/20 p-8 flex flex-col items-center justify-center text-center"
          style={{ backfaceVisibility: 'hidden' }}
        >
          {/* Glowing icon */}
          <motion.div
            className="w-20 h-20 rounded-2xl bg-gradient-to-br from-[#D4AF37]/20 to-[#B8860B]/10 flex items-center justify-center mb-6 relative"
            whileHover={{ scale: 1.05 }}
          >
            <settlement.icon className="w-10 h-10 text-[#D4AF37]" />
            <motion.div
              className="absolute inset-0 rounded-2xl bg-[#D4AF37]/10"
              animate={{
                boxShadow: [
                  '0 0 0px rgba(212,175,55,0)',
                  '0 0 20px rgba(212,175,55,0.3)',
                  '0 0 0px rgba(212,175,55,0)'
                ]
              }}
              transition={{ duration: 2, repeat: Infinity }}
            />
          </motion.div>

          <h3 className="text-xl font-light text-white mb-3">{settlement.title}</h3>
          <p className="text-gray-400">{settlement.description}</p>

          {/* Hover hint */}
          <div className="absolute bottom-4 left-0 right-0 text-center">
            <span className="text-xs text-[#D4AF37]/50">Hover to see features</span>
          </div>
        </div>

        {/* Back */}
        <div 
          className="absolute inset-0 bg-gradient-to-br from-[#D4AF37]/10 to-[#B8860B]/5 backdrop-blur-xl rounded-2xl border border-[#D4AF37]/40 p-8 flex flex-col items-center justify-center"
          style={{ backfaceVisibility: 'hidden', transform: 'rotateY(180deg)' }}
        >
          <h4 className="text-lg font-light text-white mb-6">Key Features</h4>
          
          <div className="space-y-4 w-full">
            {settlement.features.map((feature, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -20 }}
                animate={isFlipped ? { opacity: 1, x: 0 } : {}}
                transition={{ delay: i * 0.1 }}
                className="flex items-center gap-3 px-4 py-3 rounded-xl bg-[#1A1A1A]/50 border border-[#D4AF37]/20"
              >
                <div className="w-2 h-2 rounded-full bg-[#D4AF37]" />
                <span className="text-gray-300">{feature}</span>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

export default function SettlementOptions() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });

  return (
    <section ref={ref} className="relative py-24 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_left,_rgba(212,175,55,0.08)_0%,_transparent_50%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_right,_rgba(184,134,11,0.08)_0%,_transparent_50%)]" />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <p className="text-[#D4AF37] text-sm tracking-[0.3em] uppercase mb-4">Settlement Options</p>
          <h2 className="text-4xl md:text-5xl font-extralight text-white mb-4">
            Flexible Settlement Methods
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Choose the settlement approach that best fits your trade requirements.
          </p>
          <div className="w-24 h-0.5 bg-gradient-to-r from-[#D4AF37] to-[#B8860B] mx-auto mt-6" />
        </motion.div>

        {/* Settlement cards */}
        <div className="grid md:grid-cols-3 gap-8">
          {settlements.map((settlement, i) => (
            <SettlementCard key={i} settlement={settlement} index={i} isInView={isInView} />
          ))}
        </div>
      </div>
    </section>
  );
}