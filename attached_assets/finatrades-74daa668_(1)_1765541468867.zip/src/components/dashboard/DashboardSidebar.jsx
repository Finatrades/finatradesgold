import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { 
  PieChart, Vault, TrendingUp, Wallet, GitBranch, Percent, Settings, LogOut, Menu, X, CreditCard
} from 'lucide-react';
import { Button } from "@/components/ui/button";

const menuItems = [
  { icon: PieChart, label: 'Dashboard', page: 'UserDashboard' },
  { icon: Vault, label: 'Vault', page: 'FinaVaultUser' },
  { icon: TrendingUp, label: 'BNSL', page: 'FinaEarnUser' },
  { icon: Wallet, label: 'Pay', page: 'FinaPayUser' },
  { icon: GitBranch, label: 'Bridge', page: 'FinaFinanceUser' },
  { icon: Percent, label: 'Yields', page: 'YieldsUser' },
  { icon: CreditCard, label: 'Card', page: 'DebitCardUser' },
  { icon: Settings, label: 'Settings', page: 'SettingsUser' },
];

export default function DashboardSidebar({ currentPage, user }) {
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleLogout = () => {
    localStorage.removeItem('finatrades_user');
    navigate(createPageUrl("Home"));
  };

  if (!user) return null;

  return (
    <>
      {/* Mobile Menu Buttons */}
      <div className="lg:hidden fixed top-4 left-4 z-50 flex items-center gap-2">
        <button 
          onClick={() => setSidebarOpen(true)} 
          className="w-12 h-12 rounded-xl bg-white border border-[#8A2BE2]/20 flex items-center justify-center text-[#0D0D0D] shadow-lg active:scale-95 transition-transform"
        >
          <Menu className="w-5 h-5" />
        </button>
        <Link
          to={createPageUrl("FinaPayUser")}
          className={`relative w-12 h-12 rounded-xl flex items-center justify-center text-white shadow-lg active:scale-95 transition-transform ${
            currentPage === 'FinaPayUser' 
              ? 'bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF]' 
              : 'bg-gradient-to-r from-[#8A2BE2]/60 to-[#FF2FBF]/60'
          }`}
        >
          <Wallet className="w-5 h-5" />
          {currentPage === 'FinaPayUser' && (
            <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-8 h-1 bg-white/80 rounded-full" />
          )}
        </Link>
        <Link
          to={createPageUrl("FinaVaultUser")}
          className={`relative w-12 h-12 rounded-xl flex items-center justify-center shadow-lg active:scale-95 transition-transform ${
            currentPage === 'FinaVaultUser'
              ? 'bg-white border-2 border-[#8A2BE2] text-[#8A2BE2]'
              : 'bg-white border border-[#8A2BE2]/20 text-[#8A2BE2]/60'
          }`}
        >
          <Vault className="w-5 h-5" />
          {currentPage === 'FinaVaultUser' && (
            <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-8 h-1 bg-[#8A2BE2] rounded-full" />
          )}
        </Link>
      </div>

      {/* Sidebar */}
      <aside className={`fixed lg:static inset-y-0 left-0 z-50 w-64 bg-white border-r border-[#8A2BE2]/20 shadow-sm transform transition-transform lg:translate-x-0 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="p-6 border-b border-[#8A2BE2]/20">
            <Link to={createPageUrl("Home")} className="flex items-center">
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69293bd8e52dce0074daa668/ce96e4d2b_FINANEWLOGO-GOLDANDWHITENB.png" 
                alt="Finatrades" 
                className="h-8"
                style={{ filter: 'brightness(0) saturate(100%) invert(29%) sepia(89%) saturate(4527%) hue-rotate(262deg) brightness(96%) contrast(93%)' }}
              />
            </Link>
            <button 
              onClick={() => setSidebarOpen(false)} 
              className="lg:hidden absolute top-6 right-6 text-[#4A4A4A] hover:text-[#0D0D0D]"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Menu */}
          <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
            {menuItems.map((item) => {
              const isActive = currentPage === item.page;
              return (
                <Link
                  key={item.label}
                  to={createPageUrl(item.page)}
                  onClick={() => setSidebarOpen(false)}
                  className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                    isActive 
                      ? 'bg-gradient-to-r from-[#8A2BE2]/10 to-[#FF2FBF]/10 text-[#8A2BE2] border border-[#8A2BE2]/30' 
                      : 'text-[#4A4A4A] hover:bg-[#F4F6FC] hover:text-[#0D0D0D]'
                  }`}
                >
                  <item.icon className="w-5 h-5" />
                  <span className="font-medium">{item.label}</span>
                </Link>
              );
            })}
          </nav>

          {/* User Info */}
          <div className="p-4 border-t border-[#8A2BE2]/20">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] flex items-center justify-center text-white font-semibold">
                {user?.full_name?.charAt(0) || 'U'}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-[#0D0D0D] font-medium truncate">{user?.full_name || 'User'}</p>
                <p className="text-[#4A4A4A] text-sm truncate">{user?.email || ''}</p>
              </div>
            </div>
            <button
              onClick={handleLogout}
              className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl border border-[#8A2BE2]/30 text-[#4A4A4A] hover:bg-[#8A2BE2]/10 hover:text-[#0D0D0D] hover:border-[#8A2BE2]/50 transition-all font-medium"
            >
              <LogOut className="w-4 h-4" />
              Sign Out
            </button>
          </div>
        </div>
      </aside>

      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}
    </>
  );
}