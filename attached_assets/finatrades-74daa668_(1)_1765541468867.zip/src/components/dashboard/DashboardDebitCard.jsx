import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Wifi, Shield } from 'lucide-react';

export default function DashboardDebitCard({ userName, goldBalance, goldValue, goldPrice }) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div className="relative w-full max-w-sm perspective-1000">
      {/* Glow effects behind card */}
      <motion.div
        className="absolute inset-0 rounded-2xl"
        animate={{
          boxShadow: isHovered 
            ? '0 0 60px rgba(212,175,55,0.3), 0 0 100px rgba(212,175,55,0.15)'
            : '0 0 30px rgba(212,175,55,0.15), 0 0 50px rgba(212,175,55,0.08)'
        }}
        transition={{ duration: 0.5 }}
      />

      {/* Main Card */}
      <motion.div
        className="relative aspect-[1.6/1] rounded-2xl overflow-hidden cursor-pointer"
        style={{ transformStyle: 'preserve-3d' }}
        animate={{
          rotateY: isHovered ? 5 : 0,
          rotateX: isHovered ? -3 : 0,
        }}
        whileHover={{ scale: 1.02 }}
        onHoverStart={() => setIsHovered(true)}
        onHoverEnd={() => setIsHovered(false)}
        transition={{ duration: 0.3 }}
      >
        {/* Card background with premium gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-[#1A1A1A] via-[#0D0D0D] to-[#000000] border border-[#D4AF37]/30" />
        
        {/* Animated shine effect */}
        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-transparent via-[#D4AF37]/10 to-transparent"
          animate={{ x: ['-200%', '200%'] }}
          transition={{ duration: 3, repeat: Infinity, repeatDelay: 2, ease: "easeInOut" }}
        />

        {/* Gold border glow */}
        <div className="absolute inset-0 rounded-2xl border border-[#D4AF37]/40" />
        
        {/* Inner gold accent lines */}
        <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-[#D4AF37]/50 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-[#D4AF37]/30 to-transparent" />

        {/* Card Content */}
        <div className="relative h-full p-5 flex flex-col justify-between">
          {/* Top section - Logo and Chip */}
          <div className="flex items-start justify-between">
            {/* Logo */}
            <img 
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69293bd8e52dce0074daa668/ce96e4d2b_FINANEWLOGO-GOLDANDWHITENB.png" 
              alt="Finatrades" 
              className="h-6"
            />

            {/* Contactless icon */}
            <motion.div animate={{ opacity: [0.5, 1, 0.5] }} transition={{ duration: 2, repeat: Infinity }}>
              <Wifi className="w-5 h-5 text-[#D4AF37] rotate-90" />
            </motion.div>
          </div>

          {/* Chip and Gold indicator */}
          <div className="flex items-center gap-3">
            <motion.div 
              className="relative w-10 h-8 rounded-md overflow-hidden"
              animate={{ boxShadow: isHovered ? '0 0 12px rgba(212,175,55,0.5)' : '0 0 4px rgba(212,175,55,0.2)' }}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-[#D4AF37] to-[#B8860B]" />
              <div className="absolute inset-0 flex flex-col justify-center items-center gap-0.5 p-1">
                {[...Array(4)].map((_, i) => <div key={i} className="w-full h-0.5 bg-[#0A0A0A]/30" />)}
              </div>
              <div className="absolute inset-1.5 bg-gradient-to-br from-[#F7D878] to-[#D4AF37] rounded-sm" />
            </motion.div>

            <div className="flex items-center gap-1">
              <div className="w-1.5 h-1.5 rounded-full bg-[#D4AF37] animate-pulse" />
              <span className="text-[10px] text-[#D4AF37]/70 tracking-wider">GOLD BACKED</span>
            </div>
          </div>

          {/* Card number placeholder */}
          <div className="flex gap-3">
            {[...Array(4)].map((_, groupIndex) => (
              <div key={groupIndex} className="flex gap-0.5">
                {[...Array(4)].map((_, i) => (
                  <span key={i} className="text-sm text-white/80 font-mono">•</span>
                ))}
              </div>
            ))}
          </div>

          {/* Bottom section - Cardholder and validity */}
          <div className="flex items-end justify-between">
            <div>
              <p className="text-[8px] text-gray-500 uppercase tracking-wider mb-0.5">Card Holder</p>
              <p className="text-white text-sm font-light tracking-wide uppercase">{userName || 'FINATRADES USER'}</p>
            </div>
            
            <div className="text-right">
              <p className="text-[8px] text-gray-500 uppercase tracking-wider mb-0.5">Valid Thru</p>
              <p className="text-white text-sm font-light">12/28</p>
            </div>

            {/* Security badge */}
            <motion.div
              className="flex items-center gap-1 px-2 py-1 rounded-full bg-[#D4AF37]/10 border border-[#D4AF37]/30"
              animate={{ borderColor: ['rgba(212,175,55,0.3)', 'rgba(212,175,55,0.6)', 'rgba(212,175,55,0.3)'] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <Shield className="w-2.5 h-2.5 text-[#D4AF37]" />
              <span className="text-[8px] text-[#D4AF37]">SECURE</span>
            </motion.div>
          </div>
        </div>

        {/* Holographic effect overlay */}
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background: `linear-gradient(${isHovered ? '135deg' : '45deg'}, transparent 0%, rgba(212,175,55,0.03) 25%, rgba(247,216,120,0.05) 50%, rgba(212,175,55,0.03) 75%, transparent 100%)`
          }}
        />
      </motion.div>

      {/* Floating gold balance indicator */}
      <motion.div
        className="absolute -right-2 top-1/2 -translate-y-1/2 bg-gradient-to-br from-[#1A1A1A] to-[#0A0A0A] rounded-xl border border-[#D4AF37]/30 p-3 shadow-xl"
        initial={{ opacity: 0, x: 10 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 0.3 }}
      >
        <p className="text-[8px] text-gray-500 uppercase tracking-wider mb-0.5">Gold Balance</p>
        <motion.p 
          className="text-lg font-light text-[#D4AF37]"
          animate={{ opacity: [0.7, 1, 0.7] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          {goldBalance?.toFixed(2) || '0.00'}g
        </motion.p>
        <p className="text-[10px] text-gray-400">≈ ${goldValue?.toLocaleString() || '0.00'}</p>
      </motion.div>

      {/* Live price indicator */}
      <motion.div
        className="absolute -left-2 bottom-4 bg-gradient-to-br from-[#1A1A1A] to-[#0A0A0A] rounded-lg border border-[#D4AF37]/30 px-2 py-1.5 shadow-xl"
        initial={{ opacity: 0, x: -10 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 0.5 }}
      >
        <div className="flex items-center gap-1.5">
          <motion.div
            className="w-1.5 h-1.5 rounded-full bg-green-500"
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ duration: 1, repeat: Infinity }}
          />
          <span className="text-[9px] text-gray-400">Live</span>
        </div>
        <p className="text-sm font-light text-white">${goldPrice?.toFixed(2) || '85.00'}<span className="text-[9px] text-gray-500">/g</span></p>
      </motion.div>
    </div>
  );
}