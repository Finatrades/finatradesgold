import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, TrendingUp, AlertTriangle, Target, RefreshCw, Loader2, ChevronDown, ChevronUp, Brain } from 'lucide-react';
import { Button } from "@/components/ui/button";

export default function AIFinancialAdvisor({ user, profile }) {
  const [analysis, setAnalysis] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [expandedSections, setExpandedSections] = useState({
    insights: true,
    risks: false,
    rebalancing: false,
    tips: true
  });

  useEffect(() => {
    if (user && profile) {
      generateAnalysis();
    }
  }, [user, profile]);

  const generateAnalysis = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      // Prepare portfolio data
      const portfolioData = {
        goldBalance: profile?.gold_balance || 0,
        finapayWallet: 0, // Would be fetched from actual wallet
        finabridgeWallet: 0, // Would be fetched from actual wallet
        bnslWallet: 0, // Would be fetched from actual wallet
        bnslPlans: [], // Would be fetched from actual plans
        accountType: profile?.account_type || 'individual',
        kycStatus: profile?.kyc_status || 'not_started'
      };

      const prompt = `You are a personalized financial advisor for a gold-backed digital finance platform called Finatrades. Analyze the following user portfolio and provide concise, actionable insights:

Portfolio Summary:
- Total Gold Balance: ${portfolioData.goldBalance}g
- FinaPay Wallet: ${portfolioData.finapayWallet}g (liquid gold for payments)
- FinaBridge Trade Wallet: ${portfolioData.finabridgeWallet}g (locked for trade deals)
- BNSL Wallet: ${portfolioData.bnslWallet}g (earning structured returns)
- Account Type: ${portfolioData.accountType}
- KYC Status: ${portfolioData.kycStatus}

Please provide:
1. Growth Opportunities: 2-3 specific opportunities based on their current portfolio
2. Risk Assessment: 2-3 key risks they should be aware of
3. Rebalancing Strategy: Specific recommendations on how to allocate their gold across wallets
4. Financial Tips: 3 actionable tips for optimizing their gold holdings

Keep each section concise (2-3 sentences max per point). Focus on practical, specific advice.`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            growth_opportunities: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  title: { type: "string" },
                  description: { type: "string" },
                  potential_return: { type: "string" }
                }
              }
            },
            risks: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  title: { type: "string" },
                  description: { type: "string" },
                  severity: { type: "string", enum: ["low", "medium", "high"] }
                }
              }
            },
            rebalancing: {
              type: "object",
              properties: {
                recommended_allocation: {
                  type: "object",
                  properties: {
                    finapay_percentage: { type: "number" },
                    finabridge_percentage: { type: "number" },
                    bnsl_percentage: { type: "number" }
                  }
                },
                rationale: { type: "string" },
                action_steps: { type: "array", items: { type: "string" } }
              }
            },
            tips: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  title: { type: "string" },
                  description: { type: "string" }
                }
              }
            }
          }
        }
      });

      setAnalysis(response);
    } catch (err) {
      console.error('Failed to generate analysis:', err);
      setError('Failed to generate financial analysis. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const toggleSection = (section) => {
    setExpandedSections(prev => ({ ...prev, [section]: !prev[section] }));
  };

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'high': return 'text-red-600 bg-red-50 border-red-200';
      case 'medium': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'low': return 'text-green-600 bg-green-50 border-green-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  if (isLoading && !analysis) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white border-2 border-[#8A2BE2]/30 rounded-2xl p-6 shadow-lg"
      >
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] flex items-center justify-center shadow-lg">
            <Brain className="w-6 h-6 text-white animate-pulse" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-[#0D0D0D]">AI Financial Advisor</h2>
            <p className="text-[#4A4A4A] text-sm">Powered by advanced analytics</p>
          </div>
        </div>
        <div className="flex items-center justify-center py-12">
          <div className="text-center">
            <Loader2 className="w-8 h-8 animate-spin text-[#8A2BE2] mx-auto mb-3" />
            <p className="text-[#4A4A4A] text-sm">Analyzing your portfolio...</p>
          </div>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white border-2 border-[#8A2BE2]/30 rounded-2xl p-4 sm:p-6 shadow-lg"
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] flex items-center justify-center shadow-lg">
            <Brain className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-bold text-[#0D0D0D]">AI Financial Advisor</h2>
            <p className="text-[#4A4A4A] text-xs sm:text-sm">Personalized insights for your portfolio</p>
          </div>
        </div>
        <Button
          onClick={generateAnalysis}
          disabled={isLoading}
          size="sm"
          variant="outline"
          className="border-[#8A2BE2]/30 text-[#8A2BE2] hover:bg-[#8A2BE2]/10"
        >
          {isLoading ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <RefreshCw className="w-4 h-4" />
          )}
        </Button>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-4">
          <p className="text-red-600 text-sm">{error}</p>
        </div>
      )}

      {analysis && (
        <div className="space-y-4">
          {/* Growth Opportunities */}
          <div className="border-2 border-[#8A2BE2]/20 rounded-xl overflow-hidden">
            <button
              onClick={() => toggleSection('insights')}
              className="w-full flex items-center justify-between p-4 bg-gradient-to-r from-green-50 to-emerald-50 hover:from-green-100 hover:to-emerald-100 transition-colors"
            >
              <div className="flex items-center gap-3">
                <TrendingUp className="w-5 h-5 text-green-600" />
                <h3 className="text-sm sm:text-base font-bold text-[#0D0D0D]">Growth Opportunities</h3>
              </div>
              {expandedSections.insights ? <ChevronUp className="w-5 h-5 text-[#4A4A4A]" /> : <ChevronDown className="w-5 h-5 text-[#4A4A4A]" />}
            </button>
            <AnimatePresence>
              {expandedSections.insights && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="border-t-2 border-[#8A2BE2]/10"
                >
                  <div className="p-4 space-y-3">
                    {analysis.growth_opportunities?.map((opp, idx) => (
                      <div key={idx} className="bg-white rounded-lg p-3 border border-green-200">
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1">
                            <h4 className="font-semibold text-[#0D0D0D] text-sm mb-1">{opp.title}</h4>
                            <p className="text-[#4A4A4A] text-xs sm:text-sm">{opp.description}</p>
                          </div>
                          {opp.potential_return && (
                            <span className="px-2 py-1 rounded-full bg-green-100 text-green-700 text-xs font-medium whitespace-nowrap">
                              {opp.potential_return}
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Risks */}
          <div className="border-2 border-[#8A2BE2]/20 rounded-xl overflow-hidden">
            <button
              onClick={() => toggleSection('risks')}
              className="w-full flex items-center justify-between p-4 bg-gradient-to-r from-amber-50 to-orange-50 hover:from-amber-100 hover:to-orange-100 transition-colors"
            >
              <div className="flex items-center gap-3">
                <AlertTriangle className="w-5 h-5 text-amber-600" />
                <h3 className="text-sm sm:text-base font-bold text-[#0D0D0D]">Risk Assessment</h3>
              </div>
              {expandedSections.risks ? <ChevronUp className="w-5 h-5 text-[#4A4A4A]" /> : <ChevronDown className="w-5 h-5 text-[#4A4A4A]" />}
            </button>
            <AnimatePresence>
              {expandedSections.risks && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="border-t-2 border-[#8A2BE2]/10"
                >
                  <div className="p-4 space-y-3">
                    {analysis.risks?.map((risk, idx) => (
                      <div key={idx} className={`rounded-lg p-3 border ${getSeverityColor(risk.severity)}`}>
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1">
                            <h4 className="font-semibold text-sm mb-1">{risk.title}</h4>
                            <p className="text-xs sm:text-sm">{risk.description}</p>
                          </div>
                          <span className="px-2 py-1 rounded-full text-xs font-medium uppercase whitespace-nowrap">
                            {risk.severity}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Rebalancing Strategy */}
          <div className="border-2 border-[#8A2BE2]/20 rounded-xl overflow-hidden">
            <button
              onClick={() => toggleSection('rebalancing')}
              className="w-full flex items-center justify-between p-4 bg-gradient-to-r from-purple-50 to-pink-50 hover:from-purple-100 hover:to-pink-100 transition-colors"
            >
              <div className="flex items-center gap-3">
                <Target className="w-5 h-5 text-purple-600" />
                <h3 className="text-sm sm:text-base font-bold text-[#0D0D0D]">Rebalancing Strategy</h3>
              </div>
              {expandedSections.rebalancing ? <ChevronUp className="w-5 h-5 text-[#4A4A4A]" /> : <ChevronDown className="w-5 h-5 text-[#4A4A4A]" />}
            </button>
            <AnimatePresence>
              {expandedSections.rebalancing && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="border-t-2 border-[#8A2BE2]/10"
                >
                  <div className="p-4 space-y-4">
                    {/* Allocation Chart */}
                    <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg p-4 border border-purple-200">
                      <h4 className="font-semibold text-[#0D0D0D] text-sm mb-3">Recommended Allocation</h4>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs sm:text-sm text-[#4A4A4A]">FinaPay (Liquid)</span>
                          <span className="font-bold text-[#0D0D0D]">{analysis.rebalancing?.recommended_allocation?.finapay_percentage || 0}%</span>
                        </div>
                        <div className="w-full h-2 bg-white rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF]"
                            style={{ width: `${analysis.rebalancing?.recommended_allocation?.finapay_percentage || 0}%` }}
                          />
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-xs sm:text-sm text-[#4A4A4A]">FinaBridge (Trade)</span>
                          <span className="font-bold text-[#0D0D0D]">{analysis.rebalancing?.recommended_allocation?.finabridge_percentage || 0}%</span>
                        </div>
                        <div className="w-full h-2 bg-white rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-gradient-to-r from-emerald-500 to-teal-600"
                            style={{ width: `${analysis.rebalancing?.recommended_allocation?.finabridge_percentage || 0}%` }}
                          />
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-xs sm:text-sm text-[#4A4A4A]">BNSL (Growth)</span>
                          <span className="font-bold text-[#0D0D0D]">{analysis.rebalancing?.recommended_allocation?.bnsl_percentage || 0}%</span>
                        </div>
                        <div className="w-full h-2 bg-white rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-gradient-to-r from-orange-500 to-amber-600"
                            style={{ width: `${analysis.rebalancing?.recommended_allocation?.bnsl_percentage || 0}%` }}
                          />
                        </div>
                      </div>
                    </div>
                    <div className="bg-white rounded-lg p-3 border border-purple-200">
                      <p className="text-[#4A4A4A] text-xs sm:text-sm mb-3">{analysis.rebalancing?.rationale}</p>
                      {analysis.rebalancing?.action_steps && (
                        <div className="space-y-2">
                          <h5 className="font-semibold text-[#0D0D0D] text-sm">Action Steps:</h5>
                          <ul className="space-y-1">
                            {analysis.rebalancing.action_steps.map((step, idx) => (
                              <li key={idx} className="text-[#4A4A4A] text-xs sm:text-sm flex items-start gap-2">
                                <span className="text-[#8A2BE2] font-bold">{idx + 1}.</span>
                                <span>{step}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Financial Tips */}
          <div className="border-2 border-[#8A2BE2]/20 rounded-xl overflow-hidden">
            <button
              onClick={() => toggleSection('tips')}
              className="w-full flex items-center justify-between p-4 bg-gradient-to-r from-blue-50 to-cyan-50 hover:from-blue-100 hover:to-cyan-100 transition-colors"
            >
              <div className="flex items-center gap-3">
                <Sparkles className="w-5 h-5 text-blue-600" />
                <h3 className="text-sm sm:text-base font-bold text-[#0D0D0D]">Financial Tips</h3>
              </div>
              {expandedSections.tips ? <ChevronUp className="w-5 h-5 text-[#4A4A4A]" /> : <ChevronDown className="w-5 h-5 text-[#4A4A4A]" />}
            </button>
            <AnimatePresence>
              {expandedSections.tips && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="border-t-2 border-[#8A2BE2]/10"
                >
                  <div className="p-4 space-y-3">
                    {analysis.tips?.map((tip, idx) => (
                      <div key={idx} className="bg-gradient-to-r from-blue-50 to-cyan-50 rounded-lg p-3 border border-blue-200">
                        <h4 className="font-semibold text-[#0D0D0D] text-sm mb-1 flex items-center gap-2">
                          <span className="w-6 h-6 rounded-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white text-xs flex items-center justify-center font-bold">
                            {idx + 1}
                          </span>
                          {tip.title}
                        </h4>
                        <p className="text-[#4A4A4A] text-xs sm:text-sm ml-8">{tip.description}</p>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      )}

      {/* Disclaimer */}
      <div className="mt-4 pt-4 border-t border-[#8A2BE2]/20">
        <p className="text-[#4A4A4A] text-xs text-center">
          AI-generated insights are for informational purposes only. Not financial advice. Always do your own research.
        </p>
      </div>
    </motion.div>
  );
}