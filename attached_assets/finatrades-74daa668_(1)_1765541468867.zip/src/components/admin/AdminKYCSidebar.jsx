import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { 
  LayoutDashboard, User, Building2, AlertTriangle, Settings, LogOut, ArrowLeft
} from 'lucide-react';

const menuItems = [
  { icon: LayoutDashboard, label: 'KYC Dashboard', section: 'dashboard' },
  { icon: User, label: 'Personal KYC', section: 'personal' },
  { icon: Building2, label: 'Corporate KYC', section: 'corporate' },
  { icon: AlertTriangle, label: 'PEP / Sanctions Flags', section: 'pep' },
  { icon: Settings, label: 'KYC Settings', section: 'settings' },
];

export default function AdminKYCSidebar({ currentSection, onSectionChange, onLogout }) {
  return (
    <aside className="fixed inset-y-0 left-0 z-50 w-64 bg-black/60 backdrop-blur-xl border-r border-[#D1A954]/20">
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="p-6 border-b border-[#D1A954]/20">
          <Link to={createPageUrl("AdminDashboard")} className="flex items-center gap-2 text-white/60 hover:text-white mb-4 text-sm">
            <ArrowLeft className="w-4 h-4" />
            Back to Admin
          </Link>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-r from-[#D1A954] to-[#B8963E] flex items-center justify-center">
              <User className="w-5 h-5 text-black" />
            </div>
            <div>
              <h2 className="text-white font-bold">KYC Admin</h2>
              <p className="text-white/50 text-xs">Compliance Module</p>
            </div>
          </div>
        </div>

        {/* Menu */}
        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          {menuItems.map((item) => {
            const isActive = currentSection === item.section;
            return (
              <button
                key={item.section}
                onClick={() => onSectionChange(item.section)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all text-left ${
                  isActive 
                    ? 'bg-[#D1A954]/10 text-[#D1A954] border border-[#D1A954]/30' 
                    : 'text-white/60 hover:bg-white/5 hover:text-white'
                }`}
              >
                <item.icon className="w-5 h-5" />
                <span className="font-medium">{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Logout */}
        <div className="p-4 border-t border-[#D1A954]/20">
          <button
            onClick={onLogout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl border border-[#D1A954]/30 text-white/60 hover:bg-[#D1A954]/10 hover:text-white hover:border-[#D1A954]/50 transition-all"
          >
            <LogOut className="w-4 h-4" />
            <span className="font-medium">Sign Out</span>
          </button>
        </div>
      </div>
    </aside>
  );
}