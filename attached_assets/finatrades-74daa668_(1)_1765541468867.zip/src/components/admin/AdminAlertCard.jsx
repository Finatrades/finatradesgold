import React from 'react';
import { AlertTriangle, Shield, TrendingUp, CreditCard, ChevronRight } from 'lucide-react';
import { motion } from 'framer-motion';

const alertIcons = {
  aml: Shield,
  sanctions: AlertTriangle,
  volume: TrendingUp,
  payout: CreditCard,
  default: AlertTriangle
};

const alertColors = {
  critical: 'border-red-500/30 bg-red-500/5',
  warning: 'border-amber-500/30 bg-amber-500/5',
  info: 'border-blue-500/30 bg-blue-500/5'
};

export default function AdminAlertCard({ alerts = [] }) {
  if (!alerts.length) {
    return (
      <div className="bg-white border border-[#8A2BE2]/20 rounded-2xl p-6 shadow-sm">
        <h3 className="text-[#0D0D0D] font-semibold mb-4">System Alerts</h3>
        <div className="flex items-center justify-center py-8 text-[#4A4A4A]">
          <Shield className="w-8 h-8 mr-3 text-green-500" />
          <span>No active alerts</span>
        </div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white border border-[#8A2BE2]/20 rounded-2xl overflow-hidden shadow-sm"
    >
      <div className="px-6 py-4 border-b border-[#8A2BE2]/10 flex items-center justify-between">
        <h3 className="text-[#0D0D0D] font-semibold">System Alerts</h3>
        <span className="px-2 py-1 bg-red-500/20 text-red-600 text-xs rounded-full font-medium">
          {alerts.length} Active
        </span>
      </div>
      
      <div className="divide-y divide-[#8A2BE2]/10">
        {alerts.map((alert, index) => {
          const Icon = alertIcons[alert.type] || alertIcons.default;
          const colorClass = alertColors[alert.severity] || alertColors.warning;
          
          return (
            <div key={index} className={`p-4 ${colorClass} hover:bg-[#F4F6FC] transition-colors cursor-pointer`}>
              <div className="flex items-start gap-3">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                  alert.severity === 'critical' ? 'bg-red-500/20 text-red-600' :
                  alert.severity === 'warning' ? 'bg-amber-500/20 text-amber-600' :
                  'bg-blue-500/20 text-blue-600'
                }`}>
                  <Icon className="w-4 h-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[#0D0D0D] font-medium text-sm">{alert.title}</p>
                  <p className="text-[#4A4A4A] text-xs mt-1">{alert.description}</p>
                  <p className="text-[#4A4A4A] text-xs mt-2">{alert.time}</p>
                </div>
                <ChevronRight className="w-4 h-4 text-[#4A4A4A]" />
              </div>
            </div>
          );
        })}
      </div>
    </motion.div>
  );
}