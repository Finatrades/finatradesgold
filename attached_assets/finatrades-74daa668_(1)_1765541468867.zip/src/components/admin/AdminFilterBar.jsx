import React from 'react';
import { Search, Filter, X } from 'lucide-react';
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";

export default function AdminFilterBar({ 
  searchPlaceholder = 'Search...',
  searchValue,
  onSearchChange,
  filters = [],
  onClearFilters
}) {
  const hasActiveFilters = filters.some(f => f.value && f.value !== 'all');
  
  return (
    <div className="flex flex-wrap items-center gap-3 p-4 bg-white border border-[#8A2BE2]/10 rounded-xl shadow-sm">
      {/* Search */}
      <div className="relative flex-1 min-w-[200px]">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#4A4A4A]" />
        <Input
          placeholder={searchPlaceholder}
          value={searchValue}
          onChange={(e) => onSearchChange?.(e.target.value)}
          className="pl-10 bg-white border-[#8A2BE2]/20 text-[#0D0D0D] placeholder:text-[#4A4A4A] focus:border-[#8A2BE2]/50"
        />
      </div>
      
      {/* Filters */}
      {filters.map((filter, index) => (
        <Select key={index} value={filter.value} onValueChange={filter.onChange}>
          <SelectTrigger className="w-[150px] bg-white border-[#8A2BE2]/20 text-[#0D0D0D]">
            <SelectValue placeholder={filter.placeholder} />
          </SelectTrigger>
          <SelectContent className="bg-white border-[#8A2BE2]/20">
            <SelectItem value="all" className="text-[#0D0D0D]">{filter.allLabel || 'All'}</SelectItem>
            {filter.options.map((opt, i) => (
              <SelectItem key={i} value={opt.value} className="text-[#0D0D0D]">
                {opt.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      ))}
      
      {/* Clear Filters */}
      {hasActiveFilters && onClearFilters && (
        <Button
          variant="ghost"
          size="sm"
          onClick={onClearFilters}
          className="text-[#4A4A4A] hover:text-[#0D0D0D] hover:bg-[#F4F6FC]"
        >
          <X className="w-4 h-4 mr-1" />
          Clear
        </Button>
      )}
    </div>
  );
}