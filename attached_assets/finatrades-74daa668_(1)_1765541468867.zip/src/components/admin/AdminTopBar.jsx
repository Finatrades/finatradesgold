import React from 'react';
import { Bell, ChevronDown } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const roles = ['Operations', 'Compliance', 'Finance', 'Admin'];

export default function AdminTopBar({ user, environment = 'LIVE', role, onRoleChange, systemStatus = 'green' }) {
  const statusColors = {
    green: 'bg-green-500',
    amber: 'bg-amber-500',
    red: 'bg-red-500'
  };

  return (
    <header className="sticky top-0 z-30 bg-white border-b border-[#8A2BE2]/20 px-6 py-3 shadow-sm">
      <div className="flex items-center justify-between">
        {/* Left - Environment & Role */}
        <div className="flex items-center gap-4">
          {/* Environment Badge */}
          <div className={`px-3 py-1 rounded-full text-xs font-bold tracking-wider ${
            environment === 'LIVE' 
              ? 'bg-green-500/20 text-green-400 border border-green-500/30' 
              : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
          }`}>
            {environment}
          </div>

          {/* Role Tabs */}
          <div className="flex items-center bg-[#F4F6FC] rounded-lg p-1 border border-[#8A2BE2]/10">
            {roles.map((r) => (
              <button
                key={r}
                onClick={() => onRoleChange?.(r)}
                className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
                  role === r 
                    ? 'bg-white text-[#8A2BE2] shadow-sm' 
                    : 'text-[#4A4A4A] hover:text-[#0D0D0D]'
                }`}
              >
                {r}
              </button>
            ))}
          </div>
        </div>

        {/* Right - Status, Notifications, User */}
        <div className="flex items-center gap-4">
          {/* System Status */}
          <div className="flex items-center gap-2 px-3 py-1.5 bg-[#F4F6FC] rounded-lg border border-[#8A2BE2]/10">
            <div className={`w-2 h-2 rounded-full ${statusColors[systemStatus]} animate-pulse`} />
            <span className="text-[#4A4A4A] text-xs">System Status</span>
          </div>

          {/* Notifications */}
          <button className="relative w-10 h-10 rounded-lg bg-[#F4F6FC] border border-[#8A2BE2]/10 flex items-center justify-center text-[#4A4A4A] hover:bg-[#8A2BE2]/10 transition-all">
            <Bell className="w-5 h-5" />
            <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full text-[10px] font-bold text-white flex items-center justify-center">3</span>
          </button>

          {/* User Menu */}
          <DropdownMenu>
            <DropdownMenuTrigger className="flex items-center gap-3 px-3 py-2 rounded-lg bg-[#F4F6FC] border border-[#8A2BE2]/10 hover:bg-[#8A2BE2]/10 transition-all">
              <div className="w-8 h-8 rounded-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] flex items-center justify-center text-white font-bold text-sm">
                {user?.full_name?.charAt(0) || 'A'}
              </div>
              <div className="text-left hidden sm:block">
                <p className="text-[#0D0D0D] text-sm font-medium">{user?.full_name || 'Admin'}</p>
                <p className="text-[#4A4A4A] text-xs">{role || 'Admin'}</p>
              </div>
              <ChevronDown className="w-4 h-4 text-[#4A4A4A]" />
            </DropdownMenuTrigger>
            <DropdownMenuContent className="bg-white border-[#8A2BE2]/20">
              <DropdownMenuItem className="text-[#0D0D0D] hover:bg-[#F4F6FC]">
                Profile Settings
              </DropdownMenuItem>
              <DropdownMenuItem className="text-[#0D0D0D] hover:bg-[#F4F6FC]">
                Activity Log
              </DropdownMenuItem>
              <DropdownMenuItem className="text-red-500 hover:bg-red-50">
                Sign Out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}