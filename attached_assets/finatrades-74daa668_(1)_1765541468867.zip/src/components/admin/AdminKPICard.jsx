import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, TrendingDown } from 'lucide-react';

export default function AdminKPICard({ 
  icon: Icon, 
  label, 
  value, 
  subValue, 
  trend, 
  trendValue,
  color = 'from-[#D1A954] to-[#B8963E]',
  delay = 0 
}) {
  const isPositive = trend === 'up';
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      className="bg-white border border-[#8A2BE2]/20 rounded-2xl p-5 hover:border-[#8A2BE2]/40 transition-all group shadow-sm"
    >
      <div className="flex items-start justify-between mb-3">
        <div className={`w-10 h-10 rounded-xl bg-gradient-to-r ${color} flex items-center justify-center shadow-lg`}>
          <Icon className="w-5 h-5 text-white" />
        </div>
        {trend && (
          <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${
            isPositive 
              ? 'bg-green-500/10 text-green-600' 
              : 'bg-red-500/10 text-red-600'
          }`}>
            {isPositive ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
            {trendValue}
          </div>
        )}
      </div>
      <p className="text-[#4A4A4A] text-xs uppercase tracking-wider mb-1">{label}</p>
      <p className="text-[#0D0D0D] text-2xl font-bold">{value}</p>
      {subValue && <p className="text-[#4A4A4A] text-sm mt-1">{subValue}</p>}
    </motion.div>
  );
}