import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, CheckCircle, XCircle, AlertTriangle, Building2, FileText, Users, Shield, Clock, Download, Eye, ChevronDown } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import AdminStatusBadge from '@/components/admin/AdminStatusBadge';

const sampleUBOs = [
  { name: 'John Smith', passport: 'GB123456789', nationality: 'British', email: 'john@company.com', ownership: 60, pep: false },
  { name: 'Maria Garcia', passport: 'ES987654321', nationality: 'Spanish', email: 'maria@company.com', ownership: 25, pep: true },
  { name: 'Ahmed Hassan', passport: 'AE112233445', nationality: 'UAE', email: 'ahmed@company.com', ownership: 15, pep: false },
];

const corporateDocs = [
  { name: 'Certificate of Incorporation', status: 'verified', date: '2024-12-01' },
  { name: 'Trade License / Commercial License', status: 'verified', date: '2024-12-01' },
  { name: 'Memorandum & Articles of Association', status: 'uploaded', date: '2024-12-02' },
  { name: 'Shareholder Register', status: 'uploaded', date: '2024-12-02' },
  { name: 'UBO Declaration', status: 'missing', date: null },
  { name: 'Board Resolution / Power of Attorney', status: 'uploaded', date: '2024-12-03' },
];

export default function CorporateKYCDrawer({ kyc, onClose, onAction }) {
  const [riskLevel, setRiskLevel] = useState(kyc?.riskScore?.toLowerCase() || 'medium');
  const [decision, setDecision] = useState('');
  const [notes, setNotes] = useState('');
  const [amlDecision, setAmlDecision] = useState('');
  const [expandedUBO, setExpandedUBO] = useState(null);

  if (!kyc) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex"
    >
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      
      <motion.div
        initial={{ x: '100%' }}
        animate={{ x: 0 }}
        exit={{ x: '100%' }}
        transition={{ type: 'spring', damping: 30, stiffness: 300 }}
        className="absolute right-0 inset-y-0 w-full max-w-5xl bg-gradient-to-b from-[#0D0515] to-[#1a0a2e] border-l border-[#D1A954]/20 shadow-2xl flex flex-col"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#D1A954]/20">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-gradient-to-r from-purple-500 to-violet-600 flex items-center justify-center">
              <Building2 className="w-7 h-7 text-white" />
            </div>
            <div>
              <h2 className="text-white font-bold text-lg">{kyc.name}</h2>
              <div className="flex items-center gap-3 mt-1">
                <span className="text-white/50 text-sm">{kyc.id}</span>
                <span className="text-white/30">•</span>
                <span className="text-white/50 text-sm">{kyc.country}</span>
                <AdminStatusBadge status={kyc.status} />
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Select value={riskLevel} onValueChange={setRiskLevel}>
              <SelectTrigger className="w-32 bg-white/5 border-white/10 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-[#1a0a2e] border-[#D1A954]/20">
                <SelectItem value="low" className="text-green-400">Low Risk</SelectItem>
                <SelectItem value="medium" className="text-amber-400">Medium Risk</SelectItem>
                <SelectItem value="high" className="text-red-400">High Risk</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="ghost" size="icon" onClick={onClose} className="text-white/60 hover:text-white">
              <X className="w-5 h-5" />
            </Button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          <Tabs defaultValue="corporate" className="w-full">
            <TabsList className="w-full bg-white/5 border border-white/10 p-1 mb-6">
              <TabsTrigger value="corporate" className="flex-1 data-[state=active]:bg-[#D1A954]/20 data-[state=active]:text-[#D1A954]">
                <Building2 className="w-4 h-4 mr-2" />
                Corporate Details
              </TabsTrigger>
              <TabsTrigger value="ubo" className="flex-1 data-[state=active]:bg-[#D1A954]/20 data-[state=active]:text-[#D1A954]">
                <Users className="w-4 h-4 mr-2" />
                UBO & Shareholding
              </TabsTrigger>
              <TabsTrigger value="documents" className="flex-1 data-[state=active]:bg-[#D1A954]/20 data-[state=active]:text-[#D1A954]">
                <FileText className="w-4 h-4 mr-2" />
                Documents
              </TabsTrigger>
              <TabsTrigger value="pep" className="flex-1 data-[state=active]:bg-[#D1A954]/20 data-[state=active]:text-[#D1A954]">
                <Shield className="w-4 h-4 mr-2" />
                PEP / Sanctions
              </TabsTrigger>
              <TabsTrigger value="activity" className="flex-1 data-[state=active]:bg-[#D1A954]/20 data-[state=active]:text-[#D1A954]">
                <Clock className="w-4 h-4 mr-2" />
                Activity & Notes
              </TabsTrigger>
            </TabsList>

            {/* Corporate Details Tab */}
            <TabsContent value="corporate" className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                {[
                  { label: 'Registered Company Name', value: kyc.name },
                  { label: 'Registration Number', value: kyc.regNumber || 'CHE-123.456.789' },
                  { label: 'Date of Incorporation', value: kyc.incorporation || '2015-06-20' },
                  { label: 'Country of Incorporation', value: kyc.country },
                  { label: 'Legal Form', value: 'Limited Liability Company (LLC)' },
                  { label: 'Nature of Business', value: kyc.businessType || 'Precious Metals Trading' },
                  { label: 'Number of Employees', value: '50-100' },
                  { label: 'Annual Turnover', value: '$10M - $50M' },
                ].map((field, i) => (
                  <div key={i} className="bg-white/5 rounded-lg p-4 border border-white/10">
                    <p className="text-white/40 text-xs uppercase tracking-wider mb-1">{field.label}</p>
                    <p className="text-white">{field.value}</p>
                  </div>
                ))}
              </div>
              <div className="bg-white/5 rounded-lg p-4 border border-white/10">
                <p className="text-white/40 text-xs uppercase tracking-wider mb-1">Registered Address</p>
                <p className="text-white">{kyc.address || 'Bahnhofstrasse 42, 8001 Zurich, Switzerland'}</p>
              </div>
              <div className="bg-white/5 rounded-lg p-4 border border-white/10">
                <p className="text-white/40 text-xs uppercase tracking-wider mb-1">Trading Address</p>
                <p className="text-white">Same as registered address</p>
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div className="bg-white/5 rounded-lg p-4 border border-white/10">
                  <p className="text-white/40 text-xs uppercase tracking-wider mb-1">Contact Person</p>
                  <p className="text-white">Hans Mueller</p>
                </div>
                <div className="bg-white/5 rounded-lg p-4 border border-white/10">
                  <p className="text-white/40 text-xs uppercase tracking-wider mb-1">Email</p>
                  <p className="text-white">{kyc.email}</p>
                </div>
                <div className="bg-white/5 rounded-lg p-4 border border-white/10">
                  <p className="text-white/40 text-xs uppercase tracking-wider mb-1">Phone</p>
                  <p className="text-white">+41 44 123 4567</p>
                </div>
              </div>
            </TabsContent>

            {/* UBO Tab */}
            <TabsContent value="ubo" className="space-y-4">
              <div className="bg-white/5 rounded-xl border border-white/10 overflow-hidden">
                <div className="px-4 py-3 border-b border-white/10">
                  <p className="text-white font-medium">Ultimate Beneficial Owners (UBOs)</p>
                </div>
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-white/5">
                      <th className="px-4 py-3 text-left text-white/40 text-xs uppercase">Name</th>
                      <th className="px-4 py-3 text-left text-white/40 text-xs uppercase">Passport / ID</th>
                      <th className="px-4 py-3 text-left text-white/40 text-xs uppercase">Nationality</th>
                      <th className="px-4 py-3 text-left text-white/40 text-xs uppercase">Email</th>
                      <th className="px-4 py-3 text-left text-white/40 text-xs uppercase">Ownership %</th>
                      <th className="px-4 py-3 text-left text-white/40 text-xs uppercase">PEP</th>
                      <th className="px-4 py-3 text-left text-white/40 text-xs uppercase"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {sampleUBOs.map((ubo, i) => (
                      <React.Fragment key={i}>
                        <tr className="border-b border-white/5 hover:bg-white/[0.02]">
                          <td className="px-4 py-3 text-white font-medium">{ubo.name}</td>
                          <td className="px-4 py-3 text-white/70 font-mono text-sm">{ubo.passport}</td>
                          <td className="px-4 py-3 text-white/70">{ubo.nationality}</td>
                          <td className="px-4 py-3 text-white/70">{ubo.email}</td>
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-2">
                              <div className="w-16 h-2 bg-white/10 rounded-full overflow-hidden">
                                <div className="h-full bg-[#D1A954]" style={{ width: `${ubo.ownership}%` }} />
                              </div>
                              <span className="text-white/70">{ubo.ownership}%</span>
                            </div>
                          </td>
                          <td className="px-4 py-3">
                            <span className={`px-2 py-1 rounded text-xs font-medium ${ubo.pep ? 'bg-amber-500/20 text-amber-400' : 'bg-green-500/20 text-green-400'}`}>
                              {ubo.pep ? 'Yes' : 'No'}
                            </span>
                          </td>
                          <td className="px-4 py-3">
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => setExpandedUBO(expandedUBO === i ? null : i)}
                              className="text-[#D1A954]"
                            >
                              <ChevronDown className={`w-4 h-4 transition-transform ${expandedUBO === i ? 'rotate-180' : ''}`} />
                            </Button>
                          </td>
                        </tr>
                        {expandedUBO === i && (
                          <tr className="bg-white/[0.02]">
                            <td colSpan={7} className="px-4 py-4">
                              <div className="grid grid-cols-4 gap-4">
                                <div className="bg-white/5 rounded-lg p-3">
                                  <p className="text-white/40 text-xs mb-1">Date of Birth</p>
                                  <p className="text-white text-sm">1975-08-22</p>
                                </div>
                                <div className="bg-white/5 rounded-lg p-3">
                                  <p className="text-white/40 text-xs mb-1">Address</p>
                                  <p className="text-white text-sm">London, UK</p>
                                </div>
                                <div className="bg-white/5 rounded-lg p-3">
                                  <p className="text-white/40 text-xs mb-1">Source of Wealth</p>
                                  <p className="text-white text-sm">Business Ownership</p>
                                </div>
                                <div className="bg-white/5 rounded-lg p-3">
                                  <p className="text-white/40 text-xs mb-1">ID Verified</p>
                                  <p className="text-green-400 text-sm">✓ Verified</p>
                                </div>
                              </div>
                            </td>
                          </tr>
                        )}
                      </React.Fragment>
                    ))}
                  </tbody>
                </table>
              </div>
            </TabsContent>

            {/* Documents Tab */}
            <TabsContent value="documents" className="space-y-3">
              {corporateDocs.map((doc, i) => (
                <div key={i} className="flex items-center justify-between p-4 bg-white/5 rounded-xl border border-white/10">
                  <div className="flex items-center gap-4">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                      doc.status === 'verified' ? 'bg-green-500/20' :
                      doc.status === 'uploaded' ? 'bg-blue-500/20' : 'bg-red-500/20'
                    }`}>
                      <FileText className={`w-5 h-5 ${
                        doc.status === 'verified' ? 'text-green-400' :
                        doc.status === 'uploaded' ? 'text-blue-400' : 'text-red-400'
                      }`} />
                    </div>
                    <div>
                      <p className="text-white font-medium">{doc.name}</p>
                      <p className="text-white/40 text-xs">{doc.date ? `Uploaded: ${doc.date}` : 'Not uploaded'}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <AdminStatusBadge status={doc.status} customLabel={doc.status === 'missing' ? 'Missing' : doc.status === 'verified' ? 'Verified' : 'Uploaded'} />
                    {doc.status !== 'missing' && (
                      <>
                        <Button variant="ghost" size="sm" className="text-white/60 hover:text-white">
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm" className="text-white/60 hover:text-white">
                          <Download className="w-4 h-4" />
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              ))}
            </TabsContent>

            {/* PEP / Sanctions Tab */}
            <TabsContent value="pep" className="space-y-6">
              <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-5">
                <div className="flex items-center gap-3 mb-4">
                  <AlertTriangle className="w-6 h-6 text-amber-400" />
                  <h4 className="text-amber-400 font-semibold">PEP / Sanctions Screening Results</h4>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                    <span className="text-white/70">Sanctions Database Check</span>
                    <span className="text-green-400 font-medium">Clear</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                    <span className="text-white/70">PEP Database Hits</span>
                    <span className="text-amber-400 font-medium">1 Match (Maria Garcia)</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                    <span className="text-white/70">Jurisdiction Risk</span>
                    <span className="text-green-400 font-medium">Low (Switzerland)</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                    <span className="text-white/70">Adverse Media</span>
                    <span className="text-green-400 font-medium">None Found</span>
                  </div>
                </div>
              </div>

              <div>
                <p className="text-white/60 text-sm mb-2">AML Screening Notes</p>
                <Textarea
                  placeholder="Add AML screening observations..."
                  className="min-h-[100px] bg-white/5 border-white/10 text-white placeholder:text-white/40"
                />
              </div>

              <div className="flex items-center gap-4">
                <span className="text-white/60">Overall AML Decision:</span>
                <Select value={amlDecision} onValueChange={setAmlDecision}>
                  <SelectTrigger className="w-40 bg-white/5 border-white/10 text-white">
                    <SelectValue placeholder="Select..." />
                  </SelectTrigger>
                  <SelectContent className="bg-[#1a0a2e] border-[#D1A954]/20">
                    <SelectItem value="clear" className="text-green-400">Clear</SelectItem>
                    <SelectItem value="review" className="text-amber-400">Requires Review</SelectItem>
                    <SelectItem value="reject" className="text-red-400">Reject</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </TabsContent>

            {/* Activity Tab */}
            <TabsContent value="activity" className="space-y-6">
              <div className="bg-white/5 rounded-xl border border-white/10 overflow-hidden">
                <div className="px-4 py-3 border-b border-white/10">
                  <p className="text-white font-medium">Activity Log</p>
                </div>
                <div className="divide-y divide-white/5">
                  {[
                    { action: 'Corporate KYC Submitted', user: kyc.name, date: kyc.submittedDate, type: 'system' },
                    { action: 'Documents uploaded (5 files)', user: kyc.name, date: kyc.submittedDate, type: 'system' },
                    { action: 'UBO declarations added', user: kyc.name, date: kyc.submittedDate, type: 'system' },
                    { action: 'Assigned to Compliance Team', user: 'System', date: kyc.submittedDate, type: 'auto' },
                  ].map((log, i) => (
                    <div key={i} className="px-4 py-3 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`w-2 h-2 rounded-full ${log.type === 'system' ? 'bg-blue-400' : 'bg-green-400'}`} />
                        <span className="text-white/80">{log.action}</span>
                      </div>
                      <div className="text-right">
                        <p className="text-white/50 text-sm">{log.user}</p>
                        <p className="text-white/30 text-xs">{log.date}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <p className="text-white/60 text-sm mb-2">Admin Notes (Internal Only)</p>
                <Textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Add compliance notes..."
                  className="min-h-[150px] bg-white/5 border-white/10 text-white placeholder:text-white/40"
                />
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-[#D1A954]/20 bg-black/30">
          <div className="flex items-center gap-4">
            <Select value={decision} onValueChange={setDecision}>
              <SelectTrigger className="w-48 bg-white/5 border-white/10 text-white">
                <SelectValue placeholder="Select Decision" />
              </SelectTrigger>
              <SelectContent className="bg-[#1a0a2e] border-[#D1A954]/20">
                <SelectItem value="approve" className="text-green-400">Approve</SelectItem>
                <SelectItem value="reject" className="text-red-400">Reject</SelectItem>
                <SelectItem value="request_info" className="text-amber-400">Request More Information</SelectItem>
                <SelectItem value="on_hold" className="text-purple-400">On Hold</SelectItem>
              </SelectContent>
            </Select>
            <div className="flex-1" />
            <Button variant="outline" className="border-amber-500/30 text-amber-400 hover:bg-amber-500/10">
              Request Clarification
            </Button>
            <Button variant="outline" className="border-red-500/30 text-red-400 hover:bg-red-500/10">
              <XCircle className="w-4 h-4 mr-2" />
              Reject KYC
            </Button>
            <Button className="bg-gradient-to-r from-[#D1A954] to-[#B8963E] text-black font-bold">
              <CheckCircle className="w-4 h-4 mr-2" />
              Approve KYC
            </Button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}