import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, CheckCircle, XCircle, AlertTriangle, User, FileText, Camera, Clock, Download, Eye } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import AdminStatusBadge from '@/components/admin/AdminStatusBadge';

export default function PersonalKYCDrawer({ kyc, onClose, onAction }) {
  const [riskLevel, setRiskLevel] = useState(kyc?.riskScore?.toLowerCase() || 'low');
  const [decision, setDecision] = useState('');
  const [notes, setNotes] = useState('');
  const [documentVerified, setDocumentVerified] = useState(false);
  const [faceMatchApproved, setFaceMatchApproved] = useState(false);

  if (!kyc) return null;

  const activityLog = [
    { action: 'KYC Submitted', user: kyc.name, date: kyc.submittedDate, type: 'system' },
    { action: 'Documents uploaded', user: kyc.name, date: kyc.submittedDate, type: 'system' },
    { action: 'Selfie verification completed', user: 'System', date: kyc.submittedDate, type: 'auto' },
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex"
    >
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      
      {/* Drawer */}
      <motion.div
        initial={{ x: '100%' }}
        animate={{ x: 0 }}
        exit={{ x: '100%' }}
        transition={{ type: 'spring', damping: 30, stiffness: 300 }}
        className="absolute right-0 inset-y-0 w-full max-w-4xl bg-gradient-to-b from-[#0D0515] to-[#1a0a2e] border-l border-[#D1A954]/20 shadow-2xl flex flex-col"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#D1A954]/20">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-gradient-to-r from-[#D1A954] to-[#B8963E] flex items-center justify-center text-black text-xl font-bold">
              {kyc.name.charAt(0)}
            </div>
            <div>
              <h2 className="text-white font-bold text-lg">{kyc.name}</h2>
              <div className="flex items-center gap-3 mt-1">
                <span className="text-white/50 text-sm">{kyc.id}</span>
                <AdminStatusBadge status={kyc.status} />
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Select value={riskLevel} onValueChange={setRiskLevel}>
              <SelectTrigger className="w-32 bg-white/5 border-white/10 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-[#1a0a2e] border-[#D1A954]/20">
                <SelectItem value="low" className="text-green-400">Low Risk</SelectItem>
                <SelectItem value="medium" className="text-amber-400">Medium Risk</SelectItem>
                <SelectItem value="high" className="text-red-400">High Risk</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="ghost" size="icon" onClick={onClose} className="text-white/60 hover:text-white">
              <X className="w-5 h-5" />
            </Button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          <Tabs defaultValue="identity" className="w-full">
            <TabsList className="w-full bg-white/5 border border-white/10 p-1 mb-6">
              <TabsTrigger value="identity" className="flex-1 data-[state=active]:bg-[#D1A954]/20 data-[state=active]:text-[#D1A954]">
                <User className="w-4 h-4 mr-2" />
                Identity Info
              </TabsTrigger>
              <TabsTrigger value="documents" className="flex-1 data-[state=active]:bg-[#D1A954]/20 data-[state=active]:text-[#D1A954]">
                <FileText className="w-4 h-4 mr-2" />
                Documents
              </TabsTrigger>
              <TabsTrigger value="selfie" className="flex-1 data-[state=active]:bg-[#D1A954]/20 data-[state=active]:text-[#D1A954]">
                <Camera className="w-4 h-4 mr-2" />
                Selfie & Face Match
              </TabsTrigger>
              <TabsTrigger value="activity" className="flex-1 data-[state=active]:bg-[#D1A954]/20 data-[state=active]:text-[#D1A954]">
                <Clock className="w-4 h-4 mr-2" />
                Activity & Notes
              </TabsTrigger>
            </TabsList>

            {/* Identity Tab */}
            <TabsContent value="identity" className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                {[
                  { label: 'Full Name', value: kyc.name },
                  { label: 'Date of Birth', value: kyc.dob || '1985-03-15' },
                  { label: 'Nationality', value: kyc.nationality || kyc.country },
                  { label: 'ID Type', value: kyc.docType || 'Passport' },
                  { label: 'ID Number', value: kyc.docNumber || 'A12345678' },
                  { label: 'Email', value: kyc.email },
                  { label: 'Phone', value: '+971 50 123 4567' },
                  { label: 'Country', value: kyc.country },
                ].map((field, i) => (
                  <div key={i} className="bg-white/5 rounded-lg p-4 border border-white/10">
                    <p className="text-white/40 text-xs uppercase tracking-wider mb-1">{field.label}</p>
                    <p className="text-white">{field.value}</p>
                  </div>
                ))}
              </div>
              <div className="bg-white/5 rounded-lg p-4 border border-white/10">
                <p className="text-white/40 text-xs uppercase tracking-wider mb-1">Address</p>
                <p className="text-white">{kyc.address || 'Dubai Marina, Dubai, UAE'}</p>
              </div>
              <div className="bg-white/5 rounded-lg p-4 border border-white/10">
                <p className="text-white/40 text-xs uppercase tracking-wider mb-1">Source of Funds</p>
                <p className="text-white">{kyc.sourceOfFunds || 'Employment Income'}</p>
              </div>

              <div className="flex gap-3 pt-4">
                <Button variant="outline" className="border-green-500/30 text-green-400 hover:bg-green-500/10">
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Mark as Cleared
                </Button>
                <Button variant="outline" className="border-amber-500/30 text-amber-400 hover:bg-amber-500/10">
                  <AlertTriangle className="w-4 h-4 mr-2" />
                  Escalate to EDD
                </Button>
              </div>
            </TabsContent>

            {/* Documents Tab */}
            <TabsContent value="documents" className="space-y-4">
              {[
                { name: 'ID Front (Passport)', status: 'uploaded', date: kyc.submittedDate, uploadedBy: kyc.name },
                { name: 'ID Back', status: 'uploaded', date: kyc.submittedDate, uploadedBy: kyc.name },
                { name: 'Proof of Address', status: 'uploaded', date: kyc.submittedDate, uploadedBy: kyc.name },
              ].map((doc, i) => (
                <div key={i} className="flex items-center justify-between p-4 bg-white/5 rounded-xl border border-white/10">
                  <div className="flex items-center gap-4">
                    <div className="w-20 h-14 bg-white/10 rounded-lg flex items-center justify-center">
                      <FileText className="w-6 h-6 text-white/30" />
                    </div>
                    <div>
                      <p className="text-white font-medium">{doc.name}</p>
                      <p className="text-white/40 text-xs">Uploaded: {doc.date} by {doc.uploadedBy}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button variant="ghost" size="sm" className="text-white/60 hover:text-white">
                      <Eye className="w-4 h-4 mr-1" />
                      View
                    </Button>
                    <Button variant="ghost" size="sm" className="text-white/60 hover:text-white">
                      <Download className="w-4 h-4 mr-1" />
                      Download
                    </Button>
                  </div>
                </div>
              ))}

              <div className="flex items-center gap-3 p-4 bg-white/5 rounded-xl border border-white/10 mt-6">
                <Checkbox 
                  checked={documentVerified}
                  onCheckedChange={setDocumentVerified}
                  className="border-[#D1A954]/50 data-[state=checked]:bg-[#D1A954] data-[state=checked]:border-[#D1A954]"
                />
                <span className="text-white/70">Document verified & matches identity</span>
              </div>
            </TabsContent>

            {/* Selfie & Face Match Tab */}
            <TabsContent value="selfie" className="space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <p className="text-white/50 text-sm">ID Document Photo</p>
                  <div className="aspect-square bg-white/5 rounded-xl border border-white/10 flex items-center justify-center">
                    <User className="w-20 h-20 text-white/20" />
                  </div>
                </div>
                <div className="space-y-2">
                  <p className="text-white/50 text-sm">Selfie Capture</p>
                  <div className="aspect-square bg-white/5 rounded-xl border border-white/10 flex items-center justify-center">
                    <Camera className="w-20 h-20 text-white/20" />
                  </div>
                </div>
              </div>

              <div className="bg-white/5 rounded-xl border border-white/10 p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <p className="text-white/50">Face Match Score</p>
                  <span className={`text-3xl font-bold ${
                    (kyc.faceMatchScore || 94) >= 90 ? 'text-green-400' :
                    (kyc.faceMatchScore || 94) >= 75 ? 'text-amber-400' : 'text-red-400'
                  }`}>
                    {kyc.faceMatchScore || 94}%
                  </span>
                </div>
                <div className="h-3 bg-white/10 rounded-full overflow-hidden">
                  <div 
                    className={`h-full rounded-full ${
                      (kyc.faceMatchScore || 94) >= 90 ? 'bg-gradient-to-r from-green-500 to-emerald-500' :
                      (kyc.faceMatchScore || 94) >= 75 ? 'bg-gradient-to-r from-amber-500 to-orange-500' : 
                      'bg-gradient-to-r from-red-500 to-rose-500'
                    }`}
                    style={{ width: `${kyc.faceMatchScore || 94}%` }}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4 pt-2">
                  <div className="flex justify-between">
                    <span className="text-white/50 text-sm">Liveness Check</span>
                    <span className="text-green-400 text-sm font-medium">Pass</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/50 text-sm">Device</span>
                    <span className="text-white/70 text-sm">iPhone 14 Pro</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/50 text-sm">Browser</span>
                    <span className="text-white/70 text-sm">Safari 17.0</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/50 text-sm">IP Address</span>
                    <span className="text-white/70 text-sm">185.x.x.x (UAE)</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-6 p-4 bg-white/5 rounded-xl border border-white/10">
                <label className="flex items-center gap-3 cursor-pointer">
                  <Checkbox 
                    checked={faceMatchApproved}
                    onCheckedChange={setFaceMatchApproved}
                    className="border-green-500/50 data-[state=checked]:bg-green-500 data-[state=checked]:border-green-500"
                  />
                  <span className="text-white/70">Face match approved</span>
                </label>
                <label className="flex items-center gap-3 cursor-pointer">
                  <Checkbox className="border-red-500/50 data-[state=checked]:bg-red-500 data-[state=checked]:border-red-500" />
                  <span className="text-white/70">Face mismatch / suspicious</span>
                </label>
              </div>
            </TabsContent>

            {/* Activity & Notes Tab */}
            <TabsContent value="activity" className="space-y-6">
              <div className="bg-white/5 rounded-xl border border-white/10 overflow-hidden">
                <div className="px-4 py-3 border-b border-white/10">
                  <p className="text-white font-medium">Activity Log</p>
                </div>
                <div className="divide-y divide-white/5">
                  {activityLog.map((log, i) => (
                    <div key={i} className="px-4 py-3 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`w-2 h-2 rounded-full ${log.type === 'system' ? 'bg-blue-400' : 'bg-green-400'}`} />
                        <span className="text-white/80">{log.action}</span>
                      </div>
                      <div className="text-right">
                        <p className="text-white/50 text-sm">{log.user}</p>
                        <p className="text-white/30 text-xs">{log.date}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <p className="text-white/60 text-sm mb-2">Admin Notes (Internal Only)</p>
                <Textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Add compliance notes, observations, or reasons for decision..."
                  className="min-h-[150px] bg-white/5 border-white/10 text-white placeholder:text-white/40"
                />
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Footer - Decision Section */}
        <div className="px-6 py-4 border-t border-[#D1A954]/20 bg-black/30 space-y-4">
          <div className="flex items-center gap-4">
            <Select value={decision} onValueChange={setDecision}>
              <SelectTrigger className="w-48 bg-white/5 border-white/10 text-white">
                <SelectValue placeholder="Select Decision" />
              </SelectTrigger>
              <SelectContent className="bg-[#1a0a2e] border-[#D1A954]/20">
                <SelectItem value="approve" className="text-green-400">Approve</SelectItem>
                <SelectItem value="reject" className="text-red-400">Reject</SelectItem>
                <SelectItem value="request_info" className="text-amber-400">Request More Information</SelectItem>
                <SelectItem value="on_hold" className="text-purple-400">On Hold</SelectItem>
              </SelectContent>
            </Select>
            <div className="flex-1" />
            <Button 
              variant="outline" 
              className="border-amber-500/30 text-amber-400 hover:bg-amber-500/10"
            >
              Request Clarification
            </Button>
            <Button 
              variant="outline" 
              className="border-red-500/30 text-red-400 hover:bg-red-500/10"
            >
              <XCircle className="w-4 h-4 mr-2" />
              Reject KYC
            </Button>
            <Button 
              className="bg-gradient-to-r from-[#D1A954] to-[#B8963E] text-black font-bold"
              onClick={() => onAction?.('approve', kyc)}
            >
              <CheckCircle className="w-4 h-4 mr-2" />
              Approve KYC
            </Button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}