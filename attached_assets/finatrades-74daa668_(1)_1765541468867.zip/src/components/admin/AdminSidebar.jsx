import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { 
  LayoutDashboard, UserCheck, Vault, Wallet, GitBranch, 
  TrendingUp, CreditCard, BarChart3, FileText, Settings, LogOut
} from 'lucide-react';

const menuItems = [
  { icon: LayoutDashboard, label: 'Dashboard', page: 'AdminDashboard', section: 'dashboard' },
  { icon: UserCheck, label: 'KYC & Onboarding', page: 'AdminKYC', section: 'kyc' },
  { icon: Vault, label: 'FinaVault', page: 'AdminVault', section: 'vault' },
  { icon: Wallet, label: 'FinaPay & Transfers', page: 'AdminFinaPay', section: 'finapay' },
  { icon: GitBranch, label: 'FinaBridge', page: 'AdminFinaBridge', section: 'finabridge' },
  { icon: TrendingUp, label: 'BNSL Plans', page: 'AdminBNSL', section: 'bnsl' },
  { icon: CreditCard, label: 'Debit Cards', page: 'AdminCards', section: 'cards' },
  { icon: BarChart3, label: 'Yields & Reports', page: 'AdminYields', section: 'yields' },
  { icon: FileText, label: 'Audit Logs', page: 'AdminAuditLogs', section: 'audit' },
  { icon: Settings, label: 'Settings & Roles', page: 'AdminSettings', section: 'settings' },
];

export default function AdminSidebar({ currentSection, onLogout }) {
  return (
    <aside className="fixed inset-y-0 left-0 z-50 w-64 bg-white border-r border-[#8A2BE2]/20 shadow-lg">
      <div className="flex flex-col h-full">
        {/* Logo */}
        <div className="p-6 border-b border-[#8A2BE2]/20">
          <Link to={createPageUrl("AdminDashboard")} className="flex items-center">
            <img 
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69293bd8e52dce0074daa668/ce96e4d2b_FINANEWLOGO-GOLDANDWHITENB.png" 
              alt="Finatrades" 
              className="h-8"
              style={{ filter: 'brightness(0) saturate(100%) invert(29%) sepia(89%) saturate(4527%) hue-rotate(262deg) brightness(96%) contrast(93%)' }}
            />
          </Link>
        </div>

        {/* Menu */}
        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          {menuItems.map((item) => {
            const isActive = currentSection === item.section;
            return (
              <Link
                key={item.label}
                to={createPageUrl(item.page)}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                  isActive 
                    ? 'bg-gradient-to-r from-[#8A2BE2]/10 to-[#FF2FBF]/10 text-[#8A2BE2] border border-[#8A2BE2]/30' 
                    : 'text-[#4A4A4A] hover:bg-[#F4F6FC] hover:text-[#0D0D0D]'
                }`}
              >
                <item.icon className="w-5 h-5" />
                <span className="font-medium">{item.label}</span>
              </Link>
            );
          })}
        </nav>

        {/* Logout */}
        <div className="p-4 border-t border-[#8A2BE2]/20">
          <button
            onClick={onLogout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl border border-[#8A2BE2]/30 text-[#4A4A4A] hover:bg-[#8A2BE2]/10 hover:text-[#0D0D0D] hover:border-[#8A2BE2]/50 transition-all"
          >
            <LogOut className="w-4 h-4" />
            <span className="font-medium">Sign Out</span>
          </button>
        </div>
      </div>
    </aside>
  );
}