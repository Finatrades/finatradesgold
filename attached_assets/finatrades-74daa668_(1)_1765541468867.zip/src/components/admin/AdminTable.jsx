import React from 'react';
import { motion } from 'framer-motion';
import { ChevronRight } from 'lucide-react';
import { Button } from "@/components/ui/button";

export default function AdminTable({ 
  title, 
  columns, 
  data, 
  onRowAction, 
  actionLabel = 'Review',
  emptyMessage = 'No records found'
}) {
  if (!data || data.length === 0) {
    return (
      <div className="bg-white border border-[#8A2BE2]/20 rounded-2xl p-8 shadow-sm">
        <p className="text-[#4A4A4A] text-center">{emptyMessage}</p>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white border border-[#8A2BE2]/20 rounded-2xl overflow-hidden shadow-sm"
    >
      {title && (
        <div className="px-6 py-4 border-b border-[#8A2BE2]/10">
          <h3 className="text-[#0D0D0D] font-semibold">{title}</h3>
        </div>
      )}
      
      {/* Desktop Table */}
      <div className="hidden md:block overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-[#8A2BE2]/10">
              {columns.map((col, i) => (
                <th key={i} className="px-6 py-4 text-left text-[#4A4A4A] text-xs uppercase tracking-wider font-medium">
                  {col.header}
                </th>
              ))}
              {onRowAction && (
                <th className="px-6 py-4 text-right text-[#4A4A4A] text-xs uppercase tracking-wider font-medium">
                  Action
                </th>
              )}
            </tr>
          </thead>
          <tbody className="divide-y divide-[#8A2BE2]/10">
            {data.map((row, rowIndex) => (
              <tr key={rowIndex} className="hover:bg-[#F4F6FC] transition-colors">
                {columns.map((col, colIndex) => (
                  <td key={colIndex} className="px-6 py-4 text-[#0D0D0D] text-sm">
                    {col.render ? col.render(row[col.accessor], row) : row[col.accessor]}
                  </td>
                ))}
                {onRowAction && (
                  <td className="px-6 py-4 text-right">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onRowAction(row)}
                      className="text-[#FF2FBF] hover:text-[#8A2BE2] hover:bg-[#8A2BE2]/10"
                    >
                      {actionLabel}
                      <ChevronRight className="w-4 h-4 ml-1" />
                    </Button>
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Mobile Cards */}
      <div className="md:hidden divide-y divide-[#8A2BE2]/10">
        {data.map((row, rowIndex) => (
          <div key={rowIndex} className="p-4 space-y-2">
            {columns.slice(0, 4).map((col, colIndex) => (
              <div key={colIndex} className="flex justify-between items-center">
                <span className="text-[#4A4A4A] text-xs">{col.header}</span>
                <span className="text-[#0D0D0D] text-sm">
                  {col.render ? col.render(row[col.accessor], row) : row[col.accessor]}
                </span>
              </div>
            ))}
            {onRowAction && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => onRowAction(row)}
                className="w-full mt-2 border-[#8A2BE2]/30 text-[#FF2FBF] hover:bg-[#8A2BE2]/10"
              >
                {actionLabel}
                <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            )}
          </div>
        ))}
      </div>
    </motion.div>
  );
}