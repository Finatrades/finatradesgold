import React from 'react';

const statusStyles = {
  // KYC Statuses
  pending: { bg: 'bg-amber-500/15', text: 'text-amber-400', label: 'Pending' },
  in_review: { bg: 'bg-blue-500/15', text: 'text-blue-400', label: 'In Review' },
  approved: { bg: 'bg-green-500/15', text: 'text-green-400', label: 'Approved' },
  rejected: { bg: 'bg-red-500/15', text: 'text-red-400', label: 'Rejected' },
  on_hold: { bg: 'bg-purple-500/15', text: 'text-purple-400', label: 'On Hold' },
  
  // Vault Statuses
  submitted: { bg: 'bg-amber-500/15', text: 'text-amber-400', label: 'Submitted' },
  under_review: { bg: 'bg-blue-500/15', text: 'text-blue-400', label: 'Under Review' },
  received: { bg: 'bg-cyan-500/15', text: 'text-cyan-400', label: 'Received' },
  stored: { bg: 'bg-green-500/15', text: 'text-green-400', label: 'Stored' },
  
  // Trade Statuses
  docs_pending: { bg: 'bg-amber-500/15', text: 'text-amber-400', label: 'Docs Pending' },
  settled: { bg: 'bg-green-500/15', text: 'text-green-400', label: 'Settled' },
  closed: { bg: 'bg-gray-500/15', text: 'text-gray-400', label: 'Closed' },
  
  // BNSL Statuses
  active: { bg: 'bg-green-500/15', text: 'text-green-400', label: 'Active' },
  matured: { bg: 'bg-blue-500/15', text: 'text-blue-400', label: 'Matured' },
  early_term_requested: { bg: 'bg-orange-500/15', text: 'text-orange-400', label: 'Term Requested' },
  terminated: { bg: 'bg-red-500/15', text: 'text-red-400', label: 'Terminated' },
  
  // Card Statuses
  frozen: { bg: 'bg-blue-500/15', text: 'text-blue-400', label: 'Frozen' },
  blocked: { bg: 'bg-red-500/15', text: 'text-red-400', label: 'Blocked' },
  pending_kyc: { bg: 'bg-amber-500/15', text: 'text-amber-400', label: 'Pending KYC' },
  
  // Risk Levels
  low: { bg: 'bg-green-500/15', text: 'text-green-400', label: 'Low' },
  medium: { bg: 'bg-amber-500/15', text: 'text-amber-400', label: 'Medium' },
  high: { bg: 'bg-red-500/15', text: 'text-red-400', label: 'High' },
  
  // Default
  default: { bg: 'bg-gray-500/15', text: 'text-gray-400', label: 'Unknown' }
};

export default function AdminStatusBadge({ status, customLabel }) {
  const normalizedStatus = status?.toLowerCase().replace(/\s+/g, '_');
  const style = statusStyles[normalizedStatus] || statusStyles.default;
  
  return (
    <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium ${style.bg} ${style.text}`}>
      {customLabel || style.label}
    </span>
  );
}