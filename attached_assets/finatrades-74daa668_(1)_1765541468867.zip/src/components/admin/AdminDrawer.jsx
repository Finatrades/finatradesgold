import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';
import { Button } from "@/components/ui/button";

export default function AdminDrawer({ 
  open, 
  onClose, 
  title, 
  subtitle,
  children,
  footer,
  width = 'max-w-2xl'
}) {
  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50"
          />
          
          {/* Drawer */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 300 }}
            className={`fixed inset-y-0 right-0 z-50 w-full ${width} bg-white border-l border-[#8A2BE2]/20 shadow-2xl flex flex-col`}
          >
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-[#8A2BE2]/20">
              <div>
                <h2 className="text-[#0D0D0D] font-bold text-lg">{title}</h2>
                {subtitle && <p className="text-[#4A4A4A] text-sm">{subtitle}</p>}
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={onClose}
                className="text-[#4A4A4A] hover:text-[#0D0D0D] hover:bg-[#F4F6FC]"
              >
                <X className="w-5 h-5" />
              </Button>
            </div>
            
            {/* Content */}
            <div className="flex-1 overflow-y-auto p-6 bg-[#FAFBFF]">
              {children}
            </div>
            
            {/* Footer */}
            {footer && (
              <div className="px-6 py-4 border-t border-[#8A2BE2]/20 bg-[#F4F6FC]">
                {footer}
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}