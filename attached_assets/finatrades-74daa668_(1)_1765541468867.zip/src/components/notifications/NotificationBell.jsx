import React, { useState, useEffect } from 'react';
import { Bell } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import NotificationCenter from './NotificationCenter';

export default function NotificationBell({ userEmail }) {
  const [isOpen, setIsOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    if (userEmail) {
      loadUnreadCount();
      // Poll for new notifications every 30 seconds
      const interval = setInterval(loadUnreadCount, 30000);
      return () => clearInterval(interval);
    }
  }, [userEmail]);

  const loadUnreadCount = async () => {
    try {
      const notifications = await base44.entities.Notification.filter(
        { user_email: userEmail, status: 'unread' }
      );
      setUnreadCount(notifications.length);
    } catch (error) {
      console.error('Failed to load notification count:', error);
    }
  };

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="relative w-10 h-10 rounded-full bg-[#F4F6FC] border border-[#8A2BE2]/20 flex items-center justify-center text-black/70 hover:bg-[#8A2BE2]/10 hover:border-[#8A2BE2]/40 hover:text-black transition-all"
      >
        <Bell className="w-5 h-5" />
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 w-5 h-5 bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] rounded-full flex items-center justify-center text-white text-xs font-bold">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      <NotificationCenter
        isOpen={isOpen}
        onClose={() => {
          setIsOpen(false);
          loadUnreadCount();
        }}
        userEmail={userEmail}
      />
    </>
  );
}