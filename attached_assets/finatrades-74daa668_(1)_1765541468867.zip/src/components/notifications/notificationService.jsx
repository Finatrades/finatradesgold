import { base44 } from '@/api/base44Client';

// Notification creation helper functions
export const NotificationService = {
  // KYC Notifications
  async kycApproved(userEmail) {
    return base44.entities.Notification.create({
      user_email: userEmail,
      type: 'kyc',
      title: 'KYC Verification Approved',
      message: 'Congratulations! Your identity verification has been approved. You now have full access to all Finatrades features.',
      priority: 'high',
      action_url: '/UserDashboard',
      action_label: 'Go to Dashboard'
    });
  },

  async kycRejected(userEmail, reason) {
    return base44.entities.Notification.create({
      user_email: userEmail,
      type: 'kyc',
      title: 'KYC Verification Rejected',
      message: `Your identity verification was not approved. Reason: ${reason}. Please resubmit with valid documents.`,
      priority: 'urgent',
      action_url: '/KYC',
      action_label: 'Resubmit KYC'
    });
  },

  async kycPendingReview(userEmail) {
    return base44.entities.Notification.create({
      user_email: userEmail,
      type: 'kyc',
      title: 'KYC Documents Under Review',
      message: 'Your KYC documents have been submitted and are currently under review. This usually takes 1-2 business days.',
      priority: 'medium'
    });
  },

  // Trade Case Notifications
  async tradeCaseCreated(userEmail, caseId) {
    return base44.entities.Notification.create({
      user_email: userEmail,
      type: 'trade',
      title: 'Trade Case Created',
      message: `Your trade case ${caseId} has been created successfully. Gold has been locked as collateral.`,
      priority: 'medium',
      action_url: '/FinaFinanceUser',
      action_label: 'View Trade Case',
      metadata: { caseId }
    });
  },

  async tradeCaseDocumentsPending(userEmail, caseId) {
    return base44.entities.Notification.create({
      user_email: userEmail,
      type: 'trade',
      title: 'Documents Required',
      message: `Trade case ${caseId} requires document uploads. Please upload the necessary documents to proceed.`,
      priority: 'high',
      action_url: '/FinaFinanceUser',
      action_label: 'Upload Documents',
      metadata: { caseId }
    });
  },

  async tradeCaseApproved(userEmail, caseId) {
    return base44.entities.Notification.create({
      user_email: userEmail,
      type: 'trade',
      title: 'Trade Case Approved',
      message: `Trade case ${caseId} has been approved. The trade can now proceed to settlement.`,
      priority: 'high',
      action_url: '/FinaFinanceUser',
      action_label: 'View Details',
      metadata: { caseId }
    });
  },

  async tradeCaseSettled(userEmail, caseId, goldAmount) {
    return base44.entities.Notification.create({
      user_email: userEmail,
      type: 'trade',
      title: 'Trade Case Settled',
      message: `Trade case ${caseId} has been settled. ${goldAmount}g of gold has been released.`,
      priority: 'high',
      action_url: '/FinaFinanceUser',
      action_label: 'View Settlement',
      metadata: { caseId, goldAmount }
    });
  },

  // FinaPay Notifications
  async goldPurchased(userEmail, amount, value) {
    return base44.entities.Notification.create({
      user_email: userEmail,
      type: 'finapay',
      title: 'Gold Purchase Completed',
      message: `You have successfully purchased ${amount}g of gold for $${value.toLocaleString()}.`,
      priority: 'medium',
      action_url: '/FinaPayUser',
      action_label: 'View Wallet',
      metadata: { amount, value }
    });
  },

  async goldSold(userEmail, amount, value) {
    return base44.entities.Notification.create({
      user_email: userEmail,
      type: 'finapay',
      title: 'Gold Sale Completed',
      message: `You have successfully sold ${amount}g of gold for $${value.toLocaleString()}.`,
      priority: 'medium',
      action_url: '/FinaPayUser',
      action_label: 'View Wallet',
      metadata: { amount, value }
    });
  },

  async goldTransferred(userEmail, amount, recipient) {
    return base44.entities.Notification.create({
      user_email: userEmail,
      type: 'finapay',
      title: 'Gold Transfer Completed',
      message: `You have transferred ${amount}g of gold to ${recipient}.`,
      priority: 'medium',
      action_url: '/FinaPayUser',
      action_label: 'View Transaction'
    });
  },

  async goldReceived(userEmail, amount, sender) {
    return base44.entities.Notification.create({
      user_email: userEmail,
      type: 'finapay',
      title: 'Gold Received',
      message: `You have received ${amount}g of gold from ${sender}.`,
      priority: 'medium',
      action_url: '/FinaPayUser',
      action_label: 'View Wallet'
    });
  },

  // BNSL Notifications
  async bnslPlanCreated(userEmail, planId, tenure, goldAmount) {
    return base44.entities.Notification.create({
      user_email: userEmail,
      type: 'bnsl',
      title: 'BNSL Plan Created',
      message: `Your ${tenure}-month BNSL plan ${planId} has been created with ${goldAmount}g locked.`,
      priority: 'high',
      action_url: '/FinaEarnUser',
      action_label: 'View Plan',
      metadata: { planId, tenure, goldAmount }
    });
  },

  async bnslDistribution(userEmail, planId, goldAmount, monetaryValue) {
    return base44.entities.Notification.create({
      user_email: userEmail,
      type: 'bnsl',
      title: 'Quarterly Distribution Credited',
      message: `Your BNSL plan ${planId} quarterly distribution of ${goldAmount}g (≈$${monetaryValue.toFixed(2)}) has been credited to your wallet.`,
      priority: 'high',
      action_url: '/FinaEarnUser',
      action_label: 'View Distribution',
      metadata: { planId, goldAmount, monetaryValue }
    });
  },

  async bnslMaturityReminder(userEmail, planId, maturityDate) {
    return base44.entities.Notification.create({
      user_email: userEmail,
      type: 'bnsl',
      title: 'Plan Maturity Approaching',
      message: `Your BNSL plan ${planId} will mature on ${maturityDate}. Your principal gold will be released to your FinaPay wallet.`,
      priority: 'medium',
      action_url: '/FinaEarnUser',
      action_label: 'View Plan',
      metadata: { planId, maturityDate }
    });
  },

  async bnslMatured(userEmail, planId, goldAmount) {
    return base44.entities.Notification.create({
      user_email: userEmail,
      type: 'bnsl',
      title: 'BNSL Plan Matured',
      message: `Your BNSL plan ${planId} has matured! ${goldAmount}g of principal gold has been credited to your FinaPay wallet.`,
      priority: 'high',
      action_url: '/FinaPayUser',
      action_label: 'View Wallet',
      metadata: { planId, goldAmount }
    });
  },

  // Compliance Notifications
  async complianceDocumentRequired(userEmail, documentType) {
    return base44.entities.Notification.create({
      user_email: userEmail,
      type: 'compliance',
      title: 'Document Required',
      message: `A ${documentType} document is required for compliance purposes. Please upload at your earliest convenience.`,
      priority: 'urgent',
      action_url: '/SettingsUser',
      action_label: 'Upload Document'
    });
  },

  async complianceReviewRequired(userEmail, reason) {
    return base44.entities.Notification.create({
      user_email: userEmail,
      type: 'compliance',
      title: 'Compliance Review Required',
      message: `Your account requires a compliance review: ${reason}. Please contact support for assistance.`,
      priority: 'urgent'
    });
  },

  // System Notifications
  async systemMaintenance(userEmail, date, duration) {
    return base44.entities.Notification.create({
      user_email: userEmail,
      type: 'system',
      title: 'Scheduled Maintenance',
      message: `The platform will undergo maintenance on ${date} for approximately ${duration}. Some services may be temporarily unavailable.`,
      priority: 'low'
    });
  },

  async welcomeNotification(userEmail, fullName) {
    return base44.entities.Notification.create({
      user_email: userEmail,
      type: 'system',
      title: 'Welcome to Finatrades',
      message: `Welcome ${fullName}! Complete your KYC verification to unlock all features and start your gold-backed financial journey.`,
      priority: 'medium',
      action_url: '/KYC',
      action_label: 'Complete KYC'
    });
  }
};

export default NotificationService;