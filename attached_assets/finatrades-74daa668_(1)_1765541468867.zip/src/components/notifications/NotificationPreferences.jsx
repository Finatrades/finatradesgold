import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { 
  Bell, Shield, GitBranch, Wallet, TrendingUp, AlertTriangle, Info,
  Mail, Smartphone, Loader2, CheckCircle
} from 'lucide-react';
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { toast } from 'sonner';

const notificationTypes = [
  { key: 'kyc_updates', label: 'KYC Updates', description: 'Status changes for identity verification', icon: Shield, color: 'text-blue-400' },
  { key: 'trade_updates', label: 'Trade Case Updates', description: 'Trade status changes, approvals, settlements', icon: GitBranch, color: 'text-emerald-400' },
  { key: 'finapay_transactions', label: 'FinaPay Transactions', description: 'Wallet transfers, purchases, sales', icon: Wallet, color: 'text-pink-400' },
  { key: 'bnsl_updates', label: 'BNSL Updates', description: 'Plan distributions, maturity notifications', icon: TrendingUp, color: 'text-amber-400' },
  { key: 'compliance_alerts', label: 'Compliance Alerts', description: 'Required actions and regulatory updates', icon: AlertTriangle, color: 'text-red-400' },
  { key: 'system_updates', label: 'System Updates', description: 'Platform updates and maintenance notices', icon: Info, color: 'text-purple-400' }
];

const deliveryMethods = [
  { key: 'email_notifications', label: 'Email Notifications', description: 'Receive notifications via email', icon: Mail },
  { key: 'push_notifications', label: 'Push Notifications', description: 'Browser push notifications', icon: Smartphone }
];

export default function NotificationPreferences({ userEmail }) {
  const [preferences, setPreferences] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    loadPreferences();
  }, [userEmail]);

  const loadPreferences = async () => {
    setLoading(true);
    try {
      const data = await base44.entities.NotificationPreference.filter({ user_email: userEmail });
      if (data.length > 0) {
        setPreferences(data[0]);
      } else {
        // Create default preferences
        const defaultPrefs = {
          user_email: userEmail,
          kyc_updates: true,
          trade_updates: true,
          finapay_transactions: true,
          bnsl_updates: true,
          compliance_alerts: true,
          system_updates: true,
          email_notifications: true,
          push_notifications: false
        };
        const created = await base44.entities.NotificationPreference.create(defaultPrefs);
        setPreferences(created);
      }
    } catch (error) {
      console.error('Failed to load preferences:', error);
    }
    setLoading(false);
  };

  const handleToggle = async (key, value) => {
    const updated = { ...preferences, [key]: value };
    setPreferences(updated);
    
    setSaving(true);
    try {
      await base44.entities.NotificationPreference.update(preferences.id, { [key]: value });
      toast.success('Preferences updated');
    } catch (error) {
      console.error('Failed to update preferences:', error);
      setPreferences(preferences); // Revert
      toast.error('Failed to update preferences');
    }
    setSaving(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-6 h-6 text-[#D1A954] animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Notification Types */}
      <div className="bg-white/5 backdrop-blur-xl border border-[#D1A954]/20 rounded-2xl p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-[#D1A954]/20 flex items-center justify-center">
            <Bell className="w-5 h-5 text-[#D1A954]" />
          </div>
          <div>
            <h3 className="text-white font-semibold">Notification Types</h3>
            <p className="text-white/50 text-sm">Choose which notifications you want to receive</p>
          </div>
        </div>

        <div className="space-y-4">
          {notificationTypes.map((type, i) => (
            <motion.div
              key={type.key}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="flex items-center justify-between p-4 bg-white/5 rounded-xl"
            >
              <div className="flex items-center gap-4">
                <div className={`w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center`}>
                  <type.icon className={`w-5 h-5 ${type.color}`} />
                </div>
                <div>
                  <p className="text-white font-medium">{type.label}</p>
                  <p className="text-white/50 text-sm">{type.description}</p>
                </div>
              </div>
              <Switch
                checked={preferences?.[type.key] ?? true}
                onCheckedChange={(checked) => handleToggle(type.key, checked)}
                className="data-[state=checked]:bg-[#D1A954]"
              />
            </motion.div>
          ))}
        </div>
      </div>

      {/* Delivery Methods */}
      <div className="bg-white/5 backdrop-blur-xl border border-[#D1A954]/20 rounded-2xl p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-[#D1A954]/20 flex items-center justify-center">
            <Mail className="w-5 h-5 text-[#D1A954]" />
          </div>
          <div>
            <h3 className="text-white font-semibold">Delivery Methods</h3>
            <p className="text-white/50 text-sm">How you want to receive notifications</p>
          </div>
        </div>

        <div className="space-y-4">
          {deliveryMethods.map((method, i) => (
            <motion.div
              key={method.key}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="flex items-center justify-between p-4 bg-white/5 rounded-xl"
            >
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center">
                  <method.icon className="w-5 h-5 text-white/60" />
                </div>
                <div>
                  <p className="text-white font-medium">{method.label}</p>
                  <p className="text-white/50 text-sm">{method.description}</p>
                </div>
              </div>
              <Switch
                checked={preferences?.[method.key] ?? false}
                onCheckedChange={(checked) => handleToggle(method.key, checked)}
                className="data-[state=checked]:bg-[#D1A954]"
              />
            </motion.div>
          ))}
        </div>
      </div>

      {saving && (
        <div className="flex items-center justify-center gap-2 text-[#D1A954] text-sm">
          <Loader2 className="w-4 h-4 animate-spin" />
          Saving preferences...
        </div>
      )}
    </div>
  );
}