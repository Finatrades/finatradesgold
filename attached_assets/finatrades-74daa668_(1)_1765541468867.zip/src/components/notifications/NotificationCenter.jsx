import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { 
  Bell, X, Check, CheckCheck, Trash2, Settings, Filter,
  Shield, GitBranch, Wallet, TrendingUp, AlertTriangle, Info,
  ChevronRight, Clock, Archive
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";

const typeConfig = {
  kyc: { icon: Shield, color: 'text-blue-600', bg: 'bg-blue-500/10', label: 'KYC' },
  trade: { icon: GitBranch, color: 'text-emerald-600', bg: 'bg-emerald-500/10', label: 'Trade' },
  finapay: { icon: Wallet, color: 'text-pink-600', bg: 'bg-pink-500/10', label: 'FinaPay' },
  bnsl: { icon: TrendingUp, color: 'text-amber-600', bg: 'bg-amber-500/10', label: 'BNSL' },
  compliance: { icon: AlertTriangle, color: 'text-red-600', bg: 'bg-red-500/10', label: 'Compliance' },
  system: { icon: Info, color: 'text-purple-600', bg: 'bg-purple-500/10', label: 'System' }
};

const priorityColors = {
  low: 'border-l-gray-300',
  medium: 'border-l-blue-500',
  high: 'border-l-amber-500',
  urgent: 'border-l-red-500'
};

function NotificationItem({ notification, onMarkRead, onArchive, onDelete }) {
  const config = typeConfig[notification.type] || typeConfig.system;
  const Icon = config.icon;
  const isUnread = notification.status === 'unread';

  const formatDate = (dateStr) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diff = now - date;
    const mins = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (mins < 1) return 'Just now';
    if (mins < 60) return `${mins}m ago`;
    if (hours < 24) return `${hours}h ago`;
    if (days < 7) return `${days}d ago`;
    return date.toLocaleDateString();
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, x: -100 }}
      className={`p-4 border-l-4 ${priorityColors[notification.priority]} ${
        isUnread ? 'bg-[#F4F6FC]' : 'bg-white'
      } hover:bg-[#F4F6FC] transition-colors rounded-r-xl mb-2 shadow-sm`}
    >
      <div className="flex gap-3">
        <div className={`w-10 h-10 rounded-xl ${config.bg} flex items-center justify-center flex-shrink-0`}>
          <Icon className={`w-5 h-5 ${config.color}`} />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <h4 className={`font-medium ${isUnread ? 'text-black' : 'text-black/60'}`}>
                  {notification.title}
                </h4>
                {isUnread && (
                  <span className="w-2 h-2 rounded-full bg-[#8A2BE2]" />
                )}
              </div>
              <p className="text-black/70 text-sm mt-1 line-clamp-2">{notification.message}</p>
              <div className="flex items-center gap-3 mt-2">
                <span className="text-black/50 text-xs flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {formatDate(notification.created_date)}
                </span>
                <span className={`px-2 py-0.5 rounded text-xs ${config.bg} ${config.color}`}>
                  {config.label}
                </span>
              </div>
            </div>
            <div className="flex items-center gap-1">
              {isUnread && (
                <button
                  onClick={() => onMarkRead(notification.id)}
                  className="p-1.5 rounded-lg hover:bg-[#8A2BE2]/10 text-black/60 hover:text-black"
                  title="Mark as read"
                >
                  <Check className="w-4 h-4" />
                </button>
              )}
              <button
                onClick={() => onArchive(notification.id)}
                className="p-1.5 rounded-lg hover:bg-[#8A2BE2]/10 text-black/60 hover:text-black"
                title="Archive"
              >
                <Archive className="w-4 h-4" />
              </button>
              <button
                onClick={() => onDelete(notification.id)}
                className="p-1.5 rounded-lg hover:bg-red-500/10 text-black/60 hover:text-red-600"
                title="Delete"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
          {notification.action_url && (
            <Button
              size="sm"
              variant="ghost"
              className="mt-2 text-[#FF2FBF] hover:bg-[#8A2BE2]/10 h-8 px-3"
              onClick={() => window.location.href = notification.action_url}
            >
              {notification.action_label || 'View Details'}
              <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          )}
        </div>
      </div>
    </motion.div>
  );
}

export default function NotificationCenter({ isOpen, onClose, userEmail }) {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('all');
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    if (isOpen && userEmail) {
      loadNotifications();
    }
  }, [isOpen, userEmail]);

  const loadNotifications = async () => {
    setLoading(true);
    try {
      const data = await base44.entities.Notification.filter(
        { user_email: userEmail },
        '-created_date',
        100
      );
      setNotifications(data);
    } catch (error) {
      console.error('Failed to load notifications:', error);
    }
    setLoading(false);
  };

  const handleMarkRead = async (id) => {
    await base44.entities.Notification.update(id, { status: 'read' });
    setNotifications(notifications.map(n => 
      n.id === id ? { ...n, status: 'read' } : n
    ));
  };

  const handleMarkAllRead = async () => {
    const unread = notifications.filter(n => n.status === 'unread');
    await Promise.all(unread.map(n => 
      base44.entities.Notification.update(n.id, { status: 'read' })
    ));
    setNotifications(notifications.map(n => ({ ...n, status: 'read' })));
  };

  const handleArchive = async (id) => {
    await base44.entities.Notification.update(id, { status: 'archived' });
    setNotifications(notifications.filter(n => n.id !== id));
  };

  const handleDelete = async (id) => {
    await base44.entities.Notification.delete(id);
    setNotifications(notifications.filter(n => n.id !== id));
  };

  const filteredNotifications = notifications.filter(n => {
    if (activeTab === 'unread' && n.status !== 'unread') return false;
    if (filter !== 'all' && n.type !== filter) return false;
    return true;
  });

  const unreadCount = notifications.filter(n => n.status === 'unread').length;

  if (!isOpen) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex justify-end"
    >
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />

      {/* Panel */}
      <motion.div
        initial={{ x: 400 }}
        animate={{ x: 0 }}
        exit={{ x: 400 }}
        transition={{ type: 'spring', damping: 25 }}
        className="relative w-full max-w-md bg-white border-l border-[#8A2BE2]/20 shadow-2xl"
      >
        {/* Header */}
        <div className="p-4 border-b border-[#8A2BE2]/20">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#8A2BE2]/10 flex items-center justify-center">
                <Bell className="w-5 h-5 text-[#8A2BE2]" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-black">Notifications</h2>
                <p className="text-black/60 text-xs">{unreadCount} unread</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {unreadCount > 0 && (
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={handleMarkAllRead}
                  className="text-black/60 hover:text-black text-xs"
                >
                  <CheckCheck className="w-4 h-4 mr-1" />
                  Mark all read
                </Button>
              )}
              <button
                onClick={onClose}
                className="p-2 rounded-lg hover:bg-[#8A2BE2]/10 text-black/60 hover:text-black"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="bg-[#F4F6FC] w-full">
              <TabsTrigger value="all" className="flex-1 data-[state=active]:bg-gradient-to-r data-[state=active]:from-[#8A2BE2] data-[state=active]:to-[#FF2FBF] data-[state=active]:text-white">
                All
              </TabsTrigger>
              <TabsTrigger value="unread" className="flex-1 data-[state=active]:bg-gradient-to-r data-[state=active]:from-[#8A2BE2] data-[state=active]:to-[#FF2FBF] data-[state=active]:text-white">
                Unread {unreadCount > 0 && `(${unreadCount})`}
              </TabsTrigger>
            </TabsList>
          </Tabs>

          {/* Type Filter */}
          <div className="flex gap-2 mt-3 overflow-x-auto pb-1">
            {[
              { value: 'all', label: 'All' },
              { value: 'kyc', label: 'KYC' },
              { value: 'trade', label: 'Trade' },
              { value: 'finapay', label: 'FinaPay' },
              { value: 'bnsl', label: 'BNSL' },
              { value: 'compliance', label: 'Compliance' }
            ].map(f => (
              <button
                key={f.value}
                onClick={() => setFilter(f.value)}
                className={`px-3 py-1 rounded-full text-xs whitespace-nowrap transition-all ${
                  filter === f.value
                    ? 'bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white font-medium'
                    : 'bg-[#F4F6FC] text-black/70 hover:bg-[#8A2BE2]/10 hover:text-black'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>

        {/* Notifications List */}
        <ScrollArea className="h-[calc(100vh-220px)]">
          <div className="p-4">
            {loading ? (
              <div className="text-center py-12">
                <div className="w-8 h-8 border-2 border-[#8A2BE2] border-t-transparent rounded-full animate-spin mx-auto mb-3" />
                <p className="text-black/60 text-sm">Loading notifications...</p>
              </div>
            ) : filteredNotifications.length === 0 ? (
              <div className="text-center py-12">
                <Bell className="w-12 h-12 mx-auto text-black/20 mb-3" />
                <p className="text-black">No notifications</p>
                <p className="text-black/60 text-sm">You're all caught up!</p>
              </div>
            ) : (
              <AnimatePresence>
                {filteredNotifications.map(notification => (
                  <NotificationItem
                    key={notification.id}
                    notification={notification}
                    onMarkRead={handleMarkRead}
                    onArchive={handleArchive}
                    onDelete={handleDelete}
                  />
                ))}
              </AnimatePresence>
            )}
          </div>
        </ScrollArea>
      </motion.div>
    </motion.div>
  );
}