import React from 'react';
import { cn } from "@/lib/utils";

export default function SectionTitle({ title, subtitle, align = "center", light = false }) {
  return (
    <div className={cn("mb-16", align === "center" && "text-center")}>
      <h2 className={cn(
        "text-4xl md:text-5xl font-light tracking-tight mb-4",
        light ? "text-white" : "text-[#0D0D0D]"
      )}>
        {title}
      </h2>
      {subtitle && (
        <p className={cn(
          "text-lg max-w-2xl",
          align === "center" && "mx-auto",
          light ? "text-gray-300" : "text-[#4A4A4A]"
        )}>
          {subtitle}
        </p>
      )}
      <div className={cn(
        "w-24 h-0.5 bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] mt-6",
        align === "center" && "mx-auto"
      )} />
    </div>
  );
}