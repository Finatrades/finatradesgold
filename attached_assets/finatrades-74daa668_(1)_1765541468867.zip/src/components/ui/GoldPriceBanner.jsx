import React, { useState, useEffect } from 'react';
import { TrendingUp, TrendingDown, RefreshCw } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function GoldPriceBanner() {
  const [prices, setPrices] = useState({
    usdPerOz: 2650.00,
    usdPerGram: 85.22,
    aedPerOz: 9732.50,
    aedPerGram: 312.96,
    change: 0.00,
    isUp: true,
    lastUpdated: null,
    loading: true
  });

  const fetchGoldPrice = async () => {
    try {
      const response = await base44.functions.invoke('getGoldPrice');
      const data = response.data;
      
      if (data.success) {
        const prevPrice = prices.usdPerOz;
        const newPrice = data.price_per_oz;
        const changePercent = prevPrice ? ((newPrice - prevPrice) / prevPrice) * 100 : 0;
        
        setPrices({
          usdPerOz: newPrice,
          usdPerGram: data.price_per_gram,
          aedPerOz: newPrice * 3.67,
          aedPerGram: data.price_per_gram * 3.67,
          change: Math.abs(changePercent),
          isUp: changePercent >= 0,
          lastUpdated: new Date(),
          loading: false
        });
      }
    } catch (error) {
      console.error('Failed to fetch gold price:', error);
      setPrices(prev => ({ ...prev, loading: false }));
    }
  };

  useEffect(() => {
    fetchGoldPrice();
    // Refresh every 60 seconds
    const interval = setInterval(fetchGoldPrice, 60000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-gradient-to-r from-[#0D001E] to-[#1A002F] border-b border-[#8A2BE2]/20 px-4 py-2">
      <div className="max-w-7xl mx-auto flex items-center justify-between text-sm">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <span className="text-[#D1A954] font-medium">Gold Spot</span>
            {prices.loading && <RefreshCw className="w-3 h-3 text-white/40 animate-spin" />}
          </div>
          <div className="flex items-center gap-4">
            <div className="flex flex-col">
              <div className="flex items-center gap-2">
                <span className="text-white/50 text-xs">USD/oz</span>
                <span className="text-white font-semibold">${prices.usdPerOz.toFixed(2)}</span>
              </div>
              <span className="text-white/40 text-[10px]">${prices.usdPerGram.toFixed(2)}/g</span>
            </div>
            <div className="w-px h-6 bg-white/10" />
            <div className="flex flex-col">
              <div className="flex items-center gap-2">
                <span className="text-white/50 text-xs">AED/oz</span>
                <span className="text-white font-semibold">د.إ{prices.aedPerOz.toFixed(2)}</span>
              </div>
              <span className="text-white/40 text-[10px]">د.إ{prices.aedPerGram.toFixed(2)}/g</span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className={`flex items-center gap-1 ${prices.isUp ? 'text-green-400' : 'text-red-400'}`}>
            {prices.isUp ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
            <span className="font-medium">{prices.change.toFixed(2)}%</span>
          </div>
          {prices.lastUpdated && (
            <span className="text-white/30 text-[10px]">
              Updated {prices.lastUpdated.toLocaleTimeString()}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}