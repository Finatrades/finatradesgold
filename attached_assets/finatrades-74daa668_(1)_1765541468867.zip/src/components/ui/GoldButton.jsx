import React from 'react';
import { cn } from "@/lib/utils";

export default function GoldButton({ children, variant = "primary", className, ...props }) {
  const baseStyles = "relative font-medium tracking-wide transition-all duration-300 overflow-hidden group";
  
  const variants = {
    primary: "bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white px-8 py-3 rounded-full hover:shadow-[0_0_30px_rgba(255,45,200,0.35)] hover:scale-105 hover:from-[#A342FF] hover:to-[#FF4CD6]",
    outline: "border border-[#8A2BE2] text-[#8A2BE2] px-8 py-3 rounded-full hover:bg-gradient-to-r hover:from-[#8A2BE2]/10 hover:to-[#FF2FBF]/10 hover:shadow-[0_0_20px_rgba(138,43,226,0.2)]",
    ghost: "text-[#8A2BE2] hover:text-[#FF2FBF] px-4 py-2"
  };

  return (
    <button className={cn(baseStyles, variants[variant], className)} {...props}>
      <span className="relative z-10">{children}</span>
      {variant === "primary" && (
        <div className="absolute inset-0 bg-gradient-to-r from-[#A342FF] to-[#FF4CD6] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      )}
    </button>
  );
}