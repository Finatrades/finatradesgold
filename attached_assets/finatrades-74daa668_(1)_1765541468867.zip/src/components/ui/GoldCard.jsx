import React from 'react';
import { cn } from "@/lib/utils";

export default function GoldCard({ children, className, hover = true, ...props }) {
  return (
    <div 
      className={cn(
        "relative bg-white rounded-[20px] border border-[#E8E0F0] p-8",
        "shadow-[0_8px_32px_rgba(160,50,255,0.12)]",
        "before:absolute before:inset-0 before:rounded-[20px] before:bg-gradient-to-br before:from-[#8A2BE2]/5 before:to-[#FF2FBF]/5 before:opacity-0 before:transition-opacity before:duration-500",
        hover && "hover:before:opacity-100 hover:border-[#8A2BE2]/30 hover:shadow-[0_12px_48px_rgba(160,50,255,0.18)] transition-all duration-500",
        className
      )} 
      {...props}
    >
      <div className="relative z-10">{children}</div>
    </div>
  );
}