import React, { useState } from 'react';
import { FileText, Upload, Check, X, AlertCircle, ChevronRight, ArrowLeft, Shield, Loader2 } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { base44 } from '@/api/base44Client';

const REQUIRED_DOCUMENTS = [
  { id: 'incorporationCert', label: 'Certificate of Incorporation', required: true, description: 'Official incorporation certificate from registry' },
  { id: 'tradeLicense', label: 'Trade/Commercial License', required: true, description: 'Valid commercial license or trade permit' },
  { id: 'memorandum', label: 'Memorandum/Articles of Association', required: true, description: 'Company constitutional documents' },
  { id: 'shareholderList', label: 'List of Shareholders', required: false, description: 'Official register of current shareholders' },
  { id: 'bankReference', label: 'Bank Reference Letter', required: true, description: 'Letter from your primary bank' },
  { id: 'authorizedSignatories', label: 'List of Authorized Signatories', required: true, description: 'Individuals authorized to act on behalf of company' },
  { id: 'proofOfAuthorization', label: 'Proof of Authorization', required: false, description: 'Power of Attorney or authorization letter' },
];

export default function DocumentationStep({ formData, updateFormData, onComplete, onBack }) {
  const [uploading, setUploading] = useState({});
  const [uboPassportCount, setUboPassportCount] = useState(formData.documents.uboPassports?.length || 1);

  const handleUpload = async (docId, file) => {
    if (!file) return;
    setUploading(prev => ({ ...prev, [docId]: true }));
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      updateFormData({
        documents: { 
          ...formData.documents, 
          [docId]: { url: file_url, name: file.name }
        }
      });
    } catch (error) {
      console.error('Upload failed:', error);
    } finally {
      setUploading(prev => ({ ...prev, [docId]: false }));
    }
  };

  const handleUboPassportUpload = async (index, file) => {
    if (!file) return;
    setUploading(prev => ({ ...prev, [`ubo_${index}`]: true }));
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      const updated = [...(formData.documents.uboPassports || [])];
      updated[index] = { url: file_url, name: file.name };
      updateFormData({
        documents: { ...formData.documents, uboPassports: updated }
      });
    } catch (error) {
      console.error('Upload failed:', error);
    } finally {
      setUploading(prev => ({ ...prev, [`ubo_${index}`]: false }));
    }
  };

  const removeDocument = (docId) => {
    updateFormData({
      documents: { ...formData.documents, [docId]: null }
    });
  };

  const removeUboPassport = (index) => {
    const updated = [...(formData.documents.uboPassports || [])];
    updated[index] = null;
    updateFormData({
      documents: { ...formData.documents, uboPassports: updated }
    });
  };

  const getDocStatus = (docId) => {
    const doc = formData.documents[docId];
    if (doc?.url) return 'uploaded';
    const docInfo = REQUIRED_DOCUMENTS.find(d => d.id === docId);
    return docInfo?.required ? 'required' : 'optional';
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onComplete();
  };

  return (
    <div className="bg-white/[0.02] backdrop-blur-xl border border-[#D1A954]/20 rounded-2xl overflow-hidden">
      {/* Header */}
      <div className="p-6 border-b border-[#D1A954]/10">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-xl bg-[#D1A954]/10 flex items-center justify-center">
            <FileText className="w-5 h-5 text-[#D1A954]" />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-white">Upload Required KYC Documents</h2>
            <p className="text-white/40 text-sm">Step 3 of 4</p>
          </div>
        </div>
        <p className="text-white/50 text-sm mt-4">
          Please upload clear, readable copies of all required documents. Accepted formats: PDF, JPG, PNG
        </p>
      </div>

      <form onSubmit={handleSubmit} className="p-6 space-y-6">
        {/* Document Upload Cards */}
        <div className="grid gap-4">
          {REQUIRED_DOCUMENTS.map((doc) => {
            const status = getDocStatus(doc.id);
            const uploadedDoc = formData.documents[doc.id];
            const isUploading = uploading[doc.id];

            return (
              <div 
                key={doc.id}
                className={`p-4 rounded-xl border transition-all ${
                  status === 'uploaded' 
                    ? 'bg-green-500/5 border-green-500/30' 
                    : status === 'required'
                      ? 'bg-white/[0.02] border-amber-500/30'
                      : 'bg-white/[0.02] border-white/10'
                }`}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="text-white font-medium text-sm">{doc.label}</h3>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-medium ${
                        status === 'uploaded' 
                          ? 'bg-green-500/20 text-green-400'
                          : status === 'required'
                            ? 'bg-amber-500/20 text-amber-400'
                            : 'bg-white/10 text-white/50'
                      }`}>
                        {status === 'uploaded' ? 'Uploaded' : status === 'required' ? 'Required' : 'Optional'}
                      </span>
                    </div>
                    <p className="text-white/40 text-xs">{doc.description}</p>
                    
                    {uploadedDoc?.name && (
                      <div className="flex items-center gap-2 mt-2 p-2 bg-black/20 rounded-lg">
                        <FileText className="w-4 h-4 text-green-400" />
                        <span className="text-white/70 text-xs truncate flex-1">{uploadedDoc.name}</span>
                        <button 
                          type="button"
                          onClick={() => removeDocument(doc.id)}
                          className="p-1 rounded bg-red-500/20 text-red-400 hover:bg-red-500/30"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    )}
                  </div>
                  
                  {!uploadedDoc?.url && (
                    <label className={`flex items-center gap-2 px-4 py-2 rounded-lg cursor-pointer transition-all ${
                      isUploading 
                        ? 'bg-[#D1A954]/10 text-[#D1A954]'
                        : 'bg-white/5 text-white/60 hover:bg-[#D1A954]/10 hover:text-[#D1A954]'
                    }`}>
                      {isUploading ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <Upload className="w-4 h-4" />
                      )}
                      <span className="text-xs font-medium">{isUploading ? 'Uploading...' : 'Upload'}</span>
                      <input 
                        type="file" 
                        className="hidden" 
                        accept=".pdf,.png,.jpg,.jpeg"
                        disabled={isUploading}
                        onChange={(e) => handleUpload(doc.id, e.target.files[0])}
                      />
                    </label>
                  )}
                  
                  {uploadedDoc?.url && (
                    <div className="flex items-center justify-center w-10 h-10 rounded-full bg-green-500/20">
                      <Check className="w-5 h-5 text-green-400" />
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* UBO Passports Section */}
        <div className="border-t border-white/10 pt-6">
          <div className="flex items-center gap-2 mb-4">
            <div className="h-px flex-1 bg-gradient-to-r from-[#D1A954]/50 to-transparent" />
            <span className="text-[#D1A954] text-xs font-medium tracking-wider uppercase">UBO Passport Copies</span>
            <div className="h-px flex-1 bg-gradient-to-l from-[#D1A954]/50 to-transparent" />
          </div>
          
          <p className="text-white/50 text-xs mb-4">Upload passport copy for each beneficial owner (25%+ shareholding)</p>
          
          <div className="grid md:grid-cols-2 gap-4">
            {Array.from({ length: Math.max(uboPassportCount, formData.shareholders?.length || 1) }).map((_, index) => {
              const passport = formData.documents.uboPassports?.[index];
              const isUploading = uploading[`ubo_${index}`];
              
              return (
                <div key={index} className="p-4 bg-white/[0.02] border border-white/10 rounded-xl">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-white/70 text-sm">UBO {index + 1} Passport</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-medium bg-amber-500/20 text-amber-400">
                      Required
                    </span>
                  </div>
                  
                  {passport?.url ? (
                    <div className="flex items-center gap-2 p-2 bg-green-500/10 border border-green-500/30 rounded-lg">
                      <Check className="w-4 h-4 text-green-400" />
                      <span className="text-white/70 text-xs truncate flex-1">{passport.name}</span>
                      <button 
                        type="button"
                        onClick={() => removeUboPassport(index)}
                        className="p-1 rounded bg-red-500/20 text-red-400"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ) : (
                    <label className="flex items-center justify-center gap-2 p-3 border border-dashed border-white/20 rounded-lg cursor-pointer hover:border-[#D1A954]/50 hover:bg-[#D1A954]/5 transition-all">
                      {isUploading ? (
                        <Loader2 className="w-4 h-4 text-[#D1A954] animate-spin" />
                      ) : (
                        <Upload className="w-4 h-4 text-white/40" />
                      )}
                      <span className="text-white/50 text-xs">{isUploading ? 'Uploading...' : 'Upload passport'}</span>
                      <input 
                        type="file" 
                        className="hidden" 
                        accept=".pdf,.png,.jpg,.jpeg"
                        disabled={isUploading}
                        onChange={(e) => handleUboPassportUpload(index, e.target.files[0])}
                      />
                    </label>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Compliance Notice */}
        <div className="flex items-start gap-3 p-4 bg-[#D1A954]/5 border border-[#D1A954]/20 rounded-xl">
          <Shield className="w-5 h-5 text-[#D1A954] mt-0.5" />
          <div>
            <p className="text-white/70 text-sm">Secure Document Storage</p>
            <p className="text-white/40 text-xs mt-1">
              All documents are stored securely with AES-256 encryption. Only authorized compliance officers can view your documents.
            </p>
          </div>
        </div>

        {/* Navigation Buttons */}
        <div className="flex gap-4 pt-4">
          <Button
            type="button"
            variant="outline"
            onClick={onBack}
            className="flex-1 h-14 border-white/20 text-white/70 hover:bg-white/5 rounded-xl"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <Button
            type="submit"
            className="flex-[2] h-14 bg-gradient-to-r from-[#D1A954] to-[#B8963E] text-black font-semibold rounded-xl hover:shadow-[0_0_30px_rgba(209,169,84,0.3)] transition-all"
          >
            Continue to Banking Details
            <ChevronRight className="w-5 h-5 ml-2" />
          </Button>
        </div>
      </form>
    </div>
  );
}