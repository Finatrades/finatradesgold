import React from 'react';
import { Landmark, Building2, CreditCard, Check, ArrowLeft, Loader2, Shield } from 'lucide-react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";

const COUNTRIES = [
  'United Arab Emirates', 'Switzerland', 'United Kingdom', 'United States',
  'Singapore', 'Hong Kong', 'Germany', 'France', 'Netherlands', 'Luxembourg'
];

const CURRENCIES = [
  { value: 'USD', label: 'USD - US Dollar' },
  { value: 'AED', label: 'AED - UAE Dirham' },
  { value: 'EUR', label: 'EUR - Euro' },
  { value: 'GBP', label: 'GBP - British Pound' },
  { value: 'CHF', label: 'CHF - Swiss Franc' },
];

export default function BankingDetailsStep({ formData, updateFormData, onSubmit, onBack, isSubmitting }) {
  const handleSubmit = (e) => {
    e.preventDefault();
    if (formData.confirmAccuracy && formData.confirmAuthorized && formData.confirmCompliance) {
      onSubmit();
    }
  };

  const isFormValid = formData.bankName && formData.iban && formData.swiftCode && 
    formData.beneficiaryName && formData.confirmAccuracy && formData.confirmAuthorized && formData.confirmCompliance;

  return (
    <div className="bg-white/[0.02] backdrop-blur-xl border border-[#D1A954]/20 rounded-2xl overflow-hidden">
      {/* Header */}
      <div className="p-6 border-b border-[#D1A954]/10">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-xl bg-[#D1A954]/10 flex items-center justify-center">
            <Landmark className="w-5 h-5 text-[#D1A954]" />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-white">Banking Details</h2>
            <p className="text-white/40 text-sm">Step 4 of 4 — Final Step</p>
          </div>
        </div>
        <p className="text-white/50 text-sm mt-4">
          Provide your banking details for payment transactions and settlement of trade finance and withdrawals.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="p-6 space-y-8">
        {/* Bank Information */}
        <section>
          <div className="flex items-center gap-2 mb-4">
            <div className="h-px flex-1 bg-gradient-to-r from-[#D1A954]/50 to-transparent" />
            <span className="text-[#D1A954] text-xs font-medium tracking-wider uppercase">Bank Information</span>
            <div className="h-px flex-1 bg-gradient-to-l from-[#D1A954]/50 to-transparent" />
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label className="text-white/70 text-sm mb-2 block">Bank Name *</label>
              <div className="relative">
                <Building2 className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
                <Input
                  required
                  placeholder="Enter bank name"
                  className="h-12 pl-11 bg-white/5 border-white/10 text-white rounded-xl focus:border-[#D1A954]/50"
                  value={formData.bankName}
                  onChange={(e) => updateFormData({ bankName: e.target.value })}
                />
              </div>
            </div>

            <div className="md:col-span-2">
              <label className="text-white/70 text-sm mb-2 block">Bank Branch Address</label>
              <Input
                placeholder="Branch address"
                className="h-12 bg-white/5 border-white/10 text-white rounded-xl focus:border-[#D1A954]/50"
                value={formData.bankBranch}
                onChange={(e) => updateFormData({ bankBranch: e.target.value })}
              />
            </div>

            <div>
              <label className="text-white/70 text-sm mb-2 block">City</label>
              <Input
                placeholder="City"
                className="h-12 bg-white/5 border-white/10 text-white rounded-xl focus:border-[#D1A954]/50"
                value={formData.bankCity}
                onChange={(e) => updateFormData({ bankCity: e.target.value })}
              />
            </div>

            <div>
              <label className="text-white/70 text-sm mb-2 block">Country</label>
              <Select 
                value={formData.bankCountry} 
                onValueChange={(v) => updateFormData({ bankCountry: v })}
              >
                <SelectTrigger className="h-12 bg-white/5 border-white/10 text-white rounded-xl">
                  <SelectValue placeholder="Select country" />
                </SelectTrigger>
                <SelectContent className="bg-[#1a0a2e] border-[#D1A954]/30">
                  {COUNTRIES.map(country => (
                    <SelectItem key={country} value={country} className="text-white">{country}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </section>

        {/* Account Details */}
        <section>
          <div className="flex items-center gap-2 mb-4">
            <div className="h-px flex-1 bg-gradient-to-r from-[#D1A954]/50 to-transparent" />
            <span className="text-[#D1A954] text-xs font-medium tracking-wider uppercase">Account Details</span>
            <div className="h-px flex-1 bg-gradient-to-l from-[#D1A954]/50 to-transparent" />
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="text-white/70 text-sm mb-2 block">IBAN / Account Number *</label>
              <Input
                required
                placeholder="Enter IBAN or account number"
                className="h-12 bg-white/5 border-white/10 text-white rounded-xl focus:border-[#D1A954]/50 font-mono"
                value={formData.iban}
                onChange={(e) => updateFormData({ iban: e.target.value })}
              />
            </div>

            <div>
              <label className="text-white/70 text-sm mb-2 block">SWIFT/BIC Code *</label>
              <Input
                required
                placeholder="Enter SWIFT code"
                className="h-12 bg-white/5 border-white/10 text-white rounded-xl focus:border-[#D1A954]/50 font-mono uppercase"
                value={formData.swiftCode}
                onChange={(e) => updateFormData({ swiftCode: e.target.value.toUpperCase() })}
              />
            </div>

            <div>
              <label className="text-white/70 text-sm mb-2 block">Beneficiary Name *</label>
              <Input
                required
                placeholder="Account holder name"
                className="h-12 bg-white/5 border-white/10 text-white rounded-xl focus:border-[#D1A954]/50"
                value={formData.beneficiaryName}
                onChange={(e) => updateFormData({ beneficiaryName: e.target.value })}
              />
            </div>

            <div>
              <label className="text-white/70 text-sm mb-2 block">Currency Preference *</label>
              <Select 
                value={formData.currency} 
                onValueChange={(v) => updateFormData({ currency: v })}
              >
                <SelectTrigger className="h-12 bg-white/5 border-white/10 text-white rounded-xl">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[#1a0a2e] border-[#D1A954]/30">
                  {CURRENCIES.map(curr => (
                    <SelectItem key={curr.value} value={curr.value} className="text-white">{curr.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </section>

        {/* Confirmation Declaration */}
        <section>
          <div className="flex items-center gap-2 mb-4">
            <div className="h-px flex-1 bg-gradient-to-r from-[#D1A954]/50 to-transparent" />
            <span className="text-[#D1A954] text-xs font-medium tracking-wider uppercase">Confirmation Declaration</span>
            <div className="h-px flex-1 bg-gradient-to-l from-[#D1A954]/50 to-transparent" />
          </div>

          <div className="bg-white/[0.02] border border-white/10 rounded-xl p-5 space-y-4">
            <div className="flex items-start space-x-3">
              <Checkbox 
                id="confirm-accuracy" 
                checked={formData.confirmAccuracy}
                onCheckedChange={(checked) => updateFormData({ confirmAccuracy: checked })}
                className="border-[#D1A954] data-[state=checked]:bg-[#D1A954] data-[state=checked]:text-black mt-0.5"
              />
              <Label htmlFor="confirm-accuracy" className="text-white/70 text-sm leading-relaxed cursor-pointer">
                I confirm that all information provided in this application is accurate and complete to the best of my knowledge.
              </Label>
            </div>

            <div className="flex items-start space-x-3">
              <Checkbox 
                id="confirm-authorized" 
                checked={formData.confirmAuthorized}
                onCheckedChange={(checked) => updateFormData({ confirmAuthorized: checked })}
                className="border-[#D1A954] data-[state=checked]:bg-[#D1A954] data-[state=checked]:text-black mt-0.5"
              />
              <Label htmlFor="confirm-authorized" className="text-white/70 text-sm leading-relaxed cursor-pointer">
                I am an authorized signatory of this entity and have the authority to submit this KYC application.
              </Label>
            </div>

            <div className="flex items-start space-x-3">
              <Checkbox 
                id="confirm-compliance" 
                checked={formData.confirmCompliance}
                onCheckedChange={(checked) => updateFormData({ confirmCompliance: checked })}
                className="border-[#D1A954] data-[state=checked]:bg-[#D1A954] data-[state=checked]:text-black mt-0.5"
              />
              <Label htmlFor="confirm-compliance" className="text-white/70 text-sm leading-relaxed cursor-pointer">
                I understand that Finatrades may request additional compliance documents as required by regulatory authorities.
              </Label>
            </div>
          </div>
        </section>

        {/* Navigation Buttons */}
        <div className="flex gap-4 pt-4">
          <Button
            type="button"
            variant="outline"
            onClick={onBack}
            disabled={isSubmitting}
            className="flex-1 h-14 border-white/20 text-white/70 hover:bg-white/5 rounded-xl"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <Button
            type="submit"
            disabled={!isFormValid || isSubmitting}
            className="flex-[2] h-14 bg-gradient-to-r from-[#D1A954] to-[#B8963E] text-black font-semibold rounded-xl hover:shadow-[0_0_30px_rgba(209,169,84,0.3)] transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                Submitting...
              </>
            ) : (
              <>
                <Shield className="w-5 h-5 mr-2" />
                Submit KYC for Review
              </>
            )}
          </Button>
        </div>

        {/* Review Notice */}
        <p className="text-white/30 text-xs text-center">
          KYC review typically takes 24–48 hours. You will be notified by email once the review is complete.
        </p>
      </form>
    </div>
  );
}