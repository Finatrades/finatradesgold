import React from 'react';
import { Building2, Phone, Globe, Mail, User, ChevronRight } from 'lucide-react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";

const COUNTRIES = [
  'United Arab Emirates', 'Switzerland', 'United Kingdom', 'United States',
  'Singapore', 'Hong Kong', 'Germany', 'France', 'Netherlands', 'Luxembourg',
  'Saudi Arabia', 'Qatar', 'Bahrain', 'Kuwait', 'Oman', 'India', 'China', 'Japan'
];

export default function CorporateDetailsStep({ formData, updateFormData, onComplete }) {
  const handleSubmit = (e) => {
    e.preventDefault();
    onComplete();
  };

  return (
    <div className="bg-white/[0.02] backdrop-blur-xl border border-[#D1A954]/20 rounded-2xl overflow-hidden">
      {/* Header */}
      <div className="p-6 border-b border-[#D1A954]/10">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-xl bg-[#D1A954]/10 flex items-center justify-center">
            <Building2 className="w-5 h-5 text-[#D1A954]" />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-white">Corporate Information</h2>
            <p className="text-white/40 text-sm">Step 1 of 4</p>
          </div>
        </div>
        <p className="text-white/50 text-sm mt-4">
          All information will be handled confidentially in line with international compliance standards.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="p-6 space-y-8">
        {/* Company Details Section */}
        <section>
          <div className="flex items-center gap-2 mb-4">
            <div className="h-px flex-1 bg-gradient-to-r from-[#D1A954]/50 to-transparent" />
            <span className="text-[#D1A954] text-xs font-medium tracking-wider uppercase">Company Details</span>
            <div className="h-px flex-1 bg-gradient-to-l from-[#D1A954]/50 to-transparent" />
          </div>
          
          <div className="grid md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label className="text-white/70 text-sm mb-2 block">Full Registered Company Name *</label>
              <Input
                required
                placeholder="Enter company name"
                className="h-12 bg-white/5 border-white/10 text-white rounded-xl focus:border-[#D1A954]/50"
                value={formData.companyName}
                onChange={(e) => updateFormData({ companyName: e.target.value })}
              />
            </div>
            
            <div>
              <label className="text-white/70 text-sm mb-2 block">Company Registration Number *</label>
              <Input
                required
                placeholder="Registration number"
                className="h-12 bg-white/5 border-white/10 text-white rounded-xl focus:border-[#D1A954]/50"
                value={formData.registrationNumber}
                onChange={(e) => updateFormData({ registrationNumber: e.target.value })}
              />
            </div>
            
            <div>
              <label className="text-white/70 text-sm mb-2 block">Incorporation Date *</label>
              <Input
                type="date"
                required
                className="h-12 bg-white/5 border-white/10 text-white rounded-xl focus:border-[#D1A954]/50"
                value={formData.incorporationDate}
                onChange={(e) => updateFormData({ incorporationDate: e.target.value })}
              />
            </div>
            
            <div>
              <label className="text-white/70 text-sm mb-2 block">Country of Incorporation *</label>
              <Select 
                value={formData.countryOfIncorporation} 
                onValueChange={(v) => updateFormData({ countryOfIncorporation: v })}
              >
                <SelectTrigger className="h-12 bg-white/5 border-white/10 text-white rounded-xl">
                  <SelectValue placeholder="Select country" />
                </SelectTrigger>
                <SelectContent className="bg-[#1a0a2e] border-[#D1A954]/30">
                  {COUNTRIES.map(country => (
                    <SelectItem key={country} value={country} className="text-white">{country}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="text-white/70 text-sm mb-2 block">Form of Company *</label>
              <RadioGroup 
                value={formData.formOfCompany} 
                onValueChange={(v) => updateFormData({ formOfCompany: v })}
                className="flex gap-6 mt-3"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="public" id="public" className="border-[#D1A954] text-[#D1A954]" />
                  <Label htmlFor="public" className="text-white/70">Public</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="private" id="private" className="border-[#D1A954] text-[#D1A954]" />
                  <Label htmlFor="private" className="text-white/70">Private</Label>
                </div>
              </RadioGroup>
            </div>
            
            <div>
              <label className="text-white/70 text-sm mb-2 block">Nature of Business *</label>
              <Input
                required
                placeholder="e.g., Gold Trading, Commodities"
                className="h-12 bg-white/5 border-white/10 text-white rounded-xl focus:border-[#D1A954]/50"
                value={formData.natureOfBusiness}
                onChange={(e) => updateFormData({ natureOfBusiness: e.target.value })}
              />
            </div>
            
            <div>
              <label className="text-white/70 text-sm mb-2 block">Number of Employees</label>
              <Input
                type="number"
                placeholder="0"
                className="h-12 bg-white/5 border-white/10 text-white rounded-xl focus:border-[#D1A954]/50"
                value={formData.numberOfEmployees}
                onChange={(e) => updateFormData({ numberOfEmployees: e.target.value })}
              />
            </div>
          </div>
        </section>

        {/* Head Office Section */}
        <section>
          <div className="flex items-center gap-2 mb-4">
            <div className="h-px flex-1 bg-gradient-to-r from-[#D1A954]/50 to-transparent" />
            <span className="text-[#D1A954] text-xs font-medium tracking-wider uppercase">Head Office Address</span>
            <div className="h-px flex-1 bg-gradient-to-l from-[#D1A954]/50 to-transparent" />
          </div>
          
          <div className="grid md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label className="text-white/70 text-sm mb-2 block">Physical Address *</label>
              <Input
                required
                placeholder="Street address"
                className="h-12 bg-white/5 border-white/10 text-white rounded-xl focus:border-[#D1A954]/50"
                value={formData.headOfficeAddress}
                onChange={(e) => updateFormData({ headOfficeAddress: e.target.value })}
              />
            </div>
            
            <div>
              <label className="text-white/70 text-sm mb-2 block">City *</label>
              <Input
                required
                placeholder="City"
                className="h-12 bg-white/5 border-white/10 text-white rounded-xl focus:border-[#D1A954]/50"
                value={formData.headOfficeCity}
                onChange={(e) => updateFormData({ headOfficeCity: e.target.value })}
              />
            </div>
            
            <div>
              <label className="text-white/70 text-sm mb-2 block">Country *</label>
              <Select 
                value={formData.headOfficeCountry} 
                onValueChange={(v) => updateFormData({ headOfficeCountry: v })}
              >
                <SelectTrigger className="h-12 bg-white/5 border-white/10 text-white rounded-xl">
                  <SelectValue placeholder="Select country" />
                </SelectTrigger>
                <SelectContent className="bg-[#1a0a2e] border-[#D1A954]/30">
                  {COUNTRIES.map(country => (
                    <SelectItem key={country} value={country} className="text-white">{country}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="text-white/70 text-sm mb-2 block">Telephone *</label>
              <div className="relative">
                <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
                <Input
                  required
                  placeholder="+971 XX XXX XXXX"
                  className="h-12 pl-11 bg-white/5 border-white/10 text-white rounded-xl focus:border-[#D1A954]/50"
                  value={formData.telephone}
                  onChange={(e) => updateFormData({ telephone: e.target.value })}
                />
              </div>
            </div>
            
            <div>
              <label className="text-white/70 text-sm mb-2 block">Website</label>
              <div className="relative">
                <Globe className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
                <Input
                  placeholder="https://example.com"
                  className="h-12 pl-11 bg-white/5 border-white/10 text-white rounded-xl focus:border-[#D1A954]/50"
                  value={formData.website}
                  onChange={(e) => updateFormData({ website: e.target.value })}
                />
              </div>
            </div>
            
            <div>
              <label className="text-white/70 text-sm mb-2 block">Email Address *</label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
                <Input
                  type="email"
                  required
                  placeholder="company@example.com"
                  className="h-12 pl-11 bg-white/5 border-white/10 text-white rounded-xl focus:border-[#D1A954]/50"
                  value={formData.email}
                  onChange={(e) => updateFormData({ email: e.target.value })}
                />
              </div>
            </div>
          </div>
        </section>

        {/* Contact Details Section */}
        <section>
          <div className="flex items-center gap-2 mb-4">
            <div className="h-px flex-1 bg-gradient-to-r from-[#D1A954]/50 to-transparent" />
            <span className="text-[#D1A954] text-xs font-medium tracking-wider uppercase">Contact Details</span>
            <div className="h-px flex-1 bg-gradient-to-l from-[#D1A954]/50 to-transparent" />
          </div>
          
          <div className="grid md:grid-cols-2 gap-6">
            {/* Trading Contact */}
            <div className="bg-white/[0.02] border border-white/10 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-4">
                <User className="w-4 h-4 text-[#D1A954]" />
                <span className="text-white/70 text-sm font-medium">Trading Contact</span>
              </div>
              <div className="space-y-3">
                <Input
                  placeholder="Full Name"
                  className="h-10 bg-white/5 border-white/10 text-white rounded-lg focus:border-[#D1A954]/50 text-sm"
                  value={formData.tradingContactName}
                  onChange={(e) => updateFormData({ tradingContactName: e.target.value })}
                />
                <Input
                  placeholder="Mobile Number"
                  className="h-10 bg-white/5 border-white/10 text-white rounded-lg focus:border-[#D1A954]/50 text-sm"
                  value={formData.tradingContactMobile}
                  onChange={(e) => updateFormData({ tradingContactMobile: e.target.value })}
                />
                <Input
                  type="email"
                  placeholder="Email Address"
                  className="h-10 bg-white/5 border-white/10 text-white rounded-lg focus:border-[#D1A954]/50 text-sm"
                  value={formData.tradingContactEmail}
                  onChange={(e) => updateFormData({ tradingContactEmail: e.target.value })}
                />
              </div>
            </div>
            
            {/* Finance Contact */}
            <div className="bg-white/[0.02] border border-white/10 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-4">
                <User className="w-4 h-4 text-[#D1A954]" />
                <span className="text-white/70 text-sm font-medium">Finance Contact</span>
              </div>
              <div className="space-y-3">
                <Input
                  placeholder="Full Name"
                  className="h-10 bg-white/5 border-white/10 text-white rounded-lg focus:border-[#D1A954]/50 text-sm"
                  value={formData.financeContactName}
                  onChange={(e) => updateFormData({ financeContactName: e.target.value })}
                />
                <Input
                  placeholder="Mobile Number"
                  className="h-10 bg-white/5 border-white/10 text-white rounded-lg focus:border-[#D1A954]/50 text-sm"
                  value={formData.financeContactMobile}
                  onChange={(e) => updateFormData({ financeContactMobile: e.target.value })}
                />
                <Input
                  type="email"
                  placeholder="Email Address"
                  className="h-10 bg-white/5 border-white/10 text-white rounded-lg focus:border-[#D1A954]/50 text-sm"
                  value={formData.financeContactEmail}
                  onChange={(e) => updateFormData({ financeContactEmail: e.target.value })}
                />
              </div>
            </div>
          </div>
        </section>

        {/* Submit Button */}
        <div className="pt-4">
          <Button
            type="submit"
            className="w-full h-14 bg-gradient-to-r from-[#D1A954] to-[#B8963E] text-black font-semibold rounded-xl hover:shadow-[0_0_30px_rgba(209,169,84,0.3)] transition-all"
          >
            Continue to Beneficial Ownership
            <ChevronRight className="w-5 h-5 ml-2" />
          </Button>
        </div>
      </form>
    </div>
  );
}