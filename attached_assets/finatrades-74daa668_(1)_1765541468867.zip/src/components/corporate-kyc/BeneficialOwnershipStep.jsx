import React from 'react';
import { Users, Plus, Trash2, Building, AlertTriangle, ChevronRight, ArrowLeft, Upload, X, FileText } from 'lucide-react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { base44 } from '@/api/base44Client';

const COUNTRIES = [
  'United Arab Emirates', 'Switzerland', 'United Kingdom', 'United States',
  'Singapore', 'Hong Kong', 'Germany', 'France', 'Netherlands', 'Luxembourg'
];

export default function BeneficialOwnershipStep({ formData, updateFormData, onComplete, onBack }) {
  const addShareholder = () => {
    if (formData.shareholders.length < 3) {
      updateFormData({
        shareholders: [...formData.shareholders, { name: '', passportNumber: '', email: '' }]
      });
    }
  };

  const removeShareholder = (index) => {
    if (formData.shareholders.length > 1) {
      const updated = formData.shareholders.filter((_, i) => i !== index);
      updateFormData({ shareholders: updated });
    }
  };

  const updateShareholder = (index, field, value) => {
    const updated = formData.shareholders.map((sh, i) => 
      i === index ? { ...sh, [field]: value } : sh
    );
    updateFormData({ shareholders: updated });
  };

  const handleUboDocUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      updateFormData({
        corpShareholderDetails: { ...formData.corpShareholderDetails, uboDoc: file_url, uboDocName: file.name }
      });
    } catch (error) {
      console.error('Upload failed:', error);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onComplete();
  };

  return (
    <div className="bg-white/[0.02] backdrop-blur-xl border border-[#D1A954]/20 rounded-2xl overflow-hidden">
      {/* Header */}
      <div className="p-6 border-b border-[#D1A954]/10">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-xl bg-[#D1A954]/10 flex items-center justify-center">
            <Users className="w-5 h-5 text-[#D1A954]" />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-white">Beneficial Ownership & Shareholding</h2>
            <p className="text-white/40 text-sm">Step 2 of 4</p>
          </div>
        </div>
        <p className="text-white/50 text-sm mt-4">
          Individuals owning 25% or more must be disclosed as per UBO requirement.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="p-6 space-y-8">
        {/* Shareholders Table */}
        <section>
          <div className="flex items-center gap-2 mb-4">
            <div className="h-px flex-1 bg-gradient-to-r from-[#D1A954]/50 to-transparent" />
            <span className="text-[#D1A954] text-xs font-medium tracking-wider uppercase">Shareholders (25%+ Ownership)</span>
            <div className="h-px flex-1 bg-gradient-to-l from-[#D1A954]/50 to-transparent" />
          </div>

          <div className="space-y-4">
            {/* Table Header */}
            <div className="hidden md:grid md:grid-cols-[50px_1fr_1fr_1fr_50px] gap-4 px-4 py-2 bg-white/5 rounded-lg">
              <span className="text-white/50 text-xs font-medium">Sr No</span>
              <span className="text-white/50 text-xs font-medium">Full Name</span>
              <span className="text-white/50 text-xs font-medium">Passport Number</span>
              <span className="text-white/50 text-xs font-medium">Email Address</span>
              <span></span>
            </div>

            {/* Shareholder Rows */}
            {formData.shareholders.map((sh, index) => (
              <div 
                key={index} 
                className="grid grid-cols-1 md:grid-cols-[50px_1fr_1fr_1fr_50px] gap-4 p-4 bg-white/[0.02] border border-white/10 rounded-xl"
              >
                <div className="hidden md:flex items-center justify-center w-8 h-8 rounded-full bg-[#D1A954]/10 text-[#D1A954] text-sm font-medium">
                  {index + 1}
                </div>
                <div className="md:hidden flex items-center gap-2 mb-2">
                  <div className="w-6 h-6 rounded-full bg-[#D1A954]/10 text-[#D1A954] text-xs font-medium flex items-center justify-center">
                    {index + 1}
                  </div>
                  <span className="text-white/50 text-sm">Shareholder {index + 1}</span>
                </div>
                <Input
                  placeholder="Full Name"
                  className="h-10 bg-white/5 border-white/10 text-white rounded-lg focus:border-[#D1A954]/50 text-sm"
                  value={sh.name}
                  onChange={(e) => updateShareholder(index, 'name', e.target.value)}
                />
                <Input
                  placeholder="Passport Number"
                  className="h-10 bg-white/5 border-white/10 text-white rounded-lg focus:border-[#D1A954]/50 text-sm"
                  value={sh.passportNumber}
                  onChange={(e) => updateShareholder(index, 'passportNumber', e.target.value)}
                />
                <Input
                  type="email"
                  placeholder="Email Address"
                  className="h-10 bg-white/5 border-white/10 text-white rounded-lg focus:border-[#D1A954]/50 text-sm"
                  value={sh.email}
                  onChange={(e) => updateShareholder(index, 'email', e.target.value)}
                />
                <button
                  type="button"
                  onClick={() => removeShareholder(index)}
                  disabled={formData.shareholders.length === 1}
                  className="flex items-center justify-center w-10 h-10 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20 disabled:opacity-30 disabled:cursor-not-allowed"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}

            {formData.shareholders.length < 3 && (
              <button
                type="button"
                onClick={addShareholder}
                className="flex items-center justify-center gap-2 w-full p-3 border border-dashed border-[#D1A954]/30 rounded-xl text-[#D1A954] hover:bg-[#D1A954]/5 transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span className="text-sm">Add Shareholder</span>
              </button>
            )}
          </div>
        </section>

        {/* Corporate Shareholder Section */}
        <section>
          <div className="flex items-center gap-2 mb-4">
            <div className="h-px flex-1 bg-gradient-to-r from-[#D1A954]/50 to-transparent" />
            <span className="text-[#D1A954] text-xs font-medium tracking-wider uppercase">UBO Corporate Structure</span>
            <div className="h-px flex-1 bg-gradient-to-l from-[#D1A954]/50 to-transparent" />
          </div>

          <div className="bg-white/[0.02] border border-white/10 rounded-xl p-4">
            <div className="flex items-start gap-3 mb-4">
              <Building className="w-5 h-5 text-[#D1A954] mt-0.5" />
              <div>
                <p className="text-white/80 text-sm">Is any shareholder another company/legal entity?</p>
                <p className="text-white/40 text-xs mt-1">If yes, provide details of the corporate shareholder</p>
              </div>
            </div>

            <RadioGroup 
              value={formData.hasCorpShareholder ? 'yes' : 'no'} 
              onValueChange={(v) => updateFormData({ hasCorpShareholder: v === 'yes' })}
              className="flex gap-6 mb-4"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="yes" id="corp-yes" className="border-[#D1A954] text-[#D1A954]" />
                <Label htmlFor="corp-yes" className="text-white/70">Yes</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="no" id="corp-no" className="border-[#D1A954] text-[#D1A954]" />
                <Label htmlFor="corp-no" className="text-white/70">No</Label>
              </div>
            </RadioGroup>

            {formData.hasCorpShareholder && (
              <div className="space-y-4 pt-4 border-t border-white/10">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-white/60 text-xs mb-2 block">Legal Entity Name</label>
                    <Input
                      placeholder="Company name"
                      className="h-10 bg-white/5 border-white/10 text-white rounded-lg focus:border-[#D1A954]/50 text-sm"
                      value={formData.corpShareholderDetails.legalName}
                      onChange={(e) => updateFormData({
                        corpShareholderDetails: { ...formData.corpShareholderDetails, legalName: e.target.value }
                      })}
                    />
                  </div>
                  <div>
                    <label className="text-white/60 text-xs mb-2 block">Registration Number</label>
                    <Input
                      placeholder="Registration number"
                      className="h-10 bg-white/5 border-white/10 text-white rounded-lg focus:border-[#D1A954]/50 text-sm"
                      value={formData.corpShareholderDetails.regNumber}
                      onChange={(e) => updateFormData({
                        corpShareholderDetails: { ...formData.corpShareholderDetails, regNumber: e.target.value }
                      })}
                    />
                  </div>
                  <div>
                    <label className="text-white/60 text-xs mb-2 block">Country of Incorporation</label>
                    <Select 
                      value={formData.corpShareholderDetails.country} 
                      onValueChange={(v) => updateFormData({
                        corpShareholderDetails: { ...formData.corpShareholderDetails, country: v }
                      })}
                    >
                      <SelectTrigger className="h-10 bg-white/5 border-white/10 text-white rounded-lg text-sm">
                        <SelectValue placeholder="Select country" />
                      </SelectTrigger>
                      <SelectContent className="bg-[#1a0a2e] border-[#D1A954]/30">
                        {COUNTRIES.map(country => (
                          <SelectItem key={country} value={country} className="text-white text-sm">{country}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-white/60 text-xs mb-2 block">UBO Document of Entity</label>
                    {formData.corpShareholderDetails.uboDoc ? (
                      <div className="flex items-center gap-2 p-2 bg-[#D1A954]/10 border border-[#D1A954]/30 rounded-lg">
                        <FileText className="w-4 h-4 text-[#D1A954]" />
                        <span className="text-white text-xs truncate flex-1">{formData.corpShareholderDetails.uboDocName}</span>
                        <button 
                          type="button"
                          onClick={() => updateFormData({
                            corpShareholderDetails: { ...formData.corpShareholderDetails, uboDoc: null, uboDocName: null }
                          })}
                          className="p-1 rounded bg-red-500/20 text-red-400"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ) : (
                      <label className="flex items-center justify-center gap-2 h-10 border border-dashed border-white/20 rounded-lg cursor-pointer hover:border-[#D1A954]/50 hover:bg-[#D1A954]/5 transition-all">
                        <Upload className="w-4 h-4 text-white/40" />
                        <span className="text-white/50 text-xs">Upload document</span>
                        <input 
                          type="file" 
                          className="hidden" 
                          accept=".pdf,.png,.jpg,.jpeg"
                          onChange={handleUboDocUpload}
                        />
                      </label>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        </section>

        {/* PEP Section */}
        <section>
          <div className="flex items-center gap-2 mb-4">
            <div className="h-px flex-1 bg-gradient-to-r from-[#D1A954]/50 to-transparent" />
            <span className="text-[#D1A954] text-xs font-medium tracking-wider uppercase">Politically Exposed Person (PEP)</span>
            <div className="h-px flex-1 bg-gradient-to-l from-[#D1A954]/50 to-transparent" />
          </div>

          <div className="bg-amber-500/5 border border-amber-500/20 rounded-xl p-4">
            <div className="flex items-start gap-3 mb-4">
              <AlertTriangle className="w-5 h-5 text-amber-400 mt-0.5" />
              <div>
                <p className="text-white/80 text-sm">Are any of the UBOs, Shareholders, or Directors Politically Exposed Persons (PEP)?</p>
                <p className="text-white/40 text-xs mt-1">This includes individuals holding prominent public positions</p>
              </div>
            </div>

            <RadioGroup 
              value={formData.hasPEP ? 'yes' : 'no'} 
              onValueChange={(v) => updateFormData({ hasPEP: v === 'yes' })}
              className="flex gap-6 mb-4"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="yes" id="pep-yes" className="border-amber-400 text-amber-400" />
                <Label htmlFor="pep-yes" className="text-white/70">Yes</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="no" id="pep-no" className="border-amber-400 text-amber-400" />
                <Label htmlFor="pep-no" className="text-white/70">No</Label>
              </div>
            </RadioGroup>

            {formData.hasPEP && (
              <div className="pt-4 border-t border-amber-500/20">
                <label className="text-white/60 text-xs mb-2 block">Please provide PEP details</label>
                <textarea
                  placeholder="Provide details of the Politically Exposed Person(s)..."
                  className="w-full h-24 px-4 py-3 bg-white/5 border border-white/10 text-white rounded-xl focus:border-amber-500/50 focus:outline-none resize-none text-sm"
                  value={formData.pepDetails}
                  onChange={(e) => updateFormData({ pepDetails: e.target.value })}
                />
              </div>
            )}
          </div>
        </section>

        {/* Navigation Buttons */}
        <div className="flex gap-4 pt-4">
          <Button
            type="button"
            variant="outline"
            onClick={onBack}
            className="flex-1 h-14 border-white/20 text-white/70 hover:bg-white/5 rounded-xl"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <Button
            type="submit"
            className="flex-[2] h-14 bg-gradient-to-r from-[#D1A954] to-[#B8963E] text-black font-semibold rounded-xl hover:shadow-[0_0_30px_rgba(209,169,84,0.3)] transition-all"
          >
            Continue to Documentation
            <ChevronRight className="w-5 h-5 ml-2" />
          </Button>
        </div>
      </form>
    </div>
  );
}