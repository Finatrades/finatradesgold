import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Check, Clock, Mail, ArrowRight, Shield } from 'lucide-react';
import { Button } from "@/components/ui/button";

export default function KYCPendingScreen() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#000000] via-[#0d0515] to-[#1a0a2e] flex items-center justify-center p-6">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-md w-full text-center"
      >
        {/* Success Animation */}
        <div className="relative mb-8">
          {/* Outer Ring */}
          <motion.div
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.5 }}
            className="absolute inset-0 w-32 h-32 mx-auto rounded-full border-2 border-[#D1A954]/20"
          />
          
          {/* Middle Ring - Spinning */}
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
            className="absolute inset-0 w-32 h-32 mx-auto"
          >
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-2 h-2 rounded-full bg-[#D1A954]" />
          </motion.div>
          
          {/* Center Circle */}
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.4, type: "spring", stiffness: 200 }}
            className="relative w-32 h-32 mx-auto rounded-full bg-gradient-to-br from-[#D1A954] to-[#B8963E] flex items-center justify-center shadow-[0_0_60px_rgba(209,169,84,0.4)]"
          >
            <Check className="w-14 h-14 text-black" strokeWidth={3} />
          </motion.div>
        </div>

        {/* Title */}
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="text-2xl font-semibold text-white mb-3"
        >
          KYC Verification in Progress
        </motion.h1>

        {/* Description */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="text-white/60 mb-8"
        >
          Thank you. Your KYC documents were submitted successfully.
          <br />
          Our compliance team is reviewing your application.
        </motion.p>

        {/* Status Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="bg-white/[0.02] backdrop-blur-xl border border-[#D1A954]/20 rounded-2xl p-6 mb-8"
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <Clock className="w-5 h-5 text-[#D1A954]" />
            <span className="text-white/80">Estimated Review Time</span>
          </div>
          <p className="text-3xl font-bold text-[#D1A954] mb-2">24 – 48 Hours</p>
          <div className="flex items-center justify-center gap-2 text-white/50 text-sm">
            <Mail className="w-4 h-4" />
            <span>You will be notified by email</span>
          </div>
        </motion.div>

        {/* Info Text */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.9 }}
          className="text-white/40 text-sm mb-8"
        >
          You may explore the platform while we complete the verification.
        </motion.p>

        {/* Action Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1 }}
        >
          <Link to={createPageUrl("UserDashboard")}>
            <Button className="w-full h-14 bg-gradient-to-r from-[#D1A954] to-[#B8963E] text-black font-semibold rounded-xl hover:shadow-[0_0_30px_rgba(209,169,84,0.3)] transition-all">
              Go to Dashboard
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </Link>
        </motion.div>

        {/* Security Badge */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2 }}
          className="flex items-center justify-center gap-2 mt-8 text-white/30"
        >
          <Shield className="w-4 h-4" />
          <span className="text-xs">Your data is protected with bank-level encryption</span>
        </motion.div>
      </motion.div>
    </div>
  );
}