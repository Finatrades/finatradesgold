import React from 'react';
import { motion } from 'framer-motion';
import { Wallet, Lock, FileText, CheckCircle } from 'lucide-react';

export default function TradeSummaryCards({ walletBalance, lockedBalance, activeCases, completedCases }) {
  const cards = [
    {
      label: 'Available Trade Wallet Balance',
      value: `${walletBalance.toFixed(3)} g`,
      subtext: 'Available for new trade cases',
      icon: Wallet,
      highlight: true
    },
    {
      label: 'Locked for Trade Cases',
      value: `${lockedBalance.toFixed(3)} g`,
      subtext: 'Locked',
      icon: Lock
    },
    {
      label: 'Active Trade Cases',
      value: activeCases.toString(),
      subtext: 'In progress',
      icon: FileText
    },
    {
      label: 'Completed Trade Cases',
      value: completedCases.toString(),
      subtext: 'Successfully settled',
      icon: CheckCircle
    }
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-4">
      {cards.map((card, index) => (
        <motion.div
          key={card.label}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
          className={`border rounded-xl sm:rounded-2xl p-3 sm:p-5 shadow-sm ${
            card.highlight 
              ? 'bg-gradient-to-br from-amber-500/10 to-transparent border-amber-500/30' 
              : card.label === 'Locked for Trade Cases'
              ? 'bg-gradient-to-br from-orange-50 to-amber-50 border-orange-200'
              : 'bg-white border-[#8A2BE2]/20'
          }`}
        >
          <div className="flex items-center justify-between mb-2 sm:mb-3">
            <span className="text-[#4A4A4A] text-[10px] sm:text-sm">{card.label}</span>
            <div className={`w-7 h-7 sm:w-10 sm:h-10 rounded-lg sm:rounded-xl flex items-center justify-center ${
              card.highlight ? 'bg-amber-500/20' : 'bg-[#F4F6FC]'
            }`}>
              <card.icon className={`w-3.5 h-3.5 sm:w-5 sm:h-5 ${card.highlight ? 'text-amber-600' : 'text-[#4A4A4A]'}`} />
            </div>
          </div>
          <p className={`text-lg sm:text-3xl font-bold ${
            card.highlight ? 'text-amber-600' : 
            card.label === 'Locked for Trade Cases' ? 'text-orange-600' : 
            'text-[#0D0D0D]'
          }`}>
            {card.value}
          </p>
          <p className={`text-[10px] sm:text-sm mt-1 ${
            card.label === 'Locked for Trade Cases' ? 'text-orange-600 font-medium' : 'text-[#4A4A4A]'
          }`}>
            {card.subtext}
          </p>
        </motion.div>
      ))}
    </div>
  );
}