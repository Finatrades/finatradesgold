import React, { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { Ship, FileText, Shield, CreditCard, Vault, Globe, CheckCircle, TrendingUp } from 'lucide-react';

const exporterBenefits = [
  { icon: CheckCircle, title: "Verified Worth of Gold from Buyer", description: "Confirm the importer has allocated documented gold value before shipment." },
  { icon: TrendingUp, title: "Higher Confidence Before Shipment", description: "Reduce uncertainty by verifying buyer's commitment through gold allocation." },
  { icon: Shield, title: "Reduced Risk of Non-Payment", description: "Gold worth acts as a tangible assurance layer against payment defaults." },
  { icon: FileText, title: "Stable Value Anchor in Contracts", description: "Use gold worth as a reference point for stable pricing agreements." }
];

const importerBenefits = [
  { icon: CreditCard, title: "Proof of Ability to Pay", description: "Demonstrate financial capability through documented gold holdings." },
  { icon: Vault, title: "Less Upfront Cash Pressure", description: "Allocate gold worth instead of tying up operational cash reserves." },
  { icon: Globe, title: "Lower Currency Volatility Risk", description: "Gold value provides stability against fluctuating exchange rates." },
  { icon: TrendingUp, title: "Better Terms with Sellers", description: "Negotiate favorable conditions with verified gold-backed assurance." }
];

function BenefitCard({ benefit, index, side }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, x: side === 'exporter' ? -30 : 30 }}
      animate={isInView ? { opacity: 1, x: 0 } : {}}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="group relative"
    >
      <div className="relative bg-white rounded-xl border border-[#8A2BE2]/20 p-5 hover:border-[#8A2BE2]/40 transition-all duration-500 overflow-hidden shadow-[0_4px_20px_rgba(138,43,226,0.08)]">
        {/* Hover glow */}
        <motion.div
          className="absolute inset-0 bg-gradient-to-br from-[#D4AF37]/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"
        />
        
        {/* Shimmer effect on hover */}
        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-transparent via-[#D4AF37]/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000"
        />

        <div className="relative z-10 flex items-start gap-4">
          <motion.div
            className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#8A2BE2]/20 to-[#FF2FBF]/10 flex items-center justify-center flex-shrink-0"
            whileHover={{ rotate: 10, scale: 1.1 }}
          >
            <benefit.icon className="w-5 h-5 text-[#8A2BE2]" />
          </motion.div>
          <div>
            <h4 className="text-[#0D0D0D] font-medium mb-1 group-hover:text-[#8A2BE2] transition-colors">{benefit.title}</h4>
            <p className="text-[#4A4A4A] text-sm leading-relaxed">{benefit.description}</p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

export default function WhyUsFinaBridge() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="relative py-24 bg-gradient-to-b from-[#FAFBFF] via-[#F4F6FC] to-[#FAFBFF] overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_left,_rgba(138,43,226,0.05)_0%,_transparent_50%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_right,_rgba(255,47,191,0.05)_0%,_transparent_50%)]" />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        {/* Section header */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <p className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent text-sm tracking-[0.2em] uppercase mb-4">Trade with Confidence</p>
          <h2 className="text-4xl md:text-5xl font-bold text-[#0D0D0D] mb-4">
            Why Use FinaBridge for <span className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent">Trade</span>?
          </h2>
          <motion.div
            className="w-24 h-0.5 bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] mx-auto"
            initial={{ width: 0 }}
            animate={isInView ? { width: 96 } : {}}
            transition={{ duration: 0.8, delay: 0.3 }}
          />
        </motion.div>

        {/* Two columns */}
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Exporters Column */}
          <div>
            <motion.div
              className="flex items-center gap-3 mb-6"
              initial={{ opacity: 0, x: -20 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ delay: 0.2 }}
            >
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#8A2BE2] to-[#FF2FBF] flex items-center justify-center shadow-[0_0_20px_rgba(138,43,226,0.3)]">
                <Ship className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-xl text-[#0D0D0D] font-medium">For Exporters</h3>
                <p className="text-[#4A4A4A] text-sm">Sellers & Shippers</p>
              </div>
            </motion.div>
            
            <div className="space-y-4">
              {exporterBenefits.map((benefit, i) => (
                <BenefitCard key={i} benefit={benefit} index={i} side="exporter" />
              ))}
            </div>
          </div>

          {/* Importers Column */}
          <div>
            <motion.div
              className="flex items-center gap-3 mb-6"
              initial={{ opacity: 0, x: 20 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ delay: 0.2 }}
            >
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#8A2BE2] to-[#FF2FBF] flex items-center justify-center shadow-[0_0_20px_rgba(138,43,226,0.3)]">
                <CreditCard className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-xl text-[#0D0D0D] font-medium">For Importers</h3>
                <p className="text-[#4A4A4A] text-sm">Buyers & Receivers</p>
              </div>
            </motion.div>
            
            <div className="space-y-4">
              {importerBenefits.map((benefit, i) => (
                <BenefitCard key={i} benefit={benefit} index={i} side="importer" />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}