import React, { useRef, useState, useEffect } from 'react';
import { motion, useInView } from 'framer-motion';
import { Building, Ship, Link as LinkIcon } from 'lucide-react';

// Helper to get point on quadratic bezier curve
function getPointOnQuadraticBezier(t, p0, p1, p2) {
  const x = (1 - t) * (1 - t) * p0.x + 2 * (1 - t) * t * p1.x + t * t * p2.x;
  const y = (1 - t) * (1 - t) * p0.y + 2 * (1 - t) * t * p1.y + t * t * p2.y;
  return { x, y };
}

function GoldPathAnimation({ isInView }) {
  const [progress, setProgress] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);
  
  // Bezier curve control points for path "M10,60 Q100,10 190,60"
  const p0 = { x: 10, y: 60 };
  const p1 = { x: 100, y: 10 };
  const p2 = { x: 190, y: 60 };

  useEffect(() => {
    if (!isInView) return;
    
    const startDelay = setTimeout(() => {
      setIsAnimating(true);
    }, 2500);
    
    return () => clearTimeout(startDelay);
  }, [isInView]);

  useEffect(() => {
    if (!isAnimating) return;
    
    let animationId;
    let startTime;
    const duration = 5000; // 5 seconds - slower
    const pauseDuration = 2000; // 2 seconds pause

    const animate = (timestamp) => {
      if (!startTime) startTime = timestamp;
      const elapsed = timestamp - startTime;
      const totalCycle = duration + pauseDuration;
      const cycleTime = elapsed % totalCycle;
      
      if (cycleTime < duration) {
        // Ease in-out cubic
        let t = cycleTime / duration;
        t = t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
        setProgress(t);
      } else {
        setProgress(0);
      }
      
      animationId = requestAnimationFrame(animate);
    };

    animationId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationId);
  }, [isAnimating]);

  // Gold goes from importer (left) to exporter (right)
  const goldPosition = getPointOnQuadraticBezier(progress, p0, p1, p2);
  
  // Ship goes from exporter (right) to importer (left) - same progress, reversed path
  const shipPosition = getPointOnQuadraticBezier(progress, p2, p1, p0);

  return (
    <svg className="w-full h-24" viewBox="0 0 200 80" preserveAspectRatio="xMidYMid meet">
      <defs>
        <linearGradient id="bridgeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#8A2BE2" stopOpacity="0.3" />
          <stop offset="50%" stopColor="#FF2FBF" stopOpacity="1" />
          <stop offset="100%" stopColor="#8A2BE2" stopOpacity="0.3" />
        </linearGradient>
        <linearGradient id="goldGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#FFD700" />
          <stop offset="50%" stopColor="#FFA500" />
          <stop offset="100%" stopColor="#DAA520" />
        </linearGradient>
        <filter id="goldGlow" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="2" result="blur" />
          <feMerge>
            <feMergeNode in="blur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>
      
      {/* Bridge arc */}
      <motion.path
        d="M10,60 Q100,10 190,60"
        stroke="url(#bridgeGradient)"
        strokeWidth="3"
        fill="none"
        initial={{ pathLength: 0 }}
        animate={isInView ? { pathLength: 1 } : {}}
        transition={{ duration: 1.5, delay: 0.8 }}
      />
      
      {/* Support lines */}
      <motion.line x1="10" y1="60" x2="10" y2="75" stroke="#8A2BE2" strokeWidth="2" opacity="0.5" />
      <motion.line x1="190" y1="60" x2="190" y2="75" stroke="#8A2BE2" strokeWidth="2" opacity="0.5" />
      <motion.line x1="100" y1="35" x2="100" y2="75" stroke="#8A2BE2" strokeWidth="2" opacity="0.3" />
      
      {/* Animated gold bar - Importer to Exporter */}
      {isAnimating && progress > 0 && (
        <g transform={`translate(${goldPosition.x}, ${goldPosition.y})`} filter="url(#goldGlow)">
          {/* Gold bar shape */}
          <rect
            x="-7"
            y="-4"
            width="14"
            height="8"
            rx="1.5"
            fill="url(#goldGradient)"
            stroke="#B8860B"
            strokeWidth="0.5"
          />
          {/* Shine effect */}
          <rect
            x="-5"
            y="-2"
            width="4"
            height="2"
            rx="0.5"
            fill="#FFFACD"
            opacity="0.7"
          />
          {/* Bottom shadow */}
          <rect
            x="-5"
            y="1"
            width="10"
            height="2"
            rx="0.5"
            fill="#B8860B"
            opacity="0.3"
          />
        </g>
      )}
      
      {/* Animated ship - Exporter to Importer (opposite direction) */}
      {isAnimating && progress > 0 && (
        <g transform={`translate(${shipPosition.x}, ${shipPosition.y - 8})`}>
          {/* Ship hull */}
          <path
            d="M-6,4 L-8,8 L8,8 L6,4 Z"
            fill="#4B0082"
            stroke="#8A2BE2"
            strokeWidth="0.5"
          />
          {/* Ship deck */}
          <rect x="-4" y="1" width="8" height="3" fill="#6B21A8" rx="0.5" />
          {/* Ship cabin */}
          <rect x="-2" y="-2" width="4" height="3" fill="#7C3AED" rx="0.5" />
          {/* Smokestack */}
          <rect x="0" y="-5" width="2" height="3" fill="#9333EA" rx="0.3" />
          {/* Smoke puff */}
          <circle cx="1" cy="-7" r="1.5" fill="#E9D5FF" opacity="0.6" />
        </g>
      )}
    </svg>
  );
}

export default function WhatIsFinaBridge() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="relative py-24 bg-gradient-to-b from-[#FAFBFF] via-[#F4F6FC] to-[#FAFBFF] overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(138,43,226,0.05)_0%,_transparent_50%)]" />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Text */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8 }}
          >
            <motion.p
              className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent text-sm tracking-[0.2em] uppercase mb-4"
              initial={{ opacity: 0 }}
              animate={isInView ? { opacity: 1 } : {}}
              transition={{ delay: 0.2 }}
            >
              Understanding the Platform
            </motion.p>

            <h2 className="text-4xl md:text-5xl font-bold text-[#0D0D0D] mb-6">
              What is <span className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent">FinaBridge</span>?
            </h2>

            <div className="space-y-4 text-[#4A4A4A] leading-relaxed">
              <p>
                FinaBridge is a <strong className="text-[#0D0D0D]">gold-backed trade support module</strong> designed 
                for businesses engaged in international import and export operations.
              </p>
              <p>
                It provides a <strong className="text-[#0D0D0D]">stable reference</strong> for real-world trade by using 
                the verified worth of physical gold as an anchor point for contracts, negotiations, and settlements.
              </p>
              <p>
                Unlike traditional trade finance that relies solely on bank letters of credit or advance payments, 
                FinaBridge introduces a <strong className="text-[#0D0D0D]">tangible, documented value layer</strong> that 
                both parties can verify and trust.
              </p>
            </div>

            <motion.div
              className="w-24 h-0.5 bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] mt-8"
              initial={{ width: 0 }}
              animate={isInView ? { width: 96 } : {}}
              transition={{ duration: 0.8, delay: 0.5 }}
            />
          </motion.div>

          {/* Right Visual - Bridge Illustration */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="relative bg-white rounded-3xl border border-[#8A2BE2]/20 p-8 overflow-hidden shadow-[0_8px_32px_rgba(138,43,226,0.1)]">
              {/* Inner glow */}
              <div className="absolute inset-0 bg-gradient-to-br from-[#8A2BE2]/5 to-[#FF2FBF]/5" />

              <div className="relative z-10">
                {/* Bridge visualization */}
                <div className="flex items-center justify-between mb-8">
                  {/* Importer side */}
                  <motion.div
                    className="text-center"
                    initial={{ opacity: 0, x: -20 }}
                    animate={isInView ? { opacity: 1, x: 0 } : {}}
                    transition={{ delay: 0.5 }}
                  >
                    <motion.div
                      className="w-20 h-20 rounded-2xl bg-gradient-to-br from-[#8A2BE2]/20 to-[#FF2FBF]/10 border border-[#8A2BE2]/30 flex items-center justify-center mx-auto mb-3"
                      animate={{ boxShadow: ['0 0 20px rgba(138,43,226,0.1)', '0 0 40px rgba(138,43,226,0.2)', '0 0 20px rgba(138,43,226,0.1)'] }}
                      transition={{ duration: 3, repeat: Infinity }}
                    >
                      <Building className="w-8 h-8 text-[#8A2BE2]" />
                    </motion.div>
                    <span className="text-[#0D0D0D] font-medium">Importer</span>
                    <p className="text-xs text-[#4A4A4A] mt-1">Buyer</p>
                  </motion.div>

                  {/* Bridge arc */}
                  <div className="flex-1 mx-4 relative">
                    <GoldPathAnimation isInView={isInView} />

                    {/* "Gold Worth" label */}
                    <motion.div
                      className="absolute -bottom-2 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-white border border-[#8A2BE2]/30 shadow-sm"
                      initial={{ opacity: 0 }}
                      animate={isInView ? { opacity: 1 } : {}}
                      transition={{ delay: 1.5 }}
                    >
                      <span className="text-xs text-[#8A2BE2] font-medium">Worth of Gold</span>
                    </motion.div>
                  </div>

                  {/* Exporter side */}
                  <motion.div
                    className="text-center"
                    initial={{ opacity: 0, x: 20 }}
                    animate={isInView ? { opacity: 1, x: 0 } : {}}
                    transition={{ delay: 0.5 }}
                  >
                    <motion.div
                      className="w-20 h-20 rounded-2xl bg-gradient-to-br from-[#8A2BE2]/20 to-[#FF2FBF]/10 border border-[#8A2BE2]/30 flex items-center justify-center mx-auto mb-3"
                      animate={{ boxShadow: ['0 0 20px rgba(138,43,226,0.1)', '0 0 40px rgba(138,43,226,0.2)', '0 0 20px rgba(138,43,226,0.1)'] }}
                      transition={{ duration: 3, repeat: Infinity, delay: 1.5 }}
                    >
                      <Ship className="w-8 h-8 text-[#8A2BE2]" />
                    </motion.div>
                    <span className="text-[#0D0D0D] font-medium">Exporter</span>
                    <p className="text-xs text-[#4A4A4A] mt-1">Seller</p>
                  </motion.div>
                </div>

                {/* Bottom info */}
                <div className="grid grid-cols-3 gap-4 pt-6 border-t border-[#8A2BE2]/10">
                  {[
                    { label: "Verified", value: "Documentation" },
                    { label: "Stable", value: "Value Anchor" },
                    { label: "Trusted", value: "Settlement" }
                  ].map((item, i) => (
                    <motion.div
                      key={i}
                      className="text-center"
                      initial={{ opacity: 0, y: 10 }}
                      animate={isInView ? { opacity: 1, y: 0 } : {}}
                      transition={{ delay: 1 + i * 0.1 }}
                    >
                      <div className="text-[#8A2BE2] text-sm font-medium">{item.value}</div>
                      <div className="text-xs text-[#4A4A4A]">{item.label}</div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}