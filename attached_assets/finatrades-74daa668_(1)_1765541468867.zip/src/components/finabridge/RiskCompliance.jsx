import React, { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { Shield, AlertTriangle, Building, Users, Vault, FileText, CheckCircle } from 'lucide-react';

const compliancePoints = [
  { icon: Building, text: "Swiss-aligned operational framework" },
  { icon: Users, text: "Corporate KYB verification" },
  { icon: Vault, text: "Vault-level physical security" },
  { icon: FileText, text: "Full transaction and document audit trails" },
  { icon: CheckCircle, text: "Clear, verifiable ownership records" }
];

export default function RiskCompliance() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="relative py-24 bg-gradient-to-b from-[#FAFBFF] via-[#F4F6FC] to-[#FAFBFF] overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(138,43,226,0.05)_0%,_transparent_50%)]" />

      <div className="relative z-10 max-w-6xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left content */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8 }}
          >
            <div className="flex items-center gap-3 mb-6">
              <motion.div
                className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#8A2BE2]/20 to-[#FF2FBF]/10 border border-[#8A2BE2]/30 flex items-center justify-center"
                animate={{ boxShadow: ['0 0 20px rgba(138,43,226,0.1)', '0 0 40px rgba(138,43,226,0.2)', '0 0 20px rgba(138,43,226,0.1)'] }}
                transition={{ duration: 3, repeat: Infinity }}
              >
                <AlertTriangle className="w-6 h-6 text-[#8A2BE2]" />
              </motion.div>
              <p className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent text-sm tracking-wide uppercase">Important Positioning</p>
            </div>

            <h2 className="text-4xl md:text-5xl font-bold text-[#0D0D0D] mb-6">
              Risk Management, <span className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent">Not Risk Elimination</span>
            </h2>

            <div className="space-y-4 text-[#4A4A4A] leading-relaxed mb-8">
              <p>
                FinaBridge <strong className="text-[#0D0D0D]">complements</strong> traditional trade finance instruments 
                like bank letters of credit, advance payments, and trade insurance.
              </p>
              <p>
                It provides <strong className="text-[#0D0D0D]">documentation, assurance, and a stable value reference</strong> that 
                strengthens—but does not replace—existing risk mitigation tools.
              </p>
              <p>
                We <strong className="text-[#8A2BE2]">reduce</strong> trade risk; we do not <strong className="text-[#4A4A4A]">remove</strong> it entirely.
              </p>
            </div>

            <motion.div
              className="w-24 h-0.5 bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF]"
              initial={{ width: 0 }}
              animate={isInView ? { width: 96 } : {}}
              transition={{ duration: 0.8, delay: 0.5 }}
            />
          </motion.div>

          {/* Right - Compliance card */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <div className="relative bg-white rounded-3xl border border-[#8A2BE2]/20 p-8 overflow-hidden shadow-[0_8px_32px_rgba(138,43,226,0.1)]">
              {/* Inner glow */}
              <div className="absolute inset-0 bg-gradient-to-br from-[#8A2BE2]/5 to-[#FF2FBF]/5" />

              {/* Shield icon with glow */}
              <motion.div
                className="relative z-10 flex justify-center mb-8"
                animate={{ y: [0, -5, 0] }}
                transition={{ duration: 3, repeat: Infinity }}
              >
                <div className="relative">
                  <motion.div
                    className="absolute inset-0 bg-[#8A2BE2]/20 rounded-full blur-xl"
                    animate={{ scale: [1, 1.2, 1], opacity: [0.5, 0.8, 0.5] }}
                    transition={{ duration: 3, repeat: Infinity }}
                  />
                  <div className="relative w-20 h-20 rounded-2xl bg-gradient-to-br from-[#8A2BE2] to-[#FF2FBF] flex items-center justify-center shadow-[0_0_30px_rgba(138,43,226,0.3)]">
                    <Shield className="w-10 h-10 text-white" />
                  </div>
                </div>
              </motion.div>

              {/* Compliance points */}
              <div className="relative z-10 space-y-4">
                {compliancePoints.map((point, index) => (
                  <motion.div
                    key={index}
                    className="flex items-center gap-4 p-3 rounded-xl bg-[#F4F6FC]/50 border border-[#8A2BE2]/10 hover:border-[#8A2BE2]/30 transition-colors"
                    initial={{ opacity: 0, x: 20 }}
                    animate={isInView ? { opacity: 1, x: 0 } : {}}
                    transition={{ duration: 0.5, delay: 0.4 + index * 0.1 }}
                  >
                    <motion.div
                      className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#8A2BE2]/20 to-[#FF2FBF]/10 flex items-center justify-center flex-shrink-0"
                      whileHover={{ rotate: 10 }}
                    >
                      <point.icon className="w-4 h-4 text-[#8A2BE2]" />
                    </motion.div>
                    <span className="text-[#4A4A4A] text-sm">{point.text}</span>
                  </motion.div>
                ))}
              </div>

              {/* Decorative corners */}
              <div className="absolute top-4 left-4 w-8 h-8 border-l-2 border-t-2 border-[#8A2BE2]/20 rounded-tl-lg" />
              <div className="absolute top-4 right-4 w-8 h-8 border-r-2 border-t-2 border-[#8A2BE2]/20 rounded-tr-lg" />
              <div className="absolute bottom-4 left-4 w-8 h-8 border-l-2 border-b-2 border-[#8A2BE2]/20 rounded-bl-lg" />
              <div className="absolute bottom-4 right-4 w-8 h-8 border-r-2 border-b-2 border-[#8A2BE2]/20 rounded-br-lg" />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}