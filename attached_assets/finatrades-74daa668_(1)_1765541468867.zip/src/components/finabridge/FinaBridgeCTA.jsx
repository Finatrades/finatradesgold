import React, { useRef } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion, useInView } from 'framer-motion';
import { ArrowRight, Phone, Link as LinkIcon } from 'lucide-react';

// Floating particles
function FloatingParticles() {
  const particles = [...Array(30)].map((_, i) => ({
    id: i,
    x: Math.random() * 100,
    y: Math.random() * 100,
    size: 1 + Math.random() * 2,
    duration: 3 + Math.random() * 4,
    delay: Math.random() * 3,
    color: Math.random() > 0.5 ? '#8A2BE2' : '#FF2FBF'
  }));

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {particles.map((p) => (
        <motion.div
          key={p.id}
          className="absolute rounded-full"
          style={{
            left: `${p.x}%`,
            top: `${p.y}%`,
            width: p.size,
            height: p.size,
            backgroundColor: p.color,
            boxShadow: `0 0 ${p.size * 2}px ${p.color}`
          }}
          animate={{
            y: [0, -30, 0],
            opacity: [0, 0.8, 0],
          }}
          transition={{
            duration: p.duration,
            delay: p.delay,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      ))}
    </div>
  );
}

export default function FinaBridgeCTA() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="relative py-32 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#FAFBFF] via-[#F4F6FC] to-[#FAFBFF]" />
      
      {/* Glow orbs */}
      <motion.div
        className="absolute top-1/2 left-1/4 w-[400px] h-[400px] rounded-full bg-[#8A2BE2]/10 blur-[100px]"
        animate={{ scale: [1, 1.2, 1], opacity: [0.3, 0.5, 0.3] }}
        transition={{ duration: 5, repeat: Infinity }}
      />
      <motion.div
        className="absolute top-1/2 right-1/4 w-[300px] h-[300px] rounded-full bg-[#FF2FBF]/10 blur-[80px]"
        animate={{ scale: [1, 1.3, 1], opacity: [0.2, 0.4, 0.2] }}
        transition={{ duration: 6, repeat: Infinity, delay: 1 }}
      />

      {/* Diagonal light streaks */}
      <motion.div
        className="absolute inset-0 opacity-20"
        style={{
          background: 'linear-gradient(135deg, transparent 0%, transparent 45%, rgba(138,43,226,0.1) 50%, transparent 55%, transparent 100%)'
        }}
        animate={{ x: ['-100%', '100%'] }}
        transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
      />

      <FloatingParticles />

      <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
        {/* Icon */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={isInView ? { opacity: 1, scale: 1 } : {}}
          transition={{ duration: 0.6 }}
          className="w-20 h-20 mx-auto rounded-2xl bg-gradient-to-br from-[#8A2BE2] to-[#FF2FBF] flex items-center justify-center mb-8 shadow-[0_0_40px_rgba(138,43,226,0.3)]"
        >
          <LinkIcon className="w-10 h-10 text-white" />
        </motion.div>

        {/* Main headline */}
        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-4xl sm:text-5xl md:text-6xl font-bold text-[#0D0D0D] mb-6 leading-tight"
        >
          Connect Your Trade Operations to a{' '}
          <motion.span
            className="inline-block bg-gradient-to-r from-[#8A2BE2] via-[#FF66D8] to-[#FF2FBF] bg-clip-text text-transparent"
            animate={{ backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'] }}
            transition={{ duration: 5, repeat: Infinity }}
            style={{ backgroundSize: '200% 200%' }}
          >
            Gold-Backed Bridge
          </motion.span>
        </motion.h2>

        {/* Subtitle */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="text-xl text-[#4A4A4A] mb-10 max-w-2xl mx-auto"
        >
          Use FinaBridge to bring stability, trust, and speed into your import and export transactions.
        </motion.p>

        {/* CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="flex flex-col sm:flex-row gap-4 justify-center"
        >
          <Link to={createPageUrl("Home")} onClick={() => window.scrollTo(0, 0)}>
            <motion.button
              className="group relative w-full sm:w-auto px-10 py-4 rounded-full overflow-hidden"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.98 }}
            >
              {/* Button glow */}
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] rounded-full"
                animate={{ 
                  boxShadow: ['0 0 20px rgba(138,43,226,0.3)', '0 0 40px rgba(138,43,226,0.5)', '0 0 20px rgba(138,43,226,0.3)']
                }}
                transition={{ duration: 2, repeat: Infinity }}
              />
              {/* Shimmer effect */}
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent"
                animate={{ x: ['-100%', '200%'] }}
                transition={{ duration: 2, repeat: Infinity, repeatDelay: 3 }}
              />
              <span className="relative z-10 flex items-center gap-2 text-white font-medium justify-center">
                Open Corporate Account
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </span>
            </motion.button>
          </Link>

          <Link to={createPageUrl("Home") + "#contact"} onClick={() => window.scrollTo(0, 0)}>
            <motion.button
              className="w-full sm:w-auto px-10 py-4 rounded-full border border-[#8A2BE2]/40 text-[#8A2BE2] hover:bg-[#8A2BE2]/10 transition-all flex items-center gap-2 justify-center"
              whileHover={{ scale: 1.05, borderColor: 'rgba(212,175,55,0.8)' }}
              whileTap={{ scale: 0.98 }}
            >
              <Phone className="w-4 h-4" />
              Schedule a Trade Call
            </motion.button>
          </Link>
        </motion.div>

        {/* Trust indicators */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ delay: 0.8 }}
          className="flex flex-wrap justify-center gap-6 mt-12 text-sm text-[#4A4A4A]"
        >
          <span className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-[#8A2BE2]" />
            Swiss-Regulated
          </span>
          <span className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-[#8A2BE2]" />
            Physical Gold Only
          </span>
          <span className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-[#8A2BE2]" />
            Enterprise-Grade Security
          </span>
        </motion.div>
      </div>
    </section>
  );
}