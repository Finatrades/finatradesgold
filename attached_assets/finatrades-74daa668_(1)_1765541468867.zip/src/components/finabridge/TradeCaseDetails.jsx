import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, Ship, Package, FileText, Upload, Download, Eye, CheckCircle, 
  XCircle, Clock, AlertTriangle, Lock, Unlock, Shield, User, Calendar,
  RefreshCw, ChevronDown, ChevronUp
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

const documentTypes = [
  { id: 'invoice', label: 'Commercial Invoice', required: true },
  { id: 'bl', label: 'Bill of Lading', required: true },
  { id: 'packing', label: 'Packing List', required: true },
  { id: 'coo', label: 'Certificate of Origin', required: true },
  { id: 'insurance', label: 'Insurance Certificate', required: false },
  { id: 'inspection', label: 'Inspection Report', required: false },
  { id: 'other', label: 'Other Contract Documents', required: false }
];

const statusConfig = {
  draft: { label: 'Draft', color: 'bg-gray-500/20 text-gray-400', icon: FileText },
  documents_pending: { label: 'Documents Pending', color: 'bg-yellow-500/20 text-yellow-400', icon: Clock },
  under_review: { label: 'Under Review', color: 'bg-blue-500/20 text-blue-400', icon: Eye },
  approved: { label: 'Approved', color: 'bg-green-500/20 text-green-400', icon: CheckCircle },
  settled: { label: 'Settled', color: 'bg-purple-500/20 text-purple-400', icon: Unlock },
  closed: { label: 'Closed', color: 'bg-white/20 text-white/60', icon: Lock }
};

export default function TradeCaseDetails({ tradeCase, onBack, goldPrice, userRole = 'importer' }) {
  const [expandedAudit, setExpandedAudit] = useState(false);
  const [documents, setDocuments] = useState(tradeCase.documents || {});

  const handleDocUpload = (docType) => {
    // Simulate upload
    setDocuments({
      ...documents,
      [docType]: { status: 'uploaded', version: 'v1', uploadedAt: new Date().toISOString() }
    });
  };

  const StatusIcon = statusConfig[tradeCase.status]?.icon || FileText;

  const approvalSteps = [
    { step: 'Exporter Uploads Documents', actor: tradeCase.seller, status: 'completed', date: '2024-12-01 10:30' },
    { step: 'Importer Verifies', actor: tradeCase.buyer, status: 'completed', date: '2024-12-02 14:15' },
    { step: 'Finatrades Compliance Reviews', actor: 'Compliance Team', status: tradeCase.status === 'approved' ? 'completed' : 'pending', date: tradeCase.status === 'approved' ? '2024-12-03 09:00' : null },
    { step: 'Final Approval', actor: 'System', status: tradeCase.status === 'approved' ? 'completed' : 'pending', date: tradeCase.status === 'approved' ? '2024-12-03 09:01' : null },
    { step: 'Funds Released', actor: 'System', status: tradeCase.status === 'settled' ? 'completed' : 'pending', date: tradeCase.status === 'settled' ? '2024-12-04 11:00' : null }
  ];

  const auditLog = [
    { actor: 'System', role: 'System', action: 'Created Case', timestamp: '2024-12-01 09:00', details: `Trade Case ${tradeCase.id} created` },
    { actor: tradeCase.role === 'importer' ? tradeCase.buyer : tradeCase.seller, role: tradeCase.role.charAt(0).toUpperCase() + tradeCase.role.slice(1), action: 'Locked Funds', timestamp: '2024-12-01 09:01', details: `${tradeCase.lockedGold}g locked` },
    { actor: tradeCase.seller, role: 'Exporter', action: 'Uploaded Document', timestamp: '2024-12-01 10:30', details: 'Commercial Invoice v1' },
    { actor: tradeCase.seller, role: 'Exporter', action: 'Uploaded Document', timestamp: '2024-12-01 10:35', details: 'Bill of Lading v1' },
    { actor: tradeCase.buyer, role: 'Importer', action: 'Approved', timestamp: '2024-12-02 14:15', details: 'Documents verified' },
    { actor: 'Compliance', role: 'Compliance', action: 'Approved', timestamp: '2024-12-03 09:00', details: 'AML check passed' }
  ];

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2 rounded-lg bg-[#F4F6FC] text-[#4A4A4A] hover:text-[#0D0D0D] hover:bg-white border border-[#8A2BE2]/20">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-xl sm:text-2xl font-bold text-amber-600 font-mono">{tradeCase.id}</h1>
              <span className={`px-3 py-1 rounded-full text-xs font-medium ${statusConfig[tradeCase.status]?.color}`}>
                {statusConfig[tradeCase.status]?.label}
              </span>
            </div>
            <div className="flex items-center gap-4 mt-1 text-sm">
              <span className={`flex items-center gap-1 ${tradeCase.role === 'importer' ? 'text-blue-600' : 'text-green-600'}`}>
                {tradeCase.role === 'importer' ? <Package className="w-4 h-4" /> : <Ship className="w-4 h-4" />}
                {tradeCase.role.charAt(0).toUpperCase() + tradeCase.role.slice(1)}
              </span>
              <span className="text-[#4A4A4A]">{tradeCase.buyer} → {tradeCase.seller}</span>
            </div>
          </div>
        </div>
        <div className="text-right">
          <p className="text-[#4A4A4A] text-sm">Locked Gold</p>
          <p className="text-2xl font-bold text-amber-600">{tradeCase.lockedGold.toFixed(3)} g</p>
          <p className="text-[#4A4A4A] text-sm">≈ ${(tradeCase.lockedGold * goldPrice).toLocaleString()}</p>
        </div>
      </div>

      {/* Compliance Badges */}
      <div className="flex flex-wrap items-center gap-2 sm:gap-3">
        <span className="px-3 py-1.5 rounded-lg bg-green-50 border border-green-200 text-green-700 text-xs flex items-center gap-1.5">
          <Shield className="w-3.5 h-3.5" /> AML Check Passed
        </span>
        <span className="px-3 py-1.5 rounded-lg bg-green-50 border border-green-200 text-green-700 text-xs flex items-center gap-1.5">
          <CheckCircle className="w-3.5 h-3.5" /> Sanctions Cleared
        </span>
        <span className="px-3 py-1.5 rounded-lg bg-[#F4F6FC] border border-[#8A2BE2]/20 text-[#4A4A4A] text-xs flex items-center gap-1.5">
          <Eye className="w-3.5 h-3.5" /> All actions logged for TBML monitoring
        </span>
      </div>

      <div className="grid lg:grid-cols-3 gap-4 sm:gap-6">
        {/* Left Column - Trade Summary */}
        <div className="bg-white border border-[#8A2BE2]/20 rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-sm">
          <h3 className="text-[#0D0D0D] font-semibold mb-4 flex items-center gap-2">
            <FileText className="w-5 h-5 text-amber-600" />
            Trade Summary
          </h3>
          <div className="space-y-4">
            {[
              { label: 'Contract Number', value: tradeCase.contractNumber || 'PO-2024-001' },
              { label: 'Commodity', value: tradeCase.commodity },
              { label: 'Value (USD)', value: `$${tradeCase.valueUSD.toLocaleString()}` },
              { label: 'Value (Gold)', value: `${tradeCase.valueGold.toFixed(3)} g` },
              { label: 'Payment Terms', value: tradeCase.paymentTerms || 'LC at Sight' },
              { label: 'Delivery Terms', value: tradeCase.deliveryTerms || 'FOB' },
              { label: 'Shipment Method', value: tradeCase.shipmentMethod || 'Sea Freight' },
              { label: 'Expected Delivery', value: tradeCase.deliveryTimeline || 'Dec 15-20, 2024' }
            ].map((item, i) => (
              <div key={i} className="flex justify-between items-center py-2 border-b border-[#8A2BE2]/10 last:border-0">
                <span className="text-[#4A4A4A] text-sm">{item.label}</span>
                <span className="text-[#0D0D0D] text-sm font-medium">{item.value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Middle Column - Documents */}
        <div className="bg-white border border-[#8A2BE2]/20 rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-sm">
          <h3 className="text-[#0D0D0D] font-semibold mb-4 flex items-center gap-2">
            <Upload className="w-5 h-5 text-amber-600" />
            Documents
          </h3>
          <div className="space-y-3">
            {documentTypes.map(doc => {
              const docStatus = documents[doc.id];
              return (
                <div key={doc.id} className="flex items-center justify-between p-3 bg-[#F4F6FC] rounded-xl border border-[#8A2BE2]/10">
                  <div className="flex items-center gap-3">
                    <FileText className={`w-4 h-4 ${docStatus ? 'text-green-600' : 'text-[#4A4A4A]'}`} />
                    <div>
                      <p className="text-[#0D0D0D] text-sm">{doc.label}</p>
                      {docStatus && (
                        <p className="text-[#4A4A4A] text-xs">{docStatus.version} • Uploaded</p>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {docStatus ? (
                      <>
                        <span className="px-2 py-0.5 rounded text-xs bg-green-50 text-green-700 border border-green-200">Uploaded</span>
                        <button className="p-1.5 rounded-lg hover:bg-white border border-[#8A2BE2]/10 text-[#4A4A4A]">
                          <Eye className="w-4 h-4" />
                        </button>
                        <button className="p-1.5 rounded-lg hover:bg-white border border-[#8A2BE2]/10 text-[#4A4A4A]">
                          <Download className="w-4 h-4" />
                        </button>
                      </>
                    ) : (
                      <>
                        <span className={`px-2 py-0.5 rounded text-xs ${doc.required ? 'bg-red-50 text-red-700 border border-red-200' : 'bg-white text-[#4A4A4A] border border-[#8A2BE2]/10'}`}>
                          {doc.required ? 'Missing' : 'Optional'}
                        </span>
                        <button 
                          onClick={() => handleDocUpload(doc.id)}
                          className="p-1.5 rounded-lg bg-amber-50 text-amber-600 hover:bg-amber-100 border border-amber-200"
                        >
                          <Upload className="w-4 h-4" />
                        </button>
                      </>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column - Approvals & Settlement */}
        <div className="space-y-4 sm:space-y-6">
          {/* Approval Workflow */}
          <div className="bg-white border border-[#8A2BE2]/20 rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-sm">
            <h3 className="text-[#0D0D0D] font-semibold mb-4 flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-green-600" />
              Approval Workflow
            </h3>
            <div className="space-y-1">
              {approvalSteps.map((step, i) => (
                <div key={i} className="flex gap-3">
                  <div className="flex flex-col items-center">
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                      step.status === 'completed' ? 'bg-green-50 text-green-600 border border-green-200' :
                      step.status === 'pending' ? 'bg-[#F4F6FC] text-[#4A4A4A] border border-[#8A2BE2]/20' :
                      'bg-yellow-50 text-yellow-600 border border-yellow-200'
                    }`}>
                      {step.status === 'completed' ? <CheckCircle className="w-3.5 h-3.5" /> :
                       step.status === 'pending' ? <Clock className="w-3.5 h-3.5" /> :
                       <AlertTriangle className="w-3.5 h-3.5" />}
                    </div>
                    {i < approvalSteps.length - 1 && (
                      <div className={`w-0.5 h-8 ${step.status === 'completed' ? 'bg-green-200' : 'bg-[#8A2BE2]/10'}`} />
                    )}
                  </div>
                  <div className="pb-4">
                    <p className="text-[#0D0D0D] text-sm font-medium">{step.step}</p>
                    <p className="text-[#4A4A4A] text-xs">{step.actor}</p>
                    {step.date && <p className="text-[#4A4A4A] text-xs mt-0.5">{step.date}</p>}
                  </div>
                </div>
              ))}
            </div>

            {/* Role-based Actions */}
            {userRole === 'importer' && tradeCase.status === 'documents_pending' && (
              <div className="mt-4 flex gap-2">
                <Button className="flex-1 bg-green-50 text-green-700 hover:bg-green-100 border border-green-200" size="sm">
                  <CheckCircle className="w-4 h-4 mr-1" /> Approve Documents
                </Button>
                <Button variant="ghost" className="flex-1 border border-[#8A2BE2]/20 text-[#4A4A4A]" size="sm">
                  Request Changes
                </Button>
              </div>
            )}
          </div>

          {/* Settlement & Release */}
          <div className="bg-gradient-to-br from-amber-50 to-transparent border border-amber-200 rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-sm">
            <h3 className="text-[#0D0D0D] font-semibold mb-4 flex items-center gap-2">
              <Lock className="w-5 h-5 text-amber-600" />
              Settlement & Release
            </h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-[#4A4A4A] text-sm">Locked Gold</span>
                <span className="text-amber-600 font-bold">{tradeCase.lockedGold.toFixed(3)} g</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[#4A4A4A] text-sm">Status</span>
                <span className={`px-2 py-1 rounded text-xs font-medium ${
                  tradeCase.status === 'settled' ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-amber-50 text-amber-700 border border-amber-200'
                }`}>
                  {tradeCase.status === 'settled' ? 'Released' : 'Locked'}
                </span>
              </div>
            </div>

            {tradeCase.status === 'approved' && (
              <Button className="w-full mt-4 bg-gradient-to-r from-amber-500 to-amber-600 text-white font-bold hover:opacity-90">
                <Unlock className="w-4 h-4 mr-2" /> Release Gold to Exporter
              </Button>
            )}

            <p className="text-[#4A4A4A] text-xs mt-4 leading-relaxed">
              Upon release, ownership transfers from Importer → Exporter in FinaVault. 
              Exporter's FinaPay Wallet is updated accordingly.
            </p>
          </div>
        </div>
      </div>

      {/* Audit Log */}
      <div className="bg-white border border-[#8A2BE2]/20 rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-sm">
        <button 
          onClick={() => setExpandedAudit(!expandedAudit)}
          className="w-full flex items-center justify-between"
        >
          <h3 className="text-[#0D0D0D] font-semibold flex items-center gap-2">
            <RefreshCw className="w-5 h-5 text-[#8A2BE2]" />
            Audit Log
          </h3>
          {expandedAudit ? <ChevronUp className="w-5 h-5 text-[#4A4A4A]" /> : <ChevronDown className="w-5 h-5 text-[#4A4A4A]" />}
        </button>
        
        {expandedAudit && (
          <div className="mt-4 max-h-64 overflow-y-auto space-y-2">
            {auditLog.map((log, i) => (
              <div key={i} className="flex items-start gap-4 p-3 bg-[#F4F6FC] rounded-lg font-mono text-xs border border-[#8A2BE2]/10">
                <span className="text-[#4A4A4A] w-32 flex-shrink-0">{log.timestamp}</span>
                <span className="text-[#8A2BE2] w-24 flex-shrink-0">{log.role}</span>
                <span className="text-[#0D0D0D] w-28 flex-shrink-0">{log.action}</span>
                <span className="text-[#4A4A4A]">{log.details}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </motion.div>
  );
}