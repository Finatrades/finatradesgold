import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronRight, Search, Filter, Ship, Package } from 'lucide-react';
import { Input } from "@/components/ui/input";

const statusConfig = {
  draft: { label: 'Draft', color: 'bg-gray-500/20 text-gray-600' },
  documents_pending: { label: 'Documents Pending', color: 'bg-yellow-500/20 text-yellow-700' },
  under_review: { label: 'Under Review', color: 'bg-blue-500/20 text-blue-600' },
  approved: { label: 'Approved', color: 'bg-green-500/20 text-green-700' },
  settled: { label: 'Settled', color: 'bg-purple-500/20 text-purple-700' },
  closed: { label: 'Closed', color: 'bg-gray-100 text-gray-600' }
};

export default function TradeCasesTable({ cases, onViewDetails, filter, onFilterChange }) {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredCases = cases.filter(tc => {
    const matchesFilter = filter === 'all' || tc.role === filter;
    const matchesSearch = tc.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         tc.buyer.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         tc.seller.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         tc.commodity.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
      className="bg-white border border-[#8A2BE2]/20 rounded-xl sm:rounded-2xl overflow-hidden shadow-sm"
    >
      {/* Header */}
      <div className="p-3 sm:p-6 border-b border-[#8A2BE2]/10">
        <div className="flex flex-col gap-3">
          <h2 className="text-sm sm:text-lg font-bold text-[#0D0D0D]">Trade Cases</h2>
          <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3">
            <div className="relative flex-1 sm:flex-none">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#4A4A4A]" />
              <Input
                placeholder="Search cases..."
                className="pl-10 w-full sm:w-48 bg-[#F4F6FC] border-[#8A2BE2]/20 text-[#0D0D0D] rounded-lg sm:rounded-xl h-9 text-sm"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex items-center gap-1 p-1 bg-[#F4F6FC] rounded-lg sm:rounded-xl overflow-x-auto">
              {['all', 'importer', 'exporter'].map(f => (
                <button
                  key={f}
                  onClick={() => onFilterChange(f)}
                  className={`px-2 sm:px-3 py-1 sm:py-1.5 rounded-md sm:rounded-lg text-[10px] sm:text-xs font-medium transition-all capitalize whitespace-nowrap ${
                    filter === f 
                      ? 'bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white' 
                      : 'text-[#4A4A4A] hover:text-[#0D0D0D] hover:bg-white'
                  }`}
                >
                  {f === 'all' ? 'All' : f}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Table - Desktop */}
      {filteredCases.length === 0 ? (
        <div className="text-center py-10 sm:py-16">
          <Ship className="w-10 h-10 sm:w-12 sm:h-12 mx-auto text-amber-600/30 mb-3 sm:mb-4" />
          <p className="text-[#4A4A4A] mb-2 text-sm sm:text-base">No trade cases found</p>
          <p className="text-[#4A4A4A] text-xs sm:text-sm">Create your first trade case to get started</p>
        </div>
      ) : (
        <>
          {/* Desktop Table */}
          <div className="overflow-x-auto hidden sm:block">
            <table className="w-full">
              <thead className="bg-[#F4F6FC]">
                <tr className="text-left text-[#4A4A4A] text-xs uppercase tracking-wider">
                  <th className="px-6 py-4">Trade Case ID</th>
                  <th className="px-6 py-4">Role</th>
                  <th className="px-6 py-4">Buyer / Seller</th>
                  <th className="px-6 py-4">Commodity</th>
                  <th className="px-6 py-4">Value</th>
                  <th className="px-6 py-4">Locked Gold</th>
                  <th className="px-6 py-4">Status</th>
                  <th className="px-6 py-4">Last Updated</th>
                  <th className="px-6 py-4"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#8A2BE2]/10">
                {filteredCases.map(tc => (
                  <tr 
                    key={tc.id} 
                    className="text-[#4A4A4A] hover:bg-[#F4F6FC] transition-colors cursor-pointer group"
                    onClick={() => onViewDetails(tc)}
                  >
                    <td className="px-6 py-4 font-mono text-[#FF2FBF] font-semibold">{tc.id}</td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium ${
                        tc.role === 'importer' 
                          ? 'bg-blue-500/20 text-blue-600' 
                          : 'bg-green-500/20 text-green-700'
                      }`}>
                        {tc.role === 'importer' ? <Package className="w-3 h-3" /> : <Ship className="w-3 h-3" />}
                        {tc.role.charAt(0).toUpperCase() + tc.role.slice(1)}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div>
                        <p className="text-[#0D0D0D] text-sm">{tc.buyer}</p>
                        <p className="text-[#4A4A4A] text-xs">{tc.seller}</p>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-[#0D0D0D] text-sm">{tc.commodity}</td>
                    <td className="px-6 py-4">
                      <div>
                        <p className="text-[#0D0D0D] font-medium">${tc.valueUSD.toLocaleString()}</p>
                        <p className="text-amber-600 text-xs">{tc.valueGold.toFixed(2)} g</p>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-[#FF2FBF] font-medium">{tc.lockedGold.toFixed(3)} g</td>
                    <td className="px-6 py-4">
                      <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${statusConfig[tc.status]?.color || statusConfig.draft.color}`}>
                        {statusConfig[tc.status]?.label || tc.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-[#4A4A4A] text-sm">{tc.lastUpdated}</td>
                    <td className="px-6 py-4">
                      <button className="opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1 text-[#FF2FBF] text-sm font-medium">
                        View Details <ChevronRight className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Mobile Cards */}
          <div className="sm:hidden space-y-2 p-3">
            {filteredCases.map(tc => (
              <div 
                key={tc.id} 
                className="bg-[#F4F6FC] rounded-xl p-3 cursor-pointer active:bg-white border border-[#8A2BE2]/10"
                onClick={() => onViewDetails(tc)}
              >
                <div className="flex items-start justify-between mb-2">
                  <span className="text-[#FF2FBF] font-mono text-xs font-semibold">{tc.id}</span>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${statusConfig[tc.status]?.color || statusConfig.draft.color}`}>
                    {statusConfig[tc.status]?.label || tc.status}
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-2 text-xs mb-2">
                  <div>
                    <p className="text-[#4A4A4A]">Role</p>
                    <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-medium ${
                      tc.role === 'importer' ? 'bg-blue-500/20 text-blue-600' : 'bg-green-500/20 text-green-700'
                    }`}>
                      {tc.role === 'importer' ? <Package className="w-2.5 h-2.5" /> : <Ship className="w-2.5 h-2.5" />}
                      {tc.role.charAt(0).toUpperCase() + tc.role.slice(1)}
                    </span>
                  </div>
                  <div>
                    <p className="text-[#4A4A4A]">Value</p>
                    <p className="text-[#0D0D0D] font-medium">${(tc.valueUSD / 1000).toFixed(0)}K</p>
                  </div>
                  <div>
                    <p className="text-[#4A4A4A]">Locked</p>
                    <p className="text-amber-600 font-medium">{tc.lockedGold.toFixed(1)} g</p>
                  </div>
                </div>
                <p className="text-[#4A4A4A] text-[10px] truncate">{tc.buyer} ↔ {tc.seller}</p>
              </div>
            ))}
          </div>
        </>
      )}
    </motion.div>
  );
}