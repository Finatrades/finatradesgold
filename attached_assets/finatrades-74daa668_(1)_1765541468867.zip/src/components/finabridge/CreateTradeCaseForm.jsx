import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, Ship, Package, Building2, FileText, Lock, Info, 
  Loader2, CheckSquare, Globe, Calendar, DollarSign
} from 'lucide-react';
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";

const deliveryTerms = ['FOB', 'CIF', 'EXW', 'DDP', 'DAP', 'FCA', 'CFR'];
const shipmentMethods = ['Sea Freight', 'Air Freight', 'Land Transport', 'Rail', 'Multimodal'];
const countries = ['United Arab Emirates', 'Switzerland', 'United States', 'United Kingdom', 'Germany', 'France', 'China', 'India', 'Singapore', 'Hong Kong'];

export default function CreateTradeCaseForm({ walletBalance, goldPrice, onBack, onSubmit, onSaveDraft }) {
  const [isLoading, setIsLoading] = useState(false);
  const [authorized, setAuthorized] = useState(false);
  const [formData, setFormData] = useState({
    role: 'importer',
    buyerName: '',
    buyerCountry: '',
    sellerName: '',
    sellerCountry: '',
    contractNumber: '',
    commodity: '',
    valueType: 'usd',
    valueAmount: '',
    paymentTerms: '',
    deliveryTerms: '',
    shipmentMethod: '',
    deliveryStart: '',
    deliveryEnd: '',
    notes: '',
    goldToLock: ''
  });

  const goldToLockNum = parseFloat(formData.goldToLock) || 0;
  const valueInUSD = formData.valueType === 'usd' 
    ? parseFloat(formData.valueAmount) || 0 
    : (parseFloat(formData.valueAmount) || 0) * goldPrice;
  const valueInGold = formData.valueType === 'grams' 
    ? parseFloat(formData.valueAmount) || 0 
    : (parseFloat(formData.valueAmount) || 0) / goldPrice;
  const remainingBalance = walletBalance - goldToLockNum;

  const handleSubmit = async () => {
    if (!authorized || goldToLockNum <= 0 || goldToLockNum > walletBalance) return;
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    onSubmit(formData, goldToLockNum);
    setIsLoading(false);
  };

  const update = (field, value) => setFormData({ ...formData, [field]: value });

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      className="max-w-4xl mx-auto"
    >
      {/* Header */}
      <div className="flex items-center gap-4 mb-6">
        <button onClick={onBack} className="p-2 rounded-lg bg-[#F4F6FC] text-[#4A4A4A] hover:text-[#0D0D0D] hover:bg-white border border-[#8A2BE2]/20">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div>
          <h1 className="text-2xl font-bold text-[#0D0D0D]">Create Trade Case</h1>
          <p className="text-[#4A4A4A] text-sm">Set up a new gold-backed trade finance case</p>
        </div>
      </div>

      <div className="space-y-6">
        {/* Role Selection */}
        <div className="bg-white border border-[#8A2BE2]/20 rounded-2xl p-6 shadow-sm">
          <h3 className="text-[#0D0D0D] font-semibold mb-4 flex items-center gap-2">
            <Building2 className="w-5 h-5 text-[#8A2BE2]" />
            Your Role
          </h3>
          <div className="grid grid-cols-2 gap-4">
            {[
              { value: 'importer', label: 'Importer', desc: 'I am buying goods', icon: Package },
              { value: 'exporter', label: 'Exporter', desc: 'I am selling goods', icon: Ship }
            ].map(role => (
              <button
                key={role.value}
                onClick={() => update('role', role.value)}
                className={`p-4 rounded-xl border-2 flex items-center gap-4 transition-all ${
                  formData.role === role.value
                    ? 'border-[#8A2BE2] bg-[#8A2BE2]/10'
                    : 'border-[#8A2BE2]/20 hover:border-[#8A2BE2]/40'
                }`}
              >
                <role.icon className={`w-8 h-8 ${formData.role === role.value ? 'text-[#8A2BE2]' : 'text-[#4A4A4A]'}`} />
                <div className="text-left">
                  <p className={`font-medium ${formData.role === role.value ? 'text-[#8A2BE2]' : 'text-[#0D0D0D]'}`}>{role.label}</p>
                  <p className="text-[#4A4A4A] text-sm">{role.desc}</p>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Core Details */}
        <div className="bg-white border border-[#8A2BE2]/20 rounded-2xl p-6 shadow-sm">
          <h3 className="text-[#0D0D0D] font-semibold mb-4 flex items-center gap-2">
            <FileText className="w-5 h-5 text-[#8A2BE2]" />
            Core Details
          </h3>
          
          <div className="grid md:grid-cols-2 gap-6">
            {/* Buyer Info */}
            <div className="space-y-4">
              <h4 className="text-[#FF2FBF] text-sm font-medium">Buyer Information</h4>
              <Input
                placeholder="Buyer Company Name"
                className="bg-[#F4F6FC] border-[#8A2BE2]/20 text-[#0D0D0D]"
                value={formData.buyerName}
                onChange={(e) => update('buyerName', e.target.value)}
              />
              <Select value={formData.buyerCountry} onValueChange={(v) => update('buyerCountry', v)}>
                <SelectTrigger className="bg-[#F4F6FC] border-[#8A2BE2]/20 text-[#0D0D0D]">
                  <SelectValue placeholder="Select Country" />
                </SelectTrigger>
                <SelectContent className="bg-white border-[#8A2BE2]/20">
                  {countries.map(c => <SelectItem key={c} value={c} className="text-[#0D0D0D]">{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            {/* Seller Info */}
            <div className="space-y-4">
              <h4 className="text-[#FF2FBF] text-sm font-medium">Seller Information</h4>
              <Input
                placeholder="Seller Company Name"
                className="bg-[#F4F6FC] border-[#8A2BE2]/20 text-[#0D0D0D]"
                value={formData.sellerName}
                onChange={(e) => update('sellerName', e.target.value)}
              />
              <Select value={formData.sellerCountry} onValueChange={(v) => update('sellerCountry', v)}>
                <SelectTrigger className="bg-[#F4F6FC] border-[#8A2BE2]/20 text-[#0D0D0D]">
                  <SelectValue placeholder="Select Country" />
                </SelectTrigger>
                <SelectContent className="bg-white border-[#8A2BE2]/20">
                  {countries.map(c => <SelectItem key={c} value={c} className="text-[#0D0D0D]">{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4 mt-6">
            <div>
              <label className="text-[#4A4A4A] text-sm mb-2 block">Contract Number</label>
              <Input
                placeholder="e.g., PO-2024-001"
                className="bg-[#F4F6FC] border-[#8A2BE2]/20 text-[#0D0D0D]"
                value={formData.contractNumber}
                onChange={(e) => update('contractNumber', e.target.value)}
              />
            </div>
            <div>
              <label className="text-[#4A4A4A] text-sm mb-2 block">Commodity Description</label>
              <Input
                placeholder="e.g., Electronics, Raw Materials"
                className="bg-[#F4F6FC] border-[#8A2BE2]/20 text-[#0D0D0D]"
                value={formData.commodity}
                onChange={(e) => update('commodity', e.target.value)}
              />
            </div>
          </div>

          {/* Value */}
          <div className="mt-6">
            <label className="text-[#4A4A4A] text-sm mb-2 block">Trade Value</label>
            <div className="flex gap-2">
              <Input
                type="number"
                placeholder="0.00"
                className="bg-[#F4F6FC] border-[#8A2BE2]/20 text-[#0D0D0D] flex-1"
                value={formData.valueAmount}
                onChange={(e) => update('valueAmount', e.target.value)}
              />
              <Select value={formData.valueType} onValueChange={(v) => update('valueType', v)}>
                <SelectTrigger className="w-32 bg-[#F4F6FC] border-[#8A2BE2]/20 text-[#0D0D0D]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-white border-[#8A2BE2]/20">
                  <SelectItem value="usd" className="text-[#0D0D0D]">USD</SelectItem>
                  <SelectItem value="grams" className="text-[#0D0D0D]">Grams</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {formData.valueAmount && (
              <p className="text-[#FF2FBF] text-sm mt-2">
                ≈ ${valueInUSD.toLocaleString()} USD • {valueInGold.toFixed(3)} g gold
              </p>
            )}
          </div>

          {/* Terms */}
          <div className="grid md:grid-cols-3 gap-4 mt-6">
            <div>
              <label className="text-[#4A4A4A] text-sm mb-2 block">Payment Terms</label>
              <Input
                placeholder="e.g., Net 30, LC at Sight"
                className="bg-[#F4F6FC] border-[#8A2BE2]/20 text-[#0D0D0D]"
                value={formData.paymentTerms}
                onChange={(e) => update('paymentTerms', e.target.value)}
              />
            </div>
            <div>
              <label className="text-[#4A4A4A] text-sm mb-2 block">Delivery Terms</label>
              <Select value={formData.deliveryTerms} onValueChange={(v) => update('deliveryTerms', v)}>
                <SelectTrigger className="bg-[#F4F6FC] border-[#8A2BE2]/20 text-[#0D0D0D]">
                  <SelectValue placeholder="Select" />
                </SelectTrigger>
                <SelectContent className="bg-white border-[#8A2BE2]/20">
                  {deliveryTerms.map(t => <SelectItem key={t} value={t} className="text-[#0D0D0D]">{t}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-[#4A4A4A] text-sm mb-2 block">Shipment Method</label>
              <Select value={formData.shipmentMethod} onValueChange={(v) => update('shipmentMethod', v)}>
                <SelectTrigger className="bg-[#F4F6FC] border-[#8A2BE2]/20 text-[#0D0D0D]">
                  <SelectValue placeholder="Select" />
                </SelectTrigger>
                <SelectContent className="bg-white border-[#8A2BE2]/20">
                  {shipmentMethods.map(m => <SelectItem key={m} value={m} className="text-[#0D0D0D]">{m}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Delivery Timeline */}
          <div className="grid md:grid-cols-2 gap-4 mt-6">
            <div>
              <label className="text-[#4A4A4A] text-sm mb-2 block">Expected Delivery Start</label>
              <Input
                type="date"
                className="bg-[#F4F6FC] border-[#8A2BE2]/20 text-[#0D0D0D]"
                value={formData.deliveryStart}
                onChange={(e) => update('deliveryStart', e.target.value)}
              />
            </div>
            <div>
              <label className="text-[#4A4A4A] text-sm mb-2 block">Expected Delivery End</label>
              <Input
                type="date"
                className="bg-[#F4F6FC] border-[#8A2BE2]/20 text-[#0D0D0D]"
                value={formData.deliveryEnd}
                onChange={(e) => update('deliveryEnd', e.target.value)}
              />
            </div>
          </div>

          {/* Notes */}
          <div className="mt-6">
            <label className="text-[#4A4A4A] text-sm mb-2 block">Additional Notes</label>
            <Textarea
              placeholder="Any special terms, conditions, or notes..."
              className="bg-[#F4F6FC] border-[#8A2BE2]/20 text-[#0D0D0D] resize-none"
              value={formData.notes}
              onChange={(e) => update('notes', e.target.value)}
            />
          </div>
        </div>

        {/* Settlement & Locking */}
        <div className="bg-gradient-to-br from-amber-500/10 to-transparent border border-amber-500/30 rounded-2xl p-6 shadow-sm">
          <h3 className="text-[#0D0D0D] font-semibold mb-4 flex items-center gap-2">
            <Lock className="w-5 h-5 text-amber-600" />
            Settlement & Gold Locking
          </h3>

          <div className="p-4 bg-white rounded-xl mb-4 flex justify-between items-center border border-amber-500/20">
            <span className="text-[#4A4A4A]">Available Trade Wallet Balance</span>
            <span className="text-amber-600 font-bold">{walletBalance.toFixed(3)} g</span>
          </div>

          <div>
            <label className="text-[#4A4A4A] text-sm mb-2 block">Gold to Lock (g)</label>
            <Input
              type="number"
              placeholder="0.000"
              max={walletBalance}
              step="0.001"
              className="h-14 bg-white border-[#8A2BE2]/30 text-[#0D0D0D] text-xl font-bold rounded-xl focus:border-[#8A2BE2] text-center"
              value={formData.goldToLock}
              onChange={(e) => update('goldToLock', e.target.value)}
            />
          </div>

          {goldToLockNum > 0 && (
            <div className="mt-4 p-4 bg-[#F4F6FC] rounded-xl space-y-2 border border-[#8A2BE2]/10">
              <div className="flex justify-between text-sm">
                <span className="text-[#4A4A4A]">USD Value</span>
                <span className="text-[#0D0D0D]">${(goldToLockNum * goldPrice).toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-[#4A4A4A]">Post-lock Remaining Balance</span>
                <span className={remainingBalance < 0 ? 'text-red-600' : 'text-amber-600'}>
                  {remainingBalance.toFixed(3)} g
                </span>
              </div>
            </div>
          )}

          <div className="mt-4 p-4 bg-amber-50 rounded-xl border border-amber-500/20 flex gap-3">
            <Info className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
            <p className="text-amber-900 text-sm">
              Locked funds cannot be sent, sold, or staked. FinaVault marks them as 
              "Reserved – Trade Finance Settlement Balance" until trade completion.
            </p>
          </div>

          {/* Authorization Checkbox */}
          <div className="mt-6 flex items-start gap-3">
            <Checkbox
              id="authorize"
              checked={authorized}
              onCheckedChange={setAuthorized}
              className="border-[#8A2BE2] data-[state=checked]:bg-[#8A2BE2] data-[state=checked]:text-white mt-0.5"
            />
            <label htmlFor="authorize" className="text-[#0D0D0D] text-sm cursor-pointer">
              I authorize locking this amount as settlement/collateral for this trade case.
            </label>
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-4">
          <Button
            variant="outline"
            onClick={onSaveDraft}
            className="flex-1 border-[#8A2BE2]/30 text-[#FF2FBF] hover:bg-[#8A2BE2]/10"
          >
            Save as Draft
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={isLoading || !authorized || goldToLockNum <= 0 || goldToLockNum > walletBalance}
            className="flex-1 bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white font-bold hover:opacity-90"
          >
            {isLoading ? <Loader2 className="w-5 h-5 mr-2 animate-spin" /> : <Lock className="w-5 h-5 mr-2" />}
            Create Trade Case & Lock Gold
          </Button>
        </div>
      </div>
    </motion.div>
  );
}