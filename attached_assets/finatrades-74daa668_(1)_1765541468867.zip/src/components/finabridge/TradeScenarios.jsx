import React, { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { Globe, Ship, TrendingUp, ArrowRight } from 'lucide-react';

const scenarios = [
  {
    icon: Globe,
    title: "UAE Importer, African Exporter",
    description: "Importer locks $250,000 Worth of Gold. Exporter verifies. Shipment is launched earlier. Settlement is 70% via gold worth and 30% via bank transfer.",
    color: "from-blue-500/20 to-blue-600/5",
    route: "Dubai → Lagos"
  },
  {
    icon: Ship,
    title: "Exporter Avoids Buyer Default",
    description: "Exporter requires gold-backed assurance instead of full advance. Buyer locks gold worth via FinaBridge. Exporter ships with documented comfort.",
    color: "from-purple-500/20 to-purple-600/5",
    route: "Risk Mitigation"
  },
  {
    icon: TrendingUp,
    title: "Commodity Buyer and Seller Stabilize Price",
    description: "Both sides define contracts based on a Locked-In Worth of Gold to avoid disputes from market volatility.",
    color: "from-green-500/20 to-green-600/5",
    route: "Price Stability"
  }
];

function ScenarioCard({ scenario, index }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });
  const Icon = scenario.icon;

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 50 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, delay: index * 0.15 }}
      className="group relative"
    >
      <div className="relative h-full bg-gradient-to-br from-[#1A1A1A] to-[#0A0A0A] rounded-2xl border border-[#D4AF37]/10 overflow-hidden hover:border-[#D4AF37]/40 transition-all duration-500">
        {/* Gradient accent */}
        <div className={`absolute inset-0 bg-gradient-to-br ${scenario.color} opacity-50`} />
        
        {/* Animated background lines */}
        <svg className="absolute inset-0 w-full h-full opacity-10" viewBox="0 0 300 200">
          <motion.path
            d="M20,100 Q150,50 280,100"
            stroke="#D4AF37"
            strokeWidth="1"
            fill="none"
            initial={{ pathLength: 0 }}
            animate={isInView ? { pathLength: 1 } : {}}
            transition={{ duration: 2, delay: index * 0.3 }}
          />
          <motion.circle
            cx="20"
            cy="100"
            r="4"
            fill="#D4AF37"
            initial={{ opacity: 0 }}
            animate={isInView ? { opacity: 1 } : {}}
            transition={{ delay: 0.5 + index * 0.3 }}
          />
          <motion.circle
            cx="280"
            cy="100"
            r="4"
            fill="#D4AF37"
            initial={{ opacity: 0 }}
            animate={isInView ? { opacity: 1 } : {}}
            transition={{ delay: 2 + index * 0.3 }}
          />
        </svg>

        <div className="relative z-10 p-8">
          {/* Route tag */}
          <div className="flex items-center justify-between mb-6">
            <motion.div
              className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#D4AF37]/20 to-[#B8860B]/10 border border-[#D4AF37]/30 flex items-center justify-center"
              whileHover={{ rotate: 10, scale: 1.1 }}
            >
              <Icon className="w-6 h-6 text-[#D4AF37]" />
            </motion.div>
            <span className="px-3 py-1 rounded-full bg-[#D4AF37]/10 border border-[#D4AF37]/20 text-xs text-[#D4AF37]">
              {scenario.route}
            </span>
          </div>

          <h4 className="text-xl text-[#0D0D0D] font-medium mb-3 group-hover:text-[#8A2BE2] transition-colors">
            {scenario.title}
          </h4>
          
          <p className="text-[#4A4A4A] text-sm leading-relaxed mb-6">
            {scenario.description}
          </p>

          {/* Animated arrow */}
          <motion.div
            className="flex items-center gap-2 text-[#D4AF37] text-sm"
            initial={{ x: 0 }}
            whileHover={{ x: 5 }}
          >
            <span>View Details</span>
            <ArrowRight className="w-4 h-4" />
          </motion.div>
        </div>

        {/* Bottom gold accent */}
        <motion.div
          className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-[#D4AF37] to-transparent"
          initial={{ scaleX: 0 }}
          whileHover={{ scaleX: 1 }}
          transition={{ duration: 0.4 }}
        />
      </div>
    </motion.div>
  );
}

export default function TradeScenarios() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="relative py-24 bg-gradient-to-b from-[#FAFBFF] via-[#F4F6FC] to-[#FAFBFF] overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom,_rgba(212,175,55,0.04)_0%,_transparent_50%)]" />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        {/* Header */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <p className="text-[#D4AF37] text-sm tracking-[0.2em] uppercase mb-4">Real-World Applications</p>
          <h2 className="text-4xl md:text-5xl font-bold text-[#0D0D0D] mb-4">
            Real Trade Scenarios Powered by <span className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent">FinaBridge</span>
          </h2>
          <motion.div
            className="w-24 h-0.5 bg-gradient-to-r from-[#D4AF37] to-[#B8860B] mx-auto"
            initial={{ width: 0 }}
            animate={isInView ? { width: 96 } : {}}
            transition={{ duration: 0.8, delay: 0.3 }}
          />
        </motion.div>

        {/* Scenario cards */}
        <div className="grid md:grid-cols-3 gap-8">
          {scenarios.map((scenario, index) => (
            <ScenarioCard key={index} scenario={scenario} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}