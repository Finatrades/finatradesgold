import React, { useRef, useState } from 'react';
import { motion, useInView, AnimatePresence } from 'framer-motion';
import { FileText, Award, Scale, Hash, MapPin, Link2, Info } from 'lucide-react';

const documents = [
  { icon: FileText, name: "Assay Certificate", description: "Independent verification of gold purity and composition." },
  { icon: Award, name: "Refinery Details", description: "LBMA-approved refinery identification and certification." },
  { icon: Scale, name: "Purity & Weight Sheet", description: "Exact measurements: weight in grams/oz, fineness level." },
  { icon: Hash, name: "Serial & Bar Numbers", description: "Unique identifiers for each gold bar in the allocation." },
  { icon: MapPin, name: "Vault Location Certificate", description: "Physical storage location with security details." },
  { icon: Link2, name: "Ownership & Chain-of-Custody", description: "Complete provenance and transfer history." }
];

function DocumentCard({ doc, index, isActive, onHover }) {
  const Icon = doc.icon;
  
  return (
    <motion.div
      className="relative cursor-pointer"
      initial={{ opacity: 0, y: 30, rotateY: -10 }}
      animate={{ 
        opacity: 1, 
        y: 0, 
        rotateY: 0,
        z: isActive ? 50 : 0,
        scale: isActive ? 1.05 : 1
      }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      onMouseEnter={() => onHover(index)}
      onMouseLeave={() => onHover(null)}
      style={{ transformStyle: 'preserve-3d' }}
    >
      <motion.div
        className={`relative p-6 rounded-2xl transition-all duration-500 ${
          isActive 
            ? 'bg-white border-2 border-[#8A2BE2]/60 shadow-[0_0_40px_rgba(138,43,226,0.2)]'
            : 'bg-white border border-[#8A2BE2]/10 hover:border-[#8A2BE2]/30'
        }`}
      >
        {/* Glow effect */}
        {isActive && (
          <motion.div
            className="absolute inset-0 bg-gradient-to-br from-[#8A2BE2]/10 to-[#FF2FBF]/5 rounded-2xl"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          />
        )}

        {/* Shimmer on hover */}
        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-transparent via-[#8A2BE2]/10 to-transparent rounded-2xl overflow-hidden"
          initial={{ x: '-100%' }}
          animate={isActive ? { x: '100%' } : { x: '-100%' }}
          transition={{ duration: 0.8 }}
        />

        <div className="relative z-10">
          <div className="flex items-start gap-4">
            <motion.div
              className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                isActive 
                  ? 'bg-gradient-to-br from-[#8A2BE2] to-[#FF2FBF]' 
                  : 'bg-gradient-to-br from-[#8A2BE2]/20 to-[#FF2FBF]/10'
              }`}
              animate={isActive ? { rotate: [0, 5, -5, 0] } : {}}
              transition={{ duration: 0.5 }}
            >
              <Icon className={`w-5 h-5 ${isActive ? 'text-white' : 'text-[#8A2BE2]'}`} />
            </motion.div>
            <div className="flex-1">
              <h4 className={`font-medium mb-1 ${isActive ? 'text-[#8A2BE2]' : 'text-[#0D0D0D]'}`}>
                {doc.name}
              </h4>
              <AnimatePresence>
                {isActive && (
                  <motion.p
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="text-[#4A4A4A] text-sm"
                  >
                    {doc.description}
                  </motion.p>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>

        {/* Document corner fold */}
        <div className="absolute top-0 right-0 w-6 h-6 overflow-hidden">
          <div className={`absolute top-0 right-0 w-8 h-8 transform rotate-45 translate-x-4 -translate-y-4 ${
            isActive ? 'bg-[#8A2BE2]' : 'bg-[#8A2BE2]/20'
          }`} />
        </div>
      </motion.div>
    </motion.div>
  );
}

export default function GoldDocumentation() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [hoveredIndex, setHoveredIndex] = useState(null);

  return (
    <section ref={ref} className="relative py-24 bg-gradient-to-b from-[#FAFBFF] via-[#F4F6FC] to-[#FAFBFF] overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_rgba(138,43,226,0.05)_0%,_transparent_50%)]" />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        {/* Header */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <p className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent text-sm tracking-[0.2em] uppercase mb-4">Transparency & Verification</p>
          <h2 className="text-4xl md:text-5xl font-bold text-[#0D0D0D] mb-4">
            Verified Gold Documentation for <span className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent">Real Contracts</span>
          </h2>
          <motion.div
            className="w-24 h-0.5 bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] mx-auto mb-6"
            initial={{ width: 0 }}
            animate={isInView ? { width: 96 } : {}}
            transition={{ duration: 0.8, delay: 0.3 }}
          />
          <p className="text-[#4A4A4A] max-w-2xl mx-auto">
            Every allocation comes with complete documentation you can use in contracts, share with partners, and present to banks or auditors.
          </p>
        </motion.div>

        {/* Document cards grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {documents.map((doc, index) => (
            <DocumentCard
              key={index}
              doc={doc}
              index={index}
              isActive={hoveredIndex === index}
              onHover={setHoveredIndex}
            />
          ))}
        </div>

        {/* Bottom info banner */}
        <motion.div
          className="relative p-6 rounded-2xl bg-white border border-[#8A2BE2]/20 overflow-hidden shadow-[0_4px_20px_rgba(138,43,226,0.08)]"
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.8 }}
        >
          <div className="absolute inset-0 bg-gradient-to-r from-[#8A2BE2]/5 to-[#FF2FBF]/5" />
          <div className="relative z-10 flex items-center gap-4 flex-wrap justify-center text-center">
            <Info className="w-5 h-5 text-[#8A2BE2]" />
            <p className="text-[#4A4A4A]">
              All documentation is <span className="text-[#8A2BE2] font-medium">downloadable</span> and suitable for sharing with 
              <span className="text-[#0D0D0D] font-medium"> trade partners, banks, insurers, and auditors</span>.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}