import React, { useRef, useState, useEffect } from 'react';
import { motion, useInView } from 'framer-motion';
import { Vault, FileText, FileCheck, Ship, PackageCheck, ArrowLeftRight } from 'lucide-react';

const steps = [
  {
    number: "01",
    icon: Vault,
    title: "Buyer Locks Worth of Gold",
    description: "The importer allocates a defined Worth of Gold inside FinaVault."
  },
  {
    number: "02",
    icon: FileCheck,
    title: "Contract Terms Become Stable",
    description: "Both sides use the Worth of Gold as a reference to finalize trade terms."
  },
  {
    number: "03",
    icon: FileText,
    title: "Exporter Account Credited",
    description: "The Exporter account is credited but the related transaction amount remains locked until agreement terms are respected."
  },
  {
    number: "04",
    icon: Ship,
    title: "Shipment Initiation",
    description: "The exporter ships goods with greater confidence and reduced uncertainty."
  },
  {
    number: "05",
    icon: PackageCheck,
    title: "Delivery & Confirmation",
    description: "The importer confirms delivery and acceptance of goods."
  },
  {
    number: "06",
    icon: ArrowLeftRight,
    title: "Settlement Executed",
    description: "Settlement is completed using gold worth, hybrid structures, or traditional bank transfers."
  }
];

function StepNode({ step, index, isActive, isPassed }) {
  const Icon = step.icon;
  
  return (
    <motion.div
      className={`relative flex items-start gap-6 ${index % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'}`}
      initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.6, delay: index * 0.15 }}
    >
      {/* Icon circle */}
      <motion.div
        className={`relative z-10 flex-shrink-0 w-16 h-16 rounded-2xl border-2 flex items-center justify-center transition-all duration-500 ${
          isActive 
            ? 'bg-gradient-to-br from-[#8A2BE2] to-[#FF2FBF] border-[#8A2BE2] shadow-[0_0_30px_rgba(138,43,226,0.5)]'
            : isPassed
              ? 'bg-[#8A2BE2]/20 border-[#8A2BE2]/50'
              : 'bg-white border-[#8A2BE2]/20'
        }`}
        animate={isActive ? { scale: [1, 1.1, 1] } : {}}
        transition={{ duration: 1.5, repeat: isActive ? Infinity : 0 }}
      >
        <Icon className={`w-7 h-7 ${isActive ? 'text-white' : isPassed ? 'text-[#8A2BE2]' : 'text-[#4A4A4A]'}`} />
        
        {/* Number badge */}
        <div className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-white border border-[#8A2BE2]/30 flex items-center justify-center shadow-sm">
          <span className={`text-xs font-medium ${isPassed || isActive ? 'text-[#8A2BE2]' : 'text-[#4A4A4A]'}`}>
            {step.number}
          </span>
        </div>
      </motion.div>

      {/* Content card */}
      <motion.div
        className={`flex-1 max-w-md p-6 rounded-2xl transition-all duration-500 ${
          isActive
            ? 'bg-white border border-[#8A2BE2]/40 shadow-[0_0_40px_rgba(138,43,226,0.15)]'
            : 'bg-white/50 border border-[#8A2BE2]/10'
        }`}
        whileHover={{ borderColor: 'rgba(138,43,226,0.4)' }}
      >
        <h4 className={`text-lg font-medium mb-2 ${isActive ? 'text-[#8A2BE2]' : 'text-[#0D0D0D]'}`}>
          {step.title}
        </h4>
        <p className="text-[#4A4A4A] text-sm leading-relaxed">{step.description}</p>
      </motion.div>
    </motion.div>
  );
}

export default function FinaBridgeTradeFlow() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [activeStep, setActiveStep] = useState(0);

  // Auto-advance through steps
  useEffect(() => {
    if (!isInView) return;
    const interval = setInterval(() => {
      setActiveStep(prev => (prev + 1) % steps.length);
    }, 3000);
    return () => clearInterval(interval);
  }, [isInView]);

  return (
    <section ref={ref} className="relative py-24 bg-gradient-to-b from-[#FAFBFF] via-[#F4F6FC] to-[#FAFBFF] overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(138,43,226,0.05)_0%,_transparent_60%)]" />

      <div className="relative z-10 max-w-5xl mx-auto px-6">
        {/* Header */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <p className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent text-sm tracking-[0.2em] uppercase mb-4">Step-by-Step Process</p>
          <h2 className="text-4xl md:text-5xl font-bold text-[#0D0D0D] mb-4">
            How FinaBridge Works for <span className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent">Import & Export</span>
          </h2>
          <motion.div
            className="w-24 h-0.5 bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] mx-auto"
            initial={{ width: 0 }}
            animate={isInView ? { width: 96 } : {}}
            transition={{ duration: 0.8, delay: 0.3 }}
          />
        </motion.div>

        {/* Timeline */}
        <div className="relative">
          {/* Vertical snake line - hidden on mobile */}
          <div className="hidden lg:block absolute left-1/2 top-0 bottom-0 w-px">
            <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#8A2BE2]/20 to-transparent" />
            <motion.div
              className="absolute top-0 left-0 w-full bg-gradient-to-b from-[#8A2BE2] to-[#FF2FBF]"
              initial={{ height: '0%' }}
              animate={isInView ? { height: `${((activeStep + 1) / steps.length) * 100}%` } : {}}
              transition={{ duration: 0.5 }}
            />
          </div>

          {/* Mobile vertical line */}
          <div className="lg:hidden absolute left-8 top-0 bottom-0 w-px">
            <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#8A2BE2]/20 to-transparent" />
            <motion.div
              className="absolute top-0 left-0 w-full bg-gradient-to-b from-[#8A2BE2] to-[#FF2FBF]"
              initial={{ height: '0%' }}
              animate={isInView ? { height: `${((activeStep + 1) / steps.length) * 100}%` } : {}}
              transition={{ duration: 0.5 }}
            />
          </div>

          {/* Steps */}
          <div className="space-y-12 lg:space-y-16">
            {steps.map((step, index) => (
              <div 
                key={index}
                className={`lg:flex lg:justify-${index % 2 === 0 ? 'start' : 'end'}`}
              >
                <div className={`lg:w-1/2 ${index % 2 === 0 ? 'lg:pr-12' : 'lg:pl-12'}`}>
                  <StepNode
                    step={step}
                    index={index}
                    isActive={activeStep === index}
                    isPassed={activeStep > index}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Progress indicators */}
        <motion.div
          className="flex justify-center gap-2 mt-12"
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ delay: 1 }}
        >
          {steps.map((_, index) => (
            <button
              key={index}
              onClick={() => setActiveStep(index)}
              className={`w-2 h-2 rounded-full transition-all duration-300 ${
                index === activeStep 
                  ? 'bg-[#8A2BE2] w-6' 
                  : index < activeStep 
                    ? 'bg-[#8A2BE2]/50' 
                    : 'bg-[#8A2BE2]/20'
              }`}
            />
          ))}
        </motion.div>
      </div>
    </section>
  );
}