import React, { useRef } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion, useScroll, useTransform, useInView } from 'framer-motion';
import { Shield, Globe, FileText, ArrowRight, Phone, Link as LinkIcon } from 'lucide-react';
import { useLanguage } from '@/components/LanguageContext';

// Floating particles with purple/pink colors
function FloatingParticles() {
  const particles = [...Array(50)].map((_, i) => ({
    id: i,
    x: Math.random() * 100,
    y: Math.random() * 100,
    size: 1 + Math.random() * 3,
    duration: 4 + Math.random() * 6,
    delay: Math.random() * 5,
    color: Math.random() > 0.5 ? '#8A2BE2' : '#FF2FBF'
  }));

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {particles.map((p) => (
        <motion.div
          key={p.id}
          className="absolute rounded-full"
          style={{
            left: `${p.x}%`,
            top: `${p.y}%`,
            width: p.size,
            height: p.size,
            backgroundColor: p.color,
            boxShadow: `0 0 ${p.size * 2}px ${p.color}`
          }}
          animate={{
            y: [0, -40, 0],
            opacity: [0, 0.7, 0],
            scale: [0.5, 1, 0.5]
          }}
          transition={{
            duration: p.duration,
            delay: p.delay,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      ))}
    </div>
  );
}

// Bridge Visual Component
function BridgeVisual() {
  return (
    <div className="relative w-full max-w-md mx-auto">
      {/* Glow behind */}
      <motion.div
        className="absolute inset-0 bg-gradient-to-br from-[#8A2BE2]/30 to-[#FF2FBF]/20 rounded-full blur-[80px]"
        animate={{ scale: [1, 1.1, 1], opacity: [0.4, 0.6, 0.4] }}
        transition={{ duration: 4, repeat: Infinity }}
      />
      
      {/* Main card */}
      <div className="relative bg-white backdrop-blur-xl rounded-3xl border border-[#8A2BE2]/30 p-8 overflow-hidden shadow-[0_8px_32px_rgba(138,43,226,0.15)]">
        {/* World map trade routes background */}
        <svg className="absolute inset-0 w-full h-full opacity-20" viewBox="0 0 400 300">
          <defs>
            <linearGradient id="routeGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#8A2BE2" stopOpacity="0" />
              <stop offset="50%" stopColor="#FF2FBF" stopOpacity="1" />
              <stop offset="100%" stopColor="#8A2BE2" stopOpacity="0" />
            </linearGradient>
          </defs>
          {/* Animated trade routes */}
          <motion.path
            d="M50,150 Q150,80 200,150 T350,150"
            stroke="url(#routeGrad)"
            strokeWidth="2"
            fill="none"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 3, repeat: Infinity, repeatType: "loop" }}
          />
          <motion.path
            d="M30,200 Q120,120 200,180 T380,120"
            stroke="url(#routeGrad)"
            strokeWidth="1.5"
            fill="none"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 4, delay: 1, repeat: Infinity, repeatType: "loop" }}
          />
        </svg>

        {/* Bridge icon stack */}
        <div className="relative z-10 flex flex-col items-center gap-4 py-8">
          <motion.div
            className="w-24 h-24 rounded-2xl bg-gradient-to-br from-[#8A2BE2] to-[#FF2FBF] flex items-center justify-center shadow-[0_0_40px_rgba(138,43,226,0.4)]"
            animate={{ y: [0, -10, 0] }}
            transition={{ duration: 3, repeat: Infinity }}
          >
            <LinkIcon className="w-12 h-12 text-white" />
          </motion.div>
          
          <div className="flex gap-6 mt-4">
            {['Import', 'Bridge', 'Export'].map((label, i) => (
              <motion.div
                key={label}
                className="px-4 py-2 rounded-xl bg-[#8A2BE2]/10 border border-[#8A2BE2]/30 text-[#8A2BE2] text-sm font-medium"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 + i * 0.1 }}
                whileHover={{ scale: 1.05, backgroundColor: 'rgba(138,43,226,0.2)' }}
              >
                {label}
              </motion.div>
            ))}
          </div>
        </div>

        {/* Border outline */}
        <div className="absolute inset-4 border-2 border-dashed border-[#8A2BE2]/20 rounded-2xl pointer-events-none" />
        
        {/* Light beams */}
        <motion.div
          className="absolute bottom-0 left-1/2 -translate-x-1/2 w-40 h-32 bg-gradient-to-t from-[#8A2BE2]/20 to-transparent"
          animate={{ opacity: [0.3, 0.6, 0.3] }}
          transition={{ duration: 3, repeat: Infinity }}
        />
      </div>
    </div>
  );
}

export default function FinaBridgeHero() {
  const ref = useRef(null);
  const { t } = useLanguage();
  const isInView = useInView(ref, { once: true });
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"]
  });
  const y = useTransform(scrollYProgress, [0, 1], [0, 150]);
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);

  const badges = [
    { icon: Shield, text: t('finabridge.badges.1') },
    { icon: Globe, text: t('finabridge.badges.2') },
    { icon: FileText, text: t('finabridge.badges.3') }
  ];

  return (
    <section ref={ref} className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-[#FAFBFF] via-[#F4F6FC] to-[#FFFFFF]">
      {/* Background gradients */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_30%_30%,_rgba(138,43,226,0.08)_0%,_transparent_50%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_70%_70%,_rgba(255,47,191,0.06)_0%,_transparent_40%)]" />
      </div>

      <FloatingParticles />

      <motion.div 
        style={{ y, opacity }}
        className="relative z-10 max-w-7xl mx-auto px-6 py-24"
      >
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Content */}
          <div className="text-center lg:text-left">
            {/* Subtitle badge */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6 }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-[#8A2BE2]/30 bg-[#8A2BE2]/10 backdrop-blur-sm mb-6"
            >
              <LinkIcon className="w-4 h-4 text-[#8A2BE2]" />
              <span className="text-sm text-[#8A2BE2] font-semibold tracking-wide">{t('finabridge.hero.badge')}</span>
            </motion.div>

            {/* Main title */}
            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.1 }}
              className="text-4xl sm:text-5xl lg:text-6xl font-bold text-[#0D0D0D] mb-6 leading-tight"
            >
              {t('finabridge.hero.title')}{' '}
              <span className="bg-gradient-to-r from-[#8A2BE2] via-[#FF66D8] to-[#FF2FBF] bg-clip-text text-transparent">
                {t('finabridge.hero.titleHighlight')}
              </span>
            </motion.h1>

            {/* Subheadline */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-xl text-[#8A2BE2] mb-4"
            >
              {t('finabridge.hero.subtitle')}
            </motion.p>

            {/* Body text */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="text-[#4A4A4A] mb-8 max-w-xl mx-auto lg:mx-0"
            >
              {t('finabridge.hero.description')}
            </motion.p>

            {/* Badges */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="flex flex-wrap gap-3 justify-center lg:justify-start mb-8"
            >
              {badges.map((badge, i) => (
                <motion.div
                  key={i}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white border border-[#8A2BE2]/20 backdrop-blur-sm shadow-sm"
                  whileHover={{ borderColor: 'rgba(212,175,55,0.5)' }}
                >
                  <badge.icon className="w-3.5 h-3.5 text-[#8A2BE2]" />
                  <span className="text-xs text-[#4A4A4A]">{badge.text}</span>
                </motion.div>
              ))}
            </motion.div>

            {/* CTAs */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.5 }}
              className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start"
            >
              <Link to={createPageUrl("Home")} onClick={() => window.scrollTo(0, 0)}>
                <motion.button
                  className="group w-full sm:w-auto px-8 py-4 rounded-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white font-medium hover:shadow-[0_0_40px_rgba(138,43,226,0.4)] transition-all flex items-center gap-2 justify-center"
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.98 }}
                >
                  {t('finabridge.hero.cta1')}
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </motion.button>
              </Link>
              <Link to={createPageUrl("Home") + "#contact"} onClick={() => window.scrollTo(0, 0)}>
                <motion.button
                  className="w-full sm:w-auto px-8 py-4 rounded-full border border-[#8A2BE2]/40 text-[#8A2BE2] hover:bg-[#8A2BE2]/10 transition-all flex items-center gap-2 justify-center"
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Phone className="w-4 h-4" />
                  {t('finabridge.hero.cta2')}
                </motion.button>
              </Link>
            </motion.div>
          </div>

          {/* Right Visual */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="hidden lg:block"
          >
            <BridgeVisual />
          </motion.div>
        </div>
      </motion.div>

      {/* Scroll indicator */}
      <motion.div
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
        animate={{ y: [0, 8, 0], opacity: [0.3, 0.8, 0.3] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <div className="w-6 h-10 rounded-full border border-[#8A2BE2]/30 flex items-start justify-center p-2">
          <motion.div
            className="w-1 h-2 rounded-full bg-[#8A2BE2]"
            animate={{ y: [0, 12, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          />
        </div>
      </motion.div>
    </section>
  );
}