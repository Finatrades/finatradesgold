import React, { useRef, useState, useEffect } from 'react';
import { motion, useInView } from 'framer-motion';
import { TrendingUp, Eye } from 'lucide-react';

export default function GoldPriceTicker() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [price, setPrice] = useState(2650.00);
  const [displayPrice, setDisplayPrice] = useState(2650.00);

  // Simulate live price updates
  useEffect(() => {
    if (!isInView) return;
    
    const interval = setInterval(() => {
      const change = (Math.random() - 0.5) * 5;
      setPrice(prev => parseFloat((prev + change).toFixed(2)));
    }, 3000);
    
    return () => clearInterval(interval);
  }, [isInView]);

  // Animate price counter
  useEffect(() => {
    const duration = 1000;
    const steps = 30;
    const stepDuration = duration / steps;
    const increment = (price - displayPrice) / steps;
    
    let step = 0;
    const timer = setInterval(() => {
      step++;
      if (step >= steps) {
        setDisplayPrice(price);
        clearInterval(timer);
      } else {
        setDisplayPrice(prev => prev + increment);
      }
    }, stepDuration);
    
    return () => clearInterval(timer);
  }, [price]);

  const priceData = [
    { label: 'Per Gram', value: displayPrice / 31.1035, suffix: '/g' },
    { label: 'Per Ounce', value: displayPrice, suffix: '/oz' },
    { label: 'Per KG', value: displayPrice * 32.1507, suffix: '/kg' }
  ];

  return (
    <section ref={ref} className="relative py-20 overflow-hidden border-y border-[#D4AF37]/10">
      <div className="absolute inset-0 bg-gradient-to-r from-[#D4AF37]/5 via-transparent to-[#D4AF37]/5" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 1 }}
        >
          {/* Header */}
          <div className="flex flex-col md:flex-row items-center justify-between gap-6 mb-8">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#D4AF37] to-[#B8860B] flex items-center justify-center">
                <Eye className="w-6 h-6 text-black" />
              </div>
              <div>
                <h3 className="text-2xl font-light text-white">Your Gold. Fully Transparent.</h3>
                <p className="text-gray-400">Live market prices • Real-time updates</p>
              </div>
            </div>
            
            <motion.div
              className="flex items-center gap-2 px-4 py-2 rounded-full bg-green-500/10 border border-green-500/30"
              animate={{ opacity: [0.5, 1, 0.5] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <div className="w-2 h-2 rounded-full bg-green-500" />
              <span className="text-green-500 text-sm">Live</span>
            </motion.div>
          </div>
          
          {/* Price ticker */}
          <div className="relative overflow-hidden">
            <motion.div
              className="flex gap-8"
              animate={{ x: [0, -100, 0] }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            >
              {[...Array(3)].map((_, setIndex) => (
                <div key={setIndex} className="flex gap-8">
                  {priceData.map((item, i) => (
                    <div key={i} className="min-w-[200px] bg-gradient-to-br from-[#1A1A1A] to-[#0A0A0A] rounded-xl border border-[#D4AF37]/20 p-6">
                      <div className="text-gray-400 text-sm mb-2">{item.label}</div>
                      <div className="flex items-baseline gap-1">
                        <span className="text-[#D4AF37] text-sm">$</span>
                        <span className="text-2xl font-light text-white font-mono">
                          {item.value.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </span>
                        <span className="text-gray-500 text-sm">{item.suffix}</span>
                      </div>
                      <div className="flex items-center gap-1 mt-2 text-green-500 text-xs">
                        <TrendingUp className="w-3 h-3" />
                        <span>+0.42%</span>
                      </div>
                    </div>
                  ))}
                </div>
              ))}
            </motion.div>
          </div>
          
          {/* Mini chart */}
          <motion.div
            className="mt-8 h-20 flex items-end justify-center gap-1"
            initial={{ opacity: 0 }}
            animate={isInView ? { opacity: 1 } : {}}
            transition={{ delay: 0.5 }}
          >
            {[...Array(30)].map((_, i) => (
              <motion.div
                key={i}
                className="w-2 bg-gradient-to-t from-[#D4AF37] to-[#F7D878] rounded-t"
                initial={{ height: 10 }}
                animate={isInView ? { height: 20 + Math.random() * 60 } : {}}
                transition={{ delay: i * 0.03, duration: 0.5 }}
              />
            ))}
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}