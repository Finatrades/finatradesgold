import React, { useEffect, useState, useRef, useMemo } from 'react';
import { motion, useInView, AnimatePresence } from 'framer-motion';

// 8 Major trade hub nodes - positioned for visual balance on fixed globe
const tradeHubs = [
  { id: 'southafrica', name: 'South Africa', x: 50, y: 12, volume: '$1.2B', trades: 847, growth: '+12%' },
  { id: 'lagos', name: 'Lagos', x: 22, y: 28, volume: '$2.8B', trades: 1542, growth: '+18%' },
  { id: 'london', name: 'London', x: 78, y: 25, volume: '$8.4B', trades: 4231, growth: '+8%' },
  { id: 'singapore', name: 'Singapore', x: 18, y: 52, volume: '$6.2B', trades: 3156, growth: '+15%' },
  { id: 'dubai', name: 'Dubai', x: 82, y: 55, volume: '$5.7B', trades: 2890, growth: '+22%' },
  { id: 'hongkong', name: 'Hong Kong', x: 28, y: 78, volume: '$7.1B', trades: 3678, growth: '+11%' },
  { id: 'mumbai', name: 'Mumbai', x: 72, y: 75, volume: '$3.9B', trades: 2104, growth: '+19%' },
  { id: 'chad', name: 'Chad', x: 50, y: 88, volume: '$0.8B', trades: 412, growth: '+31%' },
];

// Mesh network - all nodes interconnected through center
const meshRoutes = [
  // Cross routes through center
  { id: 'lagos-dubai', from: 'lagos', to: 'dubai', type: 'ship', volume: '$1.4B' },
  { id: 'london-hongkong', from: 'london', to: 'hongkong', type: 'gold', volume: '$3.2B' },
  { id: 'singapore-mumbai', from: 'singapore', to: 'mumbai', type: 'ship', volume: '$2.1B' },
  // Diagonal routes
  { id: 'lagos-mumbai', from: 'lagos', to: 'mumbai', type: 'gold', volume: '$0.9B' },
  { id: 'london-singapore', from: 'london', to: 'singapore', type: 'ship', volume: '$2.8B' },
  { id: 'hongkong-dubai', from: 'hongkong', to: 'dubai', type: 'gold', volume: '$1.7B' },
  // Edge routes
  { id: 'lagos-singapore', from: 'lagos', to: 'singapore', type: 'ship', volume: '$1.1B' },
  { id: 'london-dubai', from: 'london', to: 'dubai', type: 'gold', volume: '$2.4B' },
  { id: 'hongkong-mumbai', from: 'hongkong', to: 'mumbai', type: 'ship', volume: '$1.6B' },
  // New routes to South Africa and Chad
  { id: 'southafrica-chad', from: 'southafrica', to: 'chad', type: 'ship', volume: '$0.5B' },
  { id: 'southafrica-dubai', from: 'southafrica', to: 'dubai', type: 'gold', volume: '$0.8B' },
  { id: 'chad-singapore', from: 'chad', to: 'singapore', type: 'ship', volume: '$0.4B' },
];

// Globe center point
const CENTER = { x: 50, y: 50 };

const getHub = (id) => tradeHubs.find(h => h.id === id);

// Generate curved bezier path through center
const generateMeshPath = (from, to) => {
  // Control point pulls toward center for curved effect
  const ctrl1X = from.x + (CENTER.x - from.x) * 0.8;
  const ctrl1Y = from.y + (CENTER.y - from.y) * 0.8;
  const ctrl2X = CENTER.x + (to.x - CENTER.x) * 0.2;
  const ctrl2Y = CENTER.y + (to.y - CENTER.y) * 0.2;
  
  return `M ${from.x} ${from.y} C ${ctrl1X} ${ctrl1Y}, ${ctrl2X} ${ctrl2Y}, ${to.x} ${to.y}`;
};

// Static globe grid - soft golden wireframe circles
function StaticGlobeGrid({ isInView }) {
  return (
    <g>
      {/* Concentric circles for globe grid effect */}
      {[15, 25, 33].map((r, i) => (
        <motion.circle
          key={`lat-${i}`}
          cx="50"
          cy="50"
          r={r}
          fill="none"
          stroke="url(#gridGoldGradient)"
          strokeWidth="0.12"
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 0.15 } : {}}
          transition={{ duration: 1.5, delay: i * 0.1 }}
        />
      ))}
      {/* Vertical and horizontal lines */}
      {[0, 45, 90, 135].map((angle, i) => (
        <motion.line
          key={`lng-${i}`}
          x1={50 + 36 * Math.cos(angle * Math.PI / 180)}
          y1={50 + 36 * Math.sin(angle * Math.PI / 180)}
          x2={50 - 36 * Math.cos(angle * Math.PI / 180)}
          y2={50 - 36 * Math.sin(angle * Math.PI / 180)}
          stroke="url(#gridGoldGradient)"
          strokeWidth="0.1"
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 0.12 } : {}}
          transition={{ duration: 1.5, delay: 0.3 + i * 0.1 }}
        />
      ))}
    </g>
  );
}



// Tooltip component for trade hubs
function HubTooltip({ hub, position }) {
  const tooltipX = hub.x < 50 ? hub.x + 8 : hub.x - 28;
  const tooltipY = hub.y < 50 ? hub.y + 6 : hub.y - 18;
  
  return (
    <motion.g
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.8 }}
      transition={{ duration: 0.2 }}
    >
      {/* Tooltip background */}
      <rect
        x={tooltipX}
        y={tooltipY}
        width="20"
        height="14"
        rx="1"
        fill="#0d0515"
        stroke="#d1a954"
        strokeWidth="0.3"
        filter="url(#tooltipShadow)"
      />
      {/* Arrow */}
      <polygon
        points={hub.x < 50 
          ? `${tooltipX},${tooltipY + 4} ${tooltipX - 2},${tooltipY + 7} ${tooltipX},${tooltipY + 10}`
          : `${tooltipX + 20},${tooltipY + 4} ${tooltipX + 22},${tooltipY + 7} ${tooltipX + 20},${tooltipY + 10}`
        }
        fill="#0d0515"
        stroke="#d1a954"
        strokeWidth="0.3"
      />
      {/* Hub name */}
      <text x={tooltipX + 10} y={tooltipY + 3.5} fill="#ffd700" fontSize="1.8" textAnchor="middle" fontWeight="500">
        {hub.name}
      </text>
      {/* Volume */}
      <text x={tooltipX + 2} y={tooltipY + 7} fill="#fff" fontSize="1.3">
        Vol: <tspan fill="#d1a954">{hub.volume}</tspan>
      </text>
      {/* Trades */}
      <text x={tooltipX + 2} y={tooltipY + 10} fill="#fff" fontSize="1.3">
        Trades: <tspan fill="#d1a954">{hub.trades.toLocaleString()}</tspan>
      </text>
      {/* Growth */}
      <text x={tooltipX + 2} y={tooltipY + 13} fill="#4ade80" fontSize="1.3">
        {hub.growth}
      </text>
    </motion.g>
  );
}

// Trade hub node - large, prominent with 2D coordinates
function TradeHubNode({ hub, isInView, isActive, isHovered, isSelected, onHover, onClick }) {
  const size = isSelected ? 3.2 : 2.8;
  
  return (
    <g 
      style={{ cursor: 'pointer' }}
      onMouseEnter={() => onHover(hub.id)}
      onMouseLeave={() => onHover(null)}
      onClick={() => onClick(hub.id)}
    >
      {/* Outer pulse ring */}
      <motion.circle
        cx={hub.x}
        cy={hub.y}
        r={size * 3.5}
        fill="none"
        stroke={isSelected ? "#ffd700" : "#d1a954"}
        strokeWidth={isSelected ? "0.4" : "0.2"}
        animate={{ 
          opacity: isSelected ? [0.5, 0.8, 0.5] : [0.2, 0.5, 0.2], 
          r: [size * 3, size * 4, size * 3] 
        }}
        transition={{ duration: isSelected ? 1.5 : 3, repeat: Infinity, ease: "easeInOut" }}
      />
      
      {/* Selection ring */}
      {isSelected && (
        <motion.circle
          cx={hub.x}
          cy={hub.y}
          r={size * 2}
          fill="none"
          stroke="#ffd700"
          strokeWidth="0.3"
          strokeDasharray="1 0.5"
          animate={{ rotate: 360 }}
          transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
          style={{ transformOrigin: `${hub.x}px ${hub.y}px` }}
        />
      )}
      
      {/* Arrival burst */}
      {isActive && (
        <motion.circle
          cx={hub.x}
          cy={hub.y}
          fill="none"
          stroke="#ffd700"
          strokeWidth="0.5"
          initial={{ r: size, opacity: 1 }}
          animate={{ r: size * 6, opacity: 0 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
        />
      )}
      
      {/* Hover glow */}
      {isHovered && (
        <motion.circle
          cx={hub.x}
          cy={hub.y}
          r={size * 3}
          fill="url(#hubGlow)"
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.6 }}
          transition={{ duration: 0.2 }}
        />
      )}
      
      {/* Core glow */}
      <circle cx={hub.x} cy={hub.y} r={size * 2.5} fill="url(#hubGlow)" opacity={isHovered || isSelected ? 0.7 : 0.5} />
      
      {/* Main node */}
      <motion.circle
        cx={hub.x}
        cy={hub.y}
        r={size}
        fill={isSelected ? "#ffd700" : "#d1a954"}
        filter="url(#hubFilter)"
        animate={isActive ? { r: [size, size * 1.4, size], fill: ['#d1a954', '#fff', '#d1a954'] } : {}}
        transition={{ duration: 0.5, ease: "easeOut" }}
      />
      
      {/* Inner bright core */}
      <circle cx={hub.x} cy={hub.y} r={size * 0.35} fill="#fff" opacity="0.9" />
      
      {/* Hub label */}
      <text
        x={hub.x}
        y={hub.y - size * 2.5}
        fill={isHovered || isSelected ? "#ffd700" : "#d1a954"}
        fontSize="2"
        textAnchor="middle"
        fontWeight={isSelected ? "600" : "400"}
        opacity={isHovered || isSelected ? 1 : 0.85}
        style={{ textTransform: 'uppercase', letterSpacing: '1px' }}
      >
        {hub.name}
      </text>
      
      {/* Invisible larger hit area */}
      <circle cx={hub.x} cy={hub.y} r={size * 4} fill="transparent" />
    </g>
  );
}

// Route tooltip component
function RouteTooltip({ route, from, to }) {
  const midX = (from.x + to.x) / 2;
  const midY = (from.y + to.y) / 2;
  const tooltipX = midX - 12;
  const tooltipY = midY - 10;
  
  return (
    <motion.g
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.8 }}
      transition={{ duration: 0.2 }}
    >
      <rect
        x={tooltipX}
        y={tooltipY}
        width="24"
        height="12"
        rx="1.5"
        fill="#0d0515"
        stroke={route.type === 'gold' ? '#ffd700' : '#d1a954'}
        strokeWidth="0.4"
        filter="url(#tooltipShadow)"
      />
      {/* Route type icon */}
      <text x={tooltipX + 2} y={tooltipY + 4} fill={route.type === 'gold' ? '#ffd700' : '#d1a954'} fontSize="2.5">
        {route.type === 'gold' ? '▣' : '⛴'}
      </text>
      {/* Route type label */}
      <text x={tooltipX + 6} y={tooltipY + 4} fill="#fff" fontSize="1.8" fontWeight="500">
        {route.type === 'gold' ? 'Gold Settlement' : 'Cargo Shipment'}
      </text>
      {/* From → To */}
      <text x={tooltipX + 2} y={tooltipY + 7.5} fill="#aaa" fontSize="1.4">
        {from.name} → {to.name}
      </text>
      {/* Volume */}
      <text x={tooltipX + 2} y={tooltipY + 10.5} fill="#fff" fontSize="1.4">
        Volume: <tspan fill="#4ade80">{route.volume}</tspan>
      </text>
    </motion.g>
  );
}

// Mesh route: elegant curved line through center with ship/gold bar
function MeshRoute({ route, from, to, isInView, delay, isSelected, isHovered, onHover, onClick }) {
  const pathD = generateMeshPath(from, to);
  
  const isShip = route.type === 'ship';
  const isGold = route.type === 'gold';
  const duration = 12; // Slow, elegant
  const repeatDelay = 5;
  const isHighlighted = isSelected || isHovered;
  
  return (
    <g 
      style={{ cursor: 'pointer' }}
      onMouseEnter={() => onHover(route.id)}
      onMouseLeave={() => onHover(null)}
      onClick={(e) => { e.stopPropagation(); onClick(route.id); }}
    >
      {/* Invisible wider hit area for easier clicking */}
      <path
        d={pathD}
        fill="none"
        stroke="transparent"
        strokeWidth="4"
        strokeLinecap="round"
      />
      
      {/* Route arc - thin, elegant gold line */}
      <motion.path
        d={pathD}
        fill="none"
        stroke={isHighlighted ? (isGold ? "#ffd700" : "#fff") : "url(#starRouteGradient)"}
        strokeWidth={isHighlighted ? "0.8" : "0.35"}
        strokeLinecap="round"
        filter={isHighlighted ? "url(#neonRouteGlow)" : "url(#softGlow)"}
        initial={{ pathLength: 0, opacity: 0 }}
        animate={isInView ? { pathLength: 1, opacity: isHighlighted ? 1 : 0.5 } : {}}
        transition={{ duration: 2.5, delay, ease: "easeOut" }}
      />
      
      {/* Subtle flowing particles - very slow */}
      {isInView && [0, 1].map(idx => (
        <motion.circle
          key={idx}
          r="0.4"
          fill="#d1a954"
          filter="url(#particleGlow)"
          animate={{ offsetDistance: ['0%', '100%'], opacity: [0, 0.5, 0.5, 0] }}
          transition={{
            duration: 10,
            delay: delay + idx * 5,
            repeat: Infinity,
            repeatDelay: 3,
            ease: "linear"
          }}
          style={{ offsetPath: `path('${pathD}')` }}
        />
      ))}
      
      {/* Miniature Ship Icon - following path */}
      {isInView && isShip && (
        <motion.g
          animate={{ offsetDistance: ['0%', '100%'] }}
          transition={{
            duration: duration,
            delay: delay + 1.5,
            repeat: Infinity,
            repeatDelay: repeatDelay,
            ease: "easeInOut"
          }}
          style={{ offsetPath: `path('${pathD}')`, offsetRotate: 'auto' }}
        >
          <motion.g
            animate={{ opacity: [0, 1, 1, 0] }}
            transition={{ duration: duration, delay: delay + 1.5, repeat: Infinity, repeatDelay: repeatDelay, ease: "easeInOut" }}
          >
            {/* Glow behind ship */}
            <circle r="2.5" fill="url(#shipGlow)" opacity="0.5" />
            {/* Miniature cargo ship */}
            <g transform="scale(0.025) translate(-100, -80)">
              {/* Hull */}
              <path d="M10 100 L190 100 L210 140 L-10 140 Z" fill="#d1a954" />
              {/* Deck */}
              <rect x="20" y="60" width="160" height="40" fill="#0d0515" stroke="#d1a954" strokeWidth="4" rx="4" />
              {/* Containers */}
              <rect x="30" y="30" width="40" height="30" fill="#ffd700" rx="3" />
              <rect x="80" y="30" width="40" height="30" fill="#b8860b" rx="3" />
              <rect x="130" y="30" width="40" height="30" fill="#d1a954" rx="3" />
              {/* Bridge */}
              <rect x="150" y="50" width="25" height="50" fill="#0d0515" stroke="#d1a954" strokeWidth="3" rx="3" />
              <circle cx="162" cy="65" r="5" fill="#ffd700" />
            </g>
          </motion.g>
        </motion.g>
      )}
      
      {/* Gold Bar Icon - slow, premium movement */}
      {isInView && isGold && (
        <motion.g
          animate={{ offsetDistance: ['0%', '100%'] }}
          transition={{
            duration: duration + 2,
            delay: delay + 2,
            repeat: Infinity,
            repeatDelay: repeatDelay + 2,
            ease: "easeInOut"
          }}
          style={{ offsetPath: `path('${pathD}')`, offsetRotate: '0deg' }}
        >
          <motion.g
            animate={{ opacity: [0, 1, 1, 0] }}
            transition={{ duration: duration + 2, delay: delay + 2, repeat: Infinity, repeatDelay: repeatDelay + 2, ease: "easeInOut" }}
          >
            {/* Glow behind gold bar */}
            <circle r="4" fill="url(#docGlow)" opacity="0.5" />
            {/* Miniature 3D Gold Bar */}
            <g transform="scale(0.022) translate(-100, -50)">
              {/* Shadow */}
              <ellipse cx="100" cy="110" rx="90" ry="15" fill="#000" opacity="0.3" />
              {/* Gold bar base */}
              <path d="M10 80 L190 80 L170 100 L30 100 Z" fill="#8b6914" />
              {/* Gold bar front */}
              <path d="M30 30 L30 100 L170 100 L170 30 Z" fill="#b8860b" />
              {/* Gold bar top (brightest) */}
              <path d="M30 30 L10 80 L190 80 L170 30 Z" fill="#d1a954" />
              {/* Highlight */}
              <path d="M40 35 L25 70 L100 70 L115 35 Z" fill="#f5e6c8" opacity="0.7" />
              {/* Shine */}
              <path d="M50 40 L40 60 L80 60 L90 40 Z" fill="#fff" opacity="0.5" />
            </g>
          </motion.g>
        </motion.g>
      )}
    </g>
  );
}

export default function BusinessGlobe() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });
  const [activeHubs, setActiveHubs] = useState(new Set());
  const [hoveredHub, setHoveredHub] = useState(null);
  const [selectedHub, setSelectedHub] = useState(null);
  const [hoveredRoute, setHoveredRoute] = useState(null);
  const [selectedRoute, setSelectedRoute] = useState(null);
  const [globeRotation, setGlobeRotation] = useState(0);

  // Subtle globe rotation animation
  useEffect(() => {
    if (!isInView) return;
    const interval = setInterval(() => {
      setGlobeRotation(prev => (prev + 0.3) % 360);
    }, 50);
    return () => clearInterval(interval);
  }, [isInView]);

  // Hub pulse on settlement arrival (fixed globe)
  useEffect(() => {
    if (!isInView) return;
    const interval = setInterval(() => {
      const hubs = ['dubai', 'singapore', 'london', 'hongkong', 'lagos', 'mumbai', 'southafrica', 'chad']
        .sort(() => Math.random() - 0.5)
        .slice(0, 2);
      setActiveHubs(new Set(hubs));
      setTimeout(() => setActiveHubs(new Set()), 700);
    }, 3500);
    return () => clearInterval(interval);
  }, [isInView]);

  // Get routes connected to selected hub
  const getConnectedRoutes = (hubId) => {
    if (!hubId) return meshRoutes;
    return meshRoutes.filter(r => r.from === hubId || r.to === hubId);
  };

  const handleHubClick = (hubId) => {
    setSelectedHub(prev => prev === hubId ? null : hubId);
    setSelectedRoute(null); // Clear route selection when hub is clicked
  };

  const handleRouteClick = (routeId) => {
    setSelectedRoute(prev => prev === routeId ? null : routeId);
    setSelectedHub(null); // Clear hub selection when route is clicked
  };

  const handleGlobeClick = () => {
    // Clear all selections when clicking on empty space
    setSelectedHub(null);
    setSelectedRoute(null);
  };

  // Get hubs connected to selected route
  const getRouteHubs = (routeId) => {
    if (!routeId) return [];
    const route = meshRoutes.find(r => r.id === routeId);
    return route ? [route.from, route.to] : [];
  };

  const filteredRoutes = selectedHub ? getConnectedRoutes(selectedHub) : meshRoutes;
  const selectedHubData = selectedHub ? tradeHubs.find(h => h.id === selectedHub) : null;
  const selectedRouteData = selectedRoute ? meshRoutes.find(r => r.id === selectedRoute) : null;
  const routeConnectedHubs = getRouteHubs(selectedRoute);



  return (
    <section 
      ref={ref} 
      className="relative py-28 overflow-hidden"
      style={{ background: 'linear-gradient(180deg, #000000 0%, #0d0515 40%, #1a0a2e 100%)' }}
    >
      {/* Intense depth lighting */}
      <div className="absolute inset-0">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] rounded-full bg-[radial-gradient(circle,_rgba(209,169,84,0.2)_0%,_rgba(209,169,84,0.08)_35%,_transparent_65%)] blur-2xl" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full bg-[radial-gradient(circle,_rgba(255,215,0,0.15)_0%,_transparent_55%)] blur-xl" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <p className="text-[#d1a954] text-xs tracking-[0.5em] uppercase mb-3 font-medium">Enterprise Infrastructure</p>
          <h2 className="text-4xl md:text-5xl font-light text-white mb-3">
            Global Business <span className="text-[#d1a954] font-normal">Settlements</span>
          </h2>
          <p className="text-gray-400 text-lg font-light tracking-wide">
            Import & Export <span className="text-[#d1a954]">Powered by Gold</span>
          </p>
          <div className="w-40 h-[2px] bg-gradient-to-r from-transparent via-[#d1a954] to-transparent mx-auto mt-6" />
        </motion.div>

        {/* Globe */}
        <div className="relative aspect-square max-w-2xl mx-auto">
          <svg 
            viewBox="0 0 100 100" 
            className="w-full h-full" 
            preserveAspectRatio="xMidYMid meet"
            onClick={handleGlobeClick}
          >
            <defs>
              {/* Hub glow */}
              <radialGradient id="hubGlow" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#ffd700" stopOpacity="1" />
                <stop offset="50%" stopColor="#d1a954" stopOpacity="0.5" />
                <stop offset="100%" stopColor="#d1a954" stopOpacity="0" />
              </radialGradient>
              
              {/* Trade route gradient */}
              <linearGradient id="tradeRouteGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#d1a954" stopOpacity="0.2" />
                <stop offset="30%" stopColor="#ffd700" stopOpacity="1" />
                <stop offset="50%" stopColor="#ffffff" stopOpacity="1" />
                <stop offset="70%" stopColor="#ffd700" stopOpacity="1" />
                <stop offset="100%" stopColor="#d1a954" stopOpacity="0.2" />
              </linearGradient>
              
              {/* Gold bar glow */}
              <radialGradient id="goldBarGlowGradient" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#ffd700" stopOpacity="0.8" />
                <stop offset="100%" stopColor="#ffd700" stopOpacity="0" />
              </radialGradient>
              
              {/* Token disc gradient */}
              <radialGradient id="tokenDiscGradient" cx="30%" cy="30%" r="70%">
                <stop offset="0%" stopColor="#f5e6c8" />
                <stop offset="50%" stopColor="#d1a954" />
                <stop offset="100%" stopColor="#a67c00" />
              </radialGradient>
              
              {/* Token glow */}
              <radialGradient id="tokenGlowGradient" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#ffd700" stopOpacity="0.7" />
                <stop offset="100%" stopColor="#ffd700" stopOpacity="0" />
              </radialGradient>
              
              {/* Globe gradient */}
              <radialGradient id="globeGrad" cx="30%" cy="25%" r="70%">
                <stop offset="0%" stopColor="#1a1a2e" stopOpacity="0.9" />
                <stop offset="50%" stopColor="#0a0a15" stopOpacity="0.95" />
                <stop offset="100%" stopColor="#000" stopOpacity="1" />
              </radialGradient>
              
              {/* Grid gold gradient */}
              <linearGradient id="gridGoldGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#d1a954" stopOpacity="0.6" />
                <stop offset="50%" stopColor="#ffd700" stopOpacity="0.4" />
                <stop offset="100%" stopColor="#d1a954" stopOpacity="0.6" />
              </linearGradient>
              
              {/* Star route gradient */}
              <linearGradient id="starRouteGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#d1a954" stopOpacity="0.3" />
                <stop offset="50%" stopColor="#ffd700" stopOpacity="0.8" />
                <stop offset="100%" stopColor="#d1a954" stopOpacity="0.3" />
              </linearGradient>
              
              {/* Ship glow */}
              <radialGradient id="shipGlow" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#d1a954" stopOpacity="0.5" />
                <stop offset="100%" stopColor="#d1a954" stopOpacity="0" />
              </radialGradient>
              
              {/* Document glow */}
              <radialGradient id="docGlow" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#ffd700" stopOpacity="0.4" />
                <stop offset="100%" stopColor="#ffd700" stopOpacity="0" />
              </radialGradient>
              
              {/* Soft glow filter */}
              <filter id="softGlow" x="-100%" y="-100%" width="300%" height="300%">
                <feGaussianBlur stdDeviation="0.8" result="blur" />
                <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
              </filter>
              
              {/* Particle glow filter */}
              <filter id="particleGlow" x="-100%" y="-100%" width="300%" height="300%">
                <feGaussianBlur stdDeviation="0.4" result="blur" />
                <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
              </filter>
              
              {/* Glass highlight */}
              <radialGradient id="glassHL" cx="30%" cy="20%" r="50%">
                <stop offset="0%" stopColor="#fff" stopOpacity="0.12" />
                <stop offset="100%" stopColor="#fff" stopOpacity="0" />
              </radialGradient>
              
              {/* Rim */}
              <linearGradient id="rimGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#fff" stopOpacity="0.5" />
                <stop offset="25%" stopColor="#d1a954" stopOpacity="0.8" />
                <stop offset="50%" stopColor="#fff" stopOpacity="0.3" />
                <stop offset="75%" stopColor="#d1a954" stopOpacity="0.8" />
                <stop offset="100%" stopColor="#fff" stopOpacity="0.5" />
              </linearGradient>
              
              {/* Filters */}
              <filter id="hubFilter" x="-100%" y="-100%" width="300%" height="300%">
                <feGaussianBlur stdDeviation="0.6" result="blur" />
                <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
              </filter>
              
              <filter id="routeGlow" x="-50%" y="-50%" width="200%" height="200%">
                <feGaussianBlur stdDeviation="1" result="blur" />
                <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
              </filter>
              
              <filter id="globeShadow" x="-50%" y="-50%" width="200%" height="200%">
                <feDropShadow dx="0" dy="0" stdDeviation="5" floodColor="#d1a954" floodOpacity="0.4" />
              </filter>
              
              {/* Bottom shadow gradient */}
              <radialGradient id="bottomShadow" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#000" stopOpacity="0.5" />
                <stop offset="100%" stopColor="#000" stopOpacity="0" />
              </radialGradient>
            </defs>

            {/* Bottom depth shadow */}
            <ellipse cx="50" cy="92" rx="30" ry="5" fill="url(#bottomShadow)" opacity="0.4" />
            
            {/* Tooltip shadow filter */}
            <filter id="tooltipShadow" x="-50%" y="-50%" width="200%" height="200%">
              <feDropShadow dx="0" dy="0.5" stdDeviation="0.5" floodColor="#000" floodOpacity="0.5" />
            </filter>
            
            {/* Filter for route neon glow */}
            <filter id="neonRouteGlow" x="-200%" y="-200%" width="500%" height="500%">
              <feGaussianBlur stdDeviation="1" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>

            {/* Globe base with pulsating glow */}
            <motion.circle 
              cx="50" 
              cy="50" 
              r="39" 
              fill="none" 
              stroke="#d1a954" 
              strokeWidth="0.3"
              animate={{ 
                opacity: [0.2, 0.4, 0.2],
                r: [39, 40, 39]
              }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            />
            <circle cx="50" cy="50" r="38" fill="url(#globeGrad)" filter="url(#globeShadow)" />
            <circle cx="50" cy="50" r="38" fill="url(#glassHL)" />
            <ellipse cx="37" cy="34" rx="15" ry="10" fill="url(#glassHL)" opacity="0.5" />
            <circle cx="50" cy="50" r="38" fill="none" stroke="url(#rimGrad)" strokeWidth="0.6" />
            
            {/* Static golden grid with subtle rotation effect */}
            <g style={{ transform: `rotate(${globeRotation * 0.1}deg)`, transformOrigin: '50px 50px' }}>
              <StaticGlobeGrid isInView={isInView} />
            </g>
            
            {/* Mesh network routes with ships and gold bars */}
            {filteredRoutes.map((route, i) => {
              const fromHub = getHub(route.from);
              const toHub = getHub(route.to);
              if (!fromHub || !toHub) return null;
              return (
                <MeshRoute
                  key={route.id}
                  route={route}
                  from={fromHub}
                  to={toHub}
                  isInView={isInView}
                  delay={0.3 + i * 0.25}
                  isSelected={selectedRoute === route.id}
                  isHovered={hoveredRoute === route.id}
                  onHover={setHoveredRoute}
                  onClick={handleRouteClick}
                />
              );
            })}

            {/* Trade hubs - fixed position */}
            {tradeHubs.map(hub => (
              <TradeHubNode
                key={hub.id}
                hub={hub}
                isInView={isInView}
                isActive={activeHubs.has(hub.id)}
                isHovered={hoveredHub === hub.id}
                isSelected={selectedHub === hub.id || routeConnectedHubs.includes(hub.id)}
                onHover={setHoveredHub}
                onClick={handleHubClick}
              />
            ))}

            {/* Tooltip for hovered hub */}
            <AnimatePresence>
              {hoveredHub && (
                <HubTooltip hub={tradeHubs.find(h => h.id === hoveredHub)} />
              )}
            </AnimatePresence>
            
            {/* Tooltip for hovered route */}
            <AnimatePresence>
              {hoveredRoute && !selectedRoute && (
                <RouteTooltip 
                  route={meshRoutes.find(r => r.id === hoveredRoute)} 
                  from={getHub(meshRoutes.find(r => r.id === hoveredRoute)?.from)}
                  to={getHub(meshRoutes.find(r => r.id === hoveredRoute)?.to)}
                />
              )}
            </AnimatePresence>
          </svg>

          {/* Selected hub info panel */}
          <AnimatePresence>
            {selectedHubData && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 20 }}
                className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-[#0d0515]/95 border border-[#d1a954]/50 rounded-xl px-6 py-4 backdrop-blur-sm"
              >
                <div className="flex items-center gap-6">
                  <div className="text-center">
                    <div className="text-[#ffd700] font-semibold text-lg">{selectedHubData.name}</div>
                    <div className="text-gray-400 text-xs">Trade Hub</div>
                  </div>
                  <div className="h-8 w-px bg-[#d1a954]/30" />
                  <div className="text-center">
                    <div className="text-white font-medium">{selectedHubData.volume}</div>
                    <div className="text-gray-400 text-xs">Volume</div>
                  </div>
                  <div className="text-center">
                    <div className="text-white font-medium">{selectedHubData.trades.toLocaleString()}</div>
                    <div className="text-gray-400 text-xs">Trades</div>
                  </div>
                  <div className="text-center">
                    <div className="text-green-400 font-medium">{selectedHubData.growth}</div>
                    <div className="text-gray-400 text-xs">Growth</div>
                  </div>
                  <button 
                    onClick={() => setSelectedHub(null)}
                    className="ml-2 text-gray-400 hover:text-white text-sm"
                  >
                    ✕
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Selected route info panel */}
          <AnimatePresence>
            {selectedRouteData && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 20 }}
                className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-[#0d0515]/95 border border-[#d1a954]/50 rounded-xl px-6 py-4 backdrop-blur-sm"
              >
                <div className="flex items-center gap-6">
                  <div className="text-center">
                    <div className="text-2xl">{selectedRouteData.type === 'gold' ? '▣' : '⛴'}</div>
                    <div className="text-gray-400 text-xs mt-1">
                      {selectedRouteData.type === 'gold' ? 'Gold' : 'Cargo'}
                    </div>
                  </div>
                  <div className="h-8 w-px bg-[#d1a954]/30" />
                  <div className="text-center">
                    <div className="text-[#ffd700] font-semibold">
                      {tradeHubs.find(h => h.id === selectedRouteData.from)?.name}
                    </div>
                    <div className="text-gray-400 text-xs">From</div>
                  </div>
                  <div className="text-[#d1a954]">→</div>
                  <div className="text-center">
                    <div className="text-[#ffd700] font-semibold">
                      {tradeHubs.find(h => h.id === selectedRouteData.to)?.name}
                    </div>
                    <div className="text-gray-400 text-xs">To</div>
                  </div>
                  <div className="h-8 w-px bg-[#d1a954]/30" />
                  <div className="text-center">
                    <div className="text-green-400 font-medium">{selectedRouteData.volume}</div>
                    <div className="text-gray-400 text-xs">Volume</div>
                  </div>
                  <button 
                    onClick={() => setSelectedRoute(null)}
                    className="ml-2 text-gray-400 hover:text-white text-sm"
                  >
                    ✕
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
          </div>

          {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 1.2, duration: 0.8 }}
          className="flex flex-wrap justify-center gap-10 md:gap-16 mt-14"
        >
          {[
            { value: '8', label: 'Major Trade Hubs' },
            { value: '$24B+', label: 'Daily Settlement' },
            { value: '1.2s', label: 'Avg. Transaction' },
            { value: '99.99%', label: 'Uptime SLA' }
          ].map((stat, i) => (
            <motion.div 
              key={i} 
              className="text-center"
              initial={{ opacity: 0, y: 15 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 1.4 + i * 0.1 }}
            >
              <div className="text-3xl md:text-4xl font-light text-[#ffd700]">{stat.value}</div>
              <div className="text-xs text-gray-500 mt-1 tracking-wider uppercase">{stat.label}</div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}