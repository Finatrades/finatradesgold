import React, { useRef } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion, useInView } from 'framer-motion';
import { Vault, Wallet, ArrowLeftRight, ArrowRight, TrendingUp, Ship, Coins, Link as LinkIcon } from 'lucide-react';
import { useAccountType } from '@/components/AccountTypeContext';
import { useLanguage } from '@/components/LanguageContext';

const getProducts = (accountType, t) => {
  if (accountType === 'business') {
    return [
      {
        id: 'vault',
        icon: Vault,
        name: 'FinaVault',
        headline: t('productSuite.business.vault.headline'),
        description: t('productSuite.business.vault.description'),
        color: '#8A2BE2',
        page: 'FinaVault'
      },
      {
        id: 'wallet',
        icon: Wallet,
        name: 'FinaPay Wallet',
        headline: t('productSuite.business.wallet.headline'),
        description: t('productSuite.business.wallet.description'),
        color: '#FF66D8',
        page: 'FinaPay'
      },
      {
        id: 'bridge',
        icon: LinkIcon,
        name: 'FinaBridge',
        headline: t('productSuite.business.bridge.headline'),
        description: t('productSuite.business.bridge.description'),
        color: '#FF2FBF',
        page: 'FinaBridge'
      },
      {
        id: 'bnsl',
        icon: Coins,
        name: 'BNSL',
        headline: t('productSuite.business.bnsl.headline'),
        description: t('productSuite.business.bnsl.description'),
        color: '#A54CFF',
        page: 'BNSL'
      }
    ];
  }
  
  // Personal mode - only 3 products (no FinaFinance/FinaBridge)
  return [
    {
      id: 'vault',
      icon: Vault,
      name: 'FinaVault',
      headline: 'Deposit / Buy Gold',
      description: 'Get instant value and turn into a settlement financial instrument with your choice of hedging or floating strategies as your business grows.',
      color: '#8A2BE2',
      page: 'FinaVault'
    },
    {
      id: 'wallet',
      icon: Wallet,
      name: 'FinaPay Wallet',
      headline: 'Payments & Transfers',
      description: 'Send and receive payments through the platform, manage your wallet and spend anywhere using your gold-backed debit card.',
      color: '#FF66D8',
      page: 'FinaPay'
    },
    {
      id: 'bnsl',
      icon: Coins,
      name: 'BNSL',
      headline: "Buy 'N' SeLL Gold Plans",
      description: 'Get substantial margins and guaranteed returns thanks to our BNSL Plans.',
      color: '#FF2FBF',
      page: 'BNSL'
    }
  ];
};

function ProductCard({ product, index, isInView, t }) {
  const Icon = product.icon;
  
  return (
    <motion.div
      className="relative group"
      initial={{ opacity: 0, y: 50 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.8, delay: index * 0.2 }}
    >
      {/* Card */}
      <div className="relative h-full bg-white rounded-[22px] border border-[#E8E0F0] p-8 overflow-hidden group-hover:border-[#8A2BE2]/50 transition-all duration-500 shadow-[0_8px_32px_rgba(160,50,255,0.08)] group-hover:shadow-[0_16px_56px_rgba(160,50,255,0.18)] flex flex-col">
        {/* Background glow */}
        <div className="absolute inset-0 bg-gradient-to-br from-[#8A2BE2]/5 to-[#FF2FBF]/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
        
        {/* Animated icon container */}
        <motion.div
          className="relative w-16 h-16 mx-auto mb-6"
          whileHover={{ scale: 1.1, rotateY: 180 }}
          transition={{ duration: 0.6 }}
        >
          {/* 3D effect layers */}
          <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-[#8A2BE2]/20 to-[#FF2FBF]/20 opacity-20 blur-xl group-hover:opacity-40 transition-opacity" />
          <div className="absolute inset-0 rounded-2xl border-2 border-[#8A2BE2]/30" />
          <div className="absolute inset-1.5 rounded-lg bg-gradient-to-br from-[#8A2BE2] to-[#FF2FBF] p-[1px]">
            <div className="w-full h-full rounded-lg bg-white flex items-center justify-center">
              <Icon className="w-7 h-7 text-[#8A2BE2]" strokeWidth={1.5} />
            </div>
          </div>
          
          {/* Orbiting particles */}
          {[...Array(3)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-1 h-1 rounded-full"
              style={{ 
                top: '50%', 
                left: '50%',
                background: i % 2 === 0 ? '#FF66D8' : '#8A2BE2'
              }}
              animate={{
                x: Math.cos((i * 120 * Math.PI) / 180) * 35,
                y: Math.sin((i * 120 * Math.PI) / 180) * 35,
                opacity: [0.3, 1, 0.3]
              }}
              transition={{
                x: { duration: 4, repeat: Infinity, ease: "linear" },
                y: { duration: 4, repeat: Infinity, ease: "linear" },
                opacity: { duration: 2, repeat: Infinity }
              }}
            />
          ))}
        </motion.div>

        {/* Content */}
        <div className="relative text-center flex flex-col flex-1">
          
          {product.headline && (
            <h3 className="text-lg font-bold text-[#0D0D0D] mb-3 text-center">{product.headline}</h3>
          )}
          
          {product.description ? (
            <p className="text-[#4A4A4A] text-sm mb-6 text-center flex-1">
              {product.description.split(/(\*\*[^*]+\*\*)/).map((part, i) => {
                if (part.startsWith('**') && part.endsWith('**')) {
                  return <strong key={i} className="font-bold text-[#0D0D0D]">{part.slice(2, -2)}</strong>;
                }
                return part;
              })}
            </p>
          ) : (
            <ul className="text-[#4A4A4A] text-sm mb-6 space-y-1.5 text-left flex-1">
              {product.bullets && product.bullets.map((bullet, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="text-green-500 mt-0.5">✔</span>
                  <span>{bullet}</span>
                </li>
              ))}
            </ul>
          )}
          
          <Link 
            to={createPageUrl(product.page)}
            onClick={() => window.scrollTo(0, 0)}
            className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white text-sm font-medium group/btn mt-auto hover:shadow-[0_0_20px_rgba(138,43,226,0.4)] transition-all w-full"
          >
            {t('productSuite.explore')} {product.name}
            <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
          </Link>
        </div>

        {/* Bottom accent */}
        <motion.div
          className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-[#8A2BE2] to-transparent"
          initial={{ scaleX: 0 }}
          whileHover={{ scaleX: 1 }}
          transition={{ duration: 0.5 }}
        />
      </div>
    </motion.div>
  );
}

export default function ProductSuite({ accountType: propAccountType }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });
  const contextValue = useAccountType() || {};
  const contextAccountType = contextValue.accountType;
  const { t } = useLanguage();
  
  const accountType = propAccountType || contextAccountType || 'personal';
  const products = getProducts(accountType, t);

  const content = {
    personal: {
      label: t('productSuite.personal.label'),
      title: t('productSuite.personal.title')
    },
    business: {
      label: t('productSuite.business.label'),
      title: t('productSuite.business.title')
    }
  };

  const current = content[accountType];

  return (
    <section ref={ref} className="relative py-32 overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(138,43,226,0.05)_0%,_transparent_50%)]" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 1 }}
          className="text-center mb-16"
        >
          <p className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent text-sm tracking-[0.3em] uppercase mb-4">{current.label}</p>
          <h2 className="text-4xl md:text-5xl font-bold text-[#0D0D0D] mb-4">
            {current.title}
          </h2>
          <div className="w-24 h-0.5 bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] mx-auto" />
        </motion.div>

        <div className={`grid gap-6 ${products.length === 3 ? 'md:grid-cols-3 max-w-5xl mx-auto' : products.length === 5 ? 'md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5' : 'md:grid-cols-2 lg:grid-cols-4'}`} style={{ gridAutoRows: '1fr' }}>
          {products.map((product, i) => (
            <ProductCard key={product.id} product={product} index={i} isInView={isInView} t={t} />
          ))}
        </div>
      </div>
    </section>
  );
}