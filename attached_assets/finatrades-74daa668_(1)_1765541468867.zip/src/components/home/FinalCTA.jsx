import React, { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { ArrowRight, Sparkles } from 'lucide-react';
import { useLanguage } from '@/components/LanguageContext';

export default function FinalCTA() {
  const ref = useRef(null);
  const { t } = useLanguage();
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="relative py-32 overflow-hidden">
      {/* Background effect */}
      <div className="absolute inset-0">
        <motion.div
          className="absolute inset-0"
          style={{
            background: 'linear-gradient(180deg, #FAFBFF 0%, #F4F6FC 50%, #FAFBFF 100%)'
          }}
        />
        
        {/* Animated neon wave */}
        <motion.div
          className="absolute bottom-0 left-0 right-0 h-96"
          style={{
            background: 'linear-gradient(180deg, transparent 0%, rgba(138,43,226,0.08) 50%, rgba(255,47,191,0.1) 100%)'
          }}
          animate={{
            y: [50, 0, 50]
          }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
        />
        
        {/* Neon particles */}
        {[...Array(30)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              bottom: '20%',
              background: i % 2 === 0 ? '#FF66D8' : '#8A2BE2'
            }}
            animate={{
              y: [-20, -200, -20],
              x: [0, (Math.random() - 0.5) * 100, 0],
              opacity: [0, 1, 0],
              scale: [0, 1.5, 0]
            }}
            transition={{
              duration: 5 + Math.random() * 5,
              repeat: Infinity,
              delay: Math.random() * 5
            }}
          />
        ))}
      </div>

      <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
        {/* Sparkle icon */}
        <motion.div
          className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-[#8A2BE2] to-[#FF2FBF] mb-8 shadow-[0_0_40px_rgba(255,45,200,0.35)]"
          initial={{ scale: 0, rotate: -180 }}
          animate={isInView ? { scale: 1, rotate: 0 } : {}}
          transition={{ duration: 0.8, type: "spring" }}
        >
          <Sparkles className="w-10 h-10 text-white" />
        </motion.div>

        <motion.h2
          className="text-4xl md:text-6xl font-extralight text-[#0D0D0D] mb-6"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          {t('finalcta.title')}
          <br />
          <span className="bg-gradient-to-r from-[#8A2BE2] via-[#FF66D8] to-[#FF2FBF] bg-clip-text text-transparent">
            {t('finalcta.titleHighlight')}
          </span>
        </motion.h2>

        <motion.p
          className="text-xl text-[#4A4A4A] mb-12 max-w-2xl mx-auto"
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          {t('finalcta.subtitle')}
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          <Link to={createPageUrl("Register")}>
            <motion.button
              className="relative px-12 py-5 rounded-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white font-medium text-lg overflow-hidden group hover:from-[#A342FF] hover:to-[#FF4CD6] hover:shadow-[0_0_40px_rgba(255,45,200,0.35)] transition-all"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.98 }}
            >
              {/* Glow pulse */}
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-[#FF66D8] to-[#A54CFF]"
                animate={{ opacity: [0, 0.5, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
              />
              
              {/* Shimmer effect */}
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent"
                animate={{ x: [-200, 200] }}
                transition={{ duration: 2, repeat: Infinity, repeatDelay: 1 }}
              />
              
              <span className="relative flex items-center gap-3">
                Get Started
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </span>
            </motion.button>
          </Link>
        </motion.div>

        {/* Bottom decorative line */}
        <motion.div
          className="mt-20 flex items-center justify-center gap-4"
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 1, delay: 1 }}
        >
          <div className="w-20 h-px bg-gradient-to-r from-transparent to-[#8A2BE2]/50" />
          <div className="w-2 h-2 rounded-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF]" />
          <div className="w-20 h-px bg-gradient-to-l from-transparent to-[#FF2FBF]/50" />
        </motion.div>
      </div>
    </section>
  );
}