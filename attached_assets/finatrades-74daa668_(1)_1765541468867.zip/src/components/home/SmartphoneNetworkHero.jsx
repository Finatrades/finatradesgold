import React, { useRef, useState, useEffect } from 'react';
import { motion, useInView } from 'framer-motion';

// Network nodes positioned on the holographic globe
const networkNodes = [
  { id: 'usa', name: 'USA', x: 22, y: 45, size: 'large' },
  { id: 'uk', name: 'UK', x: 45, y: 32, size: 'medium' },
  { id: 'eu', name: 'EU', x: 50, y: 38, size: 'medium' },
  { id: 'uae', name: 'UAE', x: 58, y: 52, size: 'medium' },
  { id: 'india', name: 'India', x: 65, y: 55, size: 'large' },
  { id: 'china', name: 'China', x: 75, y: 42, size: 'large' },
  { id: 'singapore', name: 'SG', x: 72, y: 65, size: 'small' },
  { id: 'japan', name: 'Japan', x: 82, y: 40, size: 'medium' },
  { id: 'africa', name: 'Africa', x: 50, y: 68, size: 'medium' },
];

// Connection paths between nodes
const connections = [
  { from: 'usa', to: 'uk', primary: true },
  { from: 'uk', to: 'eu', primary: true },
  { from: 'eu', to: 'uae', primary: true },
  { from: 'uae', to: 'india', primary: true },
  { from: 'india', to: 'china', primary: true },
  { from: 'china', to: 'japan', primary: true },
  { from: 'india', to: 'singapore', primary: false },
  { from: 'usa', to: 'eu', primary: false },
  { from: 'uk', to: 'africa', primary: false },
  { from: 'uae', to: 'africa', primary: false },
  { from: 'china', to: 'singapore', primary: false },
];

// Get node by id
const getNode = (id) => networkNodes.find(n => n.id === id);

// Generate curved path
const generatePath = (fromId, toId) => {
  const from = getNode(fromId);
  const to = getNode(toId);
  if (!from || !to) return '';
  
  const midX = (from.x + to.x) / 2;
  const midY = (from.y + to.y) / 2;
  const dx = to.x - from.x;
  const dy = to.y - from.y;
  const dist = Math.sqrt(dx * dx + dy * dy);
  const curve = dist * 0.3;
  const angle = Math.atan2(dy, dx) + Math.PI / 2;
  const ctrlX = midX + Math.cos(angle) * curve;
  const ctrlY = midY + Math.sin(angle) * curve * 0.5;
  
  return `M ${from.x} ${from.y} Q ${ctrlX} ${ctrlY} ${to.x} ${to.y}`;
};

// Animated connection line
function ConnectionLine({ connection, index, isInView }) {
  const path = generatePath(connection.from, connection.to);
  
  return (
    <g>
      {/* Glow layer */}
      <motion.path
        d={path}
        fill="none"
        stroke={connection.primary ? "url(#primaryGlow)" : "url(#secondaryGlow)"}
        strokeWidth={connection.primary ? "1.5" : "0.8"}
        strokeLinecap="round"
        filter="url(#lineGlow)"
        initial={{ pathLength: 0, opacity: 0 }}
        animate={isInView ? { pathLength: 1, opacity: 1 } : {}}
        transition={{ duration: 1.5, delay: index * 0.15, ease: "easeOut" }}
      />
      
      {/* Core line */}
      <motion.path
        d={path}
        fill="none"
        stroke={connection.primary ? "#F7D878" : "#D4AF37"}
        strokeWidth={connection.primary ? "0.6" : "0.3"}
        strokeLinecap="round"
        initial={{ pathLength: 0, opacity: 0 }}
        animate={isInView ? { pathLength: 1, opacity: connection.primary ? 1 : 0.6 } : {}}
        transition={{ duration: 1.5, delay: index * 0.15, ease: "easeOut" }}
      />
      
      {/* Traveling pulse */}
      {isInView && (
        <motion.circle
          r={connection.primary ? "1.5" : "1"}
          fill="#FFFFFF"
          filter="url(#pulseGlow)"
          initial={{ opacity: 0 }}
          animate={{
            opacity: [0, 1, 1, 0],
            offsetDistance: ['0%', '100%']
          }}
          transition={{
            duration: connection.primary ? 2 : 3,
            delay: index * 0.15 + 1.5,
            repeat: Infinity,
            repeatDelay: 2,
            ease: "linear"
          }}
          style={{ offsetPath: `path('${path}')` }}
        />
      )}
    </g>
  );
}

// Network node with glow
function NetworkNode({ node, index, isInView }) {
  const sizes = { large: 3, medium: 2, small: 1.5 };
  const size = sizes[node.size];
  
  return (
    <motion.g
      initial={{ opacity: 0, scale: 0 }}
      animate={isInView ? { opacity: 1, scale: 1 } : {}}
      transition={{ duration: 0.5, delay: index * 0.1 + 0.5 }}
    >
      {/* Outer pulse */}
      <motion.circle
        cx={node.x}
        cy={node.y}
        r={size * 2}
        fill="none"
        stroke="#D4AF37"
        strokeWidth="0.3"
        animate={isInView ? {
          opacity: [0.2, 0.6, 0.2],
          scale: [1, 1.5, 1]
        } : {}}
        transition={{ duration: 3, repeat: Infinity, delay: index * 0.2 }}
      />
      
      {/* Glow */}
      <motion.circle
        cx={node.x}
        cy={node.y}
        r={size * 1.5}
        fill="url(#nodeGradient)"
        filter="url(#nodeGlow)"
        animate={isInView ? { opacity: [0.5, 1, 0.5] } : {}}
        transition={{ duration: 2, repeat: Infinity, delay: index * 0.15 }}
      />
      
      {/* Core */}
      <motion.circle
        cx={node.x}
        cy={node.y}
        r={size}
        fill="#FFFFFF"
        animate={isInView ? {
          fill: ['#FFFFFF', '#F7D878', '#FFFFFF'],
          r: [size, size * 1.2, size]
        } : {}}
        transition={{ duration: 2, repeat: Infinity, delay: index * 0.15 }}
      />
      
      {/* Label */}
      <motion.text
        x={node.x}
        y={node.y - size - 3}
        textAnchor="middle"
        fill="#F7D878"
        fontSize="3"
        fontWeight="400"
        letterSpacing="0.1"
        initial={{ opacity: 0 }}
        animate={isInView ? { opacity: 1 } : {}}
        transition={{ delay: index * 0.1 + 1 }}
      >
        {node.name}
      </motion.text>
    </motion.g>
  );
}

// Holographic globe grid
function HolographicGlobe({ isInView }) {
  return (
    <g opacity="0.3">
      {/* Latitude lines */}
      {[30, 45, 60, 75].map((y, i) => (
        <motion.ellipse
          key={`lat-${i}`}
          cx="52"
          cy={y}
          rx={48 - (Math.abs(y - 52) * 0.8)}
          ry="3"
          fill="none"
          stroke="#D4AF37"
          strokeWidth="0.15"
          strokeDasharray="2 3"
          initial={{ opacity: 0, pathLength: 0 }}
          animate={isInView ? { opacity: 0.4, pathLength: 1 } : {}}
          transition={{ duration: 2, delay: i * 0.1 }}
        />
      ))}
      
      {/* Longitude arcs */}
      {[...Array(8)].map((_, i) => {
        const x = 20 + i * 10;
        return (
          <motion.path
            key={`lon-${i}`}
            d={`M ${x} 25 Q ${x + (i < 4 ? -5 : 5)} 52 ${x} 80`}
            fill="none"
            stroke="#D4AF37"
            strokeWidth="0.15"
            strokeDasharray="1 2"
            initial={{ opacity: 0, pathLength: 0 }}
            animate={isInView ? { opacity: 0.3, pathLength: 1 } : {}}
            transition={{ duration: 1.5, delay: i * 0.08 }}
          />
        );
      })}
      
      {/* Globe outline */}
      <motion.ellipse
        cx="52"
        cy="52"
        rx="42"
        ry="35"
        fill="none"
        stroke="url(#globeGradient)"
        strokeWidth="0.5"
        initial={{ opacity: 0 }}
        animate={isInView ? { opacity: 0.5 } : {}}
        transition={{ duration: 1 }}
      />
    </g>
  );
}

// Floating particles
function FloatingParticles({ isInView }) {
  const particles = React.useMemo(() => 
    [...Array(30)].map(() => ({
      x: 10 + Math.random() * 80,
      y: 20 + Math.random() * 65,
      size: 0.3 + Math.random() * 0.5,
      delay: Math.random() * 5,
      duration: 4 + Math.random() * 3
    })), []);

  return (
    <g>
      {particles.map((p, i) => (
        <motion.circle
          key={i}
          cx={p.x}
          cy={p.y}
          r={p.size}
          fill="#D4AF37"
          initial={{ opacity: 0 }}
          animate={isInView ? {
            opacity: [0, 0.8, 0],
            y: [p.y, p.y - 10, p.y]
          } : {}}
          transition={{
            duration: p.duration,
            delay: p.delay,
            repeat: Infinity
          }}
        />
      ))}
    </g>
  );
}

export default function SmartphoneNetworkHero() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [activeNode, setActiveNode] = useState(null);

  return (
    <section ref={ref} className="relative py-24 overflow-hidden bg-black">
      {/* Background effects */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(212,175,55,0.08)_0%,_transparent_60%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_70%,_rgba(0,180,216,0.04)_0%,_transparent_40%)]" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <div className="flex justify-center items-center">
          
          {/* Holographic Network Only */}
          <motion.div
            className="relative flex justify-center items-center"
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 1 }}
          >
            {/* Holographic glow background */}
            <motion.div
              className="absolute inset-0 flex items-center justify-center"
              animate={{
                opacity: [0.3, 0.6, 0.3]
              }}
              transition={{ duration: 4, repeat: Infinity }}
            >
              <div className="w-[700px] h-[700px] rounded-full bg-[radial-gradient(circle,_rgba(212,175,55,0.15)_0%,_rgba(212,175,55,0.05)_40%,_transparent_70%)]" />
            </motion.div>

            {/* Holographic projection */}
            <motion.div
              className="relative w-[700px] h-[500px]"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={isInView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 1.2, delay: 0.3 }}
            >
              {/* Network SVG */}
              <svg
                viewBox="0 0 100 100"
                className="w-full h-full"
                style={{ filter: 'drop-shadow(0 0 15px rgba(212,175,55,0.4))' }}
              >
                <defs>
                  <linearGradient id="primaryGlow" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#D4AF37" stopOpacity="0.3" />
                    <stop offset="50%" stopColor="#F7D878" stopOpacity="0.8" />
                    <stop offset="100%" stopColor="#D4AF37" stopOpacity="0.3" />
                  </linearGradient>
                  
                  <linearGradient id="secondaryGlow" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#D4AF37" stopOpacity="0.1" />
                    <stop offset="50%" stopColor="#D4AF37" stopOpacity="0.4" />
                    <stop offset="100%" stopColor="#D4AF37" stopOpacity="0.1" />
                  </linearGradient>
                  
                  <linearGradient id="globeGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#00B4D8" stopOpacity="0.3" />
                    <stop offset="50%" stopColor="#D4AF37" stopOpacity="0.5" />
                    <stop offset="100%" stopColor="#00B4D8" stopOpacity="0.3" />
                  </linearGradient>
                  
                  <radialGradient id="nodeGradient" cx="50%" cy="50%" r="50%">
                    <stop offset="0%" stopColor="#FFFFFF" />
                    <stop offset="50%" stopColor="#F7D878" />
                    <stop offset="100%" stopColor="#D4AF37" stopOpacity="0" />
                  </radialGradient>
                  
                  <filter id="lineGlow" x="-50%" y="-50%" width="200%" height="200%">
                    <feGaussianBlur stdDeviation="1.5" result="blur" />
                    <feMerge>
                      <feMergeNode in="blur" />
                      <feMergeNode in="SourceGraphic" />
                    </feMerge>
                  </filter>
                  
                  <filter id="nodeGlow" x="-100%" y="-100%" width="300%" height="300%">
                    <feGaussianBlur stdDeviation="2" result="blur" />
                    <feMerge>
                      <feMergeNode in="blur" />
                      <feMergeNode in="blur" />
                      <feMergeNode in="SourceGraphic" />
                    </feMerge>
                  </filter>
                  
                  <filter id="pulseGlow" x="-200%" y="-200%" width="500%" height="500%">
                    <feGaussianBlur stdDeviation="2" result="blur" />
                    <feMerge>
                      <feMergeNode in="blur" />
                      <feMergeNode in="SourceGraphic" />
                    </feMerge>
                  </filter>
                </defs>
                
                <HolographicGlobe isInView={isInView} />
                <FloatingParticles isInView={isInView} />
                
                {connections.map((conn, i) => (
                  <ConnectionLine
                    key={`${conn.from}-${conn.to}`}
                    connection={conn}
                    index={i}
                    isInView={isInView}
                  />
                ))}
                
                {networkNodes.map((node, i) => (
                  <NetworkNode
                    key={node.id}
                    node={node}
                    index={i}
                    isInView={isInView}
                  />
                ))}
              </svg>
            </motion.div>
          </motion.div>


        </div>
      </div>
    </section>
  );
}