import React, { useEffect, useState, useRef, useMemo } from 'react';
import { motion, useInView } from 'framer-motion';
import { useAccountType } from '@/components/AccountTypeContext';

// 19+ Country nodes with precise coordinates
const countryNodes = [
  { id: 'usa', name: 'USA', lat: 38, lng: -97, tier: 1 },
  { id: 'canada', name: 'Canada', lat: 56, lng: -106, tier: 2 },
  { id: 'brazil', name: 'Brazil', lat: -14, lng: -51, tier: 2 },
  { id: 'mexico', name: 'Mexico', lat: 23, lng: -102, tier: 3 },
  { id: 'uk', name: 'UK', lat: 55, lng: -3, tier: 1 },
  { id: 'germany', name: 'Germany', lat: 51, lng: 10, tier: 1 },
  { id: 'france', name: 'France', lat: 46, lng: 2, tier: 2 },
  { id: 'switzerland', name: 'Switzerland', lat: 47, lng: 8, tier: 1 },
  { id: 'uae', name: 'UAE', lat: 24, lng: 54, tier: 1 },
  { id: 'saudi', name: 'Saudi Arabia', lat: 24, lng: 45, tier: 2 },
  { id: 'southafrica', name: 'South Africa', lat: -30, lng: 25, tier: 3 },
  { id: 'nigeria', name: 'Nigeria', lat: 10, lng: 8, tier: 3 },
  { id: 'india', name: 'India', lat: 21, lng: 78, tier: 1 },
  { id: 'china', name: 'China', lat: 35, lng: 105, tier: 1 },
  { id: 'hongkong', name: 'Hong Kong', lat: 22, lng: 114, tier: 1 },
  { id: 'singapore', name: 'Singapore', lat: 1, lng: 104, tier: 1 },
  { id: 'japan', name: 'Japan', lat: 36, lng: 138, tier: 2 },
  { id: 'korea', name: 'South Korea', lat: 36, lng: 128, tier: 2 },
  { id: 'australia', name: 'Australia', lat: -25, lng: 134, tier: 2 },
];

// Transaction routes
const routes = [
  { from: 'switzerland', to: 'usa', primary: true },
  { from: 'switzerland', to: 'hongkong', primary: true },
  { from: 'usa', to: 'china', primary: true },
  { from: 'hongkong', to: 'singapore', primary: true },
  { from: 'singapore', to: 'india', primary: true },
  { from: 'india', to: 'uae', primary: true },
  { from: 'uae', to: 'switzerland', primary: true },
  { from: 'uk', to: 'usa' },
  { from: 'germany', to: 'china' },
  { from: 'japan', to: 'usa' },
  { from: 'australia', to: 'singapore' },
  { from: 'brazil', to: 'uk' },
  { from: 'saudi', to: 'india' },
  { from: 'korea', to: 'japan' },
  { from: 'france', to: 'uae' },
  { from: 'canada', to: 'uk' },
  { from: 'mexico', to: 'brazil' },
  { from: 'nigeria', to: 'uk' },
  { from: 'southafrica', to: 'uae' },
];

// Convert lat/lng to 3D coordinates
const latLngTo3D = (lat, lng, radius = 40) => {
  const phi = (90 - lat) * (Math.PI / 180);
  const theta = (lng + 180) * (Math.PI / 180);
  return {
    x: -(radius * Math.sin(phi) * Math.cos(theta)),
    y: radius * Math.cos(phi),
    z: radius * Math.sin(phi) * Math.sin(theta)
  };
};

// Project 3D to 2D with rotation
const project3D = (x, y, z, rotationY, rotationX = 12) => {
  const cosY = Math.cos(rotationY);
  const sinY = Math.sin(rotationY);
  let x1 = x * cosY - z * sinY;
  let z1 = x * sinY + z * cosY;
  
  const cosX = Math.cos(rotationX * Math.PI / 180);
  const sinX = Math.sin(rotationX * Math.PI / 180);
  let y1 = y * cosX - z1 * sinX;
  let z2 = y * sinX + z1 * cosX;
  
  const scale = 200 / (200 + z2);
  return {
    x: 50 + x1 * scale,
    y: 50 + y1 * scale,
    z: z2,
    scale,
    visible: z2 < 30
  };
};

// Floating gold particles around globe
function FloatingParticles({ isInView }) {
  const particles = useMemo(() => {
    return Array.from({ length: 60 }, (_, i) => ({
      id: i,
      x: 10 + Math.random() * 80,
      y: 10 + Math.random() * 80,
      size: 0.2 + Math.random() * 0.5,
      duration: 3 + Math.random() * 4,
      delay: Math.random() * 3,
      isGold: Math.random() > 0.3
    }));
  }, []);

  return (
    <g>
      {particles.map(particle => (
        <motion.circle
          key={particle.id}
          cx={particle.x}
          cy={particle.y}
          r={particle.size}
          fill={particle.isGold ? "#ffd700" : "#e8e8e8"}
          initial={{ opacity: 0 }}
          animate={isInView ? {
            opacity: [0, 0.8, 0],
            y: [particle.y, particle.y - 15, particle.y - 30],
            x: [particle.x, particle.x + (Math.random() - 0.5) * 10, particle.x + (Math.random() - 0.5) * 20]
          } : { opacity: 0 }}
          transition={{
            duration: particle.duration,
            delay: particle.delay,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      ))}
    </g>
  );
}

// Micro particles floating around globe surface
function MicroParticles({ rotation, isInView }) {
  const particles = useMemo(() => {
    return Array.from({ length: 50 }, (_, i) => ({
      id: i,
      lat: Math.random() * 160 - 80,
      lng: Math.random() * 360,
      size: 0.25 + Math.random() * 0.45,
      speed: 0.4 + Math.random() * 1.2,
      offset: Math.random() * Math.PI * 2,
      isGold: Math.random() > 0.4
    }));
  }, []);

  return (
    <g>
      {particles.map(particle => {
        const pos3d = latLngTo3D(particle.lat, particle.lng, 43 + Math.sin(Date.now() / 1000 * particle.speed + particle.offset) * 2);
        const projected = project3D(pos3d.x, pos3d.y, pos3d.z, rotation);
        
        if (!projected.visible || projected.scale < 0.5) return null;
        
        return (
          <motion.circle
            key={particle.id}
            cx={projected.x}
            cy={projected.y}
            r={particle.size * projected.scale}
            fill={particle.isGold ? "#ffd700" : "#e0e0e0"}
            opacity={0.4 * projected.scale}
            animate={{
              opacity: [0.2, 0.7, 0.2],
            }}
            transition={{
              duration: particle.speed,
              repeat: Infinity,
              delay: particle.offset
            }}
          />
        );
      })}
    </g>
  );
}

// Globe wireframe with golden orbit lines
function GlobeWireframe({ rotation, isInView }) {
  const lines = useMemo(() => {
    const result = [];
    
    // Latitude lines
    for (let lat = -60; lat <= 60; lat += 20) {
      const points = [];
      for (let lng = 0; lng <= 360; lng += 6) {
        const pos3d = latLngTo3D(lat, lng);
        points.push(pos3d);
      }
      result.push({ type: 'lat', points });
    }
    
    // Longitude lines
    for (let lng = 0; lng < 360; lng += 20) {
      const points = [];
      for (let lat = -80; lat <= 80; lat += 6) {
        const pos3d = latLngTo3D(lat, lng);
        points.push(pos3d);
      }
      result.push({ type: 'lng', points });
    }
    
    return result;
  }, []);

  return (
    <g>
      {lines.map((line, i) => {
        const projectedPoints = line.points.map(p => project3D(p.x, p.y, p.z, rotation));
        
        let pathD = '';
        let isDrawing = false;
        
        projectedPoints.forEach((point) => {
          if (point.visible) {
            if (!isDrawing) {
              pathD += `M ${point.x} ${point.y} `;
              isDrawing = true;
            } else {
              pathD += `L ${point.x} ${point.y} `;
            }
          } else {
            isDrawing = false;
          }
        });
        
        if (!pathD) return null;
        
        return (
          <path
            key={i}
            d={pathD}
            fill="none"
            stroke="url(#gridGradient)"
            strokeWidth="0.15"
            opacity={0.3}
          />
        );
      })}
    </g>
  );
}

// Animated orbital rings
function OrbitalRings({ rotation, isInView }) {
  const rings = useMemo(() => {
    return [
      { tiltX: 25, tiltZ: 0, radius: 43, speed: 1.8 },
      { tiltX: -35, tiltZ: 60, radius: 44, speed: 2.2 },
      { tiltX: 50, tiltZ: 120, radius: 42, speed: 2.5 },
      { tiltX: -15, tiltZ: 45, radius: 45, speed: 1.5 },
    ];
  }, []);

  return (
    <g>
      {rings.map((ring, ringIndex) => {
        const points = [];
        for (let angle = 0; angle <= 360; angle += 4) {
          const rad = angle * Math.PI / 180;
          const tiltXRad = ring.tiltX * Math.PI / 180;
          const tiltZRad = ring.tiltZ * Math.PI / 180;
          
          let x = ring.radius * Math.cos(rad);
          let y = 0;
          let z = ring.radius * Math.sin(rad);
          
          const y1 = y * Math.cos(tiltXRad) - z * Math.sin(tiltXRad);
          const z1 = y * Math.sin(tiltXRad) + z * Math.cos(tiltXRad);
          const x2 = x * Math.cos(tiltZRad) - y1 * Math.sin(tiltZRad);
          const y2 = x * Math.sin(tiltZRad) + y1 * Math.cos(tiltZRad);
          
          points.push({ x: x2, y: y2, z: z1 });
        }

        const projectedPoints = points.map(p => project3D(p.x, p.y, p.z, rotation));
        
        let pathD = '';
        let visibleSegments = [];
        let currentSegment = [];
        
        projectedPoints.forEach((point) => {
          if (point.z < 38) {
            currentSegment.push(point);
          } else {
            if (currentSegment.length > 0) {
              visibleSegments.push([...currentSegment]);
              currentSegment = [];
            }
          }
        });
        if (currentSegment.length > 0) visibleSegments.push(currentSegment);
        
        visibleSegments.forEach(segment => {
          segment.forEach((point, i) => {
            pathD += i === 0 ? `M ${point.x} ${point.y} ` : `L ${point.x} ${point.y} `;
          });
        });
        
        if (!pathD) return null;
        
        return (
          <g key={ringIndex}>
            <motion.path
              d={pathD}
              fill="none"
              stroke={`url(#orbitGradient)`}
              strokeWidth="0.35"
              strokeLinecap="round"
              initial={{ opacity: 0 }}
              animate={isInView ? { opacity: 0.6 } : { opacity: 0 }}
              transition={{ duration: 1, delay: ringIndex * 0.2 }}
            />
            
            {/* Gentle traveling light */}
            {isInView && pathD && (
              <motion.circle
                r="0.8"
                fill="#d1a954"
                filter="url(#particleGlow)"
                animate={{
                  opacity: [0, 0.6, 0.6, 0],
                  offsetDistance: ['0%', '100%']
                }}
                transition={{
                  duration: ring.speed * 2,
                  delay: ringIndex * 0.8,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
                style={{ offsetPath: `path('${pathD}')` }}
              />
            )}
          </g>
        );
      })}
    </g>
  );
}

// Transaction node with neon pulse effect
function TransactionNode({ node, rotation, isInView, pulseActive, isBusiness = false }) {
  const pos3d = latLngTo3D(node.lat, node.lng);
  const projected = project3D(pos3d.x, pos3d.y, pos3d.z, rotation);
  
  if (!projected.visible) return null;
  
  // Business mode: larger, more prominent nodes for financial hubs
  const baseSize = isBusiness 
    ? (node.tier === 1 ? 2.5 : node.tier === 2 ? 1.8 : 1.3)
    : (node.tier === 1 ? 2 : node.tier === 2 ? 1.5 : 1.1);
  const size = baseSize * projected.scale;
  const isGold = node.tier === 1 || node.tier === 3;
  
  return (
    <g>
      {/* Outer pulse ring - more intense for business */}
      <motion.circle
        cx={projected.x}
        cy={projected.y}
        r={size * 2.5}
        fill="none"
        stroke={isGold ? "#d1a954" : "#b0b0b0"}
        strokeWidth={isBusiness ? "0.4" : "0.25"}
        filter={isBusiness && node.tier === 1 ? "url(#businessNodeGlow)" : undefined}
        animate={{
          r: [size * 2, size * (isBusiness ? 4 : 3.5), size * 2],
          opacity: [isBusiness ? 0.6 : 0.4, 0, isBusiness ? 0.6 : 0.4]
        }}
        transition={{ duration: isBusiness ? 2 : 3, repeat: Infinity, ease: "easeInOut" }}
      />
      
      {/* Soft glow effect */}
      <circle
        cx={projected.x}
        cy={projected.y}
        r={size * 2}
        fill={isGold ? "url(#nodeGlow)" : "url(#silverNodeGlow)"}
        opacity={0.4 * projected.scale}
      />
      
      {/* Arrival pulse ring - shows when gold bar/token arrives */}
      {pulseActive && (
        <motion.circle
          cx={projected.x}
          cy={projected.y}
          r={size * 2}
          fill="none"
          stroke="#d1a954"
          strokeWidth="0.4"
          initial={{ r: size, opacity: 1 }}
          animate={{ r: size * 4, opacity: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        />
      )}
      
      {/* Main node - refined, institutional */}
      <motion.circle
        cx={projected.x}
        cy={projected.y}
        r={size}
        fill={isGold ? "#d1a954" : "#c8c8c8"}
        filter="url(#nodeFilter)"
        animate={pulseActive ? {
          r: [size, size * 1.5, size],
          fill: ['#d1a954', '#f5e6c8', '#d1a954']
        } : {}}
        transition={{ duration: 0.8, ease: "easeOut" }}
      />
      
      {/* Inner core */}
      <circle
        cx={projected.x}
        cy={projected.y}
        r={size * 0.4}
        fill="#ffffff"
        opacity={0.7}
      />
    </g>
  );
}

// Animated transaction route
function TransactionRoute({ from, to, rotation, isInView, delay, isPrimary, i = 0, isBusiness = false }) {
  const fromPos = latLngTo3D(from.lat, from.lng);
  const toPos = latLngTo3D(to.lat, to.lng);
  
  const arcPoints = useMemo(() => {
    const points = [];
    const steps = 30;
    
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      const x = fromPos.x * (1 - t) + toPos.x * t;
      const y = fromPos.y * (1 - t) + toPos.y * t;
      const z = fromPos.z * (1 - t) + toPos.z * t;
      
      const len = Math.sqrt(x * x + y * y + z * z);
      const height = 1 + Math.sin(t * Math.PI) * 0.18;
      
      points.push({
        x: (x / len) * 40 * height,
        y: (y / len) * 40 * height,
        z: (z / len) * 40 * height
      });
    }
    return points;
  }, [fromPos, toPos]);
  
  const projectedArc = arcPoints.map(p => project3D(p.x, p.y, p.z, rotation));
  const visibleCount = projectedArc.filter(p => p.visible).length;
  if (visibleCount < 15) return null;
  
  let pathD = '';
  let started = false;
  projectedArc.forEach((point) => {
    if (point.visible) {
      pathD += !started ? `M ${point.x} ${point.y} ` : `L ${point.x} ${point.y} `;
      started = true;
    }
  });
  
  if (!pathD) return null;
  
  // Business mode: thicker routes, faster animations
  const routeWidth = isBusiness ? (isPrimary ? 0.8 : 0.5) : (isPrimary ? 0.5 : 0.3);
  const routeOpacity = isBusiness ? (isPrimary ? 0.9 : 0.6) : (isPrimary ? 0.7 : 0.4);
  const travelDuration = isBusiness ? (isPrimary ? 2.5 : 3.5) : (isPrimary ? 4 : 5);
  const repeatDelay = isBusiness ? (isPrimary ? 1 : 1.5) : (isPrimary ? 2 : 3);
  
  return (
    <g>
      {/* Route path */}
      <motion.path
        d={pathD}
        fill="none"
        stroke={isPrimary ? (isBusiness ? "url(#businessRouteGradient)" : "url(#primaryRouteGradient)") : "url(#routeGradient)"}
        strokeWidth={routeWidth}
        strokeLinecap="round"
        filter={isBusiness && isPrimary ? "url(#neonGlow)" : undefined}
        initial={{ pathLength: 0, opacity: 0 }}
        animate={isInView ? { pathLength: 1, opacity: routeOpacity } : { pathLength: 0, opacity: 0 }}
        transition={{ duration: isBusiness ? 1.2 : 2, delay, ease: "easeOut" }}
      />
      
      {/* BUSINESS MODE: Container Ship Icon on primary routes */}
      {isInView && pathD && isPrimary && isBusiness && (
        <motion.g
          animate={{ offsetDistance: ['0%', '100%'] }}
          transition={{
            duration: travelDuration,
            delay: delay + 0.3,
            repeat: Infinity,
            repeatDelay: repeatDelay,
            ease: "easeInOut"
          }}
          style={{ offsetPath: `path('${pathD}')`, offsetRotate: '0deg' }}
        >
          <motion.g
            animate={{ opacity: [0, 1, 1, 0] }}
            transition={{
              duration: travelDuration,
              delay: delay + 0.3,
              repeat: Infinity,
              repeatDelay: repeatDelay,
              ease: "easeInOut"
            }}
          >
            {/* Container ship body */}
            <path d="M-3,-0.8 L3,-0.8 L2.5,0.8 L-2.5,0.8 Z" fill="#1a1a2e" stroke="#d1a954" strokeWidth="0.2" />
            {/* Ship deck */}
            <rect x="-2.2" y="-1.4" width="4.4" height="0.6" fill="#d1a954" rx="0.1" />
            {/* Containers */}
            <rect x="-1.8" y="-2" width="1" height="0.6" fill="#ffd700" rx="0.05" />
            <rect x="-0.5" y="-2" width="1" height="0.6" fill="#b8860b" rx="0.05" />
            <rect x="0.8" y="-2" width="1" height="0.6" fill="#ffd700" rx="0.05" />
            {/* Ship highlight */}
            <line x1="-2" y1="-1.2" x2="2" y2="-1.2" stroke="#fff" strokeWidth="0.1" opacity="0.5" />
          </motion.g>
        </motion.g>
      )}
      
      {/* BUSINESS MODE: LC Document Icon on secondary routes */}
      {isInView && pathD && !isPrimary && isBusiness && (
        <motion.g
          animate={{ offsetDistance: ['0%', '100%'] }}
          transition={{
            duration: travelDuration + 1,
            delay: delay + 0.8,
            repeat: Infinity,
            repeatDelay: repeatDelay + 0.5,
            ease: "easeInOut"
          }}
          style={{ offsetPath: `path('${pathD}')`, offsetRotate: '0deg' }}
        >
          <motion.g
            animate={{ opacity: [0, 1, 1, 0] }}
            transition={{
              duration: travelDuration + 1,
              delay: delay + 0.8,
              repeat: Infinity,
              repeatDelay: repeatDelay + 0.5,
              ease: "easeInOut"
            }}
          >
            {/* Document body */}
            <rect x="-1.5" y="-2" width="3" height="4" fill="#0d0515" stroke="#d1a954" strokeWidth="0.2" rx="0.2" />
            {/* Document fold corner */}
            <path d="M0.8,-2 L1.5,-2 L1.5,-1.3 Z" fill="#d1a954" />
            {/* LC text lines */}
            <line x1="-1" y1="-1" x2="0.5" y2="-1" stroke="#d1a954" strokeWidth="0.15" />
            <line x1="-1" y1="-0.4" x2="1" y2="-0.4" stroke="#ffd700" strokeWidth="0.1" opacity="0.7" />
            <line x1="-1" y1="0.1" x2="0.8" y2="0.1" stroke="#ffd700" strokeWidth="0.1" opacity="0.7" />
            {/* Gold seal */}
            <circle cx="0" cy="1" r="0.6" fill="#d1a954" />
            <circle cx="0" cy="1" r="0.35" fill="#ffd700" />
          </motion.g>
        </motion.g>
      )}
      
      {/* PERSONAL MODE: 3D Gold Bar traveling along primary routes */}
      {isInView && pathD && isPrimary && !isBusiness && (
        <motion.g
          animate={{ offsetDistance: ['0%', '100%'] }}
          transition={{
            duration: travelDuration,
            delay: delay + 0.5,
            repeat: Infinity,
            repeatDelay: repeatDelay,
            ease: "easeInOut"
          }}
          style={{ offsetPath: `path('${pathD}')`, offsetRotate: '0deg' }}
        >
          <motion.g
            animate={{ opacity: [0, 1, 1, 0] }}
            transition={{
              duration: travelDuration,
              delay: delay + 0.5,
              repeat: Infinity,
              repeatDelay: repeatDelay,
              ease: "easeInOut"
            }}
          >
            {/* Gold bar shadow */}
            <rect x="-2.5" y="-0.8" width="5" height="2" rx="0.3" fill="#000" opacity="0.3" transform="translate(0.3, 0.3)" />
            {/* Gold bar base */}
            <rect x="-2.5" y="-0.8" width="5" height="2" rx="0.3" fill="#b8860b" />
            {/* Gold bar top face (3D effect) */}
            <rect x="-2.3" y="-1" width="4.6" height="1.6" rx="0.2" fill="#d1a954" />
            {/* Gold bar highlight */}
            <rect x="-2" y="-0.9" width="3" height="0.4" rx="0.1" fill="#f5e6c8" opacity="0.7" />
            {/* Gold bar shine */}
            <rect x="-1.8" y="-0.8" width="1.5" height="0.2" rx="0.1" fill="#fff" opacity="0.5" />
            {/* Gold bar edge detail */}
            <line x1="-2.3" y1="0.5" x2="2.3" y2="0.5" stroke="#a67c00" strokeWidth="0.15" />
          </motion.g>
        </motion.g>
      )}
      
      {/* PERSONAL MODE: Digital Token on secondary routes */}
      {isInView && pathD && !isPrimary && !isBusiness && (
        <motion.g
          animate={{ offsetDistance: ['0%', '100%'] }}
          transition={{
            duration: travelDuration,
            delay: delay + 1.5,
            repeat: Infinity,
            repeatDelay: repeatDelay,
            ease: "easeInOut"
          }}
          style={{ offsetPath: `path('${pathD}')`, offsetRotate: '0deg' }}
        >
          <motion.g
            animate={{ 
              opacity: [0, 1, 1, 0],
              rotate: [0, 360]
            }}
            transition={{
              opacity: {
                duration: travelDuration,
                delay: delay + 1.5,
                repeat: Infinity,
                repeatDelay: repeatDelay,
                ease: "easeInOut"
              },
              rotate: {
                duration: 3,
                repeat: Infinity,
                ease: "linear"
              }
            }}
          >
            {/* Token outer ring */}
            <circle r="1.8" fill="none" stroke="#d1a954" strokeWidth="0.3" />
            {/* Token body */}
            <circle r="1.4" fill="url(#tokenGradient)" />
            {/* Token inner design */}
            <circle r="0.9" fill="none" stroke="#f5e6c8" strokeWidth="0.15" />
            {/* Token center */}
            <circle r="0.4" fill="#fff" opacity="0.8" />
            {/* Token shine */}
            <ellipse cx="-0.4" cy="-0.4" rx="0.5" ry="0.3" fill="#fff" opacity="0.3" />
          </motion.g>
        </motion.g>
      )}
    </g>
  );
}

export default function GlobalPaymentRouting() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });
  const [rotation, setRotation] = useState(0);
  const [activeNodes, setActiveNodes] = useState(new Set());
  
  // Get account type context
  const { accountType } = useAccountType() || { accountType: 'personal' };
  const isBusiness = accountType === 'business';

  // Rotation speed based on mode
  useEffect(() => {
    if (!isInView) return;
    
    let animationId;
    const animate = () => {
      // Business mode: faster rotation for enterprise feel
      setRotation(prev => prev + (isBusiness ? 0.004 : 0.002));
      animationId = requestAnimationFrame(animate);
    };
    animationId = requestAnimationFrame(animate);
    
    return () => cancelAnimationFrame(animationId);
  }, [isInView, isBusiness]);

  // Settlement arrival pulses
  useEffect(() => {
    if (!isInView) return;
    
    // Business mode: more frequent pulses at key financial hubs
    const hubNodes = isBusiness 
      ? ['uae', 'hongkong', 'singapore', 'uk', 'india', 'nigeria']
      : ['usa', 'hongkong', 'singapore', 'uae', 'switzerland'];
    
    const interval = setInterval(() => {
      const destinationNodes = hubNodes
        .sort(() => Math.random() - 0.5)
        .slice(0, isBusiness ? 3 : 2);
      
      setActiveNodes(new Set(destinationNodes));
      setTimeout(() => setActiveNodes(new Set()), isBusiness ? 600 : 800);
    }, isBusiness ? 2000 : 3000);
    
    return () => clearInterval(interval);
  }, [isInView, isBusiness]);

  const getNode = (id) => countryNodes.find(n => n.id === id);

  return (
    <section 
      ref={ref} 
      className="relative py-28 overflow-hidden"
      style={{
        background: 'linear-gradient(180deg, #000000 0%, #0d0515 40%, #1a0a2e 100%)'
      }}
    >
      {/* High contrast depth lighting */}
      <div className="absolute inset-0">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] rounded-full bg-[radial-gradient(circle,_rgba(209,169,84,0.15)_0%,_rgba(209,169,84,0.05)_40%,_transparent_70%)] blur-2xl" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full bg-[radial-gradient(circle,_rgba(255,215,0,0.1)_0%,_transparent_60%)] blur-xl" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] h-[300px] rounded-full bg-[radial-gradient(circle,_rgba(255,255,255,0.05)_0%,_transparent_50%)]" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        {/* Header - different for Business vs Personal */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 1 }}
          className="text-center mb-16"
        >
          <p className="text-[#d1a954] text-sm tracking-[0.4em] uppercase mb-4 font-light">
            {isBusiness ? 'Enterprise Infrastructure' : 'Global Infrastructure'}
          </p>
          <h2 className="text-4xl md:text-5xl font-extralight text-white mb-4">
            {isBusiness ? (
              <>Global Business <span className="text-[#d1a954]">Settlements</span></>
            ) : (
              'Worldwide Settlement Network'
            )}
          </h2>
          {isBusiness && (
            <p className="text-gray-400 text-lg font-light mb-4">
              Import & Export Powered by Gold
            </p>
          )}
          <div className="w-32 h-[1px] bg-gradient-to-r from-transparent via-[#d1a954] to-transparent mx-auto" />
        </motion.div>

        {/* Globe Container */}
        <div className="relative aspect-square max-w-2xl mx-auto">
          <svg
            viewBox="0 0 100 100"
            className="w-full h-full"
            preserveAspectRatio="xMidYMid meet"
          >
            <defs>
              {/* Glass sphere gradient */}
              <radialGradient id="globeGradient" cx="30%" cy="25%" r="70%">
                <stop offset="0%" stopColor="#1a1a2e" stopOpacity="0.9" />
                <stop offset="40%" stopColor="#0a0a15" stopOpacity="0.95" />
                <stop offset="100%" stopColor="#000000" stopOpacity="1" />
              </radialGradient>
              
              {/* Glass highlight */}
              <radialGradient id="glassHighlight" cx="30%" cy="20%" r="50%">
                <stop offset="0%" stopColor="#ffffff" stopOpacity="0.15" />
                <stop offset="50%" stopColor="#ffffff" stopOpacity="0.05" />
                <stop offset="100%" stopColor="#ffffff" stopOpacity="0" />
              </radialGradient>
              
              {/* Glass reflection */}
              <linearGradient id="glassReflection" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#ffffff" stopOpacity="0.1" />
                <stop offset="50%" stopColor="#ffffff" stopOpacity="0" />
                <stop offset="100%" stopColor="#d1a954" stopOpacity="0.05" />
              </linearGradient>
              
              {/* Grid gradient - neon gold */}
              <linearGradient id="gridGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#d1a954" stopOpacity="0.5" />
                <stop offset="50%" stopColor="#ffd700" stopOpacity="0.3" />
                <stop offset="100%" stopColor="#d1a954" stopOpacity="0.5" />
              </linearGradient>
              
              {/* Orbit gradient - neon */}
              <linearGradient id="orbitGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#d1a954" stopOpacity="0" />
                <stop offset="30%" stopColor="#ffd700" stopOpacity="0.8" />
                <stop offset="50%" stopColor="#ffffff" stopOpacity="1" />
                <stop offset="70%" stopColor="#ffd700" stopOpacity="0.8" />
                <stop offset="100%" stopColor="#d1a954" stopOpacity="0" />
              </linearGradient>
              
              {/* Neon gold route */}
              <linearGradient id="routeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#d1a954" stopOpacity="0.1" />
                <stop offset="50%" stopColor="#ffd700" stopOpacity="0.7" />
                <stop offset="100%" stopColor="#d1a954" stopOpacity="0.1" />
              </linearGradient>
              
              {/* Neon silver/white primary route */}
              <linearGradient id="primaryRouteGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#c0c0c0" stopOpacity="0.2" />
                <stop offset="30%" stopColor="#e8e8e8" stopOpacity="0.8" />
                <stop offset="50%" stopColor="#ffffff" stopOpacity="1" />
                <stop offset="70%" stopColor="#e8e8e8" stopOpacity="0.8" />
                <stop offset="100%" stopColor="#c0c0c0" stopOpacity="0.2" />
              </linearGradient>
              
              {/* Silver route */}
              <linearGradient id="silverRouteGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#a0a0a0" stopOpacity="0.1" />
                <stop offset="50%" stopColor="#e0e0e0" stopOpacity="0.6" />
                <stop offset="100%" stopColor="#a0a0a0" stopOpacity="0.1" />
              </linearGradient>
              
              {/* Node glow - intense neon */}
              <radialGradient id="nodeGlow" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#ffd700" stopOpacity="1" />
                <stop offset="40%" stopColor="#d1a954" stopOpacity="0.5" />
                <stop offset="100%" stopColor="#d1a954" stopOpacity="0" />
              </radialGradient>
              
              {/* Silver node glow */}
              <radialGradient id="silverNodeGlow" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#ffffff" stopOpacity="1" />
                <stop offset="40%" stopColor="#c0c0c0" stopOpacity="0.5" />
                <stop offset="100%" stopColor="#808080" stopOpacity="0" />
              </radialGradient>
              
              {/* Globe rim - glass effect */}
              <linearGradient id="rimGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#ffffff" stopOpacity="0.4" />
                <stop offset="25%" stopColor="#d1a954" stopOpacity="0.6" />
                <stop offset="50%" stopColor="#ffffff" stopOpacity="0.2" />
                <stop offset="75%" stopColor="#d1a954" stopOpacity="0.6" />
                <stop offset="100%" stopColor="#ffffff" stopOpacity="0.4" />
              </linearGradient>
              
              {/* Inner rim glow */}
              <linearGradient id="innerRimGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#ffd700" stopOpacity="0.3" />
                <stop offset="50%" stopColor="#ffffff" stopOpacity="0.1" />
                <stop offset="100%" stopColor="#ffd700" stopOpacity="0.3" />
              </linearGradient>
              
              {/* Filters */}
              <filter id="nodeFilter" x="-100%" y="-100%" width="300%" height="300%">
                <feGaussianBlur stdDeviation="0.8" result="blur" />
                <feMerge>
                  <feMergeNode in="blur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
              
              <filter id="particleGlow" x="-200%" y="-200%" width="500%" height="500%">
                <feGaussianBlur stdDeviation="2" result="blur" />
                <feMerge>
                  <feMergeNode in="blur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
              
              <filter id="neonGlow" x="-300%" y="-300%" width="700%" height="700%">
                <feGaussianBlur stdDeviation="2.5" result="blur" />
                <feComposite in="blur" in2="SourceGraphic" operator="over" />
              </filter>
              
              <filter id="globeShadow" x="-50%" y="-50%" width="200%" height="200%">
                <feDropShadow dx="0" dy="0" stdDeviation="6" floodColor="#d1a954" floodOpacity="0.3" />
              </filter>
              
              <filter id="glassBlur" x="-10%" y="-10%" width="120%" height="120%">
                <feGaussianBlur stdDeviation="0.3" />
              </filter>
              
              {/* Token gradient */}
              <radialGradient id="tokenGradient" cx="30%" cy="30%" r="70%">
                <stop offset="0%" stopColor="#f5e6c8" />
                <stop offset="50%" stopColor="#d1a954" />
                <stop offset="100%" stopColor="#a67c00" />
              </radialGradient>
              
              {/* Gold bar 3D gradient */}
              <linearGradient id="goldBarGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#f5e6c8" />
                <stop offset="30%" stopColor="#d1a954" />
                <stop offset="70%" stopColor="#b8860b" />
                <stop offset="100%" stopColor="#8b6914" />
              </linearGradient>
              
              {/* Business mode - intense gold route */}
              <linearGradient id="businessRouteGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#d1a954" stopOpacity="0.3" />
                <stop offset="20%" stopColor="#ffd700" stopOpacity="0.9" />
                <stop offset="50%" stopColor="#ffffff" stopOpacity="1" />
                <stop offset="80%" stopColor="#ffd700" stopOpacity="0.9" />
                <stop offset="100%" stopColor="#d1a954" stopOpacity="0.3" />
              </linearGradient>
              
              {/* Business mode - intense node glow */}
              <filter id="businessNodeGlow" x="-200%" y="-200%" width="500%" height="500%">
                <feGaussianBlur stdDeviation="1.5" result="blur" />
                <feMerge>
                  <feMergeNode in="blur" />
                  <feMergeNode in="blur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
            </defs>

            {/* Outer glow */}
            <circle
              cx="50"
              cy="50"
              r="44"
              fill="none"
              stroke="#d1a954"
              strokeWidth="0.2"
              opacity="0.2"
            />
            
            {/* Globe base - glass sphere */}
            <circle
              cx="50"
              cy="50"
              r="40"
              fill="url(#globeGradient)"
              filter="url(#globeShadow)"
            />
            
            {/* Glass highlight overlay */}
            <circle
              cx="50"
              cy="50"
              r="40"
              fill="url(#glassHighlight)"
            />
            
            {/* Glass reflection arc */}
            <ellipse
              cx="38"
              cy="35"
              rx="18"
              ry="12"
              fill="url(#glassReflection)"
              opacity="0.6"
            />
            
            {/* Globe rim - neon glass effect */}
            <circle
              cx="50"
              cy="50"
              r="40"
              fill="none"
              stroke="url(#rimGradient)"
              strokeWidth="0.6"
            />
            
            {/* Inner rim glow */}
            <circle
              cx="50"
              cy="50"
              r="39.5"
              fill="none"
              stroke="url(#innerRimGradient)"
              strokeWidth="0.3"
            />

            {/* Floating gold particles in background */}
            <FloatingParticles isInView={isInView} />
            
            {/* Wireframe grid */}
            <GlobeWireframe rotation={rotation} isInView={isInView} />
            
            {/* Micro particles on globe surface */}
            <MicroParticles rotation={rotation} isInView={isInView} />
            
            {/* Orbital rings */}
            <OrbitalRings rotation={rotation} isInView={isInView} />

            {/* Transaction routes */}
            {routes.map((route, i) => {
              const fromNode = getNode(route.from);
              const toNode = getNode(route.to);
              if (!fromNode || !toNode) return null;
              
              return (
                <TransactionRoute
                  key={`${route.from}-${route.to}`}
                  from={fromNode}
                  to={toNode}
                  rotation={rotation}
                  isInView={isInView}
                  delay={0.2 + i * (isBusiness ? 0.04 : 0.06)}
                  isPrimary={route.primary}
                  i={i}
                  isBusiness={isBusiness}
                />
              );
            })}

            {/* Transaction nodes */}
            {countryNodes.map((node) => (
              <TransactionNode
                key={node.id}
                node={node}
                rotation={rotation}
                isInView={isInView}
                pulseActive={activeNodes.has(node.id)}
                isBusiness={isBusiness}
              />
            ))}
          </svg>
        </div>

        {/* Stats - different for Business vs Personal */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ delay: 1.5, duration: 1 }}
          className="flex flex-wrap justify-center gap-12 md:gap-20 mt-16"
        >
          {(isBusiness ? [
            { value: '19+', label: 'Trade Corridors' },
            { value: '$18B+', label: 'Monthly Trade Volume' },
            { value: '2,400+', label: 'Active Businesses' },
            { value: '<3s', label: 'LC Settlement' }
          ] : [
            { value: '19+', label: 'Countries' },
            { value: '$18B+', label: 'Monthly Volume' },
            { value: '99.9%', label: 'Uptime' },
            { value: '<3s', label: 'Settlement' }
          ]).map((stat, i) => (
            <motion.div 
              key={i} 
              className="text-center"
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
              transition={{ delay: 1.8 + i * 0.1 }}
            >
              <div className="text-3xl md:text-4xl font-light text-[#d1a954]">{stat.value}</div>
              <div className="text-sm text-gray-500 mt-1 tracking-wide">{stat.label}</div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}