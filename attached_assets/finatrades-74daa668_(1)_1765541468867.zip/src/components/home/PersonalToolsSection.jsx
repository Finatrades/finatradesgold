import React, { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { ArrowLeftRight, Wallet, CreditCard, TrendingUp } from 'lucide-react';

const tools = [
  {
    icon: ArrowLeftRight,
    title: "Money Transfer",
    subtitle: "Send & Receive Money Instantly",
    description: "Fast, secure transfers across borders.",
    page: "FinaPay"
  },
  {
    icon: Wallet,
    title: "Digital Payments",
    subtitle: "Pay Digitally Anywhere",
    description: "Bills, utilities, services—done instantly.",
    page: "FinaPay"
  },
  {
    icon: CreditCard,
    title: "Card Payments & Withdrawals",
    subtitle: "Use Your Card Globally",
    description: "Tap, swipe, and withdraw cash anytime.",
    page: "FinaPay"
  },
  {
    icon: TrendingUp,
    title: "BNSL Earnings",
    subtitle: "Earn with BNSL Plans",
    description: "Grow your gold-backed holdings safely.",
    page: "BNSL"
  }
];

// Floating particles component
function NeonParticles() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {[...Array(20)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-1 h-1 rounded-full"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            background: i % 2 === 0 ? '#8A2BE2' : '#FF2FBF',
            opacity: 0.2 + Math.random() * 0.3,
          }}
          animate={{
            y: [0, -30, 0],
            opacity: [0.2, 0.5, 0.2],
          }}
          transition={{
            duration: 3 + Math.random() * 2,
            repeat: Infinity,
            delay: Math.random() * 2,
            ease: "easeInOut"
          }}
        />
      ))}
    </div>
  );
}

// Grid background
function GridBackground() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-10">
      <div 
        className="absolute inset-0"
        style={{
          backgroundImage: `
            linear-gradient(rgba(138,43,226,0.1) 1px, transparent 1px),
            linear-gradient(90deg, rgba(138,43,226,0.1) 1px, transparent 1px)
          `,
          backgroundSize: '60px 60px'
        }}
      />
    </div>
  );
}

// Tool card component
function ToolCard({ tool, index }) {
  const cardRef = useRef(null);
  const isInView = useInView(cardRef, { once: true, margin: "-50px" });

  return (
    <motion.div
      ref={cardRef}
      initial={{ opacity: 0, y: 40 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, delay: index * 0.15, ease: "easeOut" }}
    >
      <Link to={createPageUrl(tool.page)} onClick={() => window.scrollTo(0, 0)}>
        <motion.div
          className="relative group h-full"
          whileHover={{ y: -8, scale: 1.02 }}
          transition={{ duration: 0.3 }}
        >
          {/* Outer glow on hover */}
          <div className="absolute -inset-0.5 bg-gradient-to-r from-[#8A2BE2]/0 via-[#FF2FBF]/0 to-[#8A2BE2]/0 rounded-[22px] blur-xl group-hover:from-[#8A2BE2]/25 group-hover:via-[#FF2FBF]/35 group-hover:to-[#8A2BE2]/25 transition-all duration-500" />
          
          {/* Card */}
          <div className="relative bg-white rounded-[20px] border border-[#E8E0F0] group-hover:border-[#8A2BE2]/40 p-6 h-full overflow-hidden transition-all duration-300 shadow-[0_8px_32px_rgba(160,50,255,0.08)] group-hover:shadow-[0_12px_48px_rgba(160,50,255,0.18)]">
            
            {/* Inner glow effect */}
            <div className="absolute inset-0 bg-gradient-to-br from-[#8A2BE2]/0 to-[#FF2FBF]/0 group-hover:from-[#8A2BE2]/5 group-hover:to-[#FF2FBF]/5 transition-all duration-500" />
            
            {/* Shimmer effect on hover */}
            <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-transparent via-[#FF2FBF]/10 to-transparent -skew-x-12"
                initial={{ x: '-100%' }}
                whileHover={{ x: '200%' }}
                transition={{ duration: 0.8, ease: "easeInOut" }}
              />
            </div>

            {/* Motion streak */}
            <div className="absolute top-0 right-0 w-32 h-32 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
              <div className="absolute top-4 right-4 w-20 h-[1px] bg-gradient-to-l from-[#FF2FBF]/40 to-transparent rotate-45" />
              <div className="absolute top-8 right-2 w-12 h-[1px] bg-gradient-to-l from-[#8A2BE2]/20 to-transparent rotate-45" />
            </div>

            {/* Content */}
            <div className="relative z-10">
              {/* Icon container */}
              <div className="relative mb-5">
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-[#8A2BE2] via-[#A54CFF] to-[#FF2FBF] p-[1px] group-hover:shadow-[0_0_25px_rgba(255,45,200,0.35)] transition-shadow duration-300">
                  <div className="w-full h-full rounded-xl bg-white flex items-center justify-center">
                    <tool.icon className="w-6 h-6 text-[#8A2BE2] group-hover:text-[#FF2FBF] transition-colors duration-300" />
                  </div>
                </div>
                {/* Icon glow */}
                <div className="absolute -inset-2 bg-[#FF2FBF]/0 group-hover:bg-[#FF2FBF]/10 rounded-2xl blur-xl transition-all duration-500" />
              </div>

              {/* Title */}
              <h3 className="text-lg font-medium text-[#0D0D0D] mb-2 group-hover:bg-gradient-to-r group-hover:from-[#8A2BE2] group-hover:to-[#FF2FBF] group-hover:bg-clip-text group-hover:text-transparent transition-all duration-300">
                {tool.subtitle}
              </h3>

              {/* Description */}
              <p className="text-sm text-[#4A4A4A] group-hover:text-[#333333] transition-colors duration-300">
                {tool.description}
              </p>

              {/* Bottom accent line */}
              <div className="mt-5 h-[2px] bg-gradient-to-r from-[#8A2BE2]/0 via-[#FF2FBF]/30 to-[#8A2BE2]/0 group-hover:via-[#FF2FBF]/60 transition-all duration-300" />
            </div>
          </div>
        </motion.div>
      </Link>
    </motion.div>
  );
}

export default function PersonalToolsSection() {
  const sectionRef = useRef(null);
  const isInView = useInView(sectionRef, { once: true, margin: "-100px" });

  return (
    <section ref={sectionRef} className="relative py-20 bg-gradient-to-b from-[#FAFBFF] via-[#F4F6FC] to-[#FAFBFF] overflow-hidden">
      {/* Background effects */}
      <GridBackground />
      <NeonParticles />
      
      {/* Radial gradient overlay */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(138,43,226,0.06)_0%,_transparent_60%)]" />

      <div className="relative z-10 max-w-6xl mx-auto px-6">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-14"
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={isInView ? { scale: 1, opacity: 1 } : {}}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-[#8A2BE2]/10 to-[#FF2FBF]/10 border border-[#8A2BE2]/30 mb-6"
          >
            <div className="w-2 h-2 rounded-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] animate-pulse" />
            <span className="text-sm bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent tracking-wide">Personal Tools</span>
          </motion.div>
          
          <h2 className="text-3xl md:text-4xl font-extralight text-[#0D0D0D] mb-4">
            Your Financial <span className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent">Toolkit</span>
          </h2>
          <p className="text-[#4A4A4A] max-w-xl mx-auto">
            Everything you need to manage, transfer, and grow your wealth—all in one place.
          </p>
        </motion.div>

        {/* Tools Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {tools.map((tool, index) => (
            <ToolCard key={tool.title} tool={tool} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}