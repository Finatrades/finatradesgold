import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';

const cities = [
  { name: "Geneva", x: 47, y: 35, main: true },
  { name: "Dubai", x: 58, y: 45 },
  { name: "London", x: 45, y: 30 },
  { name: "Singapore", x: 75, y: 55 },
  { name: "Hong Kong", x: 78, y: 42 },
  { name: "Mumbai", x: 65, y: 48 }
];

const connections = [
  [0, 1], [0, 2], [0, 3], [0, 4], [0, 5],
  [1, 3], [1, 5], [3, 4], [2, 0]
];

export default function GlobalNetworkMap() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="relative py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-black via-[#0A0A0A] to-black" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 1 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-extralight text-white mb-4">
            A Global Infrastructure for
          </h2>
          <h2 className="text-4xl md:text-5xl font-light bg-gradient-to-r from-[#D4AF37] to-[#F7D878] bg-clip-text text-transparent">
            Gold-Backed Digital Finance
          </h2>
        </motion.div>

        <div className="relative h-[500px] md:h-[600px]">
          {/* World map wireframe */}
          <svg className="absolute inset-0 w-full h-full" viewBox="0 0 100 70" preserveAspectRatio="xMidYMid slice">
            {/* Simplified world outline */}
            <motion.path
              d="M10,35 Q20,20 35,25 T50,30 T65,28 T80,32 T90,35 M15,40 Q25,50 40,45 T55,48 T70,45 T85,48"
              fill="none"
              stroke="#D4AF37"
              strokeWidth="0.1"
              strokeOpacity="0.3"
              initial={{ pathLength: 0 }}
              animate={isInView ? { pathLength: 1 } : {}}
              transition={{ duration: 3 }}
            />
            
            {/* Connection lines */}
            {connections.map(([from, to], i) => {
              const fromCity = cities[from];
              const toCity = cities[to];
              return (
                <motion.line
                  key={i}
                  x1={fromCity.x}
                  y1={fromCity.y}
                  x2={toCity.x}
                  y2={toCity.y}
                  stroke="url(#goldGradient)"
                  strokeWidth="0.15"
                  initial={{ pathLength: 0, opacity: 0 }}
                  animate={isInView ? { pathLength: 1, opacity: 0.6 } : {}}
                  transition={{ duration: 1.5, delay: 0.5 + i * 0.2 }}
                />
              );
            })}

            {/* Animated pulse along lines */}
            {connections.map(([from, to], i) => {
              const fromCity = cities[from];
              const toCity = cities[to];
              return (
                <motion.circle
                  key={`pulse-${i}`}
                  r="0.5"
                  fill="#F7D878"
                  initial={{ opacity: 0 }}
                  animate={isInView ? {
                    opacity: [0, 1, 0],
                    cx: [fromCity.x, toCity.x],
                    cy: [fromCity.y, toCity.y]
                  } : {}}
                  transition={{
                    duration: 2,
                    delay: 2 + i * 0.5,
                    repeat: Infinity,
                    repeatDelay: 3
                  }}
                />
              );
            })}

            <defs>
              <linearGradient id="goldGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#D4AF37" />
                <stop offset="100%" stopColor="#F7D878" />
              </linearGradient>
            </defs>
          </svg>

          {/* City nodes */}
          {cities.map((city, i) => (
            <motion.div
              key={city.name}
              className="absolute group cursor-pointer"
              style={{ left: `${city.x}%`, top: `${city.y}%` }}
              initial={{ scale: 0, opacity: 0 }}
              animate={isInView ? { scale: 1, opacity: 1 } : {}}
              transition={{ duration: 0.5, delay: 1 + i * 0.1 }}
            >
              {/* Pulse rings */}
              <motion.div
                className="absolute -inset-4 rounded-full border border-[#D4AF37]/30"
                animate={{ scale: [1, 2], opacity: [0.5, 0] }}
                transition={{ duration: 2, repeat: Infinity, delay: i * 0.3 }}
              />
              
              {/* Node */}
              <div className={`relative w-4 h-4 rounded-full ${
                city.main 
                  ? 'bg-gradient-to-br from-[#F7D878] to-[#D4AF37] shadow-[0_0_20px_rgba(212,175,55,0.8)]' 
                  : 'bg-[#D4AF37] shadow-[0_0_10px_rgba(212,175,55,0.5)]'
              } group-hover:scale-150 transition-transform`} />
              
              {/* Label */}
              <div className="absolute left-1/2 -translate-x-1/2 -bottom-8 whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
                <span className="text-xs text-[#D4AF37] font-light">{city.name}</span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}