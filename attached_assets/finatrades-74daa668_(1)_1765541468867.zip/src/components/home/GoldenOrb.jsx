import React, { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';

export default function GoldenOrb() {
  return (
    <div className="relative w-[500px] h-[500px] md:w-[600px] md:h-[600px]">
      {/* Main Orb */}
      <motion.div
        className="absolute inset-0 rounded-full"
        style={{
          background: 'radial-gradient(circle at 30% 30%, #F7D878 0%, #D4AF37 30%, #B8860B 60%, #8B6914 100%)',
          boxShadow: '0 0 100px rgba(212, 175, 55, 0.5), 0 0 200px rgba(212, 175, 55, 0.3), inset 0 0 100px rgba(247, 216, 120, 0.3)'
        }}
        animate={{
          rotate: 360,
          scale: [1, 1.02, 1]
        }}
        transition={{
          rotate: { duration: 60, repeat: Infinity, ease: "linear" },
          scale: { duration: 4, repeat: Infinity, ease: "easeInOut" }
        }}
      >
        {/* Surface texture */}
        <div className="absolute inset-0 rounded-full opacity-30"
          style={{
            background: 'repeating-conic-gradient(from 0deg, transparent 0deg 10deg, rgba(255,255,255,0.1) 10deg 20deg)'
          }}
        />
      </motion.div>

      {/* Inner glow ring */}
      <motion.div
        className="absolute inset-8 rounded-full border-2 border-[#F7D878]/30"
        animate={{ rotate: -360 }}
        transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
      />

      {/* Orbiting particles */}
      {[...Array(12)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-2 h-2 rounded-full bg-[#F7D878]"
          style={{
            top: '50%',
            left: '50%',
            boxShadow: '0 0 10px #D4AF37, 0 0 20px #D4AF37'
          }}
          animate={{
            x: Math.cos((i * 30 * Math.PI) / 180) * 280,
            y: Math.sin((i * 30 * Math.PI) / 180) * 280,
            scale: [1, 1.5, 1],
            opacity: [0.5, 1, 0.5]
          }}
          transition={{
            x: { duration: 20, repeat: Infinity, ease: "linear", delay: i * 0.5 },
            y: { duration: 20, repeat: Infinity, ease: "linear", delay: i * 0.5 },
            scale: { duration: 2, repeat: Infinity, delay: i * 0.2 },
            opacity: { duration: 2, repeat: Infinity, delay: i * 0.2 }
          }}
        />
      ))}

      {/* Light streaks */}
      {[0, 120, 240].map((angle, i) => (
        <motion.div
          key={`streak-${i}`}
          className="absolute top-1/2 left-1/2 w-40 h-1"
          style={{
            background: 'linear-gradient(90deg, transparent, #F7D878, transparent)',
            transformOrigin: 'left center',
            rotate: `${angle}deg`
          }}
          animate={{
            opacity: [0.3, 1, 0.3],
            scaleX: [0.5, 1, 0.5]
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            delay: i * 1
          }}
        />
      ))}

      {/* Product icons floating around */}
      <motion.div
        className="absolute -top-4 left-1/2 -translate-x-1/2"
        animate={{ y: [-10, 10, -10] }}
        transition={{ duration: 4, repeat: Infinity }}
      >
        <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-[#D4AF37]/20 to-[#B8860B]/10 backdrop-blur-sm border border-[#D4AF37]/30 flex items-center justify-center">
          <svg className="w-8 h-8 text-[#D4AF37]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
          </svg>
        </div>
        <div className="text-xs text-[#D4AF37] text-center mt-2 font-light">FinaVault</div>
      </motion.div>

      <motion.div
        className="absolute top-1/2 -right-8 -translate-y-1/2"
        animate={{ x: [-10, 10, -10] }}
        transition={{ duration: 4, repeat: Infinity, delay: 1 }}
      >
        <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-[#D4AF37]/20 to-[#B8860B]/10 backdrop-blur-sm border border-[#D4AF37]/30 flex items-center justify-center">
          <svg className="w-8 h-8 text-[#D4AF37]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
          </svg>
        </div>
        <div className="text-xs text-[#D4AF37] text-center mt-2 font-light">FinaPay</div>
      </motion.div>

      <motion.div
        className="absolute -bottom-4 left-1/2 -translate-x-1/2"
        animate={{ y: [10, -10, 10] }}
        transition={{ duration: 4, repeat: Infinity, delay: 2 }}
      >
        <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-[#D4AF37]/20 to-[#B8860B]/10 backdrop-blur-sm border border-[#D4AF37]/30 flex items-center justify-center">
          <svg className="w-8 h-8 text-[#D4AF37]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
          </svg>
        </div>
        <div className="text-xs text-[#D4AF37] text-center mt-2 font-light">FinaBridge</div>
      </motion.div>

      {/* Outer glow */}
      <div className="absolute -inset-20 rounded-full bg-[#D4AF37]/5 blur-3xl" />
    </div>
  );
}