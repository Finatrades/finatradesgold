import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { ArrowRight, MessageCircle } from 'lucide-react';
import GoldButton from '../ui/GoldButton';

export default function CTASection() {
  return (
    <section className="relative py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-[#1A1A1A] via-[#0A0A0A] to-[#0A0A0A]" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_right,_rgba(212,175,55,0.15)_0%,_transparent_50%)]" />
      
      {/* Decorative Elements */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-[#D4AF37]/30 to-transparent" />
      <div className="absolute bottom-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-[#D4AF37]/30 to-transparent" />

      <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
        <div className="inline-block mb-6">
          <div className="w-20 h-20 mx-auto rounded-full bg-gradient-to-br from-[#D4AF37] to-[#B8860B] p-0.5">
            <div className="w-full h-full rounded-full bg-[#0A0A0A] flex items-center justify-center">
              <span className="text-3xl">Au</span>
            </div>
          </div>
        </div>

        <h2 className="text-4xl md:text-5xl font-light text-white mb-6">
          Your Gold. Your Control.
        </h2>
        <p className="text-xl text-gray-400 mb-10 max-w-2xl mx-auto">
          Modern finance with real-world backing. Join the new standard in gold-backed digital finance.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <Link to={createPageUrl("Contact")}>
            <GoldButton variant="primary">
              <span className="flex items-center gap-2">
                Open Account <ArrowRight className="w-4 h-4" />
              </span>
            </GoldButton>
          </Link>
          <Link to={createPageUrl("Contact")}>
            <GoldButton variant="outline">
              <span className="flex items-center gap-2">
                <MessageCircle className="w-4 h-4" /> Contact Us
              </span>
            </GoldButton>
          </Link>
        </div>
      </div>
    </section>
  );
}