import React from 'react';
import { Wifi, Shield } from 'lucide-react';

export default function FinatradesCard({ userName }) {
  return (
    <div className="relative w-full mx-auto">
      {/* Main Card */}
      <div className="relative aspect-[1.586/1] rounded-2xl overflow-hidden shadow-[0_8px_30px_rgba(138,43,226,0.3)]">
        {/* Card background */}
        <div className="absolute inset-0 bg-gradient-to-br from-[#2A1A3F] via-[#1F1333] to-[#0D001E]" />

        {/* Card Content */}
        <div className="relative h-full p-5 sm:p-7 flex flex-col justify-between">
          {/* Top section */}
          <div className="flex items-start justify-between">
            <img 
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69293bd8e52dce0074daa668/ce96e4d2b_FINANEWLOGO-GOLDANDWHITENB.png" 
              alt="Finatrades" 
              className="h-6 sm:h-7"
            />
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-green-500/20 border border-green-500/30">
                <div className="w-1.5 h-1.5 rounded-full bg-green-500" />
                <span className="text-[9px] sm:text-[10px] text-green-400 font-medium">ACTIVE</span>
              </div>
              <Wifi className="w-4 h-4 sm:w-5 sm:h-5 text-white/70 rotate-90" />
            </div>
          </div>

          {/* Gold Icon & Personal Gold */}
          <div className="flex items-center gap-3 sm:gap-4">
            <div className="relative w-12 h-12 sm:w-14 sm:h-14 rounded-lg overflow-hidden shadow-lg">
              <div className="absolute inset-0 bg-gradient-to-br from-[#FFD700] to-[#FFA500]" />
              <div className="absolute inset-0 flex flex-col justify-center items-center gap-0.5 p-1.5">
                {[...Array(4)].map((_, i) => <div key={i} className="w-full h-0.5 bg-[#0A0A0A]/20" />)}
              </div>
              <div className="absolute inset-2 bg-gradient-to-br from-[#FFE55C] to-[#FFD700] rounded" />
            </div>
            <div>
              <p className="text-white font-bold text-sm sm:text-base">PERSONAL GOLD</p>
              <p className="text-white/60 text-[10px] sm:text-xs tracking-wide">GOLD-BACKED DIGITAL</p>
            </div>
          </div>

          {/* Card number */}
          <div className="flex items-center gap-3 sm:gap-4">
            <span className="text-white text-lg sm:text-xl font-mono tracking-wider">4789</span>
            <span className="text-white/60 text-lg sm:text-xl">••••</span>
            <span className="text-white/60 text-lg sm:text-xl">••••</span>
            <span className="text-white text-lg sm:text-xl font-mono tracking-wider">3456</span>
          </div>

          {/* Bottom section */}
          <div className="flex items-end justify-between gap-2">
            <div className="flex-1 min-w-0">
              <p className="text-white/50 text-[9px] sm:text-[10px] uppercase tracking-wider mb-1">Card Holder</p>
              <p className="text-white font-medium tracking-wide uppercase text-xs sm:text-sm truncate">{userName || 'FINATRADES USER'}</p>
            </div>
            <div className="text-right flex-shrink-0">
              <p className="text-white/50 text-[9px] sm:text-[10px] uppercase tracking-wider mb-1">Valid Thru</p>
              <p className="text-white font-medium text-xs sm:text-sm">12/28</p>
            </div>
            <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-full bg-white/10 border border-white/20 flex-shrink-0">
              <Shield className="w-3.5 h-3.5 text-white" />
              <span className="text-[10px] text-white font-medium">SECURED</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}