import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { ArrowRight, Shield, Globe, Sparkles } from 'lucide-react';
import GoldButton from '../ui/GoldButton';

export default function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-[#0A0A0A]">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_rgba(212,175,55,0.15)_0%,_transparent_50%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,_rgba(184,134,11,0.1)_0%,_transparent_50%)]" />
        <div className="absolute top-0 left-0 w-full h-full opacity-30">
          <div className="absolute top-20 left-10 w-72 h-72 bg-[#D4AF37]/10 rounded-full blur-[100px] animate-pulse" />
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-[#B8860B]/10 rounded-full blur-[120px] animate-pulse delay-1000" />
        </div>
      </div>

      {/* Grid Pattern */}
      <div className="absolute inset-0 opacity-[0.03]" style={{
        backgroundImage: `linear-gradient(#D4AF37 1px, transparent 1px), linear-gradient(90deg, #D4AF37 1px, transparent 1px)`,
        backgroundSize: '60px 60px'
      }} />

      <div className="relative z-10 max-w-7xl mx-auto px-6 py-32 text-center">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-[#D4AF37]/30 bg-[#D4AF37]/5 mb-8">
          <Shield className="w-4 h-4 text-[#D4AF37]" />
          <span className="text-sm text-[#D4AF37] tracking-wide">Swiss-Regulated • Vault-Secured</span>
        </div>

        {/* Main Title */}
        <h1 className="text-5xl md:text-7xl lg:text-8xl font-extralight text-white mb-6 tracking-tight">
          A New Standard in
          <span className="block mt-2 bg-gradient-to-r from-[#D4AF37] via-[#F5E6A3] to-[#B8860B] bg-clip-text text-transparent font-light">
            Gold-Backed Finance
          </span>
        </h1>

        {/* Subtitle */}
        <p className="text-xl md:text-2xl text-gray-400 max-w-3xl mx-auto mb-12 font-light leading-relaxed">
          Secure, technology-driven financial infrastructure where real physical gold 
          supports fast, transparent, and borderless financial operations.
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-20">
          <Link to={createPageUrl("Contact")}>
            <GoldButton variant="primary">
              <span className="flex items-center gap-2">
                Open Account <ArrowRight className="w-4 h-4" />
              </span>
            </GoldButton>
          </Link>
          <Link to={createPageUrl("HowItWorks")}>
            <GoldButton variant="outline">
              Learn How It Works
            </GoldButton>
          </Link>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
          {[
            { icon: Shield, label: "Swiss Governance", value: "Geneva Based" },
            { icon: Globe, label: "Global Access", value: "Borderless" },
            { icon: Sparkles, label: "Gold Standard", value: "100% Backed" }
          ].map((stat, i) => (
            <div key={i} className="text-center group">
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-full border border-[#D4AF37]/30 mb-4 group-hover:border-[#D4AF37] transition-colors duration-300">
                <stat.icon className="w-5 h-5 text-[#D4AF37]" />
              </div>
              <div className="text-2xl font-light text-white mb-1">{stat.value}</div>
              <div className="text-sm text-gray-500 tracking-wide uppercase">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2">
        <span className="text-xs text-gray-500 tracking-widest uppercase">Scroll</span>
        <div className="w-px h-12 bg-gradient-to-b from-[#D4AF37] to-transparent" />
      </div>
    </section>
  );
}