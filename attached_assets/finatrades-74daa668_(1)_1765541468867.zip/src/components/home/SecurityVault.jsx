import React, { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { Shield, Lock, FileCheck, Building } from 'lucide-react';

const securityFeatures = [
  { icon: Shield, label: 'Swiss-grade compliance' },
  { icon: Lock, label: 'Secure vault custody' },
  { icon: FileCheck, label: 'Encrypted ledger' },
  { icon: Building, label: 'Institutional infrastructure' }
];

export default function SecurityVault() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="relative py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-black via-[#0A0A0A] to-black" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Vault Animation */}
          <motion.div
            className="relative h-[400px] flex items-center justify-center"
            initial={{ opacity: 0 }}
            animate={isInView ? { opacity: 1 } : {}}
            transition={{ duration: 1 }}
          >
            {/* Outer ring */}
            <motion.div
              className="absolute w-80 h-80 rounded-full border border-[#D4AF37]/20"
              animate={{ rotate: 360 }}
              transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
            />
            
            {/* Middle ring */}
            <motion.div
              className="absolute w-64 h-64 rounded-full border border-[#D4AF37]/30"
              animate={{ rotate: -360 }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            />
            
            {/* Vault door */}
            <motion.div
              className="relative w-48 h-48 rounded-full bg-gradient-to-br from-[#1A1A1A] to-[#0A0A0A] border-4 border-[#D4AF37]/50"
              initial={{ rotateY: 0 }}
              animate={isInView ? { rotateY: [0, 10, 0] } : {}}
              transition={{ duration: 4, repeat: Infinity }}
              style={{ transformStyle: 'preserve-3d' }}
            >
              {/* Door details */}
              <div className="absolute inset-4 rounded-full border-2 border-[#D4AF37]/30" />
              <div className="absolute inset-8 rounded-full border border-[#D4AF37]/20" />
              
              {/* Lock mechanism */}
              <div className="absolute inset-0 flex items-center justify-center">
                <motion.div
                  className="w-16 h-16 rounded-full bg-gradient-to-br from-[#D4AF37] to-[#B8860B] flex items-center justify-center"
                  animate={{ rotate: [0, 90, 0] }}
                  transition={{ duration: 4, repeat: Infinity }}
                >
                  <Lock className="w-8 h-8 text-black" />
                </motion.div>
              </div>
              
              {/* Dial markers */}
              {[...Array(12)].map((_, i) => (
                <div
                  key={i}
                  className="absolute w-1 h-3 bg-[#D4AF37]/50"
                  style={{
                    top: '10%',
                    left: '50%',
                    transform: `translateX(-50%) rotate(${i * 30}deg)`,
                    transformOrigin: '50% 370%'
                  }}
                />
              ))}
            </motion.div>
            
            {/* Scanning laser */}
            <motion.div
              className="absolute w-80 h-0.5 bg-gradient-to-r from-transparent via-[#D4AF37] to-transparent"
              animate={{ y: [-150, 150, -150], opacity: [0, 1, 0] }}
              transition={{ duration: 3, repeat: Infinity }}
            />
            
            {/* Particles */}
            {[...Array(8)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-1 h-1 bg-[#D4AF37] rounded-full"
                style={{
                  top: '50%',
                  left: '50%'
                }}
                animate={{
                  x: Math.cos((i * 45 * Math.PI) / 180) * 180,
                  y: Math.sin((i * 45 * Math.PI) / 180) * 180,
                  opacity: [0, 1, 0],
                  scale: [0, 1, 0]
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  delay: i * 0.3
                }}
              />
            ))}
            
            {/* Code streams */}
            <div className="absolute top-0 right-0 text-[#D4AF37]/30 text-xs font-mono overflow-hidden h-full w-20">
              <motion.div
                animate={{ y: [-500, 500] }}
                transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
              >
                {[...Array(30)].map((_, i) => (
                  <div key={i} className="whitespace-nowrap">
                    {Math.random().toString(16).substr(2, 8)}
                  </div>
                ))}
              </motion.div>
            </div>
          </motion.div>

          {/* Content */}
          <div>
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.8 }}
            >
              <p className="text-[#D4AF37] text-sm tracking-[0.3em] uppercase mb-4">Bank-Grade Security</p>
              <h2 className="text-4xl md:text-5xl font-extralight text-white mb-6">
                Your Gold, Secured by Swiss Standards
              </h2>
              <p className="text-gray-400 text-lg mb-10">
                Every gram of gold in the Finatrades ecosystem is protected by institutional-grade security infrastructure, encrypted ledgers, and Swiss regulatory compliance.
              </p>
              
              <div className="grid sm:grid-cols-2 gap-6">
                {securityFeatures.map((feature, i) => (
                  <motion.div
                    key={i}
                    className="flex items-center gap-4 group"
                    initial={{ opacity: 0, y: 20 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ duration: 0.5, delay: 0.5 + i * 0.1 }}
                  >
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#D4AF37]/20 to-[#B8860B]/10 flex items-center justify-center group-hover:from-[#D4AF37]/30 group-hover:to-[#B8860B]/20 transition-all">
                      <feature.icon className="w-5 h-5 text-[#D4AF37]" />
                    </div>
                    <span className="text-white">{feature.label}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}