import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Wifi, Shield, Building2, Globe, TrendingUp, ArrowRight, User } from 'lucide-react';
import { useAccountType } from '@/components/AccountTypeContext';
import { useLanguage } from '@/components/LanguageContext';

// Floating particles component
function FloatingParticles({ mode }) {
  const particles = [...Array(40)].map((_, i) => ({
    id: i,
    x: Math.random() * 100,
    y: Math.random() * 100,
    size: 1 + Math.random() * 3,
    duration: 3 + Math.random() * 4,
    delay: Math.random() * 5
  }));

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {particles.map((p) => (
        <motion.div
          key={p.id}
          className="absolute rounded-full"
          style={{
            left: `${p.x}%`,
            top: `${p.y}%`,
            width: p.size,
            height: p.size,
            background: mode === 'personal' 
              ? 'radial-gradient(circle, #FF66D8 0%, #8A2BE2 100%)'
              : 'radial-gradient(circle, #A54CFF 0%, #FF2FBF 100%)'
          }}
          animate={{
            y: [0, -30, 0],
            opacity: [0, 0.8, 0],
            scale: [0.5, 1, 0.5]
          }}
          transition={{
            duration: p.duration,
            delay: p.delay,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      ))}
    </div>
  );
}

// Futuristic grid pattern
function FuturisticGrid({ mode }) {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-20">
      <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <pattern id="grid" width="60" height="60" patternUnits="userSpaceOnUse">
            <path 
              d="M 60 0 L 0 0 0 60" 
              fill="none" 
              stroke={mode === 'personal' ? '#8A2BE2' : '#FF2FBF'} 
              strokeWidth="0.5"
              opacity="0.3"
            />
          </pattern>
          <linearGradient id="gridFade" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="white" stopOpacity="0" />
            <stop offset="30%" stopColor="white" stopOpacity="1" />
            <stop offset="70%" stopColor="white" stopOpacity="1" />
            <stop offset="100%" stopColor="white" stopOpacity="0" />
          </linearGradient>
          <mask id="gridMask">
            <rect width="100%" height="100%" fill="url(#gridFade)" />
          </mask>
        </defs>
        <rect width="100%" height="100%" fill="url(#grid)" mask="url(#gridMask)" />
      </svg>
      
      {/* Animated scan line for business mode */}
      {mode === 'business' && (
        <motion.div
          className="absolute left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#FF2FBF] to-transparent"
          animate={{ top: ['0%', '100%'] }}
          transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
        />
      )}
    </div>
  );
}

// Premium toggle switch - now synced with global context
function ModeToggle({ mode, setMode }) {
  return (
    <motion.div 
      className="relative flex items-center p-1 rounded-full bg-white/80 border border-[#8A2BE2]/20 backdrop-blur-sm shadow-[0_4px_20px_rgba(138,43,226,0.1)]"
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
    >
      <motion.div 
        className="absolute top-1 bottom-1 rounded-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] shadow-lg"
        animate={{ 
          left: mode === 'personal' ? 4 : '50%',
          width: 'calc(50% - 4px)'
        }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
      />
      <button
        onClick={() => setMode('personal')}
        className={`relative z-10 flex items-center gap-1.5 px-4 sm:px-6 py-2.5 rounded-full text-xs sm:text-sm font-medium transition-colors ${
          mode === 'personal' ? 'text-white' : 'text-[#4A4A4A] hover:text-[#8A2BE2]'
        }`}
      >
        <User className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
        Personal
      </button>
      <button
        onClick={() => setMode('business')}
        className={`relative z-10 flex items-center gap-1.5 px-4 sm:px-6 py-2.5 rounded-full text-xs sm:text-sm font-medium transition-colors ${
          mode === 'business' ? 'text-white' : 'text-[#4A4A4A] hover:text-[#8A2BE2]'
        }`}
      >
        <Building2 className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
        Business
      </button>
    </motion.div>
  );
}

// Premium 3D Card with Holographic Effects
function PremiumCard({ mode }) {
  const [isHovered, setIsHovered] = useState(false);
  const [mousePos, setMousePos] = useState({ x: 0.5, y: 0.5 });
  
  const cardData = {
    personal: {
      holder: "FINATRADES USER",
      balance: "24.85",
      value: "2,156.42",
      type: "PERSONAL GOLD",
      cardNumber: "4789 •••• •••• 3456"
    },
    business: {
      holder: "FINATRADES CORPORATE",
      balance: "248.90",
      value: "21,564.22",
      type: "ENTERPRISE GOLD",
      cardNumber: "5892 •••• •••• 7821"
    }
  };
  
  const data = cardData[mode];

  const handleMouseMove = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setMousePos({
      x: (e.clientX - rect.left) / rect.width,
      y: (e.clientY - rect.top) / rect.height,
    });
  };

  return (
    <div className="relative w-full max-w-sm sm:max-w-md mx-auto" style={{ perspective: '1500px' }}>
      {/* Multi-layer glow effect */}
      <motion.div
        className="absolute -inset-4 rounded-[40px] blur-2xl"
        animate={{
          background: mode === 'personal'
            ? 'radial-gradient(circle at 50% 50%, rgba(255,102,216,0.35) 0%, rgba(138,43,226,0.2) 40%, transparent 70%)'
            : 'radial-gradient(circle at 50% 50%, rgba(165,76,255,0.35) 0%, rgba(255,47,191,0.15) 40%, transparent 70%)',
          scale: isHovered ? 1.15 : 1
        }}
        transition={{ duration: 0.6 }}
      />
      
      {/* Secondary glow ring */}
      <motion.div
        className="absolute -inset-8 rounded-[50px]"
        animate={{
          boxShadow: isHovered 
            ? '0 0 80px 20px rgba(255,45,200,0.15), 0 0 120px 40px rgba(138,43,226,0.08)'
            : '0 0 40px 10px rgba(255,45,200,0.08), 0 0 60px 20px rgba(138,43,226,0.04)'
        }}
        transition={{ duration: 0.5 }}
      />

      {/* Floating neon particles */}
      {[...Array(12)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full"
          style={{
            width: 2 + Math.random() * 4,
            height: 2 + Math.random() * 4,
            top: `${10 + Math.random() * 80}%`,
            left: `${-10 + Math.random() * 120}%`,
            background: `radial-gradient(circle, ${i % 2 === 0 ? '#FF66D8' : '#8A2BE2'} 0%, transparent 70%)`
          }}
          animate={{
            y: [0, -25 - Math.random() * 15, 0],
            x: [0, (Math.random() - 0.5) * 20, 0],
            opacity: [0, 0.9, 0],
            scale: [0.5, 1.2, 0.5]
          }}
          transition={{
            duration: 3 + Math.random() * 2,
            delay: i * 0.3,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      ))}

      {/* Main Card */}
      <motion.div
        className="relative aspect-[1.6/1] rounded-3xl overflow-hidden cursor-pointer"
        style={{ transformStyle: 'preserve-3d' }}
        animate={{
          rotateY: isHovered ? (mousePos.x - 0.5) * 15 : 0,
          rotateX: isHovered ? (mousePos.y - 0.5) * -10 : 0,
          y: [0, -10, 0],
        }}
        whileHover={{ scale: 1.03 }}
        onMouseMove={handleMouseMove}
        onHoverStart={() => setIsHovered(true)}
        onHoverEnd={() => { setIsHovered(false); setMousePos({ x: 0.5, y: 0.5 }); }}
        transition={{ 
          rotateY: { duration: 0.1 },
          rotateX: { duration: 0.1 },
          y: { duration: 3, repeat: Infinity, ease: "easeInOut" }
        }}
      >
        {/* Premium dark purple gradient background with shading */}
        <div className="absolute inset-0 bg-gradient-to-br from-[#0d0515] via-[#1a0a2e] to-[#2d1145]" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-white/5" />
        
        {/* Neon texture overlay */}
        <div 
          className="absolute inset-0 opacity-40"
          style={{
            background: mode === 'personal'
              ? 'linear-gradient(135deg, transparent 0%, rgba(255,255,255,0.15) 25%, transparent 50%, rgba(255,102,216,0.2) 75%, transparent 100%)'
              : 'linear-gradient(135deg, transparent 0%, rgba(255,255,255,0.12) 25%, transparent 50%, rgba(165,76,255,0.18) 75%, transparent 100%)'
          }}
        />

        {/* Holographic rainbow effect */}
        <motion.div
          className="absolute inset-0 opacity-40"
          style={{
            background: `linear-gradient(${45 + mousePos.x * 90}deg, 
              transparent 0%, 
              rgba(138,43,226,0.3) 20%, 
              rgba(255,102,216,0.4) 40%, 
              rgba(255,255,255,0.2) 50%,
              rgba(255,102,216,0.4) 60%,
              rgba(138,43,226,0.3) 80%, 
              transparent 100%)`
          }}
          animate={{
            opacity: isHovered ? 0.6 : 0.3
          }}
        />
        
        {/* Moving light beam */}
        <motion.div
          className="absolute inset-0"
          style={{
            background: 'linear-gradient(105deg, transparent 40%, rgba(255,255,255,0.15) 45%, rgba(255,255,255,0.25) 50%, rgba(255,255,255,0.15) 55%, transparent 60%)',
          }}
          animate={{ 
            x: ['-100%', '200%'],
          }}
          transition={{ 
            duration: 4, 
            repeat: Infinity, 
            repeatDelay: 3,
            ease: "easeInOut"
          }}
        />

        {/* Premium neon border with glow */}
        <div className="absolute inset-0 rounded-3xl border-2 border-white/30" />
        <motion.div 
          className="absolute inset-0 rounded-3xl"
          animate={{
            boxShadow: isHovered 
              ? 'inset 0 0 30px rgba(255,255,255,0.2), inset 0 1px 0 rgba(255,255,255,0.3)'
              : 'inset 0 0 15px rgba(255,255,255,0.1), inset 0 1px 0 rgba(255,255,255,0.15)'
          }}
        />
        
        {/* Top accent line */}
        <motion.div 
          className="absolute top-0 left-8 right-8 h-[2px]"
          style={{
            background: 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.5) 20%, rgba(255,255,255,0.8) 50%, rgba(255,255,255,0.5) 80%, transparent 100%)'
          }}
          animate={{ opacity: [0.6, 1, 0.6] }}
          transition={{ duration: 2, repeat: Infinity }}
        />

        {/* Corner accents for business mode */}
        {mode === 'business' && (
          <>
            <div className="absolute top-4 left-4 w-8 h-8 border-l-2 border-t-2 border-white/40 rounded-tl-lg" />
            <div className="absolute top-4 right-4 w-8 h-8 border-r-2 border-t-2 border-white/40 rounded-tr-lg" />
            <div className="absolute bottom-4 left-4 w-8 h-8 border-l-2 border-b-2 border-white/40 rounded-bl-lg" />
            <div className="absolute bottom-4 right-4 w-8 h-8 border-r-2 border-b-2 border-white/40 rounded-br-lg" />
          </>
        )}

        {/* Card Content */}
        <div className="relative h-full p-6 flex flex-col justify-between">
          {/* Top Row */}
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69293bd8e52dce0074daa668/ce96e4d2b_FINANEWLOGO-GOLDANDWHITENB.png" 
                alt="Finatrades" 
                className="h-8"
                style={{ filter: 'hue-rotate(280deg) saturate(1.5) brightness(1.2)' }}
              />
            </div>
            <div className="flex items-center gap-2">
              <motion.div 
                className="flex items-center gap-1 px-2 py-1 rounded-full bg-green-500/20 border border-green-500/40"
                animate={{ borderColor: ['rgba(34,197,94,0.4)', 'rgba(34,197,94,0.8)', 'rgba(34,197,94,0.4)'] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <motion.div
                  className="w-1.5 h-1.5 rounded-full bg-green-400"
                  animate={{ scale: [1, 1.4, 1], opacity: [0.7, 1, 0.7] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                />
                <span className="text-[8px] text-green-400 font-medium">ACTIVE</span>
              </motion.div>
              <motion.div animate={{ opacity: [0.5, 1, 0.5] }} transition={{ duration: 2, repeat: Infinity }}>
                <Wifi className="w-5 h-5 text-[#FF66D8] rotate-90" />
              </motion.div>
            </div>
          </div>

          {/* Premium Chip */}
          <div className="flex items-center gap-4">
            <motion.div 
              className="relative w-14 h-11 rounded-lg overflow-hidden"
              animate={{ 
                boxShadow: isHovered 
                  ? '0 0 25px rgba(255,255,255,0.4), 0 0 50px rgba(255,102,216,0.3)' 
                  : '0 0 10px rgba(255,255,255,0.2)' 
              }}
            >
              {/* Chip base - gold/metallic look */}
              <div className="absolute inset-0 bg-gradient-to-br from-[#FFD700] via-[#FFC107] to-[#DAA520]" />
              {/* Chip pattern */}
              <div className="absolute inset-0 flex flex-col justify-center gap-1 p-1.5">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="flex gap-1">
                    <div className="flex-1 h-1 bg-[#8B6914]/50 rounded-full" />
                    <div className="w-3 h-1 bg-[#8B6914]/50 rounded-full" />
                  </div>
                ))}
              </div>
              {/* Chip inner glow */}
              <motion.div 
                className="absolute inset-2 rounded bg-gradient-to-br from-[#FFE066] to-[#DAA520]"
                animate={{ opacity: [0.8, 1, 0.8] }}
                transition={{ duration: 1.5, repeat: Infinity }}
              />
            </motion.div>
            
            <AnimatePresence mode="wait">
              <motion.div
                key={mode}
                initial={{ opacity: 0, x: -15 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 15 }}
                className="flex flex-col"
              >
                <div className="flex items-center gap-2">
                  <motion.div
                    className="w-2 h-2 rounded-full bg-white"
                    animate={{ 
                      scale: [1, 1.4, 1],
                      boxShadow: ['0 0 0 0 rgba(255,255,255,0.4)', '0 0 0 6px rgba(255,255,255,0)', '0 0 0 0 rgba(255,255,255,0.4)']
                    }}
                    transition={{ duration: 2, repeat: Infinity }}
                  />
                  <span className="text-[11px] text-white tracking-[0.2em] font-medium">{data.type}</span>
                </div>
                <span className="text-[9px] text-white/70 mt-0.5">GOLD-BACKED DIGITAL</span>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Card Number */}
          <div className="space-y-1">
            <AnimatePresence mode="wait">
              <motion.div
                key={mode}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex items-center gap-3"
              >
                <span className="text-xl sm:text-2xl font-light text-white tracking-[0.15em] font-mono">
                  {data.cardNumber}
                </span>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Bottom Row */}
          <div className="flex items-end justify-between">
            <div>
              <p className="text-[9px] text-white/70 uppercase tracking-wider mb-1">Card Holder</p>
              <AnimatePresence mode="wait">
                <motion.p
                  key={mode}
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -5 }}
                  className="text-white font-medium tracking-wide text-sm"
                >
                  {data.holder}
                </motion.p>
              </AnimatePresence>
            </div>
            
            <div className="text-center">
              <p className="text-[9px] text-white/70 uppercase tracking-wider mb-1">Valid Thru</p>
              <p className="text-white font-medium text-sm">12/28</p>
            </div>

            <motion.div
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/20 border border-white/40"
              animate={{ 
                borderColor: ['rgba(255,255,255,0.4)', 'rgba(255,255,255,0.7)', 'rgba(255,255,255,0.4)'],
                boxShadow: ['0 0 10px rgba(255,255,255,0.1)', '0 0 20px rgba(255,255,255,0.3)', '0 0 10px rgba(255,255,255,0.1)']
              }}
              transition={{ duration: 2.5, repeat: Infinity }}
            >
              <Shield className="w-3.5 h-3.5 text-white" />
              <span className="text-[10px] text-white font-semibold tracking-wide">SECURED</span>
            </motion.div>
          </div>
        </div>

        {/* Floating hologram effect */}
        <motion.div
          className="absolute bottom-3 right-16 w-12 h-12 rounded-full"
          style={{
            background: 'radial-gradient(circle, rgba(255,255,255,0.2) 0%, transparent 70%)',
          }}
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.5, 0.8, 0.5],
          }}
          transition={{ duration: 3, repeat: Infinity }}
        />
      </motion.div>
    </div>
  );
}

// Swiss Regulated Badge
function SwissBadge() {
  return (
    <motion.div
      className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/60 border border-[#8A2BE2]/20 backdrop-blur-sm shadow-[0_4px_20px_rgba(138,43,226,0.1)]"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 1 }}
    >
      <motion.div
        className="w-2 h-2 rounded-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF]"
        animate={{ 
          boxShadow: ['0 0 0 0 rgba(138,43,226,0.4)', '0 0 0 6px rgba(138,43,226,0)', '0 0 0 0 rgba(138,43,226,0.4)']
        }}
        transition={{ duration: 2, repeat: Infinity }}
      />
      <span className="text-xs text-[#4A4A4A]">Swiss-Regulated Platform</span>
      <Shield className="w-3 h-3 text-[#8A2BE2]" />
    </motion.div>
  );
}

export default function PremiumHeroSection() {
  // Use global account type context
  const { accountType, setAccountType } = useAccountType();
  const { t } = useLanguage();
  const mode = accountType || 'business';
  const setMode = setAccountType;

  const content = {
    personal: {
      title: t('hero.personal.title'),
      subtitle: t('hero.personal.subtitle'),
      description: t('hero.personal.description'),
      cta1: 'Sign In',
      cta2: 'Get Started',
      cta1Link: 'SignIn',
      cta2Link: 'Register'
    },
    business: {
      title: t('hero.business.title'),
      subtitle: t('hero.business.subtitle'),
      description: t('hero.business.description'),
      cta1: 'Sign In',
      cta2: 'Get Started',
      cta1Link: 'SignIn',
      cta2Link: 'Register'
    }
  };

  const current = content[mode];

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-[#FAFBFF] via-[#F4F6FC] to-[#FFFFFF]">
      {/* Background gradients */}
      <motion.div
        className="absolute inset-0"
        animate={{
          background: mode === 'personal'
            ? 'radial-gradient(ellipse at 30% 50%, rgba(255,102,216,0.08) 0%, transparent 50%), radial-gradient(ellipse at 70% 80%, rgba(138,43,226,0.05) 0%, transparent 40%)'
            : 'radial-gradient(ellipse at 50% 30%, rgba(165,76,255,0.06) 0%, transparent 50%), radial-gradient(ellipse at 80% 70%, rgba(255,47,191,0.04) 0%, transparent 40%)'
        }}
        transition={{ duration: 1 }}
      />

      <FuturisticGrid mode={mode} />
      <FloatingParticles mode={mode} />

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 py-20 sm:py-24 md:py-28 lg:py-32">
        <div className="grid lg:grid-cols-2 gap-10 lg:gap-16 items-center">
          {/* Left: Text */}
          <div className="text-center lg:text-left">
            {/* Swiss Regulated Button */}
            <div className="flex justify-center lg:justify-start mb-4">
              <Link to={createPageUrl("RegulatoryInformation")} onClick={() => window.scrollTo(0, 0)}>
                <motion.div
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-[#8A2BE2]/10 to-[#FF2FBF]/10 border border-[#8A2BE2]/40 backdrop-blur-md shadow-[0_4px_20px_rgba(138,43,226,0.15)] hover:border-[#8A2BE2]/70 hover:from-[#8A2BE2]/20 hover:to-[#FF2FBF]/20 transition-all cursor-pointer"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  whileHover={{ scale: 1.05 }}
                >
                  <span className="text-red-600 font-bold text-lg">+</span>
                  <span className="text-xs font-medium bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent tracking-wide">{t('hero.swissRegulated')}</span>
                  <Shield className="w-3.5 h-3.5 text-[#8A2BE2]" />
                </motion.div>
              </Link>
            </div>

            {/* Toggle */}
            <div className="flex justify-center lg:justify-start mb-6 md:mb-8">
              <ModeToggle mode={mode} setMode={setMode} />
            </div>

            {/* Title */}
            <AnimatePresence mode="wait">
              <motion.div
                key={mode}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.5 }}
              >
                <motion.h1 
                  className="text-3xl sm:text-4xl md:text-5xl lg:text-5xl font-extralight text-[#0D0D0D] mb-4 md:mb-6 leading-[1.1]"
                >
                  <span className="bg-gradient-to-r from-[#8A2BE2] via-[#FF66D8] to-[#FF2FBF] bg-clip-text text-transparent font-bold">
                    Finatrades
                  </span>
                  <br className="hidden sm:block" />
                  <span className="text-xl sm:text-2xl md:text-3xl lg:text-4xl block mt-2 leading-tight text-[#0D0D0D] font-bold">
                    {current.title}
                  </span>
                </motion.h1>
                
                <motion.p 
                  className="text-base sm:text-lg md:text-xl text-[#333333] mb-3 md:mb-4 max-w-xl mx-auto lg:mx-0 leading-relaxed"
                >
                  {current.subtitle}
                </motion.p>
                
                <motion.p 
                  className="text-sm md:text-base text-[#4A4A4A] mb-6 md:mb-8 max-w-xl mx-auto lg:mx-0 leading-relaxed"
                >
                  {current.description}
                </motion.p>
              </motion.div>
            </AnimatePresence>

            {/* CTAs */}
            <AnimatePresence mode="wait">
              <motion.div
                key={mode}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ delay: 0.2 }}
                className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center lg:justify-start"
              >
                <a href="https://portal.finatrades.com/">
                <motion.button
                  className="group w-full sm:w-auto px-6 sm:px-8 py-3 sm:py-4 rounded-full border border-[#8A2BE2]/40 text-[#8A2BE2] text-sm sm:text-base hover:bg-gradient-to-r hover:from-[#8A2BE2]/10 hover:to-[#FF2FBF]/10 transition-all flex items-center gap-2 justify-center"
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.98 }}
                >
                  {current.cta1}
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </motion.button>
              </a>
                
                <a href="https://portal.finatrades.com/register">
                  <motion.button
                    className="w-full sm:w-auto px-6 sm:px-8 py-3 sm:py-4 rounded-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white text-sm sm:text-base font-medium hover:shadow-[0_0_40px_rgba(255,45,200,0.35)] hover:from-[#A342FF] hover:to-[#FF4CD6] transition-all flex items-center gap-2 justify-center"
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    {current.cta2}
                    <ArrowRight className="w-4 h-4" />
                  </motion.button>
                </a>
              </motion.div>
            </AnimatePresence>

          </div>

          {/* Right: Card */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="lg:-mt-24 relative"
          >
            {/* Floating Swiss Badge */}
            <Link to={createPageUrl("RegulatoryInformation")} onClick={() => window.scrollTo(0, 0)}>
              <motion.div
                className="absolute -top-4 right-4 sm:right-8 z-20 cursor-pointer"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.8, duration: 0.5 }}
                whileHover={{ scale: 1.05 }}
              >
                <motion.div
                  className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/90 border border-[#8A2BE2]/40 backdrop-blur-md shadow-[0_4px_20px_rgba(138,43,226,0.15)] hover:border-[#8A2BE2]/70 hover:bg-white transition-colors"
                  animate={{ y: [0, -6, 0] }}
                  transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                >
                  <motion.div
                    className="w-2 h-2 rounded-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF]"
                    animate={{ 
                      boxShadow: ['0 0 0 0 rgba(138,43,226,0.4)', '0 0 0 6px rgba(138,43,226,0)', '0 0 0 0 rgba(138,43,226,0.4)']
                    }}
                    transition={{ duration: 2, repeat: Infinity }}
                  />
                  <span className="text-xs font-medium bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent tracking-wide">{t('hero.swissRegulated')}</span>
                  <Shield className="w-3.5 h-3.5 text-[#8A2BE2]" />
                </motion.div>
              </motion.div>
            </Link>
            <PremiumCard mode={mode} />
          </motion.div>
        </div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
        animate={{ y: [0, 8, 0], opacity: [0.3, 0.8, 0.3] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <div className="w-6 h-10 rounded-full border border-[#8A2BE2]/30 flex items-start justify-center p-2">
          <motion.div
            className="w-1 h-2 rounded-full bg-gradient-to-b from-[#8A2BE2] to-[#FF2FBF]"
            animate={{ y: [0, 12, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          />
        </div>
      </motion.div>
    </section>
  );
}