import React from 'react';
import { Building2, User, Briefcase, Users, TrendingUp } from 'lucide-react';
import SectionTitle from '../ui/SectionTitle';

const clientTypes = [
  { icon: Building2, label: "Importers / Exporters", description: "Streamline international trade settlements" },
  { icon: User, label: "High-Net-Worth Individuals", description: "Secure wealth preservation" },
  { icon: Briefcase, label: "Corporates", description: "Manage treasury with gold backing" },
  { icon: Users, label: "Family Offices", description: "Multi-generational wealth protection" },
  { icon: TrendingUp, label: "Precious Metal Investors", description: "Direct gold ownership and growth" }
];

export default function ClientsSection() {
  return (
    <section className="relative py-32 bg-gradient-to-b from-[#0A0A0A] via-[#111111] to-[#0A0A0A]">
      <div className="max-w-7xl mx-auto px-6">
        <SectionTitle 
          title="Built for Global Businesses"
          subtitle="Whether you are storing wealth, executing trade payments, or managing corporate imports/exports, Finatrades provides a reliable and secure path."
        />

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {clientTypes.map((client, i) => (
            <div 
              key={i}
              className="group relative p-6 rounded-2xl bg-gradient-to-br from-[#1A1A1A]/50 to-transparent border border-[#D4AF37]/10 hover:border-[#D4AF37]/30 transition-all duration-500 text-center"
            >
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-br from-[#D4AF37]/10 to-[#B8860B]/5 flex items-center justify-center group-hover:from-[#D4AF37]/20 group-hover:to-[#B8860B]/10 transition-all duration-500">
                <client.icon className="w-7 h-7 text-[#D4AF37]" />
              </div>
              <h3 className="text-lg font-light text-white mb-2">{client.label}</h3>
              <p className="text-sm text-gray-500">{client.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}