import React, { useRef, useState, useEffect } from 'react';
import { motion, useScroll, useTransform, useInView, AnimatePresence } from 'framer-motion';
import { 
  UserPlus, ShieldCheck, LayoutDashboard, Coins, 
  Vault, ArrowLeftRight, TrendingUp, Sparkles
} from 'lucide-react';

const steps = [
  {
    number: "01",
    icon: UserPlus,
    title: "Create Your Account",
    description: "Choose Individual or Corporate profile. Select your role and complete onboarding.",
    animation: "slideIn"
  },
  {
    number: "02",
    icon: ShieldCheck,
    title: "Complete KYC Verification",
    description: "Our compliance team verifies your identity. Once approved, your dashboard activates.",
    animation: "shield"
  },
  {
    number: "03",
    icon: LayoutDashboard,
    title: "Access Your Dashboard",
    description: "View gold balance, USD valuation, transactions, and earning plans in real-time.",
    animation: "dashboard"
  },
  {
    number: "04",
    icon: Coins,
    title: "Buy or Deposit Gold",
    description: "Purchase new gold or deposit existing physical gold with full certification.",
    animation: "drop"
  },
  {
    number: "05",
    icon: Vault,
    title: "Hold & Manage Securely",
    description: "All gold stored in approved vaults under professional custody management.",
    animation: "vault"
  },
  {
    number: "06",
    icon: ArrowLeftRight,
    title: "Use for Trade & Payments",
    description: "Settle cross-border trade using gold value. Faster than banking, zero intermediaries.",
    animation: "flow"
  },
  {
    number: "07",
    icon: TrendingUp,
    title: "Earn Through Holding Plans",
    description: "Choose 12, 24, or 36-month structured plans with gold-based returns.",
    animation: "rise"
  }
];

// Floating particles component
const GoldParticles = ({ active }) => {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {[...Array(20)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-1 h-1 rounded-full bg-[#D4AF37]"
          initial={{ 
            x: Math.random() * 100 + '%',
            y: '100%',
            opacity: 0,
            scale: 0
          }}
          animate={active ? {
            y: '-100%',
            opacity: [0, 1, 1, 0],
            scale: [0, 1, 1, 0]
          } : {}}
          transition={{
            duration: 3 + Math.random() * 2,
            delay: Math.random() * 2,
            repeat: Infinity,
            ease: "easeOut"
          }}
          style={{
            left: `${10 + Math.random() * 80}%`,
            filter: 'blur(0.5px)',
            boxShadow: '0 0 6px #D4AF37'
          }}
        />
      ))}
    </div>
  );
};

// Step card with animated icon
const StepCard = ({ step, index, isActive, isPassed }) => {
  const cardRef = useRef(null);
  const isInView = useInView(cardRef, { once: false, margin: "-20%" });
  
  const IconComponent = step.icon;
  
  return (
    <motion.div
      ref={cardRef}
      className="relative"
      initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
      animate={isInView ? { opacity: 1, x: 0 } : {}}
      transition={{ duration: 0.8, delay: 0.2 }}
    >
      {/* Glassmorphism Card */}
      <motion.div
        className={`relative p-8 rounded-3xl border backdrop-blur-xl transition-all duration-700 ${
          isActive || isPassed
            ? 'bg-gradient-to-br from-[#D4AF37]/15 to-[#0A0A0A]/80 border-[#D4AF37]/50 shadow-[0_0_60px_rgba(212,175,55,0.2)]'
            : 'bg-[#0A0A0A]/60 border-white/5'
        }`}
        whileHover={{ scale: 1.02, borderColor: 'rgba(212,175,55,0.6)' }}
      >
        {/* Glow effect when active */}
        <AnimatePresence>
          {(isActive || isPassed) && (
            <motion.div
              className="absolute inset-0 rounded-3xl"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              style={{
                background: 'radial-gradient(ellipse at center, rgba(212,175,55,0.1) 0%, transparent 70%)',
              }}
            />
          )}
        </AnimatePresence>

        <div className="relative z-10 flex items-start gap-6">
          {/* Animated Icon Container */}
          <motion.div
            className={`relative flex-shrink-0 w-20 h-20 rounded-2xl flex items-center justify-center overflow-hidden ${
              isActive || isPassed
                ? 'bg-gradient-to-br from-[#D4AF37] to-[#B8860B]'
                : 'bg-[#1A1A1A] border border-[#D4AF37]/20'
            }`}
            animate={isActive ? {
              boxShadow: [
                '0 0 20px rgba(212,175,55,0.3)',
                '0 0 40px rgba(212,175,55,0.5)',
                '0 0 20px rgba(212,175,55,0.3)'
              ]
            } : {}}
            transition={{ duration: 2, repeat: Infinity }}
          >
            {/* Particle burst on activation */}
            <AnimatePresence>
              {isActive && (
                <>
                  {[...Array(8)].map((_, i) => (
                    <motion.div
                      key={i}
                      className="absolute w-2 h-2 rounded-full bg-[#F7D878]"
                      initial={{ scale: 0, x: 0, y: 0 }}
                      animate={{
                        scale: [0, 1, 0],
                        x: Math.cos(i * 45 * Math.PI / 180) * 40,
                        y: Math.sin(i * 45 * Math.PI / 180) * 40,
                        opacity: [1, 0]
                      }}
                      transition={{ duration: 0.8, delay: i * 0.05 }}
                    />
                  ))}
                </>
              )}
            </AnimatePresence>
            
            <IconComponent className={`w-9 h-9 ${isActive || isPassed ? 'text-black' : 'text-[#D4AF37]'}`} />
          </motion.div>

          {/* Content */}
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <motion.span
                className={`text-sm font-mono tracking-wider ${
                  isActive || isPassed ? 'text-[#F7D878]' : 'text-[#D4AF37]/50'
                }`}
                animate={isActive ? { opacity: [0.5, 1, 0.5] } : {}}
                transition={{ duration: 2, repeat: Infinity }}
              >
                STEP {step.number}
              </motion.span>
              {isPassed && (
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="w-5 h-5 rounded-full bg-[#D4AF37] flex items-center justify-center"
                >
                  <svg className="w-3 h-3 text-black" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                  </svg>
                </motion.div>
              )}
            </div>
            
            <h3 className={`text-2xl font-light mb-3 transition-colors duration-500 ${
              isActive || isPassed ? 'text-white' : 'text-gray-400'
            }`}>
              {step.title}
            </h3>
            
            <p className={`text-sm leading-relaxed transition-colors duration-500 ${
              isActive || isPassed ? 'text-gray-300' : 'text-gray-600'
            }`}>
              {step.description}
            </p>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

// Main journey path line
const JourneyPath = ({ progress, totalSteps }) => {
  return (
    <div className="absolute left-1/2 top-0 bottom-0 w-1 -translate-x-1/2 hidden lg:block">
      {/* Background line */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#D4AF37]/10 via-[#D4AF37]/5 to-transparent rounded-full" />
      
      {/* Animated progress line */}
      <motion.div
        className="absolute top-0 left-0 right-0 bg-gradient-to-b from-[#F7D878] via-[#D4AF37] to-[#B8860B] rounded-full origin-top"
        style={{
          scaleY: progress,
          boxShadow: '0 0 20px rgba(212,175,55,0.5), 0 0 40px rgba(212,175,55,0.3)'
        }}
      />
      
      {/* Glowing orb at progress point */}
      <motion.div
        className="absolute left-1/2 -translate-x-1/2 w-6 h-6"
        style={{ top: `calc(${progress * 100}% - 12px)` }}
      >
        <motion.div
          className="w-full h-full rounded-full bg-[#F7D878]"
          animate={{
            scale: [1, 1.3, 1],
            boxShadow: [
              '0 0 20px rgba(247,216,120,0.5)',
              '0 0 40px rgba(247,216,120,0.8)',
              '0 0 20px rgba(247,216,120,0.5)'
            ]
          }}
          transition={{ duration: 1.5, repeat: Infinity }}
        />
        {/* Trailing particles */}
        {[...Array(5)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-2 h-2 rounded-full bg-[#D4AF37]"
            style={{
              left: '50%',
              top: '50%',
              marginLeft: -4,
              marginTop: -4
            }}
            animate={{
              y: [0, 30 + i * 10],
              opacity: [0.8, 0],
              scale: [1, 0.5]
            }}
            transition={{
              duration: 1,
              delay: i * 0.1,
              repeat: Infinity
            }}
          />
        ))}
      </motion.div>

      {/* Step markers */}
      {steps.map((_, index) => {
        const stepProgress = (index + 0.5) / totalSteps;
        const isReached = progress >= stepProgress;
        
        return (
          <motion.div
            key={index}
            className="absolute left-1/2 -translate-x-1/2 w-4 h-4"
            style={{ top: `calc(${stepProgress * 100}% - 8px)` }}
          >
            <motion.div
              className={`w-full h-full rounded-full border-2 transition-all duration-500 ${
                isReached 
                  ? 'bg-[#D4AF37] border-[#F7D878]' 
                  : 'bg-[#0A0A0A] border-[#D4AF37]/30'
              }`}
              animate={isReached ? {
                boxShadow: '0 0 15px rgba(212,175,55,0.6)'
              } : {}}
            />
          </motion.div>
        );
      })}
    </div>
  );
};

export default function HowItWorksAnimated() {
  const containerRef = useRef(null);
  const isInView = useInView(containerRef, { once: false, margin: "-10%" });
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  });
  
  const progress = useTransform(scrollYProgress, [0.1, 0.9], [0, 1]);
  const [currentProgress, setCurrentProgress] = useState(0);
  
  useEffect(() => {
    const unsubscribe = progress.on("change", (v) => setCurrentProgress(v));
    return () => unsubscribe();
  }, [progress]);
  
  const activeStep = Math.floor(currentProgress * steps.length);

  return (
    <section ref={containerRef} className="relative py-32 overflow-hidden bg-black">
      {/* Background effects */}
      <div className="absolute inset-0">
        {/* Gold mist */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(212,175,55,0.05)_0%,_transparent_60%)]" />
        
        {/* Grid pattern */}
        <div 
          className="absolute inset-0 opacity-[0.02]"
          style={{
            backgroundImage: `
              linear-gradient(rgba(212,175,55,0.3) 1px, transparent 1px),
              linear-gradient(90deg, rgba(212,175,55,0.3) 1px, transparent 1px)
            `,
            backgroundSize: '60px 60px'
          }}
        />
      </div>

      {/* Floating particles */}
      <GoldParticles active={isInView} />

      <div className="relative z-10 max-w-6xl mx-auto px-6">
        {/* Header */}
        <motion.div
          className="text-center mb-20"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <motion.div
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-[#D4AF37]/30 bg-[#D4AF37]/5 mb-6"
            animate={{ borderColor: ['rgba(212,175,55,0.3)', 'rgba(212,175,55,0.6)', 'rgba(212,175,55,0.3)'] }}
            transition={{ duration: 3, repeat: Infinity }}
          >
            <Sparkles className="w-4 h-4 text-[#D4AF37]" />
            <span className="text-sm text-[#D4AF37] tracking-wider">YOUR JOURNEY</span>
          </motion.div>
          
          <h2 className="text-5xl md:text-6xl font-extralight text-white mb-6">
            How It{' '}
            <span className="bg-gradient-to-r from-[#F7D878] via-[#D4AF37] to-[#B8860B] bg-clip-text text-transparent">
              Works
            </span>
          </h2>
          
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            A seamless journey from account creation to gold-backed financial freedom
          </p>
        </motion.div>

        {/* Journey content */}
        <div className="relative">
          {/* Journey path line */}
          <JourneyPath progress={currentProgress} totalSteps={steps.length} />

          {/* Steps grid */}
          <div className="space-y-8 lg:space-y-12">
            {steps.map((step, index) => {
              const stepProgress = (index + 0.5) / steps.length;
              const isActive = Math.abs(currentProgress - stepProgress) < 0.08;
              const isPassed = currentProgress > stepProgress + 0.05;
              
              return (
                <div
                  key={index}
                  className={`lg:w-[45%] ${index % 2 === 0 ? 'lg:mr-auto lg:pr-12' : 'lg:ml-auto lg:pl-12'}`}
                >
                  <StepCard
                    step={step}
                    index={index}
                    isActive={isActive}
                    isPassed={isPassed}
                  />
                </div>
              );
            })}
          </div>
        </div>

        {/* Progress indicator */}
        <motion.div
          className="mt-16 flex justify-center"
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
        >
          <div className="flex items-center gap-2">
            {steps.map((_, index) => {
              const stepProgress = (index + 0.5) / steps.length;
              const isReached = currentProgress >= stepProgress;
              
              return (
                <motion.div
                  key={index}
                  className={`w-2 h-2 rounded-full transition-all duration-300 ${
                    isReached ? 'bg-[#D4AF37]' : 'bg-[#D4AF37]/20'
                  }`}
                  animate={isReached ? { scale: [1, 1.3, 1] } : {}}
                  transition={{ duration: 0.5 }}
                />
              );
            })}
          </div>
        </motion.div>
      </div>
    </section>
  );
}