import React from 'react';
import { Eye, User, Zap, Building, Shield } from 'lucide-react';
import SectionTitle from '../ui/SectionTitle';
import GoldCard from '../ui/GoldCard';

const principles = [
  {
    icon: Eye,
    title: "Full Asset Transparency",
    description: "Every gram of gold is stored in regulated vaults with complete audit trails."
  },
  {
    icon: User,
    title: "User Ownership",
    description: "Gold belongs fully to the user, with certified proof of ownership."
  },
  {
    icon: Zap,
    title: "Instant Access",
    description: "Your gold value is reflected immediately in your dashboard."
  },
  {
    icon: Building,
    title: "No Banking Dependencies",
    description: "Independent digital financial infrastructure for true autonomy."
  },
  {
    icon: Shield,
    title: "Swiss Governance",
    description: "Operated under Finatrades Finance SA, Geneva."
  }
];

export default function PrinciplesSection() {
  return (
    <section className="relative py-32 bg-[#0A0A0A]">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(212,175,55,0.05)_0%,_transparent_70%)]" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <SectionTitle 
          title="Trusted Gold Meets Modern Technology"
          subtitle="Finatrades connects institutional-grade vaulting, precise gold records, and secure digital services to create a financial ecosystem based on real, verifiable assets."
        />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {principles.map((principle, i) => (
            <GoldCard key={i} className="group">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-gradient-to-br from-[#D4AF37]/20 to-[#B8860B]/10 flex items-center justify-center group-hover:from-[#D4AF37]/30 group-hover:to-[#B8860B]/20 transition-all duration-500">
                  <principle.icon className="w-5 h-5 text-[#D4AF37]" />
                </div>
                <div>
                  <h3 className="text-xl font-light text-white mb-2">{principle.title}</h3>
                  <p className="text-gray-400 leading-relaxed">{principle.description}</p>
                </div>
              </div>
            </GoldCard>
          ))}
        </div>
      </div>
    </section>
  );
}