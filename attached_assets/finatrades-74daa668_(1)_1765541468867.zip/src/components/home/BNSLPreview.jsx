import React, { useRef } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion, useInView } from 'framer-motion';
import { Lock, TrendingUp, Calendar, ArrowRight } from 'lucide-react';
import { useLanguage } from '@/components/LanguageContext';

const plans = [
  { duration: '12 Months', subtitle: 'Locking Period', rate: '~10%', returns: 'Guaranteed margin on buy back', color: '#8A2BE2' },
  { duration: '24 Months', subtitle: 'Locking Period', rate: '~11%', returns: 'Guaranteed margin on buy back', color: '#FF66D8', featured: true },
  { duration: '36 Months', subtitle: 'Locking Period', rate: '~12%', returns: 'Guaranteed margin on buy back', color: '#FF2FBF' }
];

export default function BNSLPreview() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const { t } = useLanguage();

  return (
    <section ref={ref} className="relative py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-[#FAFBFF] to-white" />
      
      {/* Ambient glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[radial-gradient(ellipse_at_center,_rgba(138,43,226,0.08)_0%,_transparent_60%)]" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 1 }}
          className="text-center mb-16"
        >
          <p className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent text-sm tracking-[0.3em] uppercase mb-4">{t('bnslPreview.badge')}</p>
          <h2 className="text-4xl md:text-5xl font-bold text-[#0D0D0D] mb-4">
            {t('bnslPreview.title')}
          </h2>
          <p className="text-xl text-[#4A4A4A]">{t('bnslPreview.subtitle')}</p>
          <div className="w-24 h-0.5 bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] mx-auto mt-6" />
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {plans.map((plan, i) => (
            <Link 
              key={i}
              to={createPageUrl("BNSL")}
              onClick={() => window.scrollTo(0, 0)}
            >
              <motion.div
                className={`relative group ${plan.featured ? 'md:-mt-4 md:mb-4' : ''}`}
                initial={{ opacity: 0, y: 50 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.8, delay: i * 0.2 }}
              >
              {/* Featured badge */}
              {plan.featured && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] rounded-full text-white text-xs font-medium z-10 shadow-[0_4px_20px_rgba(255,45,200,0.35)]">
                  {t('bnslPreview.mostPopular')}
                </div>
              )}
              
              <div className={`relative bg-white rounded-[20px] border ${
                plan.featured ? 'border-[#8A2BE2]/50' : 'border-[#E8E0F0]'
              } p-8 overflow-hidden group-hover:border-[#8A2BE2]/60 transition-all shadow-[0_8px_32px_rgba(160,50,255,0.08)] group-hover:shadow-[0_12px_48px_rgba(160,50,255,0.18)] cursor-pointer`}>
                {/* Background glow */}
                <div className="absolute inset-0 bg-gradient-to-br from-[#8A2BE2]/5 to-[#FF2FBF]/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                
                {/* Duration */}
                <div className="relative text-center mb-6">
                  <div className="flex items-center justify-center gap-2">
                    <Calendar className="w-5 h-5 text-[#8A2BE2]" />
                    <span className="text-3xl font-light text-[#0D0D0D]">{plan.duration}</span>
                  </div>
                  <div className="text-sm text-[#4A4A4A] mt-1">{plan.subtitle}</div>
                </div>
                
                {/* Rate counter */}
                <div className="relative text-center mb-6">
                  <motion.div
                    className="text-5xl font-light bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent"
                    initial={{ opacity: 0, scale: 0.5 }}
                    animate={isInView ? { opacity: 1, scale: 1 } : {}}
                    transition={{ delay: 0.5 + i * 0.2 }}
                  >
                    {plan.rate}
                  </motion.div>

                </div>
                
                {/* Returns */}
                <div className="relative flex items-center justify-center gap-2 text-green-500 mb-6">
                  <TrendingUp className="w-4 h-4" />
                  <span className="text-sm text-center">{plan.returns}</span>
                </div>
                
                {/* View Details Button */}
                <div className="relative flex items-center justify-center gap-2 text-[#8A2BE2] opacity-0 group-hover:opacity-100 transition-opacity">
                  <span className="text-sm font-medium">View Details</span>
                  <ArrowRight className="w-4 h-4" />
                </div>

                
                {/* Particles */}
                {[...Array(5)].map((_, j) => (
                  <motion.div
                    key={j}
                    className="absolute w-1 h-1 rounded-full"
                    style={{ 
                      left: `${20 + j * 15}%`, 
                      bottom: '20%',
                      background: j % 2 === 0 ? '#8A2BE2' : '#FF2FBF'
                    }}
                    animate={{
                      y: [-10, -30, -10],
                      opacity: [0.3, 1, 0.3]
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      delay: j * 0.3
                    }}
                  />
                ))}
              </div>
              </motion.div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}