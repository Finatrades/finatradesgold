import React, { useState, useEffect, useRef } from 'react';
import { motion, useInView, AnimatePresence } from 'framer-motion';
import { 
  UserPlus, ShieldCheck, Coins, Vault, LayoutDashboard, Clock,
  Building2, FileCheck, Users, Warehouse, Award, Globe, FileText,
  ArrowRight
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { useAccountType } from '@/components/AccountTypeContext';

// Personal steps
const personalSteps = [
  {
    number: "01",
    icon: UserPlus,
    title: "Create Your Account",
    description: "Register as an Individual and start your personal gold account."
  },
  {
    number: "02",
    icon: ShieldCheck,
    title: "Verify Your Identity",
    description: "Complete Swiss-aligned KYC verification securely."
  },
  {
    number: "03",
    icon: Coins,
    title: "Deposit or Buy Gold",
    description: "Deposit physical gold via partners or buy new gold on-platform (where available)."
  },
  {
    number: "04",
    icon: Vault,
    title: "Secure Vault Storage",
    description: "Your gold is stored in approved, regulated vaults with full documentation."
  },
  {
    number: "05",
    icon: LayoutDashboard,
    title: "Track Your Gold 24/7",
    description: "See grams, estimated value, and certificates in real time."
  },
  {
    number: "06",
    icon: Clock,
    title: "Optional: Join Holding Plans",
    description: "Lock gold into structured holding plans for defined durations."
  }
];

// Business steps
const businessSteps = [
  {
    number: "01",
    icon: Building2,
    title: "Register Corporate Profile",
    description: "Submit company details, authorized signatories, and compliance documents."
  },
  {
    number: "02",
    icon: FileCheck,
    title: "KYB & Compliance Review",
    description: "Finatrades performs a Swiss-aligned corporate verification process."
  },
  {
    number: "03",
    icon: Users,
    title: "Establish Gold Reserve Account",
    description: "Set user roles, permissions, and operational limits for your organization."
  },
  {
    number: "04",
    icon: Warehouse,
    title: "Buy / Deposit Physical Gold",
    description: "Deposit existing bars through verified channels into accredited vaults."
  },
  {
    number: "05",
    icon: Award,
    title: "Receive Holding Certificates",
    description: "Each deposit generates standardized holding documentation."
  },
  {
    number: "06",
    icon: Globe,
    title: "Use Gold for Trade & Treasury",
    description: "Integrate gold value into trade flows, settlements, or collateral structures."
  },
  {
    number: "07",
    icon: FileText,
    title: "Reporting & Audit Controls",
    description: "Access detailed reports for accounting, governance, and external audits."
  }
];

// Floating particles along the path
function PathParticles({ isActive, isBusiness }) {
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden">
      {[...Array(20)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-1 h-1 rounded-full"
          style={{
            background: isBusiness 
              ? 'radial-gradient(circle, #FF2FBF 0%, #A54CFF 100%)'
              : 'radial-gradient(circle, #FF66D8 0%, #8A2BE2 100%)',
            left: `${10 + Math.random() * 80}%`,
            top: `${10 + Math.random() * 80}%`,
          }}
          animate={isActive ? {
            y: [0, -30, 0],
            x: [0, 10, 0],
            opacity: [0, 0.8, 0],
            scale: [0.5, 1.2, 0.5]
          } : { opacity: 0 }}
          transition={{
            duration: 3 + Math.random() * 2,
            delay: i * 0.2,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      ))}
    </div>
  );
}

// Step node component
function StepNode({ step, index, isActive, isPassed, isBusiness, totalSteps }) {
  const Icon = step.icon;
  const isLeft = index % 2 === 0;
  
  return (
    <motion.div
      className={`relative flex items-center gap-6 ${isLeft ? 'flex-row' : 'flex-row-reverse'}`}
      initial={{ opacity: 0, x: isLeft ? -50 : 50 }}
      animate={{ 
        opacity: isActive || isPassed ? 1 : 0.3,
        x: 0 
      }}
      transition={{ duration: 0.4, delay: index * 0.05 }}
    >
      {/* Node circle */}
      <div className="relative flex-shrink-0">
        {/* Outer glow ring */}
        <motion.div
          className="absolute -inset-4 rounded-full"
          animate={{
            boxShadow: isActive 
              ? '0 0 40px rgba(138,43,226,0.5), 0 0 60px rgba(255,47,191,0.2)'
              : '0 0 0px rgba(138,43,226,0)'
          }}
          transition={{ duration: 2, repeat: Infinity }}
        />
        
        {/* Pulse rings */}
        {isActive && (
          <>
            <motion.div
              className="absolute -inset-2 rounded-full border border-[#8A2BE2]/50"
              animate={{ scale: [1, 1.5, 1], opacity: [0.5, 0, 0.5] }}
              transition={{ duration: 2, repeat: Infinity }}
            />
            <motion.div
              className="absolute -inset-4 rounded-full border border-[#FF2FBF]/30"
              animate={{ scale: [1, 1.8, 1], opacity: [0.3, 0, 0.3] }}
              transition={{ duration: 2, repeat: Infinity, delay: 0.3 }}
            />
          </>
        )}
        
        {/* Main node */}
        <motion.div
          className={`relative w-16 h-16 rounded-full flex items-center justify-center ${
            isBusiness ? 'rounded-xl' : 'rounded-full'
          }`}
          style={{
            background: isActive || isPassed
              ? 'linear-gradient(135deg, #8A2BE2 0%, #FF2FBF 100%)'
              : '#FFFFFF',
            border: isActive || isPassed ? '2px solid #FF66D8' : '2px solid #E8E0F0',
            boxShadow: isActive || isPassed ? '0 8px 32px rgba(160,50,255,0.25)' : '0 4px 16px rgba(0,0,0,0.05)'
          }}
          animate={{ scale: isActive ? 1.1 : 1 }}
          transition={{ duration: 1.5, repeat: Infinity }}
        >
          <Icon 
            className={`w-7 h-7 ${isActive || isPassed ? 'text-white' : 'text-[#8A2BE2]'}`} 
            strokeWidth={1.5} 
          />
          
          {/* LED indicator for business */}
          {isBusiness && (
            <motion.div
              className="absolute -top-1 -right-1 w-3 h-3 rounded-full"
              style={{
                background: isActive ? '#22C55E' : isPassed ? 'linear-gradient(135deg, #8A2BE2, #FF2FBF)' : '#E8E0F0',
                boxShadow: isActive ? '0 0 10px #22C55E' : 'none'
              }}
              animate={{ opacity: isActive ? [1, 0.5, 1] : 1 }}
              transition={{ duration: 1, repeat: Infinity }}
            />
          )}
        </motion.div>
        
        {/* Step number */}
        <motion.div
          className="absolute -bottom-2 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded-full bg-white border border-[#8A2BE2]/30 shadow-sm"
          animate={{ borderColor: isActive ? '#8A2BE2' : 'rgba(138,43,226,0.3)' }}
        >
          <span className="text-[10px] bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent font-medium">{step.number}</span>
        </motion.div>
      </div>
      
      {/* Content card */}
      <motion.div
        className={`relative max-w-sm ${isBusiness ? 'rounded-xl' : 'rounded-2xl'} overflow-hidden`}
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ 
          opacity: isActive || isPassed ? 1 : 0.5,
          scale: isActive ? 1.02 : 1
        }}
        transition={{ duration: 0.3 }}
      >
        {/* Card background */}
        <div className="absolute inset-0 bg-white/90 backdrop-blur-xl" />
        
        {/* Neon border glow */}
        <motion.div
          className={`absolute inset-0 ${isBusiness ? 'rounded-xl' : 'rounded-2xl'}`}
          style={{
            border: isActive ? '1px solid #8A2BE2' : '1px solid rgba(138,43,226,0.2)',
            boxShadow: isActive ? '0 0 20px rgba(138,43,226,0.2), inset 0 0 20px rgba(255,47,191,0.05)' : '0 4px 16px rgba(0,0,0,0.05)'
          }}
        />
        
        {/* Content */}
        <div className="relative p-5">
          <h3 className={`text-lg font-light mb-2 ${isActive ? 'bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent' : 'text-[#0D0D0D]'}`}>
            {step.title}
          </h3>
          <p className="text-sm text-[#4A4A4A] leading-relaxed">
            {step.description}
          </p>
        </div>
        
        {/* Bottom accent line */}
        <motion.div
          className="absolute bottom-0 left-0 h-0.5 bg-gradient-to-r from-[#8A2BE2] via-[#FF66D8] to-[#FF2FBF]"
          initial={{ width: '0%' }}
          animate={{ width: isActive || isPassed ? '100%' : '0%' }}
          transition={{ duration: 0.4 }}
        />
      </motion.div>
    </motion.div>
  );
}

// Snake path SVG
function SnakePath({ steps, activeStep, isBusiness }) {
  const pathRef = useRef(null);
  const [pathLength, setPathLength] = useState(0);
  
  useEffect(() => {
    if (pathRef.current) {
      setPathLength(pathRef.current.getTotalLength());
    }
  }, [steps.length]);
  
  // Generate snake path points
  const generatePath = () => {
    const points = [];
    const stepHeight = 140;
    const curveWidth = 100;
    
    steps.forEach((_, i) => {
      const y = i * stepHeight;
      const isLeft = i % 2 === 0;
      const x = isLeft ? 50 : 250;
      
      if (i === 0) {
        points.push(`M ${x} ${y}`);
      } else {
        const prevX = (i - 1) % 2 === 0 ? 50 : 250;
        const midY = y - stepHeight / 2;
        
        // Create smooth curve
        points.push(`C ${prevX} ${midY}, ${x} ${midY}, ${x} ${y}`);
      }
    });
    
    return points.join(' ');
  };
  
  const progress = (activeStep + 1) / steps.length;
  
  return (
    <svg
      className="absolute left-1/2 -translate-x-1/2 top-0 h-full pointer-events-none"
      width="300"
      style={{ height: steps.length * 140 }}
    >
      <defs>
        <linearGradient id="snakeGradient" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#8A2BE2" />
          <stop offset="50%" stopColor="#FF66D8" />
          <stop offset="100%" stopColor="#FF2FBF" />
        </linearGradient>
        <filter id="glow">
          <feGaussianBlur stdDeviation="3" result="coloredBlur" />
          <feMerge>
            <feMergeNode in="coloredBlur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>
      
      {/* Background path */}
      <path
        d={generatePath()}
        fill="none"
        stroke="#E8E0F0"
        strokeWidth={isBusiness ? "2" : "3"}
        strokeLinecap="round"
        strokeDasharray={isBusiness ? "8 8" : "none"}
      />
      
      {/* Animated path */}
      <motion.path
        ref={pathRef}
        d={generatePath()}
        fill="none"
        stroke="url(#snakeGradient)"
        strokeWidth={isBusiness ? "2" : "3"}
        strokeLinecap="round"
        filter="url(#glow)"
        initial={{ pathLength: 0 }}
        animate={{ pathLength: progress }}
        transition={{ duration: 0.5, ease: "easeOut" }}
      />
      
      {/* Moving dot - simplified without offsetPath */}
      <circle
        r="6"
        fill="#FF66D8"
        filter="url(#glow)"
        cx={activeStep % 2 === 0 ? 50 : 250}
        cy={activeStep * 140}
      />
    </svg>
  );
}

export default function HowItWorksSnake({ mode: propMode }) {
  const [activeStep, setActiveStep] = useState(0);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });
  const { accountType: contextAccountType } = useAccountType();
  
  const mode = contextAccountType || propMode || 'personal';
  const isBusiness = mode === 'business';
  const steps = isBusiness ? businessSteps : personalSteps;
  
  // Auto-advance steps
  useEffect(() => {
    if (!isInView) return;
    
    const interval = setInterval(() => {
      setActiveStep(prev => (prev + 1) % steps.length);
    }, 1500);
    
    return () => clearInterval(interval);
  }, [isInView, steps.length]);
  
  return (
    <section 
      ref={ref}
      className="relative py-24 overflow-hidden bg-gradient-to-b from-[#FAFBFF] to-white"
    >
      {/* Background effects */}
      <div className="absolute inset-0">
        <div className={`absolute inset-0 ${
          isBusiness 
            ? 'bg-[radial-gradient(ellipse_at_center,_rgba(255,47,191,0.06)_0%,_transparent_60%)]'
            : 'bg-[radial-gradient(ellipse_at_center,_rgba(138,43,226,0.06)_0%,_transparent_60%)]'
        }`} />
        
        {/* Grid pattern for business */}
        {isBusiness && (
          <div className="absolute inset-0 opacity-10">
            <svg className="w-full h-full">
              <defs>
                <pattern id="businessGrid" width="40" height="40" patternUnits="userSpaceOnUse">
                  <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#8A2BE2" strokeWidth="0.5" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#businessGrid)" />
            </svg>
          </div>
        )}
      </div>
      
      <PathParticles isActive={isInView} isBusiness={isBusiness} />
      
      <div className="relative z-10 max-w-5xl mx-auto px-6">
        {/* Header */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: isInView ? 1 : 0, y: isInView ? 0 : 30 }}
          transition={{ duration: 0.4 }}
        >
          <motion.div
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-[#8A2BE2]/10 to-[#FF2FBF]/10 border border-[#8A2BE2]/30 mb-6"
            animate={{ borderColor: ['rgba(138,43,226,0.3)', 'rgba(255,47,191,0.6)', 'rgba(138,43,226,0.3)'] }}
            transition={{ duration: 3, repeat: Infinity }}
          >
            <span className="text-xs bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent tracking-wider uppercase">
              {isBusiness ? 'Enterprise Workflow' : 'Your Journey'}
            </span>
          </motion.div>
          
          <h2 className="text-4xl md:text-5xl font-bold text-[#0D0D0D] mb-4">
            How It <span className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent">Works</span>
          </h2>
          <p className="text-[#4A4A4A] max-w-xl mx-auto">
            {isBusiness 
              ? 'A structured, compliant pathway for corporate gold management.'
              : 'A simple journey from registration to gold-backed wealth management.'}
          </p>
          
          {/* Progress indicator */}
          <div className="flex items-center justify-center gap-2 mt-8">
            {steps.map((_, i) => (
              <motion.div
                key={i}
                className="h-1 rounded-full cursor-pointer"
                style={{
                  width: i === activeStep ? 32 : 8,
                  background: i <= activeStep 
                    ? 'linear-gradient(90deg, #8A2BE2, #FF2FBF)' 
                    : '#E8E0F0'
                }}
                animate={{ width: i === activeStep ? 32 : 8 }}
                transition={{ duration: 0.3 }}
                onClick={() => setActiveStep(i)}
              />
            ))}
          </div>
        </motion.div>
        
        {/* Steps container */}
        <div className="relative" style={{ minHeight: steps.length * 140 }}>
          {/* Snake path - hidden on mobile */}
          <div className="hidden md:block">
            <SnakePath steps={steps} activeStep={activeStep} isBusiness={isBusiness} />
          </div>
          
          {/* Step nodes */}
          <div className="space-y-8 md:space-y-12">
            {steps.map((step, i) => (
              <StepNode
                key={i}
                step={step}
                index={i}
                isActive={i === activeStep}
                isPassed={i < activeStep}
                isBusiness={isBusiness}
                totalSteps={steps.length}
              />
            ))}
          </div>
        </div>
        
        {/* CTA */}
        <motion.div
          className="text-center mt-16"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: isInView ? 1 : 0, y: isInView ? 0 : 20 }}
          transition={{ duration: 0.8, delay: 0.5 }}
        >
          {/* Final glow effect */}
          <motion.div
            className="inline-block relative"
            animate={{
              boxShadow: [
                '0 0 30px rgba(138,43,226,0.2)',
                '0 0 60px rgba(255,45,200,0.3)',
                '0 0 30px rgba(138,43,226,0.2)'
              ]
            }}
            transition={{ duration: 3, repeat: Infinity }}
          >
            <Link
              to={createPageUrl(isBusiness ? "FinaBridge" : "Contact")}
              className="group inline-flex items-center gap-3 px-8 py-4 rounded-full bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] text-white font-medium hover:shadow-[0_0_40px_rgba(255,45,200,0.35)] hover:from-[#A342FF] hover:to-[#FF4CD6] transition-all"
            >
              {isBusiness ? 'Explore Business Platform' : "Let's Start"}
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Link>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}