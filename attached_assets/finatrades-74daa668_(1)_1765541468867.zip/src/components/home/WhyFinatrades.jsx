import React, { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { Shield, Zap, Gem, Building, Globe, Monitor } from 'lucide-react';
import { useLanguage } from '@/components/LanguageContext';

const getFeatures = (t) => [
  { icon: Shield, label: t('whyFinatrades.feature1.label'), desc: t('whyFinatrades.feature1.desc') },
  { icon: Zap, label: t('whyFinatrades.feature2.label'), desc: t('whyFinatrades.feature2.desc') },
  { icon: Gem, label: t('whyFinatrades.feature3.label'), desc: t('whyFinatrades.feature3.desc') },
  { icon: Building, label: t('whyFinatrades.feature4.label'), desc: t('whyFinatrades.feature4.desc') },
  { icon: Globe, label: t('whyFinatrades.feature5.label'), desc: t('whyFinatrades.feature5.desc') },
  { icon: Monitor, label: t('whyFinatrades.feature6.label'), desc: t('whyFinatrades.feature6.desc') }
];

export default function WhyFinatrades() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const { t } = useLanguage();
  const features = getFeatures(t);

  return (
    <section ref={ref} className="relative py-32 overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom,_rgba(138,43,226,0.08)_0%,_transparent_50%)]" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 1 }}
          className="text-center mb-16"
        >
          <p className="bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] bg-clip-text text-transparent text-sm tracking-[0.3em] uppercase mb-4">{t('whyFinatrades.badge')}</p>
          <h2 className="text-4xl md:text-5xl font-bold text-[#0D0D0D] mb-4">
            {t('whyFinatrades.title')}
          </h2>
          <div className="w-24 h-0.5 bg-gradient-to-r from-[#8A2BE2] to-[#FF2FBF] mx-auto" />
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, i) => (
            <motion.div
              key={i}
              className="relative group"
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: i * 0.1 }}
            >
              <div className="relative bg-white rounded-[20px] border border-[#E8E0F0] p-8 group-hover:border-[#8A2BE2]/40 transition-all duration-500 overflow-hidden shadow-[0_8px_32px_rgba(160,50,255,0.08)] group-hover:shadow-[0_12px_48px_rgba(160,50,255,0.18)]">
                {/* Glow effect */}
                <motion.div
                  className="absolute inset-0 bg-gradient-to-br from-[#8A2BE2]/10 to-[#FF2FBF]/10 opacity-0 group-hover:opacity-100 transition-opacity"
                />
                
                {/* Icon with halo */}
                <div className="relative mb-6">
                  <motion.div
                    className="absolute inset-0 rounded-full bg-gradient-to-r from-[#8A2BE2]/20 to-[#FF2FBF]/20 blur-xl"
                    initial={{ scale: 0 }}
                    whileHover={{ scale: 1.5 }}
                    transition={{ duration: 0.3 }}
                  />
                  <div className="relative w-14 h-14 rounded-xl bg-gradient-to-br from-[#8A2BE2] to-[#FF2FBF] p-[1px] group-hover:scale-110 transition-transform">
                    <div className="w-full h-full rounded-xl bg-white flex items-center justify-center">
                      <feature.icon className="w-7 h-7 text-[#8A2BE2]" strokeWidth={1.5} />
                    </div>
                  </div>
                </div>
                
                <h3 className="relative text-lg font-light text-[#0D0D0D] mb-2">{feature.label}</h3>
                <p className="relative text-[#4A4A4A] text-sm">{feature.desc}</p>
                
                {/* Decorative corner */}
                <div className="absolute top-0 right-0 w-16 h-16 overflow-hidden">
                  <div className="absolute -top-8 -right-8 w-16 h-16 bg-gradient-to-br from-[#8A2BE2]/10 to-[#FF2FBF]/10 rotate-45" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}